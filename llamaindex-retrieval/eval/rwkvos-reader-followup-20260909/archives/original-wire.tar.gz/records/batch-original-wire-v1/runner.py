import asyncio
import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shlex
import sys
import time
import httpx

OUT = Path(__file__).resolve().parent
sys.path.insert(0, '/home/chase/GitHub/rwkvrag-bm-29b-20260908/source-publication-v1/src')
from llamaindex_retrieval.rwkvos_batch import RwkvosBatchClient


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, data):
    with (OUT / name).open('x') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())


async def main():
    jobs = json.loads((OUT / 'requests.json').read_text())
    save('STARTED.json', {'at': datetime.now(timezone.utc).isoformat(), 'requests_sha256': sha((OUT / 'requests.json').read_bytes()), 'plan_sha256': sha((OUT / 'PLAN.json').read_bytes()), 'runner_sha256': sha(Path(__file__).read_bytes())})
    parts = shlex.split(Path('/mnt/c/Users/chase/.codex/attachments/5a056a59-9300-4f5d-aace-62d0a1fb046e/pasted-text.txt').read_text().replace('\\\n', ''))
    headers = {'Content-Type': 'application/json'}
    for i, part in enumerate(parts):
        if part in ('--header', '-H'):
            key, value = parts[i + 1].split(':', 1)
            if key.lower().startswith('cf-access-'):
                headers[key] = value.strip()
    results = []
    async with httpx.AsyncClient(timeout=600, trust_env=False, follow_redirects=False) as client:
        for job in jobs:
            raw = base64.b64decode(job['request_body_base64'])
            assert sha(raw) == job['request_body_sha256'] and json.loads(raw) == job['payload']
            request = client.build_request('POST', 'https://api-3b.rwkvos.com/v1/batch/completions', headers=headers, content=raw)
            assert request.content == raw
            record = {'id': job['id'], 'request_body_base64': job['request_body_base64'], 'request_body_sha256': sha(raw), 'http_attempted': False, 'at': datetime.now(timezone.utc).isoformat()}
            save(job['id'] + '.started.json', record)
            start = time.perf_counter()
            try:
                record['http_attempted'] = True
                response = await client.send(request)
                record.update(http_status=response.status_code, response_body_base64=base64.b64encode(response.content).decode(), response_body_sha256=sha(response.content))
                response.raise_for_status()
                data = json.loads(response.content)
                choices = RwkvosBatchClient._choices(data, 8, job['payload']['model'])
                old = RwkvosBatchClient._choices(job['historical_response'], 8, job['payload']['model'])
                recent_record = json.loads(Path(job['previous_current_file']).read_text())
                recent = RwkvosBatchClient._choices(recent_record['response_json'], 8, job['payload']['model'])
                comparisons = [{'index': i, 'same_as_history': a['message']['content'] == b['message']['content'], 'same_as_current_parity': a['message']['content'] == c['message']['content']} for i, (a, b, c) in enumerate(zip(choices, old, recent, strict=True))]
                record.update(status='completed', response_json=data, comparisons=comparisons, termination_verified=False)
            except Exception as error:
                record.update(status='failed', error_type=type(error).__name__)
            record['elapsed_ms'] = (time.perf_counter() - start) * 1000
            save(job['id'] + '.completed.json', record)
            results.append({'id': job['id'], 'status': record['status'], 'comparisons': record.get('comparisons')})
            print(json.dumps(results[-1]), flush=True)
            if record['status'] != 'completed':
                break
    save('COMPLETED.json', {'at': datetime.now(timezone.utc).isoformat(), 'results': results, 'automatic_retries': 0, 'semantic_quality_scored': False})


asyncio.run(main())
