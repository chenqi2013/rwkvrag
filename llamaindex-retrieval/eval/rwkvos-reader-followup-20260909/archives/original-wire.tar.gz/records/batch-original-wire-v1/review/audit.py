#!/usr/bin/env python3
"""Independent offline verification of exact historical HTTP-body replay."""
import ast
import base64
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re


OUT = Path(__file__).resolve().parent
RUN = OUT.parent
N = RUN.parent
B = N.parent / "rwkvrag-bm-29b-20260908"
PINS = {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    data = path.read_bytes()
    PINS[str(path)] = {"bytes": len(data), "sha256": sha(data)}
    return data


def load(path):
    return json.loads(read(path))


def save(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write("\n")


def wire(record, kind):
    data = base64.b64decode(record[kind + "_body_base64"], validate=True)
    assert sha(data) == record[kind + "_body_sha256"]
    obj = json.loads(data)
    key = "response_json" if kind == "response" else "payload"
    if key in record:
        assert obj == record[key]
    return data, obj


def choices(value, model):
    assert value["model"] == model and value["object"] == "chat.completion"
    assert "error" not in value and len(value["choices"]) == 8
    indexed = {}
    for choice in value["choices"]:
        index = choice["index"]
        assert type(index) is int and 0 <= index < 8 and index not in indexed
        assert choice["message"]["role"] == "assistant"
        assert isinstance(choice["message"]["content"], str) and "error" not in choice
        assert choice["finish_reason"] in {"stop", "length"}
        choice["message"]["content"].encode("utf-8")
        indexed[index] = choice
    assert set(indexed) == set(range(8))
    return indexed


def reader_syntax(text, unit_count):
    stripped = text.strip()
    if stripped == "NONE":
        return {"kind": "NONE", "selected_units": []}
    if re.fullmatch(r"E[1-9][0-9]*(?:\s*[,;，；]\s*E[1-9][0-9]*)*", stripped):
        ids = list(dict.fromkeys(int(x) for x in re.findall(r"E([1-9][0-9]*)", stripped)))
        if all(x <= unit_count for x in ids):
            return {"kind": "unit_ids", "selected_units": ids}
    return {"kind": "invalid_selection", "selected_units": None}


def difference(left, right, left_syntax, right_syntax):
    if left == right:
        return "identical"
    if left.strip() == right.strip():
        return "boundary_whitespace_only"
    if "".join(left.split()) == "".join(right.split()):
        return "whitespace_only"
    if left_syntax and right_syntax:
        if (left_syntax["kind"] == right_syntax["kind"] != "invalid_selection"
                and left_syntax["selected_units"] == right_syntax["selected_units"]):
            return "format_only_same_selection"
        if left_syntax["kind"] != right_syntax["kind"]:
            return "format_and_content"
    return "non_whitespace_content"


def main():
    jobs = load(RUN / "requests.json")
    plan, start, complete = [load(RUN / name) for name in ("PLAN.json", "STARTED.json", "COMPLETED.json")]
    runner = read(RUN / "runner.py")
    assert start["requests_sha256"] == sha(read(RUN / "requests.json"))
    assert start["plan_sha256"] == sha(read(RUN / "PLAN.json"))
    assert start["runner_sha256"] == sha(runner)
    assert plan["generation_http"] == 2 and plan["model_items"] == 16
    assert complete["automatic_retries"] == 0 and len(complete["results"]) == 2
    calls = [node for node in ast.walk(ast.parse(runner)) if isinstance(node, ast.Call)
             and isinstance(node.func, ast.Attribute) and node.func.attr == "build_request"]
    assert len(calls) == 1
    keywords = {item.arg: item.value for item in calls[0].keywords}
    assert "json" not in keywords and isinstance(keywords["content"], ast.Name)
    assert keywords["content"].id == "raw"
    cases = {row["id"]: row for row in load(N / "batch-parity-v1/cases.json")}
    groups, rows = [], []
    for job in jobs:
        name = job["id"]
        case = cases[name]
        old_base = B / "wiki-api-v1-eos/batch-http" / case["original_batch_id"]
        old_start = load(Path(str(old_base) + ".batch_started.json"))
        old = load(Path(str(old_base) + ".batch_completed.json"))
        begun = load(RUN / (name + ".started.json"))
        replay = load(RUN / (name + ".completed.json"))
        a_path = N / "batch-parity-v1/http" / (name + "-batch-before.completed.json")
        assert Path(job["previous_current_file"]) == a_path
        parity = load(a_path)
        parity_start = load(a_path.with_name(a_path.name.replace(".completed.", ".started.")))
        bodies = [wire(record, "request")[0] for record in (job, begun, replay, old_start, old)]
        assert all(data == bodies[0] for data in bodies)
        assert sha(bodies[0]) == case["original_request_sha256"]
        old_payload = json.loads(bodies[0])
        assert old_payload == job["payload"] == case["payload"]
        a_raw, a_payload = wire(parity, "request")
        assert wire(parity_start, "request")[0] == a_raw
        assert a_payload == old_payload
        assert "state_id" not in old_payload
        assert len(old_payload["contents"]) == 8
        # Both encodings are compact UTF-8 JSON. Reordering only the outer
        # keys reproduces A exactly, without modifying any prompt string.
        assert json.dumps(old_payload, ensure_ascii=False, separators=(",", ":")).encode() == bodies[0]
        reordered = {key: old_payload[key] for key in a_payload}
        assert json.dumps(reordered, ensure_ascii=False, separators=(",", ":")).encode() == a_raw
        assert list(old_payload) != list(a_payload) and bodies[0] != a_raw
        old_response_raw, old_response = wire(old, "response")
        replay_raw, replay_response = wire(replay, "response")
        a_response_raw, a_response = wire(parity, "response")
        assert old_response == job["historical_response"]
        assert sha(old_response_raw) == case["original_response_sha256"]
        assert replay["http_status"] == old["http_status"] == parity["http_status"] == 200
        assert replay["http_attempted"] is True and replay["status"] == "completed"
        assert begun["http_attempted"] is False
        model = old_payload["model"]
        outputs = {key: choices(value, model) for key, value in
                   (("history", old_response), ("replay", replay_response), ("parity_A", a_response))}
        original_slots = {slot["index"]: slot for slot in old["slots"]}
        assert set(original_slots) == set(range(8))
        group_rows = []
        for slot in case["slots"]:
            index = slot["index"]
            call_path = B / slot["original_call_file"]
            call = load(call_path)
            assert sha(read(call_path)) == slot["original_call_sha256"]
            trace = call["trace"]
            assert trace["batch_id"] == case["original_batch_id"] and trace["batch_index"] == index
            for key in ("call_id", "evidence_ids", "stage"):
                assert trace[key] == slot[key] == original_slots[index][key]
            assert trace["prompt"] == old_payload["contents"][index]
            assert sha(trace["prompt"].encode()) == slot["prompt_sha256"]
            texts = {key: indexed[index]["message"]["content"] for key, indexed in outputs.items()}
            assert texts["history"] == call["raw_text"] == trace["raw_text"] == slot["original_raw_text"]
            syntax = {key: reader_syntax(text, slot["unit_count"]) if slot["stage"] == "resolver" else None
                      for key, text in texts.items()}
            comparisons = {label: difference(texts[left], texts[right], syntax[left], syntax[right])
                           for label, left, right in (("history_vs_replay", "history", "replay"),
                               ("parity_A_vs_replay", "parity_A", "replay"),
                               ("history_vs_parity_A", "history", "parity_A"))}
            recorded = {item["index"]: item for item in replay["comparisons"]}[index]
            assert recorded["same_as_history"] == (texts["history"] == texts["replay"])
            assert recorded["same_as_current_parity"] == (texts["parity_A"] == texts["replay"])
            row = {"group": name, "index": index, "stage": slot["stage"], "case_id": slot["case_id"],
                   "original_call_id": slot["call_id"], "evidence_ids": slot["evidence_ids"],
                   "prompt_sha256": slot["prompt_sha256"], "texts": texts,
                   "text_sha256": {key: sha(text.encode()) for key, text in texts.items()},
                   "reader_syntax_only": syntax, "comparisons": comparisons,
                   "finish_reasons": {key: values[index]["finish_reason"] for key, values in outputs.items()},
                   "termination_verified": False, "semantic_quality_scored": False}
            rows.append(row)
            group_rows.append(row)
        assert len(group_rows) == 8
        groups.append({"id": name, "request_bytes": len(bodies[0]),
            "history_and_replay_body_sha256": sha(bodies[0]), "parity_A_body_sha256": sha(a_raw),
            "historical_body_replayed_byte_for_byte": True,
            "parity_A_differs_only_in_outer_json_key_order": True,
            "model_and_all_parameter_values_and_prompt_order_equal": True,
            "model": model, "state_id_omitted": True,
            "history_response_sha256": sha(old_response_raw), "replay_response_sha256": sha(replay_raw),
            "parity_A_response_sha256": sha(a_response_raw),
            "stages": dict(Counter(row["stage"] for row in group_rows)),
            "comparison_counts": {key: dict(Counter(row["comparisons"][key] for row in group_rows))
                                  for key in group_rows[0]["comparisons"]}})
    summary = {key: dict(Counter(row["comparisons"][key] for row in rows)) for key in rows[0]["comparisons"]}
    review = {"schema": "batch-original-wire-independent-review-v1", "status": "PASS",
        "reviewer": "context_resolution (Codex), independent offline receipt/source audit",
        "http_requests": 2, "model_items": 16, "stages": dict(Counter(row["stage"] for row in rows)),
        "groups": groups, "rows": rows, "summary": summary,
        "runner_uses_content_raw_not_json_serialization": True,
        "request_byte_evidence_scope": "client-built and recorded request body plus frozen runner path; no server-side echo or network-packet capture",
        "conclusion": "Restoring the exact historical JSON key order and request bytes did not restore the CAN historical outputs. JSON key order is insufficient as the sole explanation for the observed historical drift.",
        "no_weight_or_deployment_change_inferred": True, "semantic_quality_scored": False,
        "new_api_calls": 0, "raw_records_modified": False, "input_file_bindings": PINS}
    save(OUT / "REVIEW.json", review)
    print(json.dumps({"status": "PASS", "groups": groups, "summary": summary}, ensure_ascii=False))


if __name__ == "__main__":
    main()
