import asyncio
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shlex
import sys
import time

OUT = Path(__file__).resolve().parent
FIXTURES = OUT.parent / 'reader-fixtures-v1'
SOURCE = Path('/home/chase/GitHub/rwkvrag-bm-29b-20260908/source-publication-v1')
sys.path.insert(0, str(SOURCE / 'src'))
from llamaindex_retrieval.rwkvos_batch import RwkvosBatchClient, render_batch_prompt
from llamaindex_retrieval.rwkv_pipeline import parse_task_selections, structured_body
from llamaindex_retrieval.batch_receipts import summarize_batch_http


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def verify_source():
    for name, spec in json.loads((SOURCE / 'SOURCE-MANIFEST.json').read_text())['files'].items():
        raw = (SOURCE / name).read_bytes()
        assert len(raw) == spec['bytes'] and sha(raw) == spec['sha256'], name


async def main():
    verify_source()
    # Only public model inputs are loaded. No gold or historical output file is
    # read by this runner. Their scores belong to a separate offline reviewer.
    original_raw = (FIXTURES / 'inputs.jsonl').read_bytes()
    candidate_raw = (FIXTURES / 'per-task.inputs.jsonl').read_bytes()
    frozen = json.loads((FIXTURES / 'FROZEN.json').read_text())
    for name, raw in [('inputs.jsonl', original_raw), ('per-task.inputs.jsonl', candidate_raw)]:
        spec = next(row for row in frozen['files'] if row['path'] == name)
        assert sha(raw) == spec['sha256'] and len(raw) == spec['bytes']
    originals = [json.loads(line) for line in original_raw.decode().splitlines()]
    candidates = [json.loads(line) for line in candidate_raw.decode().splitlines()]
    focused_raw = (OUT / 'focused.inputs.jsonl').read_bytes()
    focused = [json.loads(line) for line in focused_raw.decode().splitlines()]
    controls = [{'id': row['id'], 'source_sample_id': row['id'], 'messages': row['original_messages'], 'prompt': row['original_prompt'], 'prompt_sha256': row['original_prompt_sha256'], 'completion_parameters': row['completion_parameters'], 'unit_count': len(row['units'])} for row in originals]
    by_id = {row['id']: row for row in originals}
    for row in candidates + focused:
        row['unit_count'] = len(by_id[row['source_sample_id']]['units'])
    phases = [('focused', focused), ('control-after', candidates)]
    assert len(controls) == 16 and len(candidates) == 80
    for _, rows in phases:
        for row in rows:
            prompt, _ = render_batch_prompt(row['messages'], row['completion_parameters']['assistant_prefill'])
            assert prompt == row['prompt'] and sha(prompt.encode()) == row['prompt_sha256']
    save('STARTED.json', {'at': datetime.now(timezone.utc).isoformat(), 'runner_sha256': sha(Path(__file__).read_bytes()), 'plan_sha256': sha((OUT / 'PLAN.json').read_bytes()), 'fixture_freeze_sha256': sha((FIXTURES / 'FROZEN.json').read_bytes()), 'source_manifest_sha256': sha((SOURCE / 'SOURCE-MANIFEST.json').read_bytes()), 'planned_calls': 160, 'focused_inputs_sha256': sha(focused_raw)})
    parts = shlex.split(Path('/mnt/c/Users/chase/.codex/attachments/5a056a59-9300-4f5d-aace-62d0a1fb046e/pasted-text.txt').read_text().replace('\\\n', ''))
    headers = {}
    for i, part in enumerate(parts):
        if part in ('--header', '-H'):
            key, value = parts[i + 1].split(':', 1)
            if key.lower().startswith('cf-access-'):
                headers[key] = value.strip()
    summaries = []
    for phase, rows in phases:
        save(f'{phase}/REQUESTS.json', rows)
        phase_begin = time.perf_counter()

        def recorder(event, record):
            save(f"{phase}/batch-http/{record['batch_id']}.{event}.json", record)

        async with RwkvosBatchClient(base_url='https://api-3b.rwkvos.com/v1', model='rwkv7-g1j-2.9b-20260831-ctx16384', headers=headers, timeout_seconds=600, max_concurrency=32, batch_size=8, batch_wait_ms=5, stop_tokens=[0], recorder=recorder) as client:
            async def call(row):
                save(f"{phase}/calls/{row['id']}.started.json", {'id': row['id'], 'source_sample_id': row['source_sample_id'], 'at': datetime.now(timezone.utc).isoformat(), 'messages': row['messages'], 'completion_parameters': row['completion_parameters'], 'expected_prompt_sha256': row['prompt_sha256']})
                result = await client.complete(row['messages'], **row['completion_parameters'])
                record = {'id': row['id'], 'source_sample_id': row['source_sample_id'], 'task_index': row.get('task_index'), 'status': result.status, 'raw_text': result.raw_text, 'trace': result.trace, 'input_prompt_unchanged': result.trace.get('prompt_sha256') == row['prompt_sha256']}
                try:
                    selected = parse_task_selections(structured_body(result), row['unit_count'])
                    record.update(format_pass=True, selected_units=[f'E{i}' for i in selected])
                except (ValueError, TypeError) as error:
                    record.update(format_pass=False, parse_error=str(error))
                save(f"{phase}/calls/{row['id']}.completed.json", record)
                return record
            results = await asyncio.gather(*(call(row) for row in rows))
        http = summarize_batch_http(OUT / phase / 'batch-http', [row['trace'] for row in results])
        summary = {'phase': phase, 'calls': len(results), 'elapsed_ms': (time.perf_counter() - phase_begin) * 1000, 'statuses': dict(Counter(r['status'] for r in results)), 'format_pass': sum(r['format_pass'] for r in results), 'nonempty_selections': sum(bool(r.get('selected_units')) for r in results), 'http': http, 'all_prompts_unchanged': all(r['input_prompt_unchanged'] for r in results), 'semantic_quality_scored': False}
        save(f'{phase}/COMPLETED.json', summary)
        summaries.append(summary)
        print(json.dumps({k: v for k, v in summary.items() if k != 'http'}), flush=True)
    verify_source()
    save('COMPLETED.json', {'at': datetime.now(timezone.utc).isoformat(), 'phases': summaries, 'source_unchanged': True, 'semantic_quality_scored': False, 'automatic_retries': 0})


asyncio.run(main())
