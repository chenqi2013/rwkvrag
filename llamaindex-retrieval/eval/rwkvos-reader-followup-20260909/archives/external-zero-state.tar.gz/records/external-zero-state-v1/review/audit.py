"""Offline request/body/state-serialization audit. No torch/model/network imports."""
import ast, base64, collections, hashlib, io, json, pickle, re, zipfile
from datetime import datetime, timezone
from pathlib import Path

N=Path(__file__).resolve().parents[2]
R=N/"external-zero-state-v1"
OUT=Path(__file__).resolve().parent
SOURCE=N.parent/"rwkvrag-bm-29b-20260908/source-publication-v1"
pins={}
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
    b=p.read_bytes();entry={"bytes":len(b),"sha256":sha(b)}
    if str(p) in pins:assert pins[str(p)]==entry
    pins[str(p)]=entry;return b
def load(p):return json.loads(read(p))
def write(name,value):
    b=(json.dumps(value,ensure_ascii=False,indent=2,sort_keys=True)+"\n").encode()
    with (OUT/name).open("xb") as f:f.write(b)
def function(p,name):
    nodes=[x for x in ast.parse(read(p)).body if isinstance(x,ast.FunctionDef) and x.name==name]
    assert len(nodes)==1
    ns={};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(p),"exec"),ns)
    return ns[name]
for p in sorted(R.rglob("*")):
    if p.is_file() and OUT not in p.parents:read(p)
plan,started,done=[load(R/x) for x in ["PLAN.json","STARTED.json","COMPLETED.json"]]
assert plan["planned_generation_http"]==3 and plan["planned_state_http"]==2 and plan["planned_model_items"]==6
assert plan["no_training"] is True and plan["automatic_retries"]==0
assert done["status"]=="failed" and done["error_type"]=="ReadError" and done["error"]==""
assert done["training"] is False and done["automatic_retries"]==0
for key,name in [("runner_sha256","runner.py"),("plan_sha256","PLAN.json"),("inputs_sha256","inputs.jsonl")]:assert started[key]==sha(read(R/name))
manifest=load(SOURCE/"SOURCE-MANIFEST.json")
assert started["source_manifest_sha256"]==sha(read(SOURCE/"SOURCE-MANIFEST.json"))
for name,entry in manifest["files"].items():assert {"bytes":len(read(SOURCE/name)),"sha256":sha(read(SOURCE/name))}==entry
render=function(SOURCE/"src/llamaindex_retrieval/rwkvos_batch.py","render_batch_prompt")
envelope=function(SOURCE/"src/llamaindex_retrieval/rwkvos_batch.py","inspect_batch_envelope")

state_path=(R/plan["state_file"]).resolve();state=read(state_path)
assert len(state)==plan["state_bytes"]==10495555 and sha(state)==plan["state_sha256"]==started["state_sha256"]
state_smoke=load(state_path.parent/"COMPLETED.json")
assert state_smoke["status"]=="PASS" and state_smoke["optimizer_steps"]==0
assert state_smoke["all_state_parameters_unchanged_zero"] is True
assert state_smoke["untrained_export"]["sha256"]==sha(state)
assert state_smoke["untrained_export"]["semantic_axes"]==plan["state_semantic_axes"]==["head","value","key"]
assert state_smoke["untrained_export"]["shape_per_layer"]==plan["state_shape"]==[40,64,64]

# Parse only a closed set of safe pickle constructors; never execute torch code.
class BFloat16Storage:pass
def rebuild(storage,offset,size,stride,requires_grad,backward_hooks):
    assert isinstance(backward_hooks,collections.OrderedDict) and not backward_hooks
    return {"storage":storage,"offset":offset,"shape":size,"stride":stride,"requires_grad":requires_grad}
class RestrictedStateReader(pickle.Unpickler):
    def find_class(self,module,name):
        allowed={("torch._utils","_rebuild_tensor_v2"):rebuild,("torch","BFloat16Storage"):BFloat16Storage,("collections","OrderedDict"):collections.OrderedDict}
        assert (module,name) in allowed,(module,name)
        return allowed[(module,name)]
    def persistent_load(self,pid):
        assert len(pid)==5 and pid[0]=="storage" and pid[1] is BFloat16Storage and pid[3]=="cpu" and pid[4]==163840
        assert isinstance(pid[2],str) and pid[2].isdigit()
        return {"id":pid[2],"device":"cpu","elements":pid[4],"dtype":"bfloat16"}
state_rows=[]
with zipfile.ZipFile(io.BytesIO(state)) as z:
    names=z.namelist();assert len(names)==len(set(names))
    assert all(not x.startswith("/") and ".." not in Path(x).parts for x in names)
    assert z.read("archive/byteorder")==b"little"
    tensors=RestrictedStateReader(io.BytesIO(z.read("archive/data.pkl"))).load()
    assert isinstance(tensors,dict) and set(tensors)=={f"blocks.{i}.att.time_state" for i in range(32)}
    stores=set()
    for i in range(32):
        key=f"blocks.{i}.att.time_state";t=tensors[key];store=t["storage"]["id"]
        assert store not in stores;stores.add(store)
        assert t["offset"]==0 and t["shape"]==(40,64,64) and t["stride"]==(4096,64,1) and t["requires_grad"] is False
        raw=z.read("archive/data/"+store)
        assert len(raw)==327680 and not any(raw)
        state_rows.append({"key":key,"shape":[40,64,64],"stride":[4096,64,1],"storage_offset":0,"dtype":"bfloat16","bytes":len(raw),"all_positive_zero_bits":True,"sha256":sha(raw)})
    assert {x for x in names if x.startswith("archive/data/")}=={"archive/data/"+x for x in stores}

upload=load(R/"upload.started.json")
body=base64.b64decode(upload["request_body_base64"],validate=True)
assert len(body)==upload["request_body_bytes"]==10495769 and sha(body)==upload["request_body_sha256"]
assert upload["url"]=="https://api-3b.rwkvos.com/v1/state/upload" and upload["method"]=="POST"
assert upload["authentication_headers_recorded"] is False
prefix="multipart/form-data; boundary="
assert upload["content_type"].startswith(prefix)
boundary=upload["content_type"][len(prefix):].encode()
filename="rwkvrag-untrained-zero-32x40x64x64.pth"
expected=(b"--"+boundary+b'\r\nContent-Disposition: form-data; name="file"; filename="'+filename.encode()+b'"\r\nContent-Type: application/octet-stream\r\n\r\n'+state+b"\r\n--"+boundary+b"--\r\n")
assert body==expected
assert b"cf-access-" not in body.lower() and b"authorization:" not in body.lower()
# Recorded JSON objects omit credential/header fields; source code reads credentials but save payloads do not include them.
def no_recorded_auth(obj):
    if isinstance(obj,dict):
        for k,v in obj.items():
            assert not k.lower().startswith("cf-access-") and k.lower() not in {"authorization","headers","request_headers","api_key","client_secret"}
            no_recorded_auth(v)
    elif isinstance(obj,list):
        for v in obj:no_recorded_auth(v)
for p in R.rglob("*.json"):
    if OUT not in p.parents:no_recorded_auth(load(p))

inputs=[json.loads(x) for x in read(R/"inputs.jsonl").splitlines()]
assert [x["id"] for x in inputs]==["held_016-r002","generic-arithmetic"]
fixture_rows=[json.loads(x) for x in read(N/"reader-fixtures-v1/inputs.jsonl").splitlines()]
fixture=next(x for x in fixture_rows if x["id"]=="held_016-r002")
fixture_freeze=load(N/"reader-fixtures-v1/FROZEN.json")
for name in ["inputs.jsonl","gold.jsonl"]:
    entry=next(x for x in fixture_freeze["files"] if x["path"]==name);b=read(N/"reader-fixtures-v1"/name)
    assert len(b)==entry["bytes"] and sha(b)==entry["sha256"]
assert inputs[0]["messages"]==fixture["original_messages"]
assert inputs[0]["prompt_sha256"]==fixture["original_prompt_sha256"]
assert inputs[1]["messages"]==[{"role":"user","content":"计算12加7，只输出结果数字。"}]
http_paths=list((R/"control-before/batch-http").glob("*.batch_completed.json"))
assert len(http_paths)==1
hc=load(http_paths[0]);hs=load(http_paths[0].with_name(http_paths[0].name.replace("batch_completed","batch_started")))
assert hc["batch_id"]==hs["batch_id"] and hc["http_status"]==200 and hc["http_attempted"] is True
assert hc["response_body_complete"] is True and hc["status"]=="completed"
request=base64.b64decode(hc["request_body_base64"],validate=True)
response=base64.b64decode(hc["response_body_base64"],validate=True)
assert sha(request)==hc["request_body_sha256"] and sha(response)==hc["response_body_sha256"]
assert hs["request_body_base64"]==hc["request_body_base64"] and hs["request_body_sha256"]==hc["request_body_sha256"]
payload=json.loads(request);resp=json.loads(response)
assert payload==hc["payload"]==hs["payload"] and resp==hc["response_json"]
assert set(payload)=={"model","max_tokens","temperature","top_k","top_p","alpha_presence","alpha_frequency","alpha_decay","chunk_size","stream","stop_tokens","contents"}
assert payload["model"]==resp["model"]==plan["model"] and payload["max_tokens"]==128
assert payload["stop_tokens"]==[0] and payload["stream"] is False and len(payload["contents"])==2
assert [x["index"] for x in hc["slots"]]==[0,1]
assert set(x["index"] for x in resp["choices"])=={0,1} and len(resp["choices"])==2
choices={x["index"]:x for x in resp["choices"]};rows=[]
phase=load(R/"control-before/COMPLETED.json")
for idx,item in enumerate(inputs):
    cid=item["id"];st=load(R/f"control-before/{cid}.started.json");co=load(R/f"control-before/{cid}.completed.json");t=co["trace"]
    prompt,prefill=render(item["messages"],item["assistant_prefill"])
    assert prompt==payload["contents"][idx]==t["prompt"] and sha(prompt.encode())==t["prompt_sha256"]
    assert st["messages"]==item["messages"]==t["messages"] and st["state_id"] is None and t["state_id"] is None
    assert co["status"]=="completed" and co==phase["results"][idx]
    assert t["batch_id"]==hc["batch_id"] and t["batch_index"]==idx
    assert t["call_id"]==hc["slots"][idx]["call_id"] and t["provider_choice"]==choices[idx]
    assert t["parameters"]=={k:v for k,v in payload.items() if k!="contents"}
    assert t["http"]==[hc]
    raw=co["raw_text"];assert raw==t["raw_text"]==choices[idx]["message"]["content"] and sha(raw.encode())==t["raw_text_sha256"]
    assert t["envelope"]==envelope(raw,prefill)
    assert t["termination_verified"] is False and t["provider_finish_reason"]=="stop" and t["usage"] is None
    rows.append({"id":cid,"index":idx,"call_id":t["call_id"],"prompt_sha256":sha(prompt.encode()),"max_tokens":128,"state_id":None,"raw_text":raw,"raw_text_sha256":sha(raw.encode()),"status":co["status"],"provider_finish_reason":"stop","actual_termination_verified":False,"diagnostic":"Exposed positive WinJS source omitted: NONE." if idx==0 else "Arithmetic value is 19, but output is an equation rather than only result digits; this is a compatibility control, not an overall quality score."})
assert rows[0]["raw_text"]=="NONE" and rows[1]["raw_text"]=="\n12 + 7 = 19"
assert not (R/"upload.completed.json").exists()
assert not any((R/name).exists() for name in ["uploaded-zero","control-after","delete-own-state.started.json","delete-own-state.completed.json"])
assert len(list(R.rglob("*.batch_started.json")))==1 and len(list(R.rglob("*.batch_completed.json")))==1
runner=read(R/"runner.py").decode();ast.parse(runner)
assert 'began=time.perf_counter();resp=await http.send(req);data=await resp.aread()' in runner
assert 'sid=None;' in runner and 'sid=upload["state_id"]' in runner and 'if sid:' in runner
assert 'files={"file":("rwkvrag-untrained-zero-32x40x64x64.pth",state,"application/octet-stream")}' in runner
assert 'follow_redirects=False' in runner
assert not any(isinstance(x,ast.While) for x in ast.walk(ast.parse(runner)))
for path,entry in list(pins.items()):assert {"bytes":len(read(Path(path))),"sha256":sha(read(Path(path)))}==entry
review={"schema":"external-zero-state-independent-review-v1","audit_status":"PASS","experiment_status":"failed","reviewer":"Codex context_resolution, independent offline receipt/source audit; no new requests","observed":{"generation_items_completed":2,"generation_http_confirmed":1,"state_upload_attempts":1,"state_upload_responses_confirmed":0,"state_delete_attempts":0,"planned_generation_items_not_run":4,"planned_generation_http_not_run":2,"planned_state_delete_http_not_run":1,"automatic_retries_observed":0,"training_updates":0},"plan":{"generation_items":6,"generation_http":3,"state_http":2,"total_http":5},"upload":{"request_body_bytes":len(body),"request_body_sha256":sha(body),"multipart_parts":1,"part_name":"file","filename":filename,"part_bytes":len(state),"part_sha256":sha(state),"only_exact_self_owned_zero_state_file":True,"request_authentication_headers_recorded":False,"send_attempt_inferred_from":"Persisted upload.started then ReadError from the runner's http.send/aread path; control-before had already completed.","request_body_full_delivery_verified":False,"http_response_observed":False,"http_status":None,"state_id_observed":None,"remote_creation_status":"unknown","cleanup_status":"not_attempted_no_state_id","exception_type":"ReadError"},"state":{"path":str(state_path),"bytes":len(state),"sha256":sha(state),"tensor_count":32,"total_elements":5242880,"serialized_axes_declared":["head","value","key"],"all_tensor_payloads_zero_independently_verified":True,"validation_method":"Stdlib ZIP and restricted unpickler accepting only three named constructors; all 32 BF16 storage byte arrays are zero. No torch import/model/GPU execution.","tensors":state_rows},"control_rows":rows,"interpretation":["No uploaded-state generation occurred. There is no A/B/A comparison, remote state compatibility result, zero-state equivalence result or state quality effect to score.","ReadError after the upload attempt does not prove the server failed to create a state; state creation and full body delivery remain unknown.","No state_id was received, so the narrowly authorized delete-own-state operation could not target a resource. Cleanup is not claimed; no unrelated state listings/deletions/retries were performed.","The pre-upload controls are retained even though the remaining plan was not executed. The endpoint's stop flag is not verified natural EOS.","The uploaded tensors are untrained zeros despite a preceding local gradient-readiness smoke; that smoke had no optimizer update. Zero tensors cannot validate semantic axis ordering or trained-state effectiveness."],"input_file_bindings":dict(pins),"new_api_or_model_calls":0,"original_records_modified":False}
write("REVIEW.json",review)
report="""本轮零 state 兼容探针没有完成，原始失败已保留。独立核验通过的是记录完整性与实际执行边界，不能把审计 PASS 当作上传或兼容性 PASS。

原计划是上传前 2 项、带零 state 2 项、上传后 2 项：共 6 项生成、3 次生成 batch HTTP，以及上传/删除各 1 次 state HTTP。实际只完成上传前 2 项、1 次生成 HTTP 200。接着发生 1 次上传尝试；其后没有上传响应、state ID、带 state 生成、后控制或删除。未执行的 4 项生成及后续 HTTP 不记作成功或已调用，也没有重试。

保存的 multipart 正文共 10,495,769 字节，按真实 boundary 独立重建后逐字节相等；只含一个名为 `file` 的自有 `rwkvrag-untrained-zero-32x40x64x64.pth` 文件，文件为 10,495,555 字节，SHA `d9e760c5cbf6101ba86266c944aa101990f43ee186d49b416578cc83dc932aff`。使用标准库 ZIP 和受限 pickle 结构读取，独立确认 32 个 BF16 张量，每个 40×64×64、全部 storage 字节为零，没有额外 tensor 或文件部分。形状不能独立证明语义轴方向。前序本机 backward smoke 没有优化器更新，因此此文件仍是未训练零 state。

`upload.started.json` 完整保存构造的请求正文，随后顶层 `COMPLETED.json` 记录 `ReadError`。按 runner 路径已进入发送/读取，但没有确认响应，不能证明完整正文已被远端接收，也不能推出服务端没有创建 state。远端创建结果为 unknown。没有得到 state ID，无法定位可能创建的自有对象；原 runner 没有执行删除，报告不声称清理成功，也不列出或触碰其他 state。

上传正文仅为文件及 multipart 头，持久化记录未包含 CF 认证头；本审计没有读取附件凭据。所有原请求/响应和 source manifest 均绑定 SHA，不修改原字节。上传前 WinJS 输出 `NONE`，仍遗漏明确给出的 Windows 8；算术控制输出 `12 + 7 = 19`，数值正确但没有遵循仅数字格式。这些只描述前控制，不能产生零 state 效果或质量提升结论。

本次由 Codex 独立离线核验，没有新的 API、GPU、训练、检索、补偿请求或模型执行。原始失败状态、缺失响应与未执行阶段都保留。
"""
with (OUT/"REPORT.md").open("x") as f:f.write(report)
artifacts={p.name:{"bytes":p.stat().st_size,"sha256":sha(p.read_bytes())} for p in sorted(OUT.iterdir()) if p.is_file()}
write("FROZEN.json",{"schema":"independent-review-freeze-v1","at":datetime.now(timezone.utc).isoformat(),"artifacts":artifacts,"input_file_bindings":review["input_file_bindings"],"new_api_or_model_calls":0})
print(json.dumps({"audit":"PASS","experiment":"failed","generations":2,"generation_http":1,"upload_attempts":1,"upload_result":"unknown","freeze_sha256":sha((OUT/"FROZEN.json").read_bytes())}))
