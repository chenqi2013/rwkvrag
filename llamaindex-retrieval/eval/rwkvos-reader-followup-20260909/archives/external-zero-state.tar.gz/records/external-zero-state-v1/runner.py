import asyncio,base64,hashlib,json,os,shlex,sys,time
from pathlib import Path
from datetime import datetime,timezone
import httpx
OUT=Path(__file__).resolve().parent
SOURCE=Path("/home/chase/GitHub/rwkvrag-bm-29b-20260908/source-publication-v1")
sys.path.insert(0,str(SOURCE/"src"))
from llamaindex_retrieval.rwkvos_batch import RwkvosBatchClient,render_batch_prompt
URL="https://api-3b.rwkvos.com/v1"
def sha(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def save(name,obj):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open("x") as f:
  json.dump(obj,f,ensure_ascii=False,indent=2);f.write("\n");f.flush();os.fsync(f.fileno())
async def main():
 plan=json.loads((OUT/"PLAN.json").read_text());state=(OUT/plan["state_file"]).read_bytes();assert len(state)==plan["state_bytes"] and sha(state)==plan["state_sha256"]
 for name,pin in json.loads((SOURCE/"SOURCE-MANIFEST.json").read_text())["files"].items():
  b=(SOURCE/name).read_bytes();assert len(b)==pin["bytes"] and sha(b)==pin["sha256"]
 rows=[json.loads(x) for x in (OUT/"inputs.jsonl").read_text().splitlines()]
 for r in rows:
  prompt,_=render_batch_prompt(r["messages"],r["assistant_prefill"])
  if "prompt_sha256" in r:assert sha(prompt.encode())==r["prompt_sha256"]
 parts=shlex.split(Path("/mnt/c/Users/chase/.codex/attachments/5a056a59-9300-4f5d-aace-62d0a1fb046e/pasted-text.txt").read_text().replace("\\\n",""))
 headers={}
 for i,part in enumerate(parts):
  if part in ("--header","-H"):
   k,v=parts[i+1].split(":",1)
   if k.lower().startswith("cf-access-"):headers[k]=v.strip()
 assert len(headers)==2
 save("STARTED.json",{"at":now(),"runner_sha256":sha(Path(__file__).read_bytes()),"plan_sha256":sha((OUT/"PLAN.json").read_bytes()),"inputs_sha256":sha((OUT/"inputs.jsonl").read_bytes()),"source_manifest_sha256":sha((SOURCE/"SOURCE-MANIFEST.json").read_bytes()),"state_sha256":sha(state)})
 async def phase(name,state_id=None):
  def recorder(event,record):save(f"{name}/batch-http/{record['batch_id']}.{event}.json",record)
  async with RwkvosBatchClient(base_url=URL,model=plan["model"],headers=headers,timeout_seconds=600,max_concurrency=2,batch_size=2,batch_wait_ms=5,stop_tokens=[0],state_id=state_id,recorder=recorder) as client:
   async def call(row):
    save(f"{name}/{row['id']}.started.json",dict(row,max_tokens=128,state_id=state_id,at=now()))
    r=await client.complete(row["messages"],stage="resolver" if row["id"].startswith("held") else "probe",max_tokens=128,assistant_prefill=row["assistant_prefill"])
    result={"id":row["id"],"status":r.status,"raw_text":r.raw_text,"trace":r.trace}
    save(f"{name}/{row['id']}.completed.json",result);return result
   results=await asyncio.gather(*(call(r) for r in rows))
  save(f"{name}/COMPLETED.json",{"at":now(),"results":results});print(json.dumps({"phase":name,"statuses":[r["status"] for r in results]}),flush=True);return results
 async with httpx.AsyncClient(timeout=600,follow_redirects=False) as http:
  async def state_request(name,route,**kwargs):
   req=http.build_request("POST",URL+route,headers=headers,**kwargs);body=await req.aread()
   save(name+".started.json",{"at":now(),"url":str(req.url),"method":req.method,"content_type":req.headers.get("content-type"),"request_body_base64":base64.b64encode(body).decode(),"request_body_bytes":len(body),"request_body_sha256":sha(body),"authentication_headers_recorded":False})
   began=time.perf_counter();resp=await http.send(req);data=await resp.aread()
   save(name+".completed.json",{"at":now(),"http_status":resp.status_code,"response_body_base64":base64.b64encode(data).decode(),"response_body_sha256":sha(data),"elapsed_ms":(time.perf_counter()-began)*1000})
   resp.raise_for_status();return resp.json()
  sid=None;summary={"at":now(),"training":False,"state_is_untrained_zero":True,"automatic_retries":0}
  try:
   before=await phase("control-before")
   upload=await state_request("upload","/state/upload",files={"file":("rwkvrag-untrained-zero-32x40x64x64.pth",state,"application/octet-stream")})
   sid=upload["state_id"];assert isinstance(sid,str) and sid
   during=await phase("uploaded-zero",sid)
   after=await phase("control-after")
   summary.update(status="complete",upload=upload,comparisons=[{"id":a["id"],"all_completed":all(x["status"]=="completed" for x in [a,b,c]),"before_equals_zero":a["raw_text"]==b["raw_text"],"before_equals_after":a["raw_text"]==c["raw_text"]} for a,b,c in zip(before,during,after)])
  except Exception as e:summary.update(status="failed",error_type=type(e).__name__,error=str(e))
  finally:
   if sid:
    try:summary["cleanup"]=await state_request("delete-own-state","/state/delete",json={"state_id":sid})
    except Exception as e:summary["cleanup_error"]={"type":type(e).__name__,"message":str(e)}
   summary["completed_at"]=now();save("COMPLETED.json",summary);print(json.dumps({k:v for k,v in summary.items() if k not in ["upload","cleanup"]}),flush=True)
asyncio.run(main())
