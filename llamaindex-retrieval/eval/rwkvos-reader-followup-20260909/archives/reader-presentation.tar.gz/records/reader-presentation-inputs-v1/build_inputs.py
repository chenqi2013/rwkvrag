#!/usr/bin/env python3
"""Prepare a frozen metadata-presentation control; no network or model imports."""
import copy
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path


OUT = Path(__file__).resolve().parent
FIXTURES = OUT.parent / "reader-fixtures-v1"
MARKERS = [("task", "\n任务："), ("tasks", "\n子问题："), ("source", "\n来源："),
           ("context", "\n原文父级上下文："), ("units", "\n原文：")]
CONTEXT_KEYS = {"sha256", "level", "kind", "start", "end", "text"}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def text_sha(text):
    return sha(text.encode("utf-8"))


def save(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write("\n")


def parts(message):
    """Read consecutive JSON values, not delimiter-like text inside values."""
    decoder = json.JSONDecoder()
    result = {}
    cursor = message.index(MARKERS[0][1])
    result["instructions"] = message[:cursor]
    for key, marker in MARKERS:
        assert message.startswith(marker, cursor), (key, "unexpected original layout")
        start = cursor + len(marker)
        value, length = decoder.raw_decode(message[start:])
        cursor = start + length
        result[key] = {"start": start, "end": cursor, "value": value,
                       "raw": message[start:cursor]}
    assert cursor == len(message), "unparsed prompt suffix"
    return result


def replace_sections(message, sections, replacement):
    for key in sorted(replacement, key=lambda k: sections[k]["start"], reverse=True):
        value = sections[key]
        message = message[:value["start"]] + replacement[key] + message[value["end"]:]
    return message


def build_one(row):
    assert len(row["original_messages"]) == 1
    original_message = row["original_messages"][0]
    assert set(original_message) == {"role", "content"} and original_message["role"] == "user"
    before = original_message["content"]
    parsed = parts(before)
    assert parsed["task"]["raw"] == row["task"]
    assert parsed["tasks"]["value"] == row["active_tasks"]
    original_source = parsed["source"]["value"]
    assert set(original_source) == {"id", "title", "uri"}
    assert original_source == {k: row["source"][k] for k in ("id", "title", "uri")}
    assert isinstance(original_source["title"], str)
    contexts = parsed["context"]["value"]
    assert contexts == row["context"] == row["source"]["metadata"]["context_spans"]
    for context in contexts:
        assert set(context) == CONTEXT_KEYS
        assert context["kind"] == "heading" and type(context["level"]) is int
        assert isinstance(context["text"], str)
        assert context["text"].startswith("#" * context["level"] + " ")
        assert text_sha(context["text"]) == context["sha256"]
        assert type(context["start"]) is int and type(context["end"]) is int
        assert context["end"] - context["start"] == len(context["text"])
    units = {unit["id"]: unit["text"] for unit in row["units"]}
    assert len(units) == len(row["units"]) and parsed["units"]["value"] == units
    for unit in row["units"]:
        assert row["source"]["snippet"][unit["start"]:unit["end"]] == unit["text"]
        assert text_sha(unit["text"]) == unit["sha256"]
    replacements = {
        "source": json.dumps({"title": original_source["title"]}, ensure_ascii=False),
        "context": json.dumps([context["text"] for context in contexts], ensure_ascii=False),
    }
    after = replace_sections(before, parsed, replacements)
    candidate = parts(after)
    assert candidate["instructions"] == parsed["instructions"]
    for key in ("task", "tasks", "units"):
        assert candidate[key]["raw"] == parsed[key]["raw"]
    assert candidate["source"]["value"] == {"title": row["source"]["title"]}
    assert candidate["context"]["value"] == [context["text"] for context in contexts]
    masks = {"source": "<SOURCE_PRESENTATION>", "context": "<CONTEXT_PRESENTATION>"}
    assert replace_sections(before, parsed, masks) == replace_sections(after, candidate, masks)

    # Match the actual frozen complete-prefill transport envelope; do not
    # regenerate a different template or reinterpret assistant continuation.
    assert row["original_prompt"] == "User: " + before + "\n\nAssistant: <think></think>"
    assert text_sha(row["original_prompt"]) == row["original_prompt_sha256"]
    assert row["prefill_mode"] == "complete" and row["transport"] == "rwkvos_batch"
    prompt = "User: " + after + "\n\nAssistant: <think></think>"
    output = {
        "id": row["id"], "source_sample_id": row["id"], "case_id": row["case_id"],
        "reader_rank": row["reader_rank"], "messages": [{"role": "user", "content": after}],
        "prompt": prompt, "prompt_sha256": text_sha(prompt),
        "completion_parameters": copy.deepcopy(row["completion_parameters"]),
        "http_payload": {**copy.deepcopy(row["original_http_parameters"]), "contents": [prompt]},
        "transport": row["transport"], "prefill_mode": row["prefill_mode"], "state_id": row["state_id"],
        "original_source_sample_prompt_sha256": row["original_prompt_sha256"],
        "original_call_id": row["original_call_id"],
        "original_source_sample_sha256": text_sha(json.dumps(row, ensure_ascii=False, sort_keys=True)),
        "task": row["task"], "active_tasks": copy.deepcopy(row["active_tasks"]),
        "source": copy.deepcopy(row["source"]), "context": copy.deepcopy(row["context"]),
        "units": copy.deepcopy(row["units"]),
        "metadata_presentation": "title_and_verbatim_context_text_only",
        "outer_source_context_units": "trace identity only; never send this outer fixture as model content",
    }
    edits = []
    for key in ("source", "context"):
        old, new = parsed[key], candidate[key]
        edits.append({"section": key,
            "original_unicode_span": [old["start"], old["end"]],
            "candidate_unicode_span": [new["start"], new["end"]],
            "original_utf8_sha256": text_sha(old["raw"]),
            "candidate_utf8_sha256": text_sha(new["raw"]),
            "changed": old["raw"] != new["raw"]})
    audit = {"id": row["id"], "status": "PASS", "edits": edits,
        "original_prompt_sha256": row["original_prompt_sha256"], "candidate_prompt_sha256": text_sha(prompt),
        "original_user_content_sha256": text_sha(before), "candidate_user_content_sha256": text_sha(after),
        "original_prompt_characters": len(row["original_prompt"]), "candidate_prompt_characters": len(prompt),
        "only_two_declared_section_replacements": True,
        "all_other_characters_and_utf8_bytes_identical": True,
        "instructions_sha256": text_sha(parsed["instructions"]),
        "task_section_sha256": text_sha(parsed["task"]["raw"]),
        "joint_task_array_sha256": text_sha(parsed["tasks"]["raw"]),
        "evidence_json_section_sha256": text_sha(parsed["units"]["raw"]),
        "source_title_unchanged": True, "context_texts_and_order_unchanged": True,
        "context_count": len(contexts), "context_text_characters": sum(len(x["text"]) for x in contexts),
        "unit_count": len(units), "unit_text_characters": sum(len(x) for x in units.values()),
        "outer_source_context_units_identity_unchanged": True,
        "completion_and_http_parameters_unchanged": True,
        "no_gold_or_model_output_inserted": True,
    }
    diff = "".join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile=row["id"] + "/original-user-content", tofile=row["id"] + "/candidate-user-content"))
    return output, audit, diff


def main():
    plan = json.loads((OUT / "PLAN.json").read_bytes())
    source_bytes = (FIXTURES / "inputs.jsonl").read_bytes()
    assert sha(source_bytes) == plan["source_inputs"]["sha256"]
    assert sha((FIXTURES / "FROZEN.json").read_bytes()) == plan["source_fixture_freeze"]["sha256"]
    rows = [json.loads(line) for line in source_bytes.splitlines()]
    assert len(rows) == 16 and len({row["id"] for row in rows}) == 16
    built = [build_one(row) for row in rows]
    (OUT / "diffs").mkdir(exist_ok=False)
    with (OUT / "inputs.jsonl").open("x", encoding="utf-8") as stream:
        for output, _, diff in built:
            stream.write(json.dumps(output, ensure_ascii=False) + "\n")
            with (OUT / "diffs" / (output["id"] + ".diff")).open("x", encoding="utf-8") as view:
                view.write(diff)
    audits = [item[1] for item in built]
    assert sum(row["context_count"] for row in audits) == 24
    assert sum(row["context_text_characters"] for row in audits) == 278
    assert sum(row["unit_text_characters"] for row in audits) == 3503
    save(OUT / "EXACT-DIFF-AUDIT.json", {
        "schema": "reader-presentation-exact-diff-v1", "status": "PASS", "cases": 16,
        "source_inputs_sha256": sha(source_bytes), "plan_sha256": sha((OUT / "PLAN.json").read_bytes()),
        "candidate_inputs_sha256": sha((OUT / "inputs.jsonl").read_bytes()),
        "generator_sha256": sha(Path(__file__).read_bytes()), "rows": audits,
        "total_original_prompt_characters": sum(row["original_prompt_characters"] for row in audits),
        "total_candidate_prompt_characters": sum(row["candidate_prompt_characters"] for row in audits),
        "necessary_non_text_factual_content_found": False,
        "observed_parent_context_kind": "heading; Markdown level markers retained in text",
        "E_unit_localization_limitation": "all 16 frozen sources have one E unit; this does not test multi-unit selection",
        "source_fixture_unchanged": sha((FIXTURES / "inputs.jsonl").read_bytes()) == sha(source_bytes),
        "gold_or_new_outputs_read": False, "model_calls": 0, "retrieval_calls": 0,
        "quality_or_promotion_claim": False,
    })
    files = []
    for path in sorted(OUT.rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts:
            data = path.read_bytes()
            files.append({"path": path.relative_to(OUT).as_posix(), "bytes": len(data), "sha256": sha(data)})
    save(OUT / "FROZEN.json", {"schema": "reader-presentation-inputs-v1-freeze",
        "frozen_at": datetime.now(timezone.utc).isoformat(), "files": files,
        "source_fixture_freeze_sha256": plan["source_fixture_freeze"]["sha256"],
        "model_calls": 0, "production_files_modified": False})
    print(json.dumps({"status": "PASS", "cases": 16,
        "inputs_sha256": sha((OUT / "inputs.jsonl").read_bytes()),
        "audit_sha256": sha((OUT / "EXACT-DIFF-AUDIT.json").read_bytes()),
        "freeze_sha256": sha((OUT / "FROZEN.json").read_bytes())}))


if __name__ == "__main__":
    main()
