import asyncio
import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shlex
import sys
import time

import httpx

OUT = Path(__file__).resolve().parent
SOURCE = Path('/home/chase/GitHub/rwkvrag-bm-29b-20260908/source-publication-v1')
sys.path.insert(0, str(SOURCE / 'src'))
from llamaindex_retrieval.config import Settings
from llamaindex_retrieval.rwkv_pipeline import parse_plan, parse_task_selections
from llamaindex_retrieval.rwkvos_batch import RwkvosBatchClient


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def verify():
    for name, spec in json.loads((SOURCE / 'SOURCE-MANIFEST.json').read_text())['files'].items():
        raw = (SOURCE / name).read_bytes()
        assert len(raw) == spec['bytes'] and sha(raw) == spec['sha256'], name


def classify(raw, slot):
    try:
        if slot['stage'] == 'resolver':
            selection = parse_task_selections(raw.strip(), slot['unit_count'])
            return {'format_pass': True, 'selection': selection, 'kind': 'selected' if selection else 'NONE'}
        return {'format_pass': True, 'plan': parse_plan(raw.strip(), Settings(_env_file=None, native_plan_protocol='queries_fields')), 'kind': 'plan'}
    except (ValueError, TypeError) as error:
        return {'format_pass': False, 'kind': 'invalid', 'error': str(error)}


async def main():
    verify()
    groups = json.loads((OUT / 'cases.json').read_text())
    jobs = []
    for group in groups:
        for phase, indices in [('batch-before', list(range(8))), *[(f'single-{i}', [i]) for i in range(8)], ('batch-after', list(range(8)))]:
            payload = {**group['payload'], 'contents': [group['payload']['contents'][i] for i in indices]}
            jobs.append({'id': f"{group['id']}-{phase}", 'group': group['id'], 'phase': phase, 'indices': indices, 'payload': payload})
    save('requests.json', jobs)
    save('STARTED.json', {'started_at': datetime.now(timezone.utc).isoformat(), 'cases_sha256': sha((OUT / 'cases.json').read_bytes()), 'plan_sha256': sha((OUT / 'PLAN.json').read_bytes()), 'runner_sha256': sha(Path(__file__).read_bytes()), 'source_manifest_sha256': sha((SOURCE / 'SOURCE-MANIFEST.json').read_bytes()), 'planned_http': len(jobs)})
    parts = shlex.split(Path('/mnt/c/Users/chase/.codex/attachments/5a056a59-9300-4f5d-aace-62d0a1fb046e/pasted-text.txt').read_text().replace('\\\n', ''))
    headers = {'Content-Type': 'application/json'}
    for i, part in enumerate(parts):
        if part in ('--header', '-H'):
            key, value = parts[i + 1].split(':', 1)
            if key.lower().startswith('cf-access-'):
                headers[key] = value.strip()
    outcomes = []
    async with httpx.AsyncClient(timeout=600, follow_redirects=False, trust_env=False) as client:
        for job in jobs:
            request = client.build_request('POST', 'https://api-3b.rwkvos.com/v1/batch/completions', headers=headers, json=job['payload'])
            record = {'id': job['id'], 'started_at': datetime.now(timezone.utc).isoformat(), 'payload': job['payload'], 'indices': job['indices'], 'http_attempted': False, 'request_body_base64': base64.b64encode(request.content).decode(), 'request_body_sha256': sha(request.content), 'termination_verified': False}
            save(f"http/{job['id']}.started.json", record)
            before = time.perf_counter()
            try:
                record['http_attempted'] = True
                response = await client.send(request)
                raw = response.content
                record.update(http_status=response.status_code, response_body_base64=base64.b64encode(raw).decode(), response_body_sha256=sha(raw), response_body_complete=True)
                response.raise_for_status()
                data = json.loads(raw)
                choices = RwkvosBatchClient._choices(data, len(job['indices']), job['payload']['model'])
                record['response_json'] = data
                group = next(g for g in groups if g['id'] == job['group'])
                output = [{'original_index': i, 'raw_text': choice['message']['content'], 'raw_sha256': sha(choice['message']['content'].encode()), 'classification': classify(choice['message']['content'], group['slots'][i])} for i, choice in zip(job['indices'], choices, strict=True)]
                record.update(status='completed', outputs=output)
            except Exception as error:
                record.update(status='failed', error_type=type(error).__name__)
            record.update(completed_at=datetime.now(timezone.utc).isoformat(), elapsed_ms=(time.perf_counter() - before) * 1000)
            save(f"http/{job['id']}.completed.json", record)
            outcomes.append(record)
            print(job['id'], record['status'], round(record['elapsed_ms']), flush=True)
            if record['status'] != 'completed':
                break
    verify()
    comparisons = []
    for group in groups:
        by_id = {r['id']: r for r in outcomes}
        ids = [f"{group['id']}-batch-before", f"{group['id']}-batch-after"]
        if not all(i in by_id and by_id[i]['status'] == 'completed' for i in ids):
            continue
        for i, slot in enumerate(group['slots']):
            before = by_id[ids[0]]['outputs'][i]
            after = by_id[ids[1]]['outputs'][i]
            single = by_id[f"{group['id']}-single-{i}"]['outputs'][0]
            comparisons.append({'group': group['id'], 'index': i, 'stage': slot['stage'], 'case_id': slot['case_id'], 'batch_repeat_identical': before['raw_text'] == after['raw_text'], 'before_single_identical': before['raw_text'] == single['raw_text'], 'after_single_identical': after['raw_text'] == single['raw_text'], 'historical_before_identical': slot['original_raw_text'] == before['raw_text'], 'before': before['classification'], 'single': single['classification'], 'after': after['classification']})
    summary = {'completed_at': datetime.now(timezone.utc).isoformat(), 'planned_http': len(jobs), 'attempted_http': len(outcomes), 'completed_http': sum(r['status'] == 'completed' for r in outcomes), 'model_items_returned': sum(len(r.get('outputs', [])) for r in outcomes), 'comparisons': comparisons, 'automatic_retries': 0, 'source_unchanged': True, 'semantic_quality_scored': False}
    save('COMPLETED.json', summary)
    print(json.dumps({'http': summary['completed_http'], 'items': summary['model_items_returned'], 'repeat_equal': sum(r['batch_repeat_identical'] for r in comparisons), 'single_equal_before': sum(r['before_single_identical'] for r in comparisons), 'slots': len(comparisons)}), flush=True)


asyncio.run(main())
