"""Offline independent replay of the immutable batch-parity A/B/A receipts."""
import ast
import base64
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import re
from types import SimpleNamespace

RUN = Path(__file__).resolve().parent.parent
OUT = RUN / "review"
OLD = Path('/home/chase/GitHub/rwkvrag-bm-29b-20260908')
SOURCE = OLD / 'source-publication-v1'
PINS = {
    'cases.json': '0aa495373881186a9a3fad6c640def1255ba0e55a9a6f6ef346237e18c83128e',
    'PLAN.json': '194a142fa4434eb8c9206a0c7ec22e5040bee72f002cf566088ecaa77af32af3',
    'runner.py': 'eee20e3496b30f73b58623645f4de8926ff2298f5e57f7f751bc11501c92fe75',
}


def sha(data):
    return sha256(data).hexdigest()


def pairs(values):
    out = {}
    for key, value in values:
        assert key not in out, ('duplicate_json_key', key)
        out[key] = value
    return out


def loads(raw):
    def bad_constant(value):
        raise ValueError(value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=bad_constant)


def load(path):
    return loads(path.read_bytes().decode('utf-8'))


def body(record, direction):
    raw = base64.b64decode(record[f'{direction}_body_base64'], validate=True)
    assert sha(raw) == record[f'{direction}_body_sha256']
    parsed = loads(raw.decode('utf-8'))
    if direction == 'request':
        assert parsed == record['payload']
    else:
        assert parsed == record['response_json']
    return raw, parsed


def choices(data, count, model):
    assert data['object'] == 'chat.completion' and data['model'] == model
    assert 'error' not in data and len(data['choices']) == count
    values = {}
    for item in data['choices']:
        index = item['index']
        assert type(index) is int and 0 <= index < count and index not in values
        assert item['message']['role'] == 'assistant'
        assert isinstance(item['message']['content'], str)
        item['message']['content'].encode('utf-8')
        assert item['finish_reason'] in ('stop', 'length') and 'error' not in item
        values[index] = item
    return [values[i] for i in range(count)]


def pure_functions(path):
    wanted = ('parse_plan', 'parse_task_selections')
    tree = ast.parse(path.read_text())
    nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in wanted]
    assert len(nodes) == 2
    ns = {'json': json, 're': re, 'Settings': object}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec'), ns)
    return ns, {n.name: ast.dump(n, include_attributes=False) for n in nodes}


def classify(raw, slot, functions, settings):
    try:
        if slot['stage'] == 'resolver':
            selected = functions['parse_task_selections'](raw.strip(), slot['unit_count'])
            return {'format_pass': True, 'selection': selected,
                    'kind': 'selected' if selected else 'NONE'}
        plan = functions['parse_plan'](raw.strip(), settings)
        return {'format_pass': True, 'plan': plan, 'kind': 'plan'}
    except (ValueError, TypeError) as error:
        return {'format_pass': False, 'kind': 'invalid', 'error': str(error)}


def main():
    for name, expected in PINS.items():
        assert sha((RUN / name).read_bytes()) == expected, name
    started, declared = load(RUN/'STARTED.json'), load(RUN/'COMPLETED.json')
    for name, key in [('cases.json','cases_sha256'), ('PLAN.json','plan_sha256'), ('runner.py','runner_sha256')]:
        assert started[key] == PINS[name]
    manifest = SOURCE/'SOURCE-MANIFEST.json'
    assert sha(manifest.read_bytes()) == started['source_manifest_sha256'] == '15d64abc9a9ce960c89b1ae4bfbcc0c8730782e4f3ec3f370fb669716fdc3b9f'
    specs = load(manifest)['files']
    for name, spec in specs.items():
        raw = (SOURCE/name).read_bytes()
        assert len(raw) == spec['bytes'] and sha(raw) == spec['sha256'], name
    functions, ast_current = pure_functions(SOURCE/'src/llamaindex_retrieval/rwkv_pipeline.py')
    oldrun = OLD/'wiki-api-v1-eos'
    oldmanifest, oldsettings = load(oldrun/'manifest.json'), load(oldrun/'settings.json')
    oldspecs = load(oldrun/'source-manifest.json')
    oldparser = Path(oldmanifest['arguments']['source_root'])/'src/llamaindex_retrieval/rwkv_pipeline.py'
    assert sha(oldparser.read_bytes()) == oldspecs['src/llamaindex_retrieval/rwkv_pipeline.py']['sha256']
    _, ast_old = pure_functions(oldparser)
    assert ast_current == ast_old
    settings = SimpleNamespace(**{k:oldsettings[k] for k in ('native_plan_protocol','native_max_queries','native_max_fields')})
    assert vars(settings) == {'native_plan_protocol':'queries_fields','native_max_queries':6,'native_max_fields':12}
    groups, jobs = load(RUN/'cases.json'), load(RUN/'requests.json')
    assert [g['id'] for g in groups] == ['can','development']
    expected_jobs = []
    history = {}
    for group in groups:
        assert len(group['slots']) == len(group['payload']['contents']) == 8
        assert 'state_id' not in group['payload']
        history[group['id']] = []
        for index, slot in enumerate(group['slots']):
            assert index == slot['index']
            oldpath = OLD/slot['original_call_file']
            assert sha(oldpath.read_bytes()) == slot['original_call_sha256']
            old = load(oldpath)
            trace = old['trace']
            assert old['case_id'] == slot['case_id'] and trace['stage'] == slot['stage']
            assert trace['call_id'] == slot['call_id'] and trace['evidence_ids'] == slot['evidence_ids']
            assert old['status'] == 'completed' and trace['batch_index'] == index
            assert trace['batch_size'] == 8 and trace['batch_id'] == group['original_batch_id']
            assert old['run_binding']['manifest_sha256'] == sha((oldrun/'manifest.json').read_bytes())
            assert old['run_binding']['settings_sha256'] == sha((oldrun/'settings.json').read_bytes())
            wire = next(w for w in trace['http'] if w.get('batch_id') == group['original_batch_id'])
            request_raw, payload = body(wire,'request')
            response_raw, data = body(wire,'response')
            assert sha(request_raw) == group['original_request_sha256']
            assert sha(response_raw) == group['original_response_sha256']
            assert payload == group['payload']
            assert trace['parameters'] == {k:v for k,v in payload.items() if k!='contents'}
            assert payload['contents'][index] == trace['prompt']
            assert sha(trace['prompt'].encode()) == slot['prompt_sha256'] == trace['prompt_sha256']
            choice = choices(data,8,payload['model'])[index]
            raw = choice['message']['content']
            assert raw == old['raw_text'] == trace['raw_text'] == slot['original_raw_text']
            assert choice == trace['provider_choice']
            assert trace['prefill'] == '<think></think>'
            if slot['stage'] == 'resolver':
                units = loads(trace['messages'][0]['content'].rsplit('\n原文：',1)[1])
                assert list(units) == [f'E{i+1}' for i in range(slot['unit_count'])]
                assert all(isinstance(value,str) for value in units.values())
            history[group['id']].append({'classification':classify(raw,slot,functions,settings),
                                        'request_key_order':list(payload),'request_raw':request_raw})
        phases = [('batch-before',list(range(8))), *[(f'single-{i}',[i]) for i in range(8)], ('batch-after',list(range(8)))]
        for phase, indices in phases:
            expected_jobs.append({'id':f"{group['id']}-{phase}",'group':group['id'],'phase':phase,
                'indices':indices,'payload':{**group['payload'],'contents':[group['payload']['contents'][i] for i in indices]}})
    assert jobs == expected_jobs and len(jobs) == 20
    expected_files = {f'{j["id"]}.{event}.json' for j in jobs for event in ('started','completed')}
    assert {p.name for p in (RUN/'http').iterdir()} == expected_files
    byid, wirechecks, endings = {}, [], []
    previous_end = datetime.fromisoformat(started['started_at'])
    total_items = 0
    group_byid = {g['id']:g for g in groups}
    for job in jobs:
        start = load(RUN/'http'/f'{job["id"]}.started.json')
        end = load(RUN/'http'/f'{job["id"]}.completed.json')
        assert start['http_attempted'] is False and end['http_attempted'] is True
        assert start['payload'] == end['payload'] == job['payload']
        assert start['indices'] == end['indices'] == job['indices']
        assert start['id'] == end['id'] == job['id']
        for key in start:
            if key != 'http_attempted': assert start[key] == end[key], (job['id'],key)
        reqraw,payload = body(end,'request')
        assert base64.b64decode(start['request_body_base64'],validate=True) == reqraw
        raw,data = body(end,'response')
        assert end['http_status'] == 200 and end['status'] == 'completed' and end['response_body_complete'] is True
        assert end['termination_verified'] is False
        start_at,end_at = datetime.fromisoformat(start['started_at']),datetime.fromisoformat(end['completed_at'])
        assert previous_end <= start_at <= end_at
        previous_end = end_at
        values = choices(data,len(job['indices']),payload['model'])
        group = group_byid[job['group']]
        output=[]
        for original_index, choice in zip(job['indices'],values,strict=True):
            text = choice['message']['content']
            output.append({'original_index':original_index,'raw_text':text,'raw_sha256':sha(text.encode()),
                           'classification':classify(text,group['slots'][original_index],functions,settings)})
            endings.append(choice['finish_reason'])
        assert output == end['outputs']
        total_items += len(output)
        byid[job['id']] = end
        wirechecks.append({'id':job['id'],'http_status':200,'items':len(output),'elapsed_ms':end['elapsed_ms'],
                           'request_sha256':sha(reqraw),'response_sha256':sha(raw),
                           'payload_and_index_binding':True,'raw_to_classification_exact':True})
    assert previous_end <= datetime.fromisoformat(declared['completed_at'])
    comparisons, rows = [], []
    for group in groups:
        gid=group['id']
        for i,slot in enumerate(group['slots']):
            a=byid[f'{gid}-batch-before']['outputs'][i]
            b=byid[f'{gid}-single-{i}']['outputs'][0]
            a2=byid[f'{gid}-batch-after']['outputs'][i]
            comp={'group':gid,'index':i,'stage':slot['stage'],'case_id':slot['case_id'],
                  'batch_repeat_identical':a['raw_text']==a2['raw_text'],
                  'before_single_identical':a['raw_text']==b['raw_text'],
                  'after_single_identical':a2['raw_text']==b['raw_text'],
                  'historical_before_identical':slot['original_raw_text']==a['raw_text'],
                  'before':a['classification'],'single':b['classification'],'after':a2['classification']}
            comparisons.append(comp)
            current_req,_=body(byid[f'{gid}-batch-before'],'request')
            rows.append({**comp,'prompt_sha256':slot['prompt_sha256'],'original_call_file':slot['original_call_file'],
                         'historical':history[gid][i]['classification'],
                         'historical_raw_sha256':sha(slot['original_raw_text'].encode()),'current_raw_sha256':a['raw_sha256'],
                         'historical_request_bytes_identical':history[gid][i]['request_raw']==current_req,
                         'historical_payload_values_identical':True,
                         'historical_request_key_order':history[gid][i]['request_key_order'],
                         'current_request_key_order':list(group['payload'])})
    assert comparisons == declared['comparisons']
    for key,value in {'planned_http':20,'attempted_http':20,'completed_http':20,'model_items_returned':48,
                      'automatic_retries':0,'source_unchanged':True,'semantic_quality_scored':False}.items():
        assert declared[key] == value
    summaries=[]
    for group in groups:
        selected=[r for r in rows if r['group']==group['id']]
        summaries.append({'group':group['id'],'slots':len(selected),
            'historical_equal':sum(r['historical_before_identical'] for r in selected),
            'A_B_A_equal':sum(r['batch_repeat_identical'] and r['before_single_identical'] and r['after_single_identical'] for r in selected),
            'historical_kinds':dict(Counter(r['historical']['kind'] for r in selected)),
            'current_kinds_per_condition':dict(Counter(r['before']['kind'] for r in selected)),
            'historical_strict_selected_units':sum(len(r['historical'].get('selection',[])) for r in selected),
            'current_strict_selected_units_per_condition':sum(len(r['before'].get('selection',[])) for r in selected),
            'batch_before_after_response_body_identical':byid[f'{group["id"]}-batch-before']['response_body_sha256']==byid[f'{group["id"]}-batch-after']['response_body_sha256']})
    report={'status':'PASS','created_at':datetime.now(timezone.utc).isoformat(),'http':20,'items':total_items,'original_slots':16,
            'all_A_B_A_slot_bytes_identical':all(r['batch_repeat_identical'] and r['before_single_identical'] and r['after_single_identical'] for r in rows),
            'original_COMPLETED_exact_replay':True,'historical_strict_parser_AST_identical':True,
            'all_prompt_bytes_and_sampling_values_match_history':True,'historical_request_bytes_match':False,
            'actual_new_http_intervals_sequential':True,'provider_finish_reasons':dict(Counter(endings)),
            'termination_verified':False,'semantic_quality_scored':False,'groups':summaries,'rows':rows,'wire_checks':wirechecks,
            'wall_seconds':(datetime.fromisoformat(declared['completed_at'])-datetime.fromisoformat(started['started_at'])).total_seconds(),
            'limitations':['Only 16 unique slots from two old groups, not an end-to-end quality evaluation.',
                          'Historical objects were serialized with different JSON key order; values and prompt UTF-8 bytes match, complete request bodies do not.',
                          'URL is bound by frozen runner source; per-call receipts themselves omit URL/headers.',
                          'Current receipt set and single-loop runner show 20 attempts without automatic retries; this does not attest all provider activity.',
                          'Provider stop does not establish natural completion or generation-token usage.',
                          'History differs in time and surrounding provider workload; weights, revision, worker/state and implementation causes are unverified.'],
            'input_files':{str(p.relative_to(RUN)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(RUN.rglob('*')) if p.is_file() and OUT not in p.parents},
            'auditor_sha256':sha(Path(__file__).read_bytes())}
    with (OUT/'MECHANICAL-AUDIT.json').open('x') as stream:
        json.dump(report,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps({k:report[k] for k in ('status','http','items','original_slots','groups','wall_seconds')},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
