# Batch A/B/A 独立机械审计

审计 PASS：20 个顺序 HTTP、48 个返回项、16 个独立槽位，无遗漏或额外重试收据。A（batch8）→B（同8项依次 batch1）→A重复，两组共16槽位的原始输出 UTF-8 字节均完全一致；两次 batch8 的整个原始响应正文也分别一致。原 COMPLETED.json 的计数、每项分类和相等性全部由原始字节重算通过。整轮46.631秒，属于一致性检查，不作为吞吐基准。

| 原组 | 组成 | 本轮 A=B=A重复 | 相对历史输出相等 | 历史严格分类 | 本轮每臂严格分类 |
|---|---|---:|---:|---|---|
| can | 8个CAN Reader | 8/8 | 0/8 | 8个invalid | 7个NONE、1个invalid |
| development | 1个planner、7个Reader | 8/8 | 8/8 | planner invalid、7个NONE | 完全相同 |

本轮每臂严格格式通过14/16，均为Reader的NONE。历史7/16严格通过，也均为NONE。两边严格选中的E单元总数都为0。没有把NONE增加或非法输出中的答案值算成事实、引用或阅读质量改善；planner的代码围栏JSON仍按原严格合同失败，没有剥围栏救分。

请求核对：16份历史 model-call 收据逐文件 SHA、原 batch 请求与响应 SHA、实际 model、sampling字段、完整 prompt 字符与 UTF-8 SHA、slot/call/source ID均相符。新20个请求仅依预登记将 contents 取原8项或单项，原8项顺序不变，singleton响应 index=0映射回固定原槽位。每份 started/completed 原始 request/response base64、SHA、解析对象及输出投影均互相一致。解析函数从已固定源码 AST 单独加载；与历史实际快照的 parse_plan/parse_task_selections AST一致；Reader可用 E 范围从历史完整消息末尾的原文JSON独立恢复。

**历史与本轮的整个 request body 不逐字相同。** 历史 wire 对象键顺序与本轮从排序JSON加载后的顺序不同；解码后的完整参数对象和 prompt 原文相同。审计没有把这些不同的 request body SHA 写成“字节一致”。本轮 A与A重复的request body自身逐字相同。认证值未读取或记录；新收据未记录URL/headers，目标endpoint由已固定runner中的常量绑定。

当前可支持的结论：这16个输入在本轮顺序A/B/A中没有显示输出对 batch1/batch8 的敏感性；CAN组存在相对历史的输出漂移。这个小对照不证明一般批处理完全等价，也不能把历史漂移归因于远端权重、源码revision、worker/state、负载或JSON键顺序。部署身份与当时周边请求不可从这些记录独立认证。

全部48项提供方finish_reason=stop，但真实自然终止仍未验证，真实生成token数未知。本次未请求API、未做检索、未修改生产源码或任何旧run/评分文件。SOURCE-MANIFEST全部文件hash仍匹配。

可重放的审计代码：audit.py（纯本地；依赖原source-publication-v1、source-api-v1和wiki-api-v1-eos历史收据）。其输出采用独占创建，避免覆盖已有证据。MECHANICAL-AUDIT.json保留全部46个本轮根文件/HTTP收据的hash、逐项比较与限制；历史依赖由原cases.json中的文件SHA及run bindings固定。
