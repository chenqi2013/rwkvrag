
import copy
import json
import os
from pathlib import Path
from types import SimpleNamespace
from typing import Optional, Dict, Sequence, List, Literal
import logging
import torch.nn.functional as F

import torch
import torch.distributed
import transformers
from datasets import load_dataset
import numpy as np
from dataclasses import dataclass, field
from torch.utils.data import Dataset
# from transformers import AutoTokenizer, Rwkv6Config, Rwkv6Model, Rwkv6Tokenizer

#tokenizer = Rwkv6Tokenizer.from_pretrained("RWKV/v6-Finch-1B6-HF")

tokenizer_path = 'RWKV/rwkv-5-world-3b'
IGNORE_INDEX = -100
EOT_TOKEN = "\x17"

RWKV_PROMPT = "User: {instruction}\n\nAssistant: "


def _load_sft_source(data_file: str, split: str):
    expanded_path = os.path.abspath(os.path.expanduser(data_file))
    if os.path.isfile(expanded_path) and expanded_path.endswith((".json", ".jsonl")):
        return load_dataset("json", data_files=expanded_path, split=split)
    return load_dataset(data_file, split=split)



def _tokenize_fn(strings: Sequence[str], tokenizer: transformers.PreTrainedTokenizer) -> Dict:
    """Tokenize a list of strings."""
    tokenized_list = [tokenizer(text, max_length=tokenizer.model_max_length,truncation=True,)for text in strings]
    input_ids = labels = [np.array(tokenized.input_ids) for tokenized in tokenized_list]
    input_ids_lens = labels_lens = [len(tokenized.input_ids) for tokenized in tokenized_list]

    return dict(
        input_ids=input_ids,
        labels=labels,
        input_ids_lens=input_ids_lens,
        labels_lens=labels_lens,
    )

def preprocess(
    sources: Sequence[str],
    targets: Sequence[str],
    tokenizer: transformers.PreTrainedTokenizer,
) -> Dict:
    """Preprocess the data by tokenizing."""
    examples = [s + t for s, t in zip(sources, targets)]
    examples_tokenized, sources_tokenized = [_tokenize_fn(strings, tokenizer) for strings in (examples, sources)]
    input_ids = examples_tokenized["input_ids"]
    labels = copy.deepcopy(input_ids)
    for label, source_len in zip(labels, sources_tokenized["input_ids_lens"]):
        label[:source_len] = IGNORE_INDEX
    return dict(input_ids=input_ids, labels=labels)

def train_tokenize_function(examples, tokenizer, query, response):
    sources = [
        RWKV_PROMPT.format_map(dict(instruction=instruction))
        for instruction in examples[query]
    ]
    targets = [f"{output}\n{EOT_TOKEN}" for output in examples[response]]
    data_dict = preprocess(sources, targets, tokenizer)
    return data_dict

def sft_dataset(script_args):

    tokenizer = _load_tokenizer(
        getattr(script_args, "tokenizer_path", tokenizer_path),
        model_max_length=script_args.ctx_len,
    )
    if getattr(tokenizer, "pad_token", None) is None:
        tokenizer.pad_token = tokenizer.eos_token
    # logger.info("PAD Token:", tokenizer.pad_token, tokenizer.pad_token_id)
    # logger.info("BOS Token", tokenizer.bos_token, tokenizer.bos_token_id)
    # logger.info("EOS Token", tokenizer.eos_token, tokenizer.eos_token_id)

    raw_train_datasets = _load_sft_source(
        script_args.data_file, script_args.sft_split
    )

    # if script_args.local_rank > 0: 
    #     torch.distributed.barrier()
        
    train_dataset = raw_train_datasets.map(
        train_tokenize_function,
        batched=True,
        batch_size=3000,
        num_proc=max(1, min(os.cpu_count() or 1, 32)),
        remove_columns=raw_train_datasets.column_names,
        load_from_cache_file=True,
        desc="Running tokenizer on train dataset",
        fn_kwargs={"tokenizer": tokenizer, "query": script_args.sft_field[0], "response": script_args.sft_field[1]}
    )
    data_collator = DataCollatorForSupervisedDataset(tokenizer=tokenizer)
    data_module = data_collator(train_dataset)

    return (data_module["input_ids"], data_module["labels"], data_module["attention_mask"])


def load_tokenizer(script_args):
    tokenizer = _load_tokenizer(
        getattr(script_args, "tokenizer_path", tokenizer_path),
        model_max_length=script_args.ctx_len + 1,
    )
    if getattr(tokenizer, "pad_token", None) is None:
        tokenizer.pad_token = tokenizer.eos_token
    return tokenizer


class RWKVWorldTokenizer:
    def __init__(self, model_max_length: int):
        from rwkv.utils import PIPELINE

        self.pipeline = PIPELINE("rwkv6", "rwkv_vocab_v20230424")
        self.model_max_length = model_max_length
        self.pad_token_id = 0
        self.pad_token = "<pad>"
        self.eos_token = EOT_TOKEN

    def __call__(
        self,
        text: str,
        max_length: int | None = None,
        truncation: bool = False,
        add_special_tokens: bool = False,
    ):
        input_ids = self.pipeline.encode(text)
        limit = max_length or self.model_max_length
        if truncation and limit:
            input_ids = input_ids[:limit]
        return SimpleNamespace(input_ids=input_ids)


def _load_tokenizer(path: str, model_max_length: int):
    try:
        local_files_only = path.lower().startswith("rwkv/")
        return transformers.AutoTokenizer.from_pretrained(
            path,
            model_max_length=model_max_length,
            padding_side="right",
            use_fast=True,
            trust_remote_code=True,
            local_files_only=local_files_only,
        )
    except Exception as exc:
        if "rwkv" not in path.lower():
            raise
        print(
            "Falling back to local RWKV world tokenizer because "
            f"AutoTokenizer failed: {type(exc).__name__}"
        )
        return RWKVWorldTokenizer(model_max_length=model_max_length)


class LazyAgentSFTDataset(Dataset):
    def __init__(self, script_args):
        self.args = script_args
        self.tokenizer = load_tokenizer(script_args)
        self.query_field = (
            script_args.sft_field[0] if script_args.sft_field else "user"
        )
        self.response_field = (
            script_args.sft_field[1]
            if script_args.sft_field and len(script_args.sft_field) > 1
            else "assistant"
        )
        self.prompt_head_tokens = max(
            0, int(getattr(script_args, "agent_prompt_head_tokens", 2048))
        )
        self.records = list(_iter_local_json_records(script_args.data_file))
        if script_args.epoch_steps < len(self.records):
            self.records = self.records[: script_args.epoch_steps]

    def __len__(self):
        return len(self.records)

    def __getitem__(self, idx):
        row = self.records[idx]
        source = str(row[self.query_field])
        target = f"{row[self.response_field]}\n{EOT_TOKEN}"
        source_ids = self.tokenizer(source, add_special_tokens=False).input_ids
        target_ids = self.tokenizer(target, add_special_tokens=False).input_ids
        max_len = self.args.ctx_len + 1
        if len(target_ids) >= max_len:
            target_ids = target_ids[: max_len - 1]
        max_source_len = max(1, max_len - len(target_ids))
        source_ids = _truncate_source_ids(
            source_ids, max_source_len, self.prompt_head_tokens
        )
        input_ids = source_ids + target_ids
        labels = [IGNORE_INDEX] * len(source_ids) + list(target_ids)
        if len(input_ids) < 2:
            input_ids = input_ids + [self.tokenizer.pad_token_id]
            labels = labels + [IGNORE_INDEX]
        return {
            "input_ids": torch.tensor(input_ids[:-1], dtype=torch.long),
            "labels": torch.tensor(labels[1:], dtype=torch.long),
            "attention_mask": torch.ones(len(input_ids) - 1, dtype=torch.bool),
        }


class TokenizedAgentSFTDataset(Dataset):
    def __init__(self, script_args):
        from rwkvt.dataset.binidx import MMapIndexedDataset

        self.args = script_args
        prefix = str(Path(script_args.data_file).expanduser())
        self.inputs = MMapIndexedDataset(f"{prefix}.input", skip_warmup=True)
        self.labels = MMapIndexedDataset(f"{prefix}.label", skip_warmup=True)
        if len(self.inputs) != len(self.labels):
            raise ValueError(
                "agent_sft_binidx input/label length mismatch: "
                f"{len(self.inputs)} != {len(self.labels)}"
            )
        if script_args.epoch_steps < len(self.inputs):
            self.inputs = self.inputs.head(script_args.epoch_steps)
            self.labels = self.labels.head(script_args.epoch_steps)
        self.tokenizer = SimpleNamespace(pad_token_id=0)

    def __len__(self):
        return len(self.inputs)

    def __getitem__(self, idx):
        input_ids = torch.tensor(
            self.inputs[idx].astype(np.int64), dtype=torch.long
        )
        labels = torch.tensor(
            self.labels[idx].astype(np.int64), dtype=torch.long
        )
        return {
            "input_ids": input_ids,
            "labels": labels,
            "attention_mask": torch.ones(input_ids.shape[0], dtype=torch.bool),
        }


@dataclass
class DataCollatorForAgentSFT:
    tokenizer: transformers.PreTrainedTokenizer

    def __call__(
        self, instances: Sequence[Dict]
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        input_ids = [instance["input_ids"] for instance in instances]
        labels = [instance["labels"] for instance in instances]
        attention_mask = [instance["attention_mask"] for instance in instances]
        input_ids = torch.nn.utils.rnn.pad_sequence(
            input_ids,
            batch_first=True,
            padding_value=self.tokenizer.pad_token_id,
        )
        labels = torch.nn.utils.rnn.pad_sequence(
            labels, batch_first=True, padding_value=IGNORE_INDEX
        )
        attention_mask = torch.nn.utils.rnn.pad_sequence(
            attention_mask, batch_first=True, padding_value=0
        )
        return input_ids, labels, attention_mask


def _iter_local_json_records(data_file: str):
    expanded_path = Path(data_file).expanduser()
    if expanded_path.suffix == ".jsonl":
        with expanded_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if line:
                    yield json.loads(line)
        return
    with expanded_path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if isinstance(payload, list):
        yield from payload
    elif isinstance(payload, dict) and isinstance(payload.get("data"), list):
        yield from payload["data"]
    elif isinstance(payload, dict):
        yield payload
    else:
        raise ValueError(f"Unsupported SFT payload: {data_file}")


def _truncate_source_ids(
    source_ids: list[int], max_source_len: int, head_tokens: int
) -> list[int]:
    if len(source_ids) <= max_source_len:
        return source_ids
    if head_tokens <= 0:
        return source_ids[-max_source_len:]
    head_len = min(head_tokens, max_source_len)
    tail_len = max_source_len - head_len
    if tail_len <= 0:
        return source_ids[:head_len]
    return source_ids[:head_len] + source_ids[-tail_len:]


@dataclass
class DataCollatorForSupervisedDataset(object):
    """Collate examples for supervised fine-tuning."""
    tokenizer: transformers.PreTrainedTokenizer

    def __call__(self, instances: Sequence[Dict]) -> Dict[str, torch.Tensor]:
        input_ids, labels = tuple([instance[key] for instance in instances] for key in ("input_ids", "labels"))
        input_ids = [torch.tensor(x) for x in input_ids]
        input_ids = torch.nn.utils.rnn.pad_sequence(
            input_ids, batch_first=True, padding_value=self.tokenizer.pad_token_id
        )
        labels = [torch.tensor(x) for x in labels]
        labels = torch.nn.utils.rnn.pad_sequence(labels, batch_first=True, padding_value=IGNORE_INDEX)
        
        return dict(
            input_ids=input_ids,
            labels=labels,
            attention_mask=input_ids.ne(self.tokenizer.pad_token_id),
        )
# class Data():
#     model_name_or_path: str = "RWKV/rwkv-5-world-3b"
#     data_file :str = "/home/rwkv/JL/data/MetaMathQA"
#     sft_split: str = "train[:5000]"#field(default="train[:100000]", metadata={"help": "(`['train', 'test', 'eval']`):"})
#     sft_field: List[str] = ["query", "response"]#field(default=["query", "response"], metadata={"help": "Fields of dataset input and output."})
#     ctx_len: int = 100


# if __name__ == "__main__":
#     args = Data()
#     sft_dataset(args)
