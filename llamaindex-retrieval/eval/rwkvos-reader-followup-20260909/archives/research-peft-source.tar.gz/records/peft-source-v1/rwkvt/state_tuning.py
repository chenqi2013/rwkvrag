"""RWKV-7 state-tuning checkpoint validation and export helpers.

RWKV-PEFT stores ``time_state`` as ``[head, value, key]``.  The local vLLM
RWKV-7 recurrent state pool uses the same semantic layout.  The FLA training
wrapper transposes this parameter only at its public ``initial_state`` API
boundary; that implementation detail must not leak into checkpoint export.

Because value and key dimensions are normally both 64, shape checks cannot
detect an accidental transpose.  Metadata therefore records the semantic
axes and the serving export is deliberately an identity copy.
"""

from __future__ import annotations

import json
import os
import re
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import torch


STATE_CHECKPOINT_FORMAT = "rwkv7-state-tuning-v2"
STATE_KEY_PATTERN = "blocks.{layer}.att.time_state"
_STATE_KEY_RE = re.compile(r"^blocks\.(\d+)\.att\.time_state$")
_WRAPPER_PREFIXES = ("_forward_module.", "module.", "model.")


@dataclass(frozen=True)
class SavedStateCheckpoints:
    training_path: Path
    vllm_path: Path
    metadata_path: Path


def _strip_wrapper_prefixes(name: str) -> str:
    """Strip known leading framework wrappers without rewriting inner names."""
    changed = True
    while changed:
        changed = False
        for prefix in _WRAPPER_PREFIXES:
            if name.startswith(prefix):
                name = name[len(prefix) :]
                changed = True
                break
    return name


def is_state_tuning_key(name: str) -> bool:
    """Return whether ``name`` is exactly an RWKV block ``time_state`` key."""
    return _STATE_KEY_RE.fullmatch(_strip_wrapper_prefixes(name)) is not None


def unwrap_state_dict(checkpoint: Any) -> Mapping[str, Any]:
    """Accept a raw state dict or a Lightning-style ``state_dict`` wrapper."""
    if not isinstance(checkpoint, Mapping):
        raise TypeError(
            f"state checkpoint must be a mapping, got {type(checkpoint).__name__}"
        )
    nested = checkpoint.get("state_dict")
    if isinstance(nested, Mapping):
        return nested
    return checkpoint


def extract_state_tuning_state(
    checkpoint: Mapping[str, Any], expected_layers: int | None = None
) -> dict[str, torch.Tensor]:
    """Extract and strictly validate RWKV-7 ``time_state`` tensors.

    Returned tensors retain RWKV-PEFT's training layout ``[H, V, K]``.
    """
    checkpoint = unwrap_state_dict(checkpoint)
    by_layer: dict[int, tuple[str, torch.Tensor]] = {}

    for source_name, value in checkpoint.items():
        if not isinstance(source_name, str):
            continue
        normalized_name = _strip_wrapper_prefixes(source_name)
        match = _STATE_KEY_RE.fullmatch(normalized_name)
        if match is None:
            continue
        if not isinstance(value, torch.Tensor):
            raise TypeError(f"{source_name} must be a tensor")

        layer = int(match.group(1))
        if layer in by_layer:
            previous_name = by_layer[layer][0]
            raise ValueError(
                f"duplicate state for layer {layer}: {previous_name!r} and "
                f"{source_name!r}"
            )
        by_layer[layer] = (source_name, value)

    if not by_layer:
        raise ValueError(
            f"no state tensors matched {STATE_KEY_PATTERN!r} in checkpoint"
        )

    if expected_layers is not None:
        if expected_layers <= 0:
            raise ValueError("expected_layers must be positive")
        expected = set(range(expected_layers))
    else:
        expected = set(range(max(by_layer) + 1))

    actual = set(by_layer)
    missing = sorted(expected - actual)
    unexpected = sorted(actual - expected)
    if missing or unexpected:
        raise ValueError(
            "state layers are not the expected contiguous range: "
            f"missing={missing}, unexpected={unexpected}"
        )

    ordered: dict[str, torch.Tensor] = {}
    reference_shape: tuple[int, ...] | None = None
    reference_dtype: torch.dtype | None = None
    for layer in sorted(by_layer):
        source_name, tensor = by_layer[layer]
        if tensor.ndim != 3:
            raise ValueError(
                f"{source_name} must have rank 3 [H,V,K], got {tuple(tensor.shape)}"
            )
        shape = tuple(tensor.shape)
        if shape[-2] != shape[-1]:
            raise ValueError(
                f"{source_name} must have equal key/value sizes, got {shape}"
            )
        if reference_shape is None:
            reference_shape = shape
            reference_dtype = tensor.dtype
        elif shape != reference_shape:
            raise ValueError(
                f"inconsistent state shape at {source_name}: {shape} != "
                f"{reference_shape}"
            )
        elif tensor.dtype != reference_dtype:
            raise ValueError(
                f"inconsistent state dtype at {source_name}: {tensor.dtype} != "
                f"{reference_dtype}"
            )
        if not bool(torch.isfinite(tensor).all()):
            non_finite = int((~torch.isfinite(tensor)).sum().item())
            raise ValueError(
                f"{source_name} contains {non_finite} non-finite state values"
            )
        ordered[STATE_KEY_PATTERN.format(layer=layer)] = tensor

    return ordered


def _cpu_contiguous(tensor: torch.Tensor) -> torch.Tensor:
    return tensor.detach().to(device="cpu").contiguous().clone()


def training_state_dict(
    checkpoint: Mapping[str, Any], expected_layers: int | None = None
) -> dict[str, torch.Tensor]:
    """Materialize a portable RWKV-PEFT state dict in ``[H,V,K]`` layout."""
    state = extract_state_tuning_state(checkpoint, expected_layers)
    return {name: _cpu_contiguous(tensor) for name, tensor in state.items()}


def vllm_state_dict(
    checkpoint: Mapping[str, Any], expected_layers: int | None = None
) -> dict[str, torch.Tensor]:
    """Materialize a vLLM-ready state dict in canonical ``[H,V,K]`` layout."""
    state = extract_state_tuning_state(checkpoint, expected_layers)
    return {name: _cpu_contiguous(tensor) for name, tensor in state.items()}


def vllm_checkpoint_path(training_path: str | os.PathLike[str]) -> Path:
    path = Path(training_path)
    suffix = path.suffix or ".pth"
    stem = path.name[: -len(path.suffix)] if path.suffix else path.name
    return path.with_name(f"{stem}.vllm{suffix}")


def metadata_path(vllm_path: str | os.PathLike[str]) -> Path:
    return Path(vllm_path).with_suffix(".json")


def _atomic_torch_save(payload: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        torch.save(payload, temporary)
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def _atomic_json_save(payload: Mapping[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    try:
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def _metadata(
    state: Mapping[str, torch.Tensor],
    training_path: Path,
    vllm_path: Path,
) -> dict[str, Any]:
    first = next(iter(state.values()))
    return {
        "format": STATE_CHECKPOINT_FORMAT,
        "tensor_key_pattern": STATE_KEY_PATTERN,
        "training_layout": "[head,value,key]",
        "vllm_layout": "[head,value,key]",
        "conversion": "identity",
        "num_layers": len(state),
        "num_heads": first.shape[0],
        "head_size": first.shape[-1],
        "dtype": str(first.dtype).removeprefix("torch."),
        "training_checkpoint": training_path.name,
        "vllm_checkpoint": vllm_path.name,
    }


def save_state_checkpoint_pair(
    checkpoint: Mapping[str, Any],
    training_path: str | os.PathLike[str],
    expected_layers: int | None = None,
) -> SavedStateCheckpoints:
    """Save a training state plus an explicit identity-layout serving copy."""
    training_path = Path(training_path)
    vllm_path = vllm_checkpoint_path(training_path)
    sidecar_path = metadata_path(vllm_path)

    training_state = training_state_dict(checkpoint, expected_layers)
    canonical_state = vllm_state_dict(training_state, expected_layers)
    metadata = _metadata(training_state, training_path, vllm_path)

    _atomic_torch_save(training_state, training_path)
    _atomic_torch_save(canonical_state, vllm_path)
    _atomic_json_save(metadata, sidecar_path)
    return SavedStateCheckpoints(training_path, vllm_path, sidecar_path)


def convert_state_checkpoint_for_vllm(
    source_path: str | os.PathLike[str],
    output_path: str | os.PathLike[str] | None = None,
    expected_layers: int | None = None,
) -> SavedStateCheckpoints:
    """Validate and export an existing checkpoint without rewriting it."""
    source_path = Path(source_path)
    try:
        checkpoint = torch.load(source_path, map_location="cpu", weights_only=True)
    except TypeError:  # PyTorch versions before ``weights_only``.
        checkpoint = torch.load(source_path, map_location="cpu")

    training_state = training_state_dict(unwrap_state_dict(checkpoint), expected_layers)
    vllm_path = Path(output_path) if output_path else vllm_checkpoint_path(source_path)
    sidecar_path = metadata_path(vllm_path)
    canonical_state = vllm_state_dict(training_state, expected_layers)
    metadata = _metadata(training_state, source_path, vllm_path)

    _atomic_torch_save(canonical_state, vllm_path)
    _atomic_json_save(metadata, sidecar_path)
    return SavedStateCheckpoints(source_path, vllm_path, sidecar_path)
