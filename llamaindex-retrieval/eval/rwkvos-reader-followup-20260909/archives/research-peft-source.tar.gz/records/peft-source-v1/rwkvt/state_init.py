"""Fail-closed loading for RWKV state-tuning continuation checkpoints."""

from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Mapping

import torch


SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _model_state_parameters(model: torch.nn.Module) -> dict[str, torch.nn.Parameter]:
    return {
        name: parameter
        for name, parameter in model.named_parameters()
        if name.endswith(".time_state")
    }


def initialize_state_parameters(
    model: torch.nn.Module,
    checkpoint_path: str,
    expected_sha256: str,
    *,
    expected_tensor_count: int = 61,
    metadata_path: str = "",
) -> dict[str, Any]:
    """Load an exact state-only checkpoint after validating it completely."""

    path = Path(checkpoint_path).expanduser().resolve()
    expected_digest = str(expected_sha256 or "").strip().lower()
    if not path.is_file():
        raise FileNotFoundError(f"state_init checkpoint does not exist: {path}")
    if not SHA256_PATTERN.fullmatch(expected_digest):
        raise ValueError(
            "state_init_sha256 must be an explicit 64-character lowercase SHA-256"
        )
    actual_digest = sha256_file(path)
    if actual_digest != expected_digest:
        raise ValueError(
            f"state_init SHA-256 mismatch: expected {expected_digest}, got {actual_digest}"
        )

    checkpoint = torch.load(
        str(path), map_location="cpu", weights_only=True, mmap=True
    )
    if not isinstance(checkpoint, Mapping):
        raise TypeError("state_init checkpoint must be a tensor mapping")
    model_parameters = _model_state_parameters(model)
    expected_keys = set(model_parameters)
    checkpoint_keys = set(checkpoint)
    if len(model_parameters) != int(expected_tensor_count):
        raise ValueError(
            "model state tensor count mismatch: "
            f"expected {expected_tensor_count}, found {len(model_parameters)}"
        )
    missing = sorted(expected_keys - checkpoint_keys)
    unexpected = sorted(checkpoint_keys - expected_keys)
    if missing or unexpected:
        raise ValueError(
            f"state_init key mismatch: missing={missing[:8]}, "
            f"unexpected={unexpected[:8]}"
        )

    validated: dict[str, torch.Tensor] = {}
    squared_norm = 0.0
    max_abs = 0.0
    for name in sorted(expected_keys):
        value = checkpoint[name]
        parameter = model_parameters[name]
        if not isinstance(value, torch.Tensor):
            raise TypeError(f"state_init value is not a tensor: {name}")
        if tuple(value.shape) != tuple(parameter.shape):
            raise ValueError(
                f"state_init shape mismatch for {name}: "
                f"checkpoint={tuple(value.shape)} model={tuple(parameter.shape)}"
            )
        if not torch.isfinite(value).all().item():
            raise ValueError(f"state_init contains non-finite values: {name}")
        cpu_value = value.detach().to(device="cpu")
        validated[name] = cpu_value
        float_value = cpu_value.float()
        squared_norm += float(torch.sum(float_value * float_value).item())
        max_abs = max(max_abs, float(torch.max(torch.abs(float_value)).item()))
    if max_abs == 0.0:
        raise ValueError(
            "state_init is all zero and cannot be used as a continuation checkpoint"
        )

    with torch.no_grad():
        for name, value in validated.items():
            parameter = model_parameters[name]
            parameter.copy_(value.to(device=parameter.device, dtype=parameter.dtype))

    key_digest = hashlib.sha256("\n".join(sorted(expected_keys)).encode()).hexdigest()
    metadata = {
        "schema_version": "rwkv-state-init.v1",
        "checkpoint_path": str(path),
        "sha256": actual_digest,
        "state_tensor_count": len(validated),
        "state_key_set_sha256": key_digest,
        "state_l2_norm": squared_norm**0.5,
        "state_max_abs": max_abs,
        "validation": "sha256_keys_shapes_finite_nonzero",
    }
    if metadata_path:
        destination = Path(metadata_path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name(f"{destination.name}.tmp-{os.getpid()}")
        temporary.write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, destination)
    return metadata
