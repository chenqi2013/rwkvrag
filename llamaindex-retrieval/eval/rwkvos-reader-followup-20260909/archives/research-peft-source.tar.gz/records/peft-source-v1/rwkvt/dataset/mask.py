"""Next-token loss masks for conversational RWKV training data."""

import numpy as np
import torch


IGNORE_INDEX = -100


def _to_list(seq):
    if isinstance(seq, torch.Tensor):
        return seq.tolist()
    if isinstance(seq, np.ndarray):
        return seq.tolist()
    return list(seq)


def _find_subsequence_positions(seq, pattern, limit):
    if not pattern or limit < len(pattern):
        return []
    return [
        index
        for index in range(limit - len(pattern) + 1)
        if seq[index : index + len(pattern)] == pattern
    ]


def create_mask(seq, token1, token2, min_len):
    """Keep next-token labels only for assistant spans."""

    seq_list = _to_list(seq)
    upper = min(min_len, len(seq_list))
    labels = torch.full(
        (max(len(seq_list) - 1, 0),), IGNORE_INDEX, dtype=torch.long
    )
    if upper <= 1:
        return labels

    user_pattern = _to_list(token1)
    assistant_pattern = _to_list(token2)
    markers = []
    for position in _find_subsequence_positions(seq_list, user_pattern, upper):
        markers.append((position, "user", len(user_pattern)))
    for position in _find_subsequence_positions(
        seq_list, assistant_pattern, upper
    ):
        markers.append((position, "assistant", len(assistant_pattern)))
    markers.sort(key=lambda item: item[0])

    found_assistant = False
    for marker_index, (start, role, marker_len) in enumerate(markers):
        if role != "assistant":
            continue
        found_assistant = True
        content_start = max(start + marker_len, 1)
        content_end = (
            markers[marker_index + 1][0]
            if marker_index + 1 < len(markers)
            else upper
        )
        content_end = min(content_end, upper)
        if content_start < content_end:
            labels[content_start - 1 : content_end - 1] = torch.tensor(
                seq_list[content_start:content_end], dtype=torch.long
            )

    if not found_assistant:
        labels[: upper - 1] = torch.tensor(seq_list[1:upper], dtype=torch.long)

    return labels


def generate_mask(seq, token1, token2, min_len):
    return create_mask(seq, token1, token2, min_len)


mask_fn_dict = {
    "qa": create_mask,
    "se": generate_mask,
}
