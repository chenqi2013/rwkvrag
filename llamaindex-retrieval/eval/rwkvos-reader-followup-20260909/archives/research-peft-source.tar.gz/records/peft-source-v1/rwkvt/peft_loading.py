import os
import torch
import importlib
import json
from rwkvt.lightning_train.light_rwkv import RWKV
from rwkvt.args_type import TrainingArgs
from rwkvt.lightning_train.trainer import generate_init_weight
from rwkvt.state_init import initialize_state_parameters
from rwkvt.state_tuning import is_state_tuning_key
from accelerate import init_empty_weights

from peft import get_peft_model, LoraConfig, BoneConfig, MissConfig, TaskType
from peft import *
if "7" in os.environ["RWKV_MY_TESTING"]:
    from rwkvt.rwkv7.model import RWKV7 as RWKVModel
elif "6" in os.environ["RWKV_MY_TESTING"]:
    from rwkvt.rwkv6.model import RWKV6 as RWKVModel
elif "5" in os.environ["RWKV_MY_TESTING"]:
    from rwkvt.rwkv5.model import RWKV5 as RWKVModel
else:
    raise ValueError(f"Unsupported model version: . Valid options: 5,6,7")


class RWKVConfig:
    def __init__(self, n_embd=2048, n_layer=24):
        self.model_type = "rwkv"
        self.tie_word_embeddings = False
        self.n_embd = n_embd
        self.n_layer = n_layer

    def get(self, key, default=None):
        return getattr(self, key, default)

def load_peft_model(args: TrainingArgs):
    with init_empty_weights():
        model = RWKVModel(args)
    model = RWKVModel(args)
    state_dict = torch.load(args.load_model, map_location="cpu", weights_only=True, mmap=True)
    print(f"########## Loading {args.load_model}... ##########")
    model.load_state_dict(state_dict, strict=(not True), assign=True)
    if os.environ["RWKV_TRAIN_TYPE"] == 'state':
        state_init = str(getattr(args, "state_init", "") or "").strip()
        if int(getattr(args, "require_state_init", 0)) and not state_init:
            raise ValueError(
                "state continuation is required, but --state_init was not provided"
            )
        if state_init:
            metadata = initialize_state_parameters(
                model,
                state_init,
                str(getattr(args, "state_init_sha256", "") or ""),
                expected_tensor_count=int(
                    getattr(args, "state_init_expected_tensors", args.n_layer)
                ),
                metadata_path=os.path.join(
                    args.proj_dir, "state_init_metadata.json"
                ),
            )
            args.state_init_actual_sha256 = metadata["sha256"]
            args.state_init_state_tensor_count = metadata["state_tensor_count"]
            print(
                "########## Loaded verified state continuation "
                f"{metadata['checkpoint_path']} "
                f"({metadata['state_tensor_count']} tensors, "
                f"sha256={metadata['sha256']}) ##########"
            )
        elif str(getattr(args, "state_init_sha256", "") or "").strip():
            raise ValueError("--state_init_sha256 was provided without --state_init")

        model = RWKV(args, model=model)
        model.requires_grad_(False)
        trainable_state_names = []
        for name, param in model.named_parameters():
            if is_state_tuning_key(name):
                param.requires_grad = True
                trainable_state_names.append(name)
        if len(trainable_state_names) != args.n_layer:
            raise RuntimeError(
                "state tuning must expose exactly one time_state per layer: "
                f"expected {args.n_layer}, found {len(trainable_state_names)} "
                f"({trainable_state_names})"
            )
    elif args.peft!='none':
       
        model.config = RWKVConfig(n_embd=args.n_embd, n_layer=args.n_layer)

        # if args.peft == 'lora':
        #     peft_config = LoraConfig(
        #         task_type=TaskType.CAUSAL_LM,
        #         r=args.lora_config['lora_r'],
        #         lora_alpha=args.lora_config['lora_alpha'],
        #         lora_dropout=args.lora_config['lora_dropout'],
        #         target_modules=["receptance", "key", "value", "output"],
        #     )
        # elif args.peft == 'miss':
        #     peft_config = MissConfig(
        #     task_type=TaskType.CAUSAL_LM,
        #     r=args.miss_config['r'],
        #     target_modules=["receptance", "key", "value", "output"],
        # )
        
        # === 动态加载 PEFT Config 类 ===
        peft_dict={
            "lora": LoraConfig,
            "miss": MissConfig,
            "adalora": AdaLoraConfig,
            "prefix": PrefixTuningConfig,
        }
        ConfigClass = peft_dict[args.peft]

        peft_args = json.loads(args.peft_config)
        peft_kwargs = {
            "target_modules": ["receptance", "key", "value", "output"],
            **peft_args,
        }
        if args.train_type != "infctx":
            peft_kwargs["task_type"] = TaskType.CAUSAL_LM
        peft_config = ConfigClass(**peft_kwargs)

        model = get_peft_model(model, peft_config)
        model.print_trainable_parameters()
        model = RWKV(args, model=model)
    else:
        model = RWKV(args, model=model)


    return args, model
