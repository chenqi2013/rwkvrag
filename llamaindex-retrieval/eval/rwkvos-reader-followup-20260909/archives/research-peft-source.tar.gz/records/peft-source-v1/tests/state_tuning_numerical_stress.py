"""GPU stress comparison for RWKV-PEFT and vLLM RWKV-7 state layouts.

This is intentionally not collected by the default pytest suite.  It requires
both RWKV-PEFT's pinned ``rwkvfla`` package and the sibling vLLM RWKV runtime.
"""

from __future__ import annotations

import argparse
import json
import time
from dataclasses import asdict, dataclass

import torch
import torch.nn.functional as F

from rwkvt.state_tuning import vllm_state_dict


@dataclass(frozen=True)
class Scenario:
    name: str
    batch: int
    tokens: int
    heads: int
    head_size: int
    state_scale: float
    seed: int
    chunk_size: int


def _metrics(actual: torch.Tensor, expected: torch.Tensor) -> dict[str, float]:
    actual = actual.float()
    expected = expected.float()
    difference = actual - expected
    expected_norm = torch.linalg.vector_norm(expected).clamp_min(
        torch.finfo(torch.float32).tiny
    )
    return {
        "max_abs": float(difference.abs().max()),
        "relative_l2": float(torch.linalg.vector_norm(difference) / expected_norm),
        "cosine": float(
            F.cosine_similarity(actual.double().flatten(), expected.double().flatten(), dim=0)
        ),
    }


def _token_metrics(actual: torch.Tensor, expected: torch.Tensor) -> dict[str, float]:
    actual = actual.float()
    expected = expected.float()
    difference = actual - expected
    difference_norm = torch.linalg.vector_norm(difference, dim=(0, 2, 3))
    expected_norm = torch.linalg.vector_norm(expected, dim=(0, 2, 3)).clamp_min(
        torch.finfo(torch.float32).tiny
    )
    relative_l2 = difference_norm / expected_norm
    cosine = F.cosine_similarity(
        actual.double().permute(1, 0, 2, 3).flatten(1),
        expected.double().permute(1, 0, 2, 3).flatten(1),
        dim=1,
    )
    max_abs = difference.abs().amax(dim=(0, 2, 3))
    return {
        "first_relative_l2": float(relative_l2[0]),
        "last_relative_l2": float(relative_l2[-1]),
        "p50_relative_l2": float(torch.quantile(relative_l2, 0.50)),
        "p95_relative_l2": float(torch.quantile(relative_l2, 0.95)),
        "p99_relative_l2": float(torch.quantile(relative_l2, 0.99)),
        "max_relative_l2": float(relative_l2.max()),
        "max_relative_l2_token": int(relative_l2.argmax()),
        "min_cosine": float(cosine.min()),
        "min_cosine_token": int(cosine.argmin()),
        "max_abs": float(max_abs.max()),
        "max_abs_token": int(max_abs.argmax()),
    }


def _master_inputs(scenario: Scenario, device: torch.device):
    generator = torch.Generator(device=device).manual_seed(scenario.seed)
    shape = (
        scenario.batch,
        scenario.tokens,
        scenario.heads,
        scenario.head_size,
    )
    r = torch.randn(shape, generator=generator, device=device) * 0.45
    k = torch.randn(shape, generator=generator, device=device) * 0.35
    v = torch.randn(shape, generator=generator, device=device) * 0.55
    kk = F.normalize(
        torch.randn(shape, generator=generator, device=device), p=2.0, dim=-1
    )
    gate = torch.sigmoid(
        torch.randn(shape, generator=generator, device=device) * 1.4
    )
    a = -kk
    b = kk * gate
    decay_logits = torch.randn(shape, generator=generator, device=device) * 0.8
    decay_bias = torch.linspace(
        -11.625,
        7.90625,
        scenario.heads * scenario.head_size,
        device=device,
    ).reshape(scenario.heads, scenario.head_size)

    state_shape = (scenario.heads, scenario.head_size, scenario.head_size)
    random_state = torch.randn(state_shape, generator=generator, device=device)
    value_axis = torch.linspace(-1.0, 1.0, scenario.head_size, device=device)
    key_axis = torch.linspace(1.0, -0.5, scenario.head_size, device=device)
    asymmetric = value_axis[:, None] * 0.7 + key_axis[None, :] * 0.3
    training_state = scenario.state_scale * (
        random_state * 0.25 + asymmetric.unsqueeze(0)
    )
    return r, decay_logits, k, v, a, b, decay_bias, training_state


def _run_peft(
    old_chunk,
    tensors,
    scenario: Scenario,
) -> tuple[torch.Tensor, torch.Tensor]:
    r, decay_logits, k, v, a, b, decay_bias, training_state = tensors
    dtype = torch.bfloat16
    r, decay_logits, k, v, a, b = (
        tensor.to(dtype=dtype) for tensor in (r, decay_logits, k, v, a, b)
    )
    decay_bias = decay_bias.to(dtype=dtype)
    training_state = training_state.to(dtype=dtype)
    peft_decay = -F.softplus(-(decay_logits + decay_bias[None, None])) - 0.5
    initial_state = training_state.transpose(-2, -1).expand(
        scenario.batch, -1, -1, -1
    )
    output, final_state = old_chunk(
        r=r,
        k=k,
        v=v,
        a=a,
        b=b,
        w=peft_decay,
        scale=1.0,
        initial_state=initial_state,
        output_final_state=True,
        head_first=False,
    )
    return output, final_state


def _run_vllm(
    prepare_metadata,
    recurrent,
    tensors,
    scenario: Scenario,
    *,
    wrong_layout: bool = False,
    chunked: bool = False,
) -> tuple[torch.Tensor, torch.Tensor]:
    r, decay_logits, k, v, a, b, decay_bias, training_state = tensors
    dtype = torch.float16
    r, decay_logits, k, v, a, b = (
        tensor.to(dtype=dtype) for tensor in (r, decay_logits, k, v, a, b)
    )
    decay_bias = decay_bias.to(dtype=dtype)
    training_state = training_state.to(dtype=torch.bfloat16)
    if wrong_layout:
        canonical = training_state.transpose(-2, -1).float().contiguous()
    else:
        canonical = vllm_state_dict(
            {"blocks.0.att.time_state": training_state}, expected_layers=1
        )["blocks.0.att.time_state"].to(device=r.device, dtype=torch.float32)
    state_pool = canonical.unsqueeze(0).expand(scenario.batch, -1, -1, -1).clone()

    def run_part(start: int, end: int) -> torch.Tensor:
        length = end - start
        packed = [
            tensor[:, start:end].reshape(
                1, scenario.batch * length, scenario.heads, scenario.head_size
            ).contiguous()
            for tensor in (r, decay_logits, k, v, a, b)
        ]
        cu_seqlens = torch.arange(
            0,
            (scenario.batch + 1) * length,
            length,
            dtype=torch.int32,
            device=r.device,
        )
        state_indices = torch.arange(
            scenario.batch, dtype=torch.int32, device=r.device
        )
        validated = prepare_metadata(
            cu_seqlens,
            state_indices,
            total_tokens=scenario.batch * length,
            state_pool_size=scenario.batch,
        )
        output = recurrent(
            *packed,
            decay_bias=decay_bias,
            elapsed_t=None,
            validated_metadata=validated,
            state_pool=state_pool,
            cu_seqlens=cu_seqlens,
            state_indices=state_indices,
            mode="fp32io16",
        )
        return output.reshape(
            scenario.batch, length, scenario.heads, scenario.head_size
        )

    if not chunked:
        return run_part(0, scenario.tokens), state_pool

    outputs = []
    for start in range(0, scenario.tokens, scenario.chunk_size):
        outputs.append(run_part(start, min(start + scenario.chunk_size, scenario.tokens)))
    return torch.cat(outputs, dim=1), state_pool


def run_scenario(scenario: Scenario) -> dict[str, object]:
    from rwkvfla.ops.rwkv7 import chunk_rwkv7 as old_chunk
    from vllm.model_executor.models.rwkv7_wkv_backend import (
        prepare_fla_rwkv7_recurrent_metadata,
        run_fla_rwkv7_recurrent_from_decay_logits,
    )

    device = torch.device("cuda")
    torch.cuda.reset_peak_memory_stats(device)
    tensors = _master_inputs(scenario, device)
    start_time = time.perf_counter()
    with torch.inference_mode():
        peft_output, peft_state = _run_peft(old_chunk, tensors, scenario)
        vllm_output, vllm_state = _run_vllm(
            prepare_fla_rwkv7_recurrent_metadata,
            run_fla_rwkv7_recurrent_from_decay_logits,
            tensors,
            scenario,
        )
        chunked_output, chunked_state = _run_vllm(
            prepare_fla_rwkv7_recurrent_metadata,
            run_fla_rwkv7_recurrent_from_decay_logits,
            tensors,
            scenario,
            chunked=True,
        )
        wrong_output, _ = _run_vllm(
            prepare_fla_rwkv7_recurrent_metadata,
            run_fla_rwkv7_recurrent_from_decay_logits,
            tensors,
            scenario,
            wrong_layout=True,
        )
        torch.cuda.synchronize(device)

    result = {
        "scenario": asdict(scenario),
        "peft_bf16_vs_vllm_fp16": _metrics(vllm_output, peft_output),
        "per_token": _token_metrics(vllm_output, peft_output),
        "final_state": _metrics(vllm_state, peft_state),
        "vllm_chunked_vs_full": _metrics(chunked_output, vllm_output),
        "vllm_chunked_final_state": _metrics(chunked_state, vllm_state),
        "wrong_layout_vs_peft": _metrics(wrong_output, peft_output),
        "finite": {
            "peft_output": bool(torch.isfinite(peft_output).all()),
            "vllm_output": bool(torch.isfinite(vllm_output).all()),
            "peft_state": bool(torch.isfinite(peft_state).all()),
            "vllm_state": bool(torch.isfinite(vllm_state).all()),
        },
        "elapsed_seconds": time.perf_counter() - start_time,
        "peak_gpu_gib": torch.cuda.max_memory_allocated(device) / 1024**3,
    }
    if not all(result["finite"].values()):
        raise AssertionError(f"non-finite WKV result in {scenario.name}")
    correct_error = result["peft_bf16_vs_vllm_fp16"]["relative_l2"]
    if correct_error > 0.02:
        raise AssertionError(
            f"correct state layout drifted too far in {scenario.name}: {correct_error}"
        )
    chunk_error = result["vllm_chunked_vs_full"]["relative_l2"]
    if chunk_error > 1e-5:
        raise AssertionError(
            f"chunked WKV diverged from full execution in {scenario.name}: "
            f"{chunk_error}"
        )
    wrong_error = result["wrong_layout_vs_peft"]["relative_l2"]
    if scenario.state_scale > 0 and wrong_error <= correct_error * 5:
        raise AssertionError(
            f"wrong state layout was not clearly detected in {scenario.name}: "
            f"correct={correct_error}, wrong={wrong_error}"
        )
    del tensors, peft_output, peft_state, vllm_output, vllm_state
    del chunked_output, chunked_state, wrong_output
    torch.cuda.empty_cache()
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--layer-sweep", action="store_true")
    parser.add_argument("--summary-only", action="store_true")
    parser.add_argument("--output", help="optional JSON report path")
    parser.add_argument(
        "--scenario",
        action="append",
        help="run only the named scenario; may be supplied more than once",
    )
    args = parser.parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")

    if args.quick:
        scenarios = [Scenario("quick", 1, 64, 8, 64, 0.5, 71, 17)]
    elif args.layer_sweep:
        state_scales = (0.0, 0.001, 0.01, 0.1, 0.5, 1.0, 2.0, 4.0, 8.0)
        chunk_sizes = (1, 7, 31, 64, 127)
        scenarios = [
            Scenario(
                f"layer_{layer:02d}",
                1,
                256,
                64,
                64,
                state_scales[layer % len(state_scales)],
                710000 + layer,
                chunk_sizes[layer % len(chunk_sizes)],
            )
            for layer in range(61)
        ]
    else:
        scenarios = [
            Scenario("13b_ctx2496", 1, 2496, 64, 64, 0.5, 71, 256),
            Scenario("13b_high_state", 1, 2496, 64, 64, 4.0, 1701, 127),
            Scenario("batched_total2496", 4, 624, 64, 64, 1.0, 7104, 113),
            Scenario("decode_heavy", 8, 192, 64, 64, 2.0, 7188, 1),
        ]
    if args.scenario:
        requested = set(args.scenario)
        scenarios = [scenario for scenario in scenarios if scenario.name in requested]
        missing = requested - {scenario.name for scenario in scenarios}
        if missing:
            raise ValueError(f"unknown scenarios: {sorted(missing)}")

    report = {
        "torch": torch.__version__,
        "cuda": torch.version.cuda,
        "gpu": torch.cuda.get_device_name(0),
        "scenarios": [],
    }
    for scenario in scenarios:
        result = run_scenario(scenario)
        report["scenarios"].append(result)
        if not args.summary_only:
            print(json.dumps(result, sort_keys=True), flush=True)
    relative_l2 = [
        result["peft_bf16_vs_vllm_fp16"]["relative_l2"]
        for result in report["scenarios"]
    ]
    wrong_relative_l2 = [
        result["wrong_layout_vs_peft"]["relative_l2"]
        for result in report["scenarios"]
    ]
    report["summary"] = {
        "scenario_count": len(report["scenarios"]),
        "correct_relative_l2_mean": sum(relative_l2) / len(relative_l2),
        "correct_relative_l2_max": max(relative_l2),
        "correct_cosine_min": min(
            result["peft_bf16_vs_vllm_fp16"]["cosine"]
            for result in report["scenarios"]
        ),
        "wrong_relative_l2_mean": sum(wrong_relative_l2)
        / len(wrong_relative_l2),
        "wrong_relative_l2_max": max(wrong_relative_l2),
        "chunked_relative_l2_max": max(
            result["vllm_chunked_vs_full"]["relative_l2"]
            for result in report["scenarios"]
        ),
        "all_finite": all(
            all(result["finite"].values()) for result in report["scenarios"]
        ),
    }
    if args.output:
        from pathlib import Path

        Path(args.output).write_text(
            json.dumps(report, sort_keys=True, indent=2) + "\n", encoding="utf-8"
        )
    print(
        json.dumps(report["summary"] if args.summary_only else report, sort_keys=True),
        flush=True,
    )


if __name__ == "__main__":
    main()
