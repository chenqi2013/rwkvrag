import torch

from rwkvt.dataset.mask import IGNORE_INDEX, create_mask


def test_qa_mask_keeps_only_assistant_content_next_token_labels():
    user = [10, 11]
    assistant = [20, 21]
    sequence = torch.tensor(
        user + [1, 2] + assistant + [3, 4] + user + [5] + assistant + [6, 7]
    )

    labels = create_mask(sequence, user, assistant, len(sequence))

    expected = torch.full((len(sequence) - 1,), IGNORE_INDEX, dtype=torch.long)
    # Labels are shifted: label index n predicts source token n + 1.
    expected[5:7] = torch.tensor([3, 4])
    expected[12:14] = torch.tensor([6, 7])
    torch.testing.assert_close(labels, expected)


def test_qa_mask_falls_back_to_full_labels_without_role_markers():
    sequence = torch.tensor([1, 2, 3, 4])

    labels = create_mask(sequence, [10], [20], len(sequence))

    torch.testing.assert_close(labels, torch.tensor([2, 3, 4]))
