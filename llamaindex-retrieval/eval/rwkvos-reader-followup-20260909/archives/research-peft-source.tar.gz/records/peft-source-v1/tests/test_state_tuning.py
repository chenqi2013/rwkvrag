import json
import subprocess
import sys
from pathlib import Path

import pytest
import torch

from rwkvt.state_tuning import (
    convert_state_checkpoint_for_vllm,
    extract_state_tuning_state,
    is_state_tuning_key,
    save_state_checkpoint_pair,
    vllm_state_dict,
)


def _state(layer: int, offset: int = 0) -> tuple[str, torch.Tensor]:
    tensor = torch.arange(18, dtype=torch.float32).reshape(2, 3, 3) + offset
    return f"model.blocks.{layer}.att.time_state", tensor


def _load(path):
    try:
        return torch.load(path, map_location="cpu", weights_only=True)
    except TypeError:
        return torch.load(path, map_location="cpu")


def test_extracts_only_exact_time_state_keys_in_layer_order():
    key1, state1 = _state(1, 100)
    key0, state0 = _state(0)
    checkpoint = {
        key1: state1,
        "model.blocks.0.att.state_projection.weight": torch.ones(3, 3),
        "model.some_state": torch.ones(1),
        key0: state0,
    }

    extracted = extract_state_tuning_state(checkpoint, expected_layers=2)

    assert list(extracted) == [
        "blocks.0.att.time_state",
        "blocks.1.att.time_state",
    ]
    assert extracted["blocks.0.att.time_state"] is state0
    assert extracted["blocks.1.att.time_state"] is state1


def test_state_parameter_selector_is_exact():
    assert is_state_tuning_key("model.blocks.12.att.time_state")
    assert is_state_tuning_key("module.model.blocks.0.att.time_state")
    assert not is_state_tuning_key("model.blocks.0.att.state_projection.weight")
    assert not is_state_tuning_key("model.some_state")


def test_vllm_export_preserves_square_non_symmetric_state_orientation():
    key, training_state = _state(0)

    canonical = vllm_state_dict({key: training_state}, expected_layers=1)[
        "blocks.0.att.time_state"
    ]

    assert canonical.is_contiguous()
    torch.testing.assert_close(canonical, training_state)
    assert canonical[0, 1, 2].item() == training_state[0, 1, 2].item()
    assert canonical[0, 1, 2].item() != training_state[0, 2, 1].item()


def test_identity_state_matches_value_key_recurrence_orientation():
    key, training_state = _state(0)
    canonical = vllm_state_dict({key: training_state})[
        "blocks.0.att.time_state"
    ]
    receptance = torch.tensor([0.25, -0.5, 1.0])

    expected = torch.einsum("k,hvk->hv", receptance, training_state)
    actual = torch.einsum("k,hvk->hv", receptance, canonical)
    wrong = torch.einsum(
        "k,hvk->hv", receptance, training_state.transpose(-2, -1)
    )

    torch.testing.assert_close(actual, expected)
    assert not torch.allclose(wrong, expected)


@pytest.mark.parametrize(
    "checkpoint, message",
    [
        (
            {"model.blocks.1.att.time_state": torch.zeros(2, 3, 3)},
            "missing=\\[0\\]",
        ),
        (
            {
                "model.blocks.0.att.time_state": torch.zeros(2, 3, 3),
                "model.blocks.1.att.time_state": torch.zeros(2, 4, 4),
            },
            "inconsistent state shape",
        ),
        (
            {"model.blocks.0.att.time_state": torch.zeros(2, 3, 4)},
            "equal key/value sizes",
        ),
        (
            {
                "model.blocks.0.att.time_state": torch.tensor(
                    [[[0.0, float("nan")], [float("inf"), 1.0]]]
                )
            },
            "contains 2 non-finite state values",
        ),
    ],
)
def test_rejects_incomplete_or_incompatible_state(checkpoint, message):
    with pytest.raises(ValueError, match=message):
        extract_state_tuning_state(checkpoint)


def test_pair_save_keeps_training_layout_and_emits_vllm_sidecar(tmp_path):
    key0, state0 = _state(0)
    key1, state1 = _state(1, 100)
    training_path = tmp_path / "rwkv-step-20.pth"

    saved = save_state_checkpoint_pair(
        {key0: state0, key1: state1}, training_path, expected_layers=2
    )

    assert saved.training_path == training_path
    assert saved.vllm_path == tmp_path / "rwkv-step-20.vllm.pth"
    assert saved.metadata_path == tmp_path / "rwkv-step-20.vllm.json"
    raw = _load(saved.training_path)
    canonical = _load(saved.vllm_path)
    torch.testing.assert_close(raw["blocks.0.att.time_state"], state0)
    torch.testing.assert_close(
        canonical["blocks.0.att.time_state"], state0
    )

    metadata = json.loads(saved.metadata_path.read_text(encoding="utf-8"))
    assert metadata["format"] == "rwkv7-state-tuning-v2"
    assert metadata["training_layout"] == "[head,value,key]"
    assert metadata["vllm_layout"] == "[head,value,key]"
    assert metadata["conversion"] == "identity"
    assert metadata["num_layers"] == 2


def test_existing_checkpoint_conversion_does_not_rewrite_source(tmp_path):
    key, state = _state(0)
    source = tmp_path / "existing.pth"
    torch.save({key: state}, source)
    source_bytes = source.read_bytes()

    saved = convert_state_checkpoint_for_vllm(source, expected_layers=1)

    assert source.read_bytes() == source_bytes
    canonical = _load(saved.vllm_path)
    torch.testing.assert_close(
        canonical["blocks.0.att.time_state"], state
    )


def test_13b_scale_checkpoint_pair_preserves_all_61_layers(tmp_path):
    layers = 61
    heads = 64
    head_size = 64
    base = torch.arange(
        heads * head_size * head_size, dtype=torch.float32
    ).reshape(heads, head_size, head_size)
    base = ((base.remainder(2047) - 1023) / 128).to(torch.bfloat16)
    checkpoint = {
        f"model.blocks.{layer}.att.time_state": (base + layer / 16).contiguous()
        for layer in range(layers)
    }
    training_path = tmp_path / "rwkv-13b-state.pth"

    saved = save_state_checkpoint_pair(
        checkpoint, training_path, expected_layers=layers
    )

    raw = _load(saved.training_path)
    canonical = _load(saved.vllm_path)
    assert len(raw) == layers
    assert len(canonical) == layers
    for layer in (0, 1, 30, 59, 60):
        name = f"blocks.{layer}.att.time_state"
        assert raw[name].shape == (heads, head_size, head_size)
        assert raw[name].dtype == torch.bfloat16
        torch.testing.assert_close(canonical[name], raw[name])
        assert canonical[name].is_contiguous()


def test_conversion_cli_runs_end_to_end(tmp_path):
    key0, state0 = _state(0)
    key1, state1 = _state(1, 100)
    source = tmp_path / "cli-source.pth"
    output = tmp_path / "explicit-serving-state.pth"
    torch.save({key0: state0, key1: state1}, source)

    completed = subprocess.run(
        [
            sys.executable,
            str(Path(__file__).parents[1] / "convert_state_for_vllm.py"),
            str(source),
            "--output",
            str(output),
            "--expected-layers",
            "2",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    assert "source unchanged:" in completed.stdout
    assert "vLLM-ready state:" in completed.stdout
    converted = _load(output)
    torch.testing.assert_close(
        converted["blocks.1.att.time_state"], state1
    )
    assert output.with_suffix(".json").is_file()


def test_atomic_save_failure_preserves_existing_checkpoint(tmp_path, monkeypatch):
    import rwkvt.state_tuning as state_tuning

    key, state = _state(0)
    destination = tmp_path / "existing.pth"
    destination.write_bytes(b"known-good-checkpoint")

    def fail_after_partial_write(_payload, path):
        Path(path).write_bytes(b"partial")
        raise OSError("injected serialization failure")

    monkeypatch.setattr(state_tuning.torch, "save", fail_after_partial_write)
    with pytest.raises(OSError, match="injected serialization failure"):
        save_state_checkpoint_pair({key: state}, destination, expected_layers=1)

    assert destination.read_bytes() == b"known-good-checkpoint"
    assert not list(tmp_path.glob(".*.tmp-*"))


def test_randomized_layout_conversion_is_exact_for_100_checkpoints():
    generator = torch.Generator().manual_seed(710100)
    dtypes = (torch.float16, torch.bfloat16, torch.float32)

    for iteration in range(100):
        layers = 1 + iteration % 7
        heads = 1 + iteration % 9
        head_size = 2 + iteration % 16
        dtype = dtypes[iteration % len(dtypes)]
        checkpoint = {}
        for layer in range(layers):
            state = torch.randn(
                heads,
                head_size,
                head_size,
                generator=generator,
                dtype=torch.float32,
            )
            state = (state * (1 + iteration) + layer * 0.125).to(dtype)
            checkpoint[f"module.model.blocks.{layer}.att.time_state"] = state

        converted = vllm_state_dict(checkpoint, expected_layers=layers)

        for layer in range(layers):
            source = checkpoint[
                f"module.model.blocks.{layer}.att.time_state"
            ]
            actual = converted[f"blocks.{layer}.att.time_state"]
            torch.testing.assert_close(
                actual, source, rtol=0, atol=0
            )
            assert actual.dtype == dtype
            assert actual.device.type == "cpu"
            assert actual.is_contiguous()
