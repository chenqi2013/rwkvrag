from __future__ import annotations

import json
from pathlib import Path

import pytest
import torch

from rwkvt.state_init import initialize_state_parameters, sha256_file


class _Attention(torch.nn.Module):
    def __init__(self, size: int = 3):
        super().__init__()
        self.time_state = torch.nn.Parameter(torch.zeros(size, size))


class _Block(torch.nn.Module):
    def __init__(self, size: int = 3):
        super().__init__()
        self.att = _Attention(size)


class _TinyStateModel(torch.nn.Module):
    def __init__(self, count: int = 2, size: int = 3):
        super().__init__()
        self.blocks = torch.nn.ModuleList([_Block(size) for _ in range(count)])
        self.other = torch.nn.Parameter(torch.full((1,), 9.0))


def _checkpoint(
    path: Path, *, count: int = 2, size: int = 3
) -> dict[str, torch.Tensor]:
    payload = {
        f"blocks.{index}.att.time_state": torch.full(
            (size, size), float(index + 1), dtype=torch.bfloat16
        )
        for index in range(count)
    }
    torch.save(payload, path)
    return payload


def test_loads_verified_state_without_touching_other_parameters(tmp_path: Path):
    checkpoint_path = tmp_path / "state.pth"
    payload = _checkpoint(checkpoint_path)
    model = _TinyStateModel()
    metadata_path = tmp_path / "run/state_init_metadata.json"

    metadata = initialize_state_parameters(
        model,
        str(checkpoint_path),
        sha256_file(checkpoint_path),
        expected_tensor_count=2,
        metadata_path=str(metadata_path),
    )

    assert metadata["state_tensor_count"] == 2
    assert metadata["state_max_abs"] == 2.0
    assert json.loads(metadata_path.read_text())["sha256"] == sha256_file(
        checkpoint_path
    )
    assert torch.equal(
        model.blocks[0].att.time_state, payload["blocks.0.att.time_state"]
    )
    assert torch.equal(
        model.blocks[1].att.time_state, payload["blocks.1.att.time_state"]
    )
    assert model.other.item() == 9.0


def test_rejects_wrong_sha_before_mutating_model(tmp_path: Path):
    checkpoint_path = tmp_path / "state.pth"
    _checkpoint(checkpoint_path)
    model = _TinyStateModel()

    with pytest.raises(ValueError, match="SHA-256 mismatch"):
        initialize_state_parameters(
            model,
            str(checkpoint_path),
            "0" * 64,
            expected_tensor_count=2,
        )
    assert torch.count_nonzero(model.blocks[0].att.time_state).item() == 0


@pytest.mark.parametrize(
    "mode", ["missing_key", "unexpected_key", "wrong_shape", "all_zero"]
)
def test_rejects_incompatible_state_payload(tmp_path: Path, mode: str):
    checkpoint_path = tmp_path / f"{mode}.pth"
    payload = _checkpoint(checkpoint_path)
    if mode == "missing_key":
        payload.pop("blocks.1.att.time_state")
    elif mode == "unexpected_key":
        payload["blocks.2.att.time_state"] = torch.ones(3, 3)
    elif mode == "wrong_shape":
        payload["blocks.1.att.time_state"] = torch.ones(4, 3)
    else:
        payload = {name: torch.zeros_like(value) for name, value in payload.items()}
    torch.save(payload, checkpoint_path)

    with pytest.raises((ValueError, TypeError)):
        initialize_state_parameters(
            _TinyStateModel(),
            str(checkpoint_path),
            sha256_file(checkpoint_path),
            expected_tensor_count=2,
        )
