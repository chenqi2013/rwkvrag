"""End-to-end RWKV-7 state-tuning numerical alignment on a real checkpoint.

The reference path uses RWKV-PEFT's pinned ``rwkvfla`` chunk operator with
BF16 weights/activations.  The serving path uses the pinned FlashRWKV recurrent
operator with FP16 weights/activations and an FP32 state pool, matching vLLM's
``fp32io16`` execution contract.
"""

from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

import torch
import torch.nn.functional as F

from rwkvt.state_tuning import vllm_state_dict


def _metrics(actual: torch.Tensor, expected: torch.Tensor) -> dict[str, float]:
    actual = actual.float()
    expected = expected.float()
    difference = actual - expected
    denominator = torch.linalg.vector_norm(expected).clamp_min(
        torch.finfo(torch.float32).tiny
    )
    return {
        "max_abs": float(difference.abs().max()),
        "relative_l2": float(torch.linalg.vector_norm(difference) / denominator),
        "cosine": float(
            F.cosine_similarity(actual.double().flatten(), expected.double().flatten(), dim=0)
        ),
    }


def _token_metrics(actual: torch.Tensor, expected: torch.Tensor) -> dict[str, object]:
    actual = actual.float().squeeze(0)
    expected = expected.float().squeeze(0)
    difference = actual - expected
    relative_l2 = torch.linalg.vector_norm(difference, dim=-1) / torch.linalg.vector_norm(
        expected, dim=-1
    ).clamp_min(torch.finfo(torch.float32).tiny)
    cosine = F.cosine_similarity(actual.double(), expected.double(), dim=-1)
    top1_match = actual.argmax(dim=-1) == expected.argmax(dim=-1)
    mismatches = (~top1_match).nonzero().flatten()
    return {
        "first_relative_l2": float(relative_l2[0]),
        "last_relative_l2": float(relative_l2[-1]),
        "p50_relative_l2": float(torch.quantile(relative_l2, 0.50)),
        "p95_relative_l2": float(torch.quantile(relative_l2, 0.95)),
        "p99_relative_l2": float(torch.quantile(relative_l2, 0.99)),
        "max_relative_l2": float(relative_l2.max()),
        "max_relative_l2_token": int(relative_l2.argmax()),
        "min_cosine": float(cosine.min()),
        "min_cosine_token": int(cosine.argmin()),
        "top1_match_rate": float(top1_match.float().mean()),
        "first_top1_mismatch": int(mismatches[0]) if mismatches.numel() else None,
    }


def _old_rwkv_flash(old_chunk):
    def run(
        receptance,
        decay_logits,
        key,
        value,
        a,
        b,
        state,
        head_size,
        *,
        decay_bias=None,
        **_kwargs,
    ):
        batch, tokens, hidden = receptance.shape
        heads = hidden // head_size
        if decay_bias is not None:
            decay_logits = decay_logits + decay_bias.reshape(1, 1, hidden)
        peft_decay = -F.softplus(-decay_logits) - 0.5
        tensors = [
            tensor.reshape(batch, tokens, heads, head_size).contiguous()
            for tensor in (receptance, key, value, a, b)
        ]
        output, final_state = old_chunk(
            r=tensors[0],
            k=tensors[1],
            v=tensors[2],
            a=tensors[3],
            b=tensors[4],
            w=peft_decay.reshape(batch, tokens, heads, head_size).contiguous(),
            initial_state=state,
            output_final_state=True,
            scale=1.0,
            head_first=False,
        )
        return output.reshape(batch, tokens, hidden), final_state

    return run


def _prompt_tokens(model_path: Path, target_tokens: int, device: torch.device):
    from vllm.tokenizers.rwkv import RWKVTokenizer

    tokenizer = RWKVTokenizer.from_pretrained(str(model_path))
    text = (
        "User: 请分析下面这段程序的状态管理、数值稳定性和并发行为，并给出修复建议。\n"
        "The same recurrent state must produce equivalent token logits across runtimes.\n"
        "Assistant: 我会逐层检查 time-mix、WKV state、dtype 和 token 边界。\n"
    )
    unit = tokenizer.encode(text, add_special_tokens=False)
    token_ids = ([0] + unit * (target_tokens // len(unit) + 2))[:target_tokens]
    return torch.tensor([token_ids], dtype=torch.long, device=device)


def _initial_states(model, state_scale: float, device: torch.device):
    config = model.config
    layers = config.num_hidden_layers
    heads = config.num_attention_heads
    head_size = config.head_size
    hidden = config.hidden_size
    generator = torch.Generator(device=device).manual_seed(710024)
    random_state = torch.randn(
        layers, heads, head_size, head_size, generator=generator, device=device
    )
    value_axis = torch.linspace(-1.0, 1.0, head_size, device=device)
    key_axis = torch.linspace(0.75, -0.25, head_size, device=device)
    asymmetric = value_axis[:, None] * 0.8 + key_axis[None, :] * 0.2
    layer_scale = torch.linspace(0.25, 1.0, layers, device=device)[:, None, None, None]
    training_state = (
        state_scale
        * layer_scale
        * (random_state * 0.2 + asymmetric[None, None])
    ).to(torch.bfloat16)

    checkpoint = {
        f"model.blocks.{layer}.att.time_state": training_state[layer]
        for layer in range(layers)
    }
    exported = vllm_state_dict(checkpoint, expected_layers=layers)
    canonical = torch.stack(
        [exported[f"blocks.{layer}.att.time_state"] for layer in range(layers)]
    ).unsqueeze(1)
    canonical = canonical.to(device=device, dtype=torch.float32)
    old_canonical = training_state.transpose(-2, -1).unsqueeze(1)
    wrong = training_state.transpose(-2, -1).unsqueeze(1).float()
    old_state = (
        torch.zeros(layers, 1, hidden, dtype=torch.bfloat16, device=device),
        old_canonical,
        torch.zeros(layers, 1, hidden, dtype=torch.bfloat16, device=device),
    )
    vllm_state = (
        torch.zeros(layers, 1, hidden, dtype=torch.float16, device=device),
        canonical,
        torch.zeros(layers, 1, hidden, dtype=torch.float16, device=device),
    )
    wrong_state = (vllm_state[0].clone(), wrong, vllm_state[2].clone())
    return old_state, vllm_state, wrong_state


def _set_trace(model, enabled: bool):
    for block in model.model.blocks:
        block.att._rwkv7_trace = [] if enabled else None


def _take_trace(model):
    trace = []
    for block in model.model.blocks:
        entry = block.att._rwkv7_trace[0]
        trace.append(
            {
                "wkv_output": entry["wkv_output"].detach().cpu(),
                "layer_output": entry["layer_output"].detach().cpu(),
                "final_state": entry["final_state"].detach().cpu(),
            }
        )
        block.att._rwkv7_trace = None
    return trace


def _replay_identical_inputs(model, native_flash):
    correct = []
    wrong = []
    with torch.inference_mode():
        for layer, block in enumerate(model.model.blocks):
            entry = block.att._rwkv7_trace[0]
            arguments = (
                entry["receptance"],
                entry["decay_logits"],
                entry["key"],
                entry["value"],
                entry["a"],
                entry["b"],
            )
            initial_state = entry["initial_state"].float().contiguous()
            output, final_state = native_flash(
                *arguments,
                initial_state.clone(),
                model.config.head_size,
                decay_bias=None,
            )
            wrong_output, wrong_state = native_flash(
                *arguments,
                initial_state.transpose(-2, -1).contiguous(),
                model.config.head_size,
                decay_bias=None,
            )
            correct.append(
                {
                    "layer": layer,
                    "wkv_output": _metrics(output, entry["wkv_output"]),
                    "final_state": _metrics(final_state, entry["final_state"]),
                }
            )
            wrong.append(
                {
                    "layer": layer,
                    "wkv_output": _metrics(wrong_output, entry["wkv_output"]),
                    "final_state": _metrics(wrong_state, entry["final_state"]),
                }
            )
    return correct, wrong


def _clone_state(state):
    return tuple(tensor.clone() for tensor in state)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model",
        default=os.environ.get("RWKV7_STRESS_MODEL"),
        help="local RWKV7 Hugging Face artifact (or set RWKV7_STRESS_MODEL)",
    )
    parser.add_argument("--tokens", type=int, default=512)
    parser.add_argument("--chunk-size", type=int, default=127)
    parser.add_argument("--state-scale", type=float, default=2.0)
    parser.add_argument("--output", help="optional JSON report path")
    args = parser.parse_args()

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    if not args.model:
        raise ValueError("--model or RWKV7_STRESS_MODEL is required")
    import transformers.models.rwkv7.modeling_rwkv7 as modeling_rwkv7
    from transformers.models.rwkv7.modeling_rwkv7 import Rwkv7ForCausalLM
    from rwkvfla.ops.rwkv7 import chunk_rwkv7 as old_chunk

    device = torch.device("cuda")
    model_path = Path(args.model)
    torch.cuda.reset_peak_memory_stats(device)
    started = time.perf_counter()
    model = Rwkv7ForCausalLM.from_pretrained(
        model_path,
        dtype=torch.bfloat16,
        trust_remote_code=False,
        local_files_only=True,
    ).eval().to(device)
    input_ids = _prompt_tokens(model_path, args.tokens, device)
    old_state, current_state, wrong_state = _initial_states(
        model, args.state_scale, device
    )

    native_flash = modeling_rwkv7._rwkv7_flash
    modeling_rwkv7._rwkv7_flash = _old_rwkv_flash(old_chunk)
    _set_trace(model, True)
    with torch.inference_mode():
        old_result = model(
            input_ids=input_ids,
            state=_clone_state(old_state),
            use_cache=True,
        )
        torch.cuda.synchronize(device)
    old_logits = old_result.logits.detach().cpu()
    old_final_wkv = old_result.state[1].detach().cpu()
    modeling_rwkv7._rwkv7_flash = native_flash
    identical_input_alignment, identical_input_wrong = _replay_identical_inputs(
        model, native_flash
    )
    old_trace = _take_trace(model)
    del old_result, old_state
    torch.cuda.empty_cache()

    same_dtype_state = (
        current_state[0].to(torch.bfloat16),
        current_state[1],
        current_state[2].to(torch.bfloat16),
    )
    with torch.inference_mode():
        same_dtype_result = model(
            input_ids=input_ids,
            state=_clone_state(same_dtype_state),
            use_cache=True,
        )
        torch.cuda.synchronize(device)
    same_dtype_logits = same_dtype_result.logits.detach().cpu()
    same_dtype_final_wkv = same_dtype_result.state[1].detach().cpu()
    del same_dtype_result, same_dtype_state
    torch.cuda.empty_cache()

    model.half()
    _set_trace(model, True)
    with torch.inference_mode():
        current_result = model(
            input_ids=input_ids,
            state=_clone_state(current_state),
            use_cache=True,
        )
        torch.cuda.synchronize(device)
    current_logits = current_result.logits.detach().cpu()
    current_final_wkv = current_result.state[1].detach().cpu()
    current_trace = _take_trace(model)
    del current_result
    torch.cuda.empty_cache()

    layer_metrics = []
    for layer, (actual, expected) in enumerate(zip(current_trace, old_trace, strict=True)):
        layer_metrics.append(
            {
                "layer": layer,
                "wkv_output": _metrics(actual["wkv_output"], expected["wkv_output"]),
                "layer_output": _metrics(actual["layer_output"], expected["layer_output"]),
                "final_state": _metrics(actual["final_state"], expected["final_state"]),
            }
        )
    del current_trace, old_trace

    with torch.inference_mode():
        chunk_state = _clone_state(current_state)
        chunk_logits = []
        for start in range(0, args.tokens, args.chunk_size):
            result = model(
                input_ids=input_ids[:, start : start + args.chunk_size],
                state=chunk_state,
                use_cache=True,
            )
            chunk_logits.append(result.logits.detach().cpu())
            chunk_state = result.state
        chunk_logits = torch.cat(chunk_logits, dim=1)
        chunk_final_wkv = chunk_state[1].detach().cpu()

        wrong_result = model(
            input_ids=input_ids,
            state=_clone_state(wrong_state),
            use_cache=True,
        )
        wrong_logits = wrong_result.logits.detach().cpu()
        torch.cuda.synchronize(device)

    report = {
        "model": str(model_path),
        "checkpoint": {
            "layers": model.config.num_hidden_layers,
            "hidden_size": model.config.hidden_size,
            "heads": model.config.num_attention_heads,
            "head_size": model.config.head_size,
            "vocab_size": model.config.vocab_size,
        },
        "tokens": args.tokens,
        "chunk_size": args.chunk_size,
        "state_scale": args.state_scale,
        "logits": _metrics(current_logits, old_logits),
        "logits_per_token": _token_metrics(current_logits, old_logits),
        "final_wkv_state": _metrics(current_final_wkv, old_final_wkv),
        "same_bf16_logits": _metrics(same_dtype_logits, old_logits),
        "same_bf16_logits_per_token": _token_metrics(
            same_dtype_logits, old_logits
        ),
        "same_bf16_final_wkv_state": _metrics(
            same_dtype_final_wkv, old_final_wkv
        ),
        "identical_input_wkv_alignment": identical_input_alignment,
        "identical_input_wrong_layout": identical_input_wrong,
        "layer_metrics": layer_metrics,
        "chunked_vs_full_logits": _metrics(chunk_logits, current_logits),
        "chunked_vs_full_final_state": _metrics(
            chunk_final_wkv, current_final_wkv
        ),
        "wrong_layout_logits_vs_peft": _metrics(wrong_logits, old_logits),
        "wrong_layout_per_token": _token_metrics(wrong_logits, old_logits),
        "finite": {
            "old_logits": bool(torch.isfinite(old_logits).all()),
            "current_logits": bool(torch.isfinite(current_logits).all()),
            "wrong_logits": bool(torch.isfinite(wrong_logits).all()),
            "old_state": bool(torch.isfinite(old_final_wkv).all()),
            "current_state": bool(torch.isfinite(current_final_wkv).all()),
        },
        "elapsed_seconds": time.perf_counter() - started,
        "peak_gpu_gib": torch.cuda.max_memory_allocated(device) / 1024**3,
    }
    identical_correct_max = max(
        layer["wkv_output"]["relative_l2"]
        for layer in identical_input_alignment
    )
    if identical_correct_max > 0.02:
        raise AssertionError(
            f"identical-input WKV alignment drifted too far: {identical_correct_max}"
        )
    if args.state_scale > 0:
        identical_wrong_min = min(
            layer["wkv_output"]["relative_l2"]
            for layer in identical_input_wrong
        )
        if identical_wrong_min <= identical_correct_max * 5:
            raise AssertionError(
                "wrong state layout was not clearly detected: "
                f"correct_max={identical_correct_max}, wrong_min={identical_wrong_min}"
            )
    if report["chunked_vs_full_logits"]["relative_l2"] > 0.01:
        raise AssertionError("chunked full-model logits diverged from full prefill")
    if not all(report["finite"].values()):
        raise AssertionError("full-model stress test produced non-finite values")
    if args.output:
        Path(args.output).write_text(
            json.dumps(report, sort_keys=True, indent=2) + "\n", encoding="utf-8"
        )
    print(json.dumps(report, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
