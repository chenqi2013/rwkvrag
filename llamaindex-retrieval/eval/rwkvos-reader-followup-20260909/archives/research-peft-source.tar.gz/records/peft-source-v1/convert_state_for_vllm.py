#!/usr/bin/env python3
"""Validate and export an RWKV-PEFT state checkpoint for local vLLM."""

from __future__ import annotations

import argparse

from rwkvt.state_tuning import convert_state_checkpoint_for_vllm


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Validate RWKV-PEFT time_state tensors in the shared "
            "[head,value,key] layout and create a serving copy. "
            "The source file is not modified."
        )
    )
    parser.add_argument("source", help="RWKV-PEFT state-tuning .pth checkpoint")
    parser.add_argument(
        "--output",
        help="output path (default: insert .vllm before the source suffix)",
    )
    parser.add_argument(
        "--expected-layers",
        type=int,
        help="require exactly layers 0..N-1",
    )
    args = parser.parse_args()

    saved = convert_state_checkpoint_for_vllm(
        args.source,
        output_path=args.output,
        expected_layers=args.expected_layers,
    )
    print(f"source unchanged: {saved.training_path}")
    print(f"vLLM-ready state: {saved.vllm_path}")
    print(f"layout metadata: {saved.metadata_path}")


if __name__ == "__main__":
    main()
