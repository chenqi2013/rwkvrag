#!/usr/bin/env bash
set -euo pipefail

project_dir="${PROJECT_DIR:-/home/chase/chase/RWKV-PEFT}"
load_model="${LOAD_MODEL:-/home/chase/weights/BlinkDL__rwkv7-g1/rwkv7-g1i-13.3b-20260805-ctx16384.pth}"
data_file="${DATA_FILE:-${project_dir}/data/round71/state_tuning_train.jsonl}"
proj_dir="${PROJ_DIR:-${project_dir}/out/g1i-13.3b-round71-state-ctx2496-lr5e-5-seed71}"

ctx_len="${CTX_LEN:-2496}"
epoch_steps="${EPOCH_STEPS:-1000}"
epoch_count="${EPOCH_COUNT:-1}"
lr_init="${LR_INIT:-5e-5}"
lr_final="${LR_FINAL:-5e-6}"
warmup_steps="${WARMUP_STEPS:-10}"
num_workers="${NUM_WORKERS:-2}"

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"

cd "$project_dir"
mkdir -p "$proj_dir"

exec .venv/bin/python train.py \
  --load_model "$load_model" \
  --proj_dir "$proj_dir" \
  --data_file "$data_file" \
  --data_type jsonl \
  --vocab_size 65536 \
  --n_layer 61 \
  --n_embd 4096 \
  --ctx_len "$ctx_len" \
  --micro_bsz 1 \
  --accumulate_grad_batches 1 \
  --epoch_steps "$epoch_steps" \
  --epoch_count "$epoch_count" \
  --epoch_save 1 \
  --lr_init "$lr_init" \
  --lr_final "$lr_final" \
  --warmup_steps "$warmup_steps" \
  --beta1 0.9 \
  --beta2 0.99 \
  --adam_eps 1e-8 \
  --random_seed 71 \
  --accelerator gpu \
  --precision bf16 \
  --devices 1 \
  --strategy deepspeed_stage_1 \
  --grad_cp 1 \
  --num_workers "$num_workers" \
  --my_testing x070 \
  --peft state \
  --op fla
