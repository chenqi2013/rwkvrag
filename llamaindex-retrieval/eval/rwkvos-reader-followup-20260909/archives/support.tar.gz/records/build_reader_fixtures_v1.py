"""Freeze exposed Reader inputs and explicit separate labels, with no network."""
import ast
import base64
from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent
OLD = Path('/home/chase/GitHub/rwkvrag-bm-29b-20260908')
RUN = OLD / 'wiki-api-v1-eos'
OUT = ROOT / 'reader-fixtures-v1'
DIAG = OLD / 'review/wiki-api-reader-diagnosis-v1'
DIAG_FREEZE_SHA = '69fa324836b2c679c4792d8157285bfd02c004c84e6fa1fa48242688189e6314'
SELECT = {'held_004': [1, 2, 3, 4, 5, 6, 7, 8],
          'held_016': [1, 2, 5, 6, 8, 10, 35, 64]}
NEGATIVE = {
    ('held_004', 1): '完整输入仅标题# CAN FD，无ID位数、载荷字节、速率值或线路影响条件。',
    ('held_004', 3): '只有和传统CAN差异这一章节标题及CAN FD父标题；并未陈述任何具体差异或所求值。',
    ('held_004', 5): '仅订定CAN FD标准的供应商章节标题；所问不包含供应商，且标题没有四目标事实。',
    ('held_004', 6): '完整正文只列供应商（ST/Infineon/NXP/TI/Kvaser/Daimler/GM）；厂商身份不能推出ID/载荷/速率/线路限制。',
    ('held_004', 7): '只含外部链接章节标题与CAN FD父标题，没有任何实际回答信息。',
    ('held_004', 8): '仅外链标题清单，包括Bit Rate Calculator、Comparison、Protection等近似主题；未提供计算结果/数值/线路条件正文，不访问链接补证据。',
    ('held_016', 6): '只有Windows NT 4.0标题，不是NativeScript/WinJS1.0/RPG Maker MV/Media Foundation的事实。',
    ('held_016', 10): 'NT4.0发行/支持期限/架构/命名历史正文；虽出现Windows版本和GUI，未绑定WinJS1.0或Media Foundation，也不说明NativeScript XML或RPG音乐格式。',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def save(path, data):
    with path.open('x', encoding='utf-8') as file:
        file.write(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def jsonl(path, rows):
    with path.open('x', encoding='utf-8') as file:
        for row in rows:
            file.write(json.dumps(row, ensure_ascii=False) + '\n')


def original_binding(path):
    data = path.read_bytes()
    return {'root': 'rwkvrag-bm-29b-20260908', 'path': str(path.relative_to(OLD)),
            'sha256': sha(data), 'bytes': len(data)}


def main():
    assert not OUT.exists(), 'Do not overwrite frozen fixtures'
    assert sha((DIAG / 'FROZEN.json').read_bytes()) == DIAG_FREEZE_SHA
    for item in read(DIAG / 'FROZEN.json')['artifacts']:
        data = (OLD / item['path']).read_bytes()
        assert sha(data) == item['sha256'] and len(data) == item['bytes']
    diagnosis = {(x['case_id'], x['reader_rank']): x for x in
                 map(json.loads, (DIAG / 'calls.jsonl').read_text().splitlines())}
    fixtures = {x['id']: x for x in map(json.loads, (RUN / 'frozen/fixtures.jsonl').read_text().splitlines())}
    source_path = RUN / 'source/src/llamaindex_retrieval/rwkv_pipeline.py'
    expected_source = read(RUN / 'source-manifest.json')['src/llamaindex_retrieval/rwkv_pipeline.py']
    assert sha(source_path.read_bytes()) == expected_source['sha256']
    scope = {'json': json, 'SourceItem': object}
    nodes = [n for n in ast.parse(source_path.read_text()).body if isinstance(n, ast.FunctionDef) and n.name == 'task_resolver_prompt']
    assert len(nodes) == 1
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source_path), 'exec'), scope)
    build_prompt = scope['task_resolver_prompt']
    inputs, gold, task_inputs, baselines, copies = [], [], [], [], []
    bindings = {str(p): original_binding(p) for p in [
        DIAG / 'FROZEN.json', DIAG / 'calls.jsonl', RUN / 'frozen/fixtures.jsonl',
        source_path, RUN / 'source-manifest.json', RUN / 'settings.json']}
    for case_id, ranks in SELECT.items():
        case_path = RUN / 'completed' / (case_id + '.json')
        bindings[str(case_path)] = original_binding(case_path)
        response = read(case_path)['response']
        fixture = fixtures[case_id]
        for rank in ranks:
            sid = f'{case_id}-r{rank:03d}'
            diag = diagnosis[(case_id, rank)]
            source = response['retrieval']['candidates'][rank - 1]
            event = next(c for c in response['generation']['model_calls'] if c.get('stage') == 'resolver' and c['source_id'] == source['id'])
            assert event['call_id'] == diag['call_id']
            snippet = source['snippet']
            assert sha(snippet.encode()) == event['source_sha256']
            task = json.dumps({'history': fixture['history'], 'latest_question': fixture['question']}, ensure_ascii=False)
            active = response['retrieval']['active_tasks']
            message = event['messages'][0]['content']
            context = json.loads(message.split('\n原文父级上下文：', 1)[1].split('\n原文：', 1)[0])
            assert context == source['metadata'].get('context_spans', [])
            ordered_source = dict(source, metadata=dict(source['metadata'], context_spans=context))
            units = [{**u, 'text': snippet[u['start']:u['end']]} for u in event['units']]
            assert len(units) == 1 and units[0]['text'] == snippet
            for unit in units:
                assert sha(unit['text'].encode()) == unit['sha256']
            prepared_units = [SimpleNamespace(text=u['text']) for u in units]
            rebuilt = build_prompt(task, active, SimpleNamespace(**ordered_source), prepared_units)
            assert rebuilt == message
            assert event['prompt'] == 'User: ' + message + '\n\nAssistant: <think></think>'
            http = event['http'][0]
            request_raw = base64.b64decode(http['request_body_base64'], validate=True)
            response_raw = base64.b64decode(http['response_body_base64'], validate=True)
            assert sha(request_raw) == http['request_body_sha256']
            assert sha(response_raw) == http['response_body_sha256']
            request_body, response_body = json.loads(request_raw), json.loads(response_raw)
            assert request_body['contents'][event['batch_index']] == event['prompt']
            choice = next(c for c in response_body['choices'] if c['index'] == event['batch_index'])
            assert choice['message']['content'] == event['raw_text']
            cp = OLD / diag['model_completed_path']
            sp = OLD / diag['model_started_path']
            assert read(sp)['messages'] == event['messages']
            assert read(cp)['raw_text'] == event['raw_text']
            for path, suffix in [(cp, 'completed'), (sp, 'started')]:
                bindings[str(path)] = original_binding(path)
                copies.append((f'baseline/{sid}.{suffix}.json', path.read_bytes()))
            item = {'id': sid, 'case_id': case_id, 'reader_rank': rank,
                'original_messages': event['messages'], 'original_prompt': event['prompt'],
                'original_prompt_sha256': event['prompt_sha256'], 'task': task,
                'active_tasks': active, 'source': source, 'context': context, 'units': units,
                'completion_parameters': read(sp)['parameters'],
                'original_http_parameters': {k: v for k, v in request_body.items() if k != 'contents'},
                'transport': 'rwkvos_batch', 'prefill_mode': 'complete', 'state_id': event['state_id'],
                'original_call_id': event['call_id'], 'baseline_completed_path': f'baseline/{sid}.completed.json',
                'baseline_started_path': f'baseline/{sid}.started.json',
                'baseline_completed_sha256': sha(cp.read_bytes()), 'baseline_started_sha256': sha(sp.read_bytes()),
                'original_case_binding': original_binding(case_path),
                'original_case_source_pointer': diag['source_pointer'], 'original_case_trace_pointer': diag['case_pointer']}
            # Model input records deliberately have no labels, facts or old raw output.
            assert all(k not in item for k in ['gold', 'oracle', 'expected_facts', 'raw_text', 'label'])
            inputs.append(item)
            observations = deepcopy(diag['verified_support_for'])
            negative = (case_id, rank) in NEGATIVE
            assert negative == (not observations)
            per_task = []
            for i, text in enumerate(active, 1):
                tid = f'{sid}-t{i:02d}'
                task_message = build_prompt(task, [text], SimpleNamespace(**ordered_source), prepared_units)
                before, rest = message.split('\n子问题：', 1)
                _, after = rest.split('\n来源：', 1)
                assert task_message == before + '\n子问题：' + json.dumps([text], ensure_ascii=False) + '\n来源：' + after
                task_prompt = 'User: ' + task_message + '\n\nAssistant: <think></think>'
                task_inputs.append({'id': tid, 'source_sample_id': sid, 'case_id': case_id,
                    'task_index': i, 'original_task_text': text, 'messages': [{'role': 'user', 'content': task_message}],
                    'prompt': task_prompt, 'prompt_sha256': sha(task_prompt.encode()),
                    'completion_parameters': read(sp)['parameters'],
                    'http_payload': {**item['original_http_parameters'], 'contents': [task_prompt]},
                    'original_source_sample_prompt_sha256': event['prompt_sha256']})
                underspecified = case_id == 'held_016' and i in (5, 6)
                fact_id = f'F{i}'
                evidence = [deepcopy(x) for x in observations if x['fact_id'] == fact_id]
                if case_id == 'held_016' and i == 3 and evidence:
                    quote = '手機板使用m4a格式'
                    start = snippet.index(quote)
                    evidence[0].update(quote=quote, source_span={'start': start, 'end': start + len(quote), 'unit': 'unicode_code_points'},
                        page_span={'start': source['metadata']['source_span']['start'] + start,
                                   'end': source['metadata']['source_span']['start'] + start + len(quote), 'unit': 'unicode_code_points'})
                expected = None if underspecified else ['E1'] if evidence else []
                per_task.append({'id': tid, 'task_index': i, 'task_text': text,
                    'diagnostic_status': 'underspecified' if underspecified else 'task_specific_support' if evidence else 'no_task_specific_support',
                    'supported_unit_ids': expected, 'evidence': evidence,
                    'reason': '原模型增加的泛开发文档查询没有具体属性，不强造task特异正/负标签；不改变原输入。' if underspecified else
                        '原文明确支持该原模型子问题；事实引文仅在金标，未写入模型输入。' if evidence else
                        '实际E1不支持此单项子问题；若支持原完整问题的另一项，仍由主指标保留为有效source，不能直接称幻选。',
                    'used_for_primary_score': False})
            gold.append({'id': sid, 'case_id': case_id, 'label': 'negative' if negative else 'positive',
                'expected_full_question_union_unit_ids': [] if negative else ['E1'],
                'full_question_fact_support': observations, 'per_task_diagnostics': per_task,
                'negative_reason': NEGATIVE.get((case_id, rank)),
                'negative_review': {'method': 'Codex read complete actual source, parent context, task and units; not inferred from baseline NONE',
                    'read_span': {'start': 0, 'end': len(snippet), 'unit': 'unicode_code_points'},
                    'external_links_followed': False} if negative else None,
                'source_text_sha256': event['source_sha256'],
                'known_target_omission': '原task3仅手机版；完整用户问题F3仍要求Windows版ogg与手机版m4a。仅Windows目标被原query遗漏，不能将task3悄悄改成双平台。' if case_id == 'held_016' else None,
                'union_selection_is_not_all_fields_complete': True})
            baselines.append({'id': sid, 'raw_text': event['raw_text'], 'status': event['status'],
                'parse_outcome': diag['parse_outcome'], 'parse_error': diag['parse_error'],
                'selected_units': diag['selected_units'], 'raw_text_sha256': event['raw_text_sha256'],
                'source_level_exact_match': negative and diag['parse_outcome'] == 'pure_NONE',
                'termination_verified': False})
    assert len(inputs) == 16 and len(gold) == 16 and len(task_inputs) == 80
    assert Counter(x['case_id'] for x in inputs) == {'held_004': 8, 'held_016': 8}
    assert Counter(x['label'] for x in gold) == {'positive': 8, 'negative': 8}
    assert sum(t['diagnostic_status'] == 'underspecified' for g in gold for t in g['per_task_diagnostics']) == 16
    assert sum(t['supported_unit_ids'] == ['E1'] for g in gold for t in g['per_task_diagnostics']) == 11
    assert Counter(x['parse_outcome'] for x in baselines) == {'pure_NONE': 8, 'invalid_selection_syntax': 7, 'unknown_unit': 1}
    assert sum(x['source_level_exact_match'] for x in baselines) == 2
    OUT.mkdir(parents=True)
    (OUT / 'baseline').mkdir()
    for name, data in copies:
        with (OUT / name).open('xb') as file:
            file.write(data)
    jsonl(OUT / 'inputs.jsonl', inputs)
    jsonl(OUT / 'per-task.inputs.jsonl', task_inputs)
    jsonl(OUT / 'gold.jsonl', gold)
    jsonl(OUT / 'baseline-observations.jsonl', baselines)
    plan = {'schema': 'exposed-reader-fixtures-v1', 'status': 'offline prepared; no API calls',
        'selection': {'original_run': str(RUN), 'positive_sources': 8, 'negative_sources': 8,
                      'per_case': {'held_004': {'positive': 2, 'negative': 6}, 'held_016': {'positive': 6, 'negative': 2}},
                      'selection_rule': 'Retain all eight previously explicitly verified positive source calls; manually choose six CAN title/vendor/link negatives and two wrong-object Windows NT4 negatives, giving eight samples per original case.',
                      'not_blind': True, 'baseline_outputs_exposed': True},
        'prospective_change': 'Each call receives exactly one unchanged original model task in the 子问题 list. Complete task/history/source/units/context and all other instruction characters remain byte-identical. No new task priority sentence.',
        'prepared_call_count': 80, 'executed_model_calls': 0,
        'same_output_protocol': 'Only actual E IDs separated by allowed comma/semicolon separators, or exactly NONE; original strict parser unchanged.',
        'main_metrics': {'denominator_sources': 16, 'positive_sources': 8, 'negative_sources': 8,
                         'selection': 'Union only valid selections across all actual task calls for a source; compare with that source support for the complete effective question.',
                         'strict_source_success': 'All scheduled task calls received valid protocol outputs AND merged selected unit IDs equal full-question expected IDs. Any transport/parser failure remains a failed/incomplete source; cannot cherry-pick successful siblings.',
                         'also_report': ['raw per-call protocol pass denominator 80', 'source union exact match and completeness separately', 'positive recall denominator 8', 'negative false selections denominator 8', 'all source/call errors and unknown termination']},
        'diagnostic_limits': ['Original full task JSON remains: selecting a unit supporting another original target is not automatically a false positive for the source. Per-task specificity is diagnostic only.',
            'Sixteen calls corresponding to held_016 original generic tasks 5/6 are underspecified, without invented task-specific gold. They remain in actual call and format denominators, and valid choices participate in source union.',
            'The original task3 asks only mobile format; user full question asks Windows plus mobile. Separate labels preserve this discrepancy without editing input.',
            'A selected E1 can support only some facts; selection never implies complete coverage of all user fields.',
            'All sixteen sources contain one E unit. This suite cannot demonstrate multi-unit disambiguation, unseen-topic generalization or end-to-end QA improvement.',
            'Sources and old outputs are exposed development fixtures, deliberately balanced by source polarity and case, not a representative blind sample.',
            'Provider stop does not verify natural termination; no token usage or deployed weights hash is invented.'],
        'baseline_summary': {'sources': 16, 'strict_source_success': 2, 'valid_pure_NONE': 8,
                             'invalid_syntax': 7, 'unknown_unit': 1, 'positive_recall': 0,
                             'valid_negative_success': 2, 'false_positive_valid_selections': 0,
                             'format_failures_count_as_failure': True},
        'original_bindings': list(bindings.values())}
    save(OUT / 'PLAN.json', plan)
    save(OUT / 'CHECKS.json', {'status': 'PASS', 'original_source_prompt_http_and_slots_verified': 16,
        'copied_original_model_receipts': 32, 'per_task_only_list_change_verified': 80,
        'inputs_have_no_gold_or_baseline_raw': True, 'per_task_underspecified': 16,
        'task_specific_positive_pairs': 11, 'task_specific_negative_pairs': 53,
        'new_model_calls': 0, 'old_scores_or_raw_modified': False})
    text = '''# Reader 对照样本：已曝光开发材料

保留上一轮外部 2.9B Wiki Reader 的八个已核实正向来源，另对完整原文、父级标题和原有效问题逐字审阅选出八个近似负例。两题各八个来源；CAN FD 为2正/6负，开发文档为6正/2负。这不是新盲测，也不代表实际语料正负比例。

`inputs.jsonl` 保存16个完整原输入，不含金标或旧raw输出；`gold.jsonl` 单独保存原文语义支持、Unicode偏移与逐task诊断。`baseline/` 的32个文件逐字复制原started/completed收据，SHA绑定原目录；`baseline-observations.jsonl` 只供离线比较，不可送模型。`per-task.inputs.jsonl` 预备80条输入，每条仅把原“子问题”数组换成包含一个原字符串的数组，其他提示词字符、完整任务/历史/来源/父级上下文/E单元不变。

主要比较按16个source对**完整有效问题**的选择取并集：8正例召回、8负例误选、来源选择正确性和80调用的严格格式/失败分别报告。任何某task失败不得被其他成功task掩盖；严格来源成功须全部预定调用协议完整且并集与预期一致。只选择到一块有用原文不等于所有字段已覆盖，也不等于Writer答案正确。

016原查询第5/6项只是泛泛“开发文档”，16个对应调用标underspecified，不强造逐task语义标签，但保留实际调用/格式分母和source并集。原第3项只问手机版；原用户完整问题同时要求Windows版ogg和手机版m4a，两种支持分开保留，不补改原查询。

只缩短子问题列表时，完整任务JSON仍保留其他目标，原提示也允许支持任务任一部分。因此逐task特异选择仅作诊断，不把支持其他原目标的选择自动算幻选。没有追加任务优先级指令；这项解释已在执行前由root确认。

六个CAN负例分别是标题、差异标题、厂商标题、厂商名单、外链标题和外链清单；看到Calculator等链接名也不能假设链接正文已读。两个开发文档负例是Windows NT4.0标题和发行/支持/架构介绍；Windows字样不能转成WinJS/Media Foundation事实。负例不是根据原NONE推定，六个CAN负例的原模型输出事实上都是格式失败。每条完整理由见gold。

原16调用为8个NONE和8个格式失败，正例召回0/8，严格来源成功2/16；旧输出已曝光。每个来源恰好只有E1，故不验证多单元定位能力。提供方stop不可靠，终止仍unknown。此目录只完成离线冻结，零API调用，未改生产、旧raw或旧QA分。
'''
    with (OUT / 'README.md').open('x', encoding='utf-8') as file:
        file.write(text)
    artifacts = []
    for path in sorted(OUT.rglob('*')):
        if path.is_file():
            data = path.read_bytes()
            artifacts.append({'path': str(path.relative_to(OUT)), 'bytes': len(data), 'sha256': sha(data)})
    save(OUT / 'FROZEN.json', {'schema': 'reader-fixtures-v1-freeze', 'files': artifacts,
        'builder': {'path': '../build_reader_fixtures_v1.py', 'sha256': sha(Path(__file__).read_bytes())},
        'original_diagnosis_freeze_sha256': DIAG_FREEZE_SHA, 'original_bindings': list(bindings.values()),
        'executed_model_calls': 0})
    print(json.dumps({'output': str(OUT), 'source_samples': 16, 'prepared_task_calls': 80,
                      'freeze_sha256': sha((OUT / 'FROZEN.json').read_bytes())}, ensure_ascii=False))


if __name__ == '__main__':
    main()
