"""Offline release/scan failure checks using only temporary synthetic records."""
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

TOOL = Path('/home/chase/GitHub/rwkvrag-bm250820/llamaindex-retrieval/eval/rwkvos-reader-followup-20260909/build_archive.py')
spec = importlib.util.spec_from_file_location('followup_archive_tested', TOOL)
tool = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tool)


class Checks(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.bindings = {}
        for name in sorted(tool.REQUIRED_EXPERIMENTS):
            p = self.root / name / 'COMPLETED.json'
            p.parent.mkdir()
            p.write_text('{}\n')
            self.bindings[p.relative_to(self.root).as_posix()] = tool.builder.file_sha(p)
        self.final = {'status': 'complete', 'bindings': self.bindings,
                      'completed_experiments': sorted(tool.REQUIRED_EXPERIMENTS)}

    def tearDown(self):
        self.tmp.cleanup()
        tool.SCAN_EXCEPTIONS.clear()

    def release(self):
        p = self.root / 'FINAL.json'
        p.write_text(json.dumps(self.final))
        return tool.check_release(self.root, p, tool.builder.file_sha(p))

    def test_complete_frozen_inputs(self):
        self.assertEqual(self.release()[1], self.bindings)

    def test_incomplete_refused(self):
        self.final['status'] = 'running'
        with self.assertRaisesRegex(ValueError, 'status=complete'):
            self.release()

    def test_changed_bound_file_refused(self):
        (self.root / next(iter(self.bindings))).write_text('changed')
        with self.assertRaisesRegex(ValueError, 'changed'):
            self.release()

    def test_missing_terminal_refused(self):
        del self.bindings[next(iter(self.bindings))]
        with self.assertRaisesRegex(ValueError, 'terminal receipt'):
            self.release()

    def test_traversal_refused(self):
        self.bindings['../escape.json'] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'unsafe'):
            self.release()

    def test_symlink_refused(self):
        p = self.root / next(iter(self.bindings))
        p.unlink()
        p.symlink_to(self.root / 'FINAL.json')
        with self.assertRaisesRegex(ValueError, 'symbolic'):
            self.release()

    def test_weight_exclusion_and_receipt_preservation(self):
        self.assertIsNotNone(tool.exclusion(Path('local/checkpoints/model.pth')))
        self.assertIsNotNone(tool.exclusion(Path('RESUME.json')))
        self.assertIsNotNone(tool.exclusion(Path('local/.venv/bin/python')))
        self.assertIsNone(tool.exclusion(Path('local/download-attempt-01.jsonl')))

    def test_signed_url_refused(self):
        with self.assertRaisesRegex(ValueError, 'signed URL'):
            tool.scan_public(b'https://example.test/file?' + b'X-Amz-' + b'Signature=synthetic', 'record.txt')

    def test_base64_signed_url_refused(self):
        b64 = base64.b64encode(b'https://example.test/file?' + b'X-Amz-' + b'Signature=synthetic').decode()
        with self.assertRaisesRegex(ValueError, 'signed URL'):
            tool.scan_public(json.dumps({'response_body_base64': b64}).encode(), 'record.json')

    def test_authorization_requires_exact_exception(self):
        raw = b'{"authorization":"Synthetic permission to run a local test."}'
        with self.assertRaisesRegex(ValueError, 'credential field'):
            tool.scan_public(raw, 'test.json')
        tool.SCAN_EXCEPTIONS['test.json'] = {'sha256': hashlib.sha256(raw).hexdigest(),
                                           'json_pointer': '/authorization'}
        tool.scan_public(raw, 'test.json')
        with self.assertRaisesRegex(ValueError, 'bytes changed'):
            tool.scan_public(raw + b' ', 'test.json')

    def test_exception_still_scans_value(self):
        raw = b'{"authorization":"Bearer ' + b'ABCDEFGHIJKLMNOP"}'
        tool.SCAN_EXCEPTIONS['test.json'] = {'sha256': hashlib.sha256(raw).hexdigest(),
                                           'json_pointer': '/authorization'}
        with self.assertRaisesRegex(ValueError, 'bearer-credential'):
            tool.scan_public(raw, 'test.json')

    def test_actual_credential_scans_recursive_wire(self):
        p = self.root / 'synthetic-curl.txt'
        p.write_text("curl -H 'CF-Access-Client-Id: synthetic-test-id' -H 'CF-Access-Client-Secret: synthetic-test-secret'")
        scanner = tool.CredentialScan(p)
        raw = json.dumps({'body_base64': base64.b64encode(b'synthetic-test-secret').decode()}).encode()
        with self.assertRaisesRegex(ValueError, 'credential scan failed'):
            scanner.scan_bytes(raw, 'record.json')


if __name__ == '__main__':
    unittest.main(verbosity=2)
