"""Readonly focused-instruction comparison, with contemporaneous control drift."""
import ast
import base64
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re

N = Path(__file__).resolve().parent
R = N / 'reader-focused-task-v1'
F = N / 'reader-fixtures-v1'
O = R / 'review'
PHASES = {'prior-control': N / 'reader-per-task-v1/per-task',
          'focused': R / 'focused', 'repeat-control': R / 'control-after'}
FIXTURE_SHA = '0fd20a0db58f2ce444fc07c9904137e5c6b2809ba595150b550299aaa6560e56'


def sha(data):
    return sha256(data).hexdigest()


def load(p):
    return json.loads(p.read_text())


def jsonl(p):
    return list(map(json.loads, p.read_text().splitlines()))


def bind(p):
    b = p.read_bytes()
    return {'path': str(p.resolve()), 'bytes': len(b), 'sha256': sha(b)}


def save(p, value):
    with p.open('x', encoding='utf-8') as file:
        file.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    assert not O.exists()
    started, plan = load(R / 'STARTED.json'), load(R / 'PLAN.json')
    assert sha((R / 'runner.py').read_bytes()) == started['runner_sha256']
    assert sha((R / 'PLAN.json').read_bytes()) == started['plan_sha256']
    assert sha((F / 'FROZEN.json').read_bytes()) == FIXTURE_SHA == started['fixture_freeze_sha256']
    assert sha((R / 'focused.inputs.jsonl').read_bytes()) == started['focused_inputs_sha256']
    for x in load(F / 'FROZEN.json')['files']:
        data = (F / x['path']).read_bytes()
        assert sha(data) == x['sha256'] and len(data) == x['bytes']
    source = Path(load(N / 'reader-per-task-v1/PLAN.json')['source_snapshot'])
    manifest = source / 'SOURCE-MANIFEST.json'
    assert sha(manifest.read_bytes()) == started['source_manifest_sha256']
    for name, spec in load(manifest)['files'].items():
        data = (source / name).read_bytes()
        assert sha(data) == spec['sha256'] and len(data) == spec['bytes']
    parser_path = source / 'src/llamaindex_retrieval/rwkv_pipeline.py'
    fn = next(n for n in ast.parse(parser_path.read_text()).body if isinstance(n, ast.FunctionDef) and n.name == 'parse_task_selections')
    scope = {'re': re}
    exec(compile(ast.Module(body=[fn], type_ignores=[]), str(parser_path), 'exec'), scope)
    parse = scope['parse_task_selections']
    inputs = {x['id']: x for x in jsonl(F / 'inputs.jsonl')}
    tasks = {x['id']: x for x in jsonl(F / 'per-task.inputs.jsonl')}
    gold = {x['id']: x for x in jsonl(F / 'gold.jsonl')}
    focused = {x['id']: x for x in jsonl(R / 'focused.inputs.jsonl')}
    assert set(tasks) == set(focused) and len(tasks) == 80
    for rid, row in tasks.items():
        old_message = row['messages'][0]['content']
        expected = old_message
        for old, new in zip(plan['change']['old'], plan['change']['new'], strict=True):
            assert expected.count(old) == 1
            expected = expected.replace(old, new, 1)
        assert focused[rid]['messages'] == [{'role': 'user', 'content': expected}]
        assert focused[rid]['prompt'] == 'User: ' + expected + '\n\nAssistant: <think></think>'
        assert focused[rid]['completion_parameters'] == row['completion_parameters']
        # The complete JSON task and the entire source/context/unit suffix stay exact.
        assert expected.split('\n任务：', 1)[1] == old_message.split('\n任务：', 1)[1]
    bindings = [bind(p) for p in [F / 'FROZEN.json', F / 'inputs.jsonl', F / 'per-task.inputs.jsonl', F / 'gold.jsonl',
        R / 'PLAN.json', R / 'STARTED.json', R / 'COMPLETED.json', R / 'runner.py', R / 'focused.inputs.jsonl',
        N / 'reader-per-task-v1/review/FROZEN.json', manifest, parser_path]]
    all_calls, all_sources, summaries, schedules = [], [], [], {}
    outputs = {}
    unique_call_ids = set()
    for phase, directory in PHASES.items():
        requests = load(directory / 'REQUESTS.json')
        assert {x['id'] for x in requests} == set(tasks) and len(requests) == 80
        assert len(list((directory / 'calls').glob('*.started.json'))) == 80
        assert len(list((directory / 'calls').glob('*.completed.json'))) == 80
        expected_rows = focused if phase == 'focused' else tasks
        batch_paths = sorted((directory / 'batch-http').glob('*.batch_completed.json'))
        batches = {}
        for path in batch_paths:
            b = load(path)
            pre_path = Path(str(path).replace('.batch_completed.json', '.batch_started.json'))
            pre = load(pre_path)
            assert pre['payload'] == b['payload'] and pre['request_body_sha256'] == b['request_body_sha256']
            request_raw = base64.b64decode(b['request_body_base64'], validate=True)
            response_raw = base64.b64decode(b['response_body_base64'], validate=True)
            assert sha(request_raw) == b['request_body_sha256'] and sha(response_raw) == b['response_body_sha256']
            assert json.loads(request_raw) == b['payload'] and json.loads(response_raw) == b['response_json']
            assert b['http_status'] == 200 and b['http_attempted'] is True and b['response_body_complete'] is True
            assert b['response_json']['model'] == b['payload']['model']
            assert len(b['payload']['contents']) == 8
            assert sorted(c['index'] for c in b['response_json']['choices']) == list(range(8))
            assert b['batch_id'] not in batches
            batches[b['batch_id']] = b
            bindings += [bind(path), bind(pre_path)]
        assert len(batches) == 10
        calls, by_id, provider_id_to_job = [], {}, {}
        for req in requests:
            rid, sid = req['id'], req['source_sample_id']
            exp = expected_rows[rid]
            for k in ['messages', 'prompt', 'prompt_sha256', 'completion_parameters']:
                assert req[k] == exp[k]
            path = directory / 'calls' / (rid + '.completed.json')
            pre_path = directory / 'calls' / (rid + '.started.json')
            row, pre = load(path), load(pre_path)
            trace = row['trace']
            assert trace['messages'] == pre['messages'] == exp['messages']
            assert pre['completion_parameters'] == exp['completion_parameters']
            assert trace['prompt'] == exp['prompt'] and sha(trace['prompt'].encode()) == exp['prompt_sha256'] == trace['prompt_sha256']
            assert trace['parameters'] == inputs[sid]['original_http_parameters']
            assert trace['state_id'] is None and trace['prefill'] == '<think></think>'
            assert trace['call_id'] not in unique_call_ids
            unique_call_ids.add(trace['call_id'])
            provider_id_to_job[trace['call_id']] = rid
            assert row['status'] == trace['status'] == 'completed'
            assert trace['termination'] == 'unknown' and trace['termination_verified'] is False
            assert len(trace['http']) == 1 and trace['http'][0] == batches[trace['batch_id']]
            batch = batches[trace['batch_id']]
            assert batch['payload']['contents'][trace['batch_index']] == trace['prompt']
            choice = next(c for c in batch['response_json']['choices'] if c['index'] == trace['batch_index'])
            raw = row['raw_text']
            assert raw == choice['message']['content'] == trace['raw_text']
            assert sha(raw.encode()) == trace['raw_text_sha256']
            assert choice['finish_reason'] == trace['provider_finish_reason'] == 'stop'
            assert trace['envelope'] == {'valid': True, 'answer_span': {'start': 0, 'end': len(raw), 'unit': 'unicode_code_points'}, 'raw_text_modified': False}
            error, selected = None, []
            try:
                selected = [f'E{i}' for i in parse(raw.strip(), len(inputs[sid]['units']))]
            except (ValueError, TypeError) as exc:
                error = str(exc)
            assert row['format_pass'] == (error is None) and row.get('parse_error') == error
            if error is None:
                assert row['selected_units'] == selected
            task_gold = next(t for t in gold[sid]['per_task_diagnostics'] if t['id'] == rid)
            entry = {'phase': phase, 'id': rid, 'source_sample_id': sid, 'label': gold[sid]['label'],
                'raw_text': raw, 'raw_sha256': sha(raw.encode()), 'format_pass': error is None,
                'parse_error': error, 'selected_units': selected, 'raw_path': str(path.relative_to(N)),
                'task_specific_expected': task_gold['supported_unit_ids'],
                'task_specific_diagnostic_match': None if task_gold['supported_unit_ids'] is None else error is None and selected == task_gold['supported_unit_ids'],
                'prompt_sha256': trace['prompt_sha256'], 'batch_id': trace['batch_id'], 'batch_index': trace['batch_index'],
                'request_sha256': batch['request_body_sha256'], 'response_sha256': batch['response_body_sha256'], 'termination_verified': False}
            calls.append(entry)
            by_id[rid] = entry
            bindings += [bind(path), bind(pre_path)]
        all_calls.extend(calls)
        outputs[phase] = by_id
        ordered_batches = sorted(batches.values(), key=lambda b: b['started_at'])
        schedules[phase] = [{'batch_position': i + 1, 'batch_id': b['batch_id'], 'started_at': b['started_at'],
            'slot_jobs': [provider_id_to_job[x['call_id']] for x in sorted(b['slots'], key=lambda x: x['index'])],
            'request_body_sha256': b['request_body_sha256'], 'response_body_sha256': b['response_body_sha256']}
            for i, b in enumerate(ordered_batches)]
        sources = []
        for sid in inputs:
            siblings = [c for c in calls if c['source_sample_id'] == sid]
            assert len(siblings) == len(inputs[sid]['active_tasks'])
            union = list(dict.fromkeys(u for c in siblings if c['format_pass'] for u in c['selected_units']))
            expect = gold[sid]['expected_full_question_union_unit_ids']
            errors = [c['id'] for c in siblings if not c['format_pass']]
            source_row = {'phase': phase, 'source_sample_id': sid, 'label': gold[sid]['label'],
                'siblings': [c['id'] for c in siblings], 'failed_siblings': errors,
                'selected_union': union, 'expected_union': expect,
                'all_siblings_valid': not errors, 'union_match_ignoring_errors': set(union) == set(expect),
                'strict_source_success': not errors and set(union) == set(expect),
                'positive_recalled': bool(set(union) & set(expect)) if expect else None,
                'valid_negative_false_selection': bool(union) if not expect else None}
            sources.append(source_row)
        all_sources.extend(sources)
        original = load(directory / 'COMPLETED.json')
        assert original['calls'] == 80 and original['format_pass'] == sum(c['format_pass'] for c in calls)
        assert original['http']['http_requests'] == 10 and original['http']['unknown'] == 0
        summaries.append({'phase': phase, 'calls': 80, 'http': 10, 'format_pass': sum(c['format_pass'] for c in calls),
            'valid_nonempty': sum(bool(c['selected_units']) for c in calls), 'positive_source_recall': sum(s['positive_recalled'] is True for s in sources),
            'positive_denominator': 8, 'negative_false_selections': sum(s['valid_negative_false_selection'] is True for s in sources),
            'negative_denominator': 8, 'strict_negative_success': sum(s['strict_source_success'] and s['label'] == 'negative' for s in sources),
            'strict_source_success': sum(s['strict_source_success'] for s in sources), 'source_denominator': 16,
            'failed_sources': [s['source_sample_id'] for s in sources if s['failed_siblings']],
            'unscorable_generic_tasks': 16,
            'task_specific_diagnostic': dict(Counter(
                ('underspecified_valid' if c['format_pass'] else 'underspecified_format_failure')
                if c['task_specific_expected'] is None else
                ('positive_match' if c['task_specific_diagnostic_match'] else 'positive_miss')
                if c['task_specific_expected'] else
                ('negative_match' if c['task_specific_diagnostic_match'] else 'negative_failure')
                for c in calls)),
            'elapsed_ms': original['elapsed_ms']})
        bindings += [bind(directory / 'REQUESTS.json'), bind(directory / 'COMPLETED.json')]
    comparisons = []
    for left, right in [('prior-control', 'repeat-control'), ('prior-control', 'focused'), ('focused', 'repeat-control')]:
        differences = []
        for rid in tasks:
            a, b = outputs[left][rid], outputs[right][rid]
            if a['raw_text'] != b['raw_text']:
                differences.append({'id': rid, 'left_raw': a['raw_text'], 'right_raw': b['raw_text'],
                    'left_format_pass': a['format_pass'], 'right_format_pass': b['format_pass'],
                    'only_outside_whitespace': a['raw_text'].strip() == b['raw_text'].strip(),
                    'left_raw_sha256': a['raw_sha256'], 'right_raw_sha256': b['raw_sha256']})
        comparisons.append({'left': left, 'right': right,
            'same_batch_order_and_slot_jobs': [b['slot_jobs'] for b in schedules[left]] == [b['slot_jobs'] for b in schedules[right]],
            'same_request_body_batches': sum(a['request_body_sha256'] == b['request_body_sha256'] for a, b in zip(schedules[left], schedules[right], strict=True)),
            'same_raw_calls': 80 - len(differences), 'different_raw_calls': differences,
            'format_changed_calls': sum(d['left_format_pass'] != d['right_format_pass'] for d in differences)})
    assert [s['format_pass'] for s in summaries] == [78, 76, 77]
    assert [s['strict_source_success'] for s in summaries] == [7, 6, 5]
    assert all(s['positive_source_recall'] == 0 and s['valid_nonempty'] == 0 for s in summaries)
    assert comparisons[0]['same_request_body_batches'] == 10 and comparisons[0]['same_raw_calls'] == 74
    assert comparisons[0]['format_changed_calls'] == 5
    assert all(c['same_batch_order_and_slot_jobs'] for c in comparisons)
    report = {'schema': 'focused-reader-contract-review-v1', 'reviewer': 'Codex independent frozen-gold offline review',
        'phase_summary': summaries, 'control_comparisons': comparisons, 'batch_schedules': schedules,
        'stable_controls': False, 'promotion': False,
        'reason': 'No positive source recall in any phase. Repeated controls used identical request bodies and slot composition but six raw outputs changed; causal attribution of format/source-score differences to the focus instruction is not established.',
        'all_raw_failures': [c for c in all_calls if not c['format_pass']],
        'checks': {'raw_call_receipts': 240, 'batch_http_receipts': 30, 'every_slot_content_and_index_verified': True,
            'gold_and_source_freezes_verified': True, 'only_two_instruction_replacements': 80,
            'all_other_task_source_context_units_unchanged': True, 'strict_parser_recomputed': 240,
            'reviewer_new_api_calls': 0},
        'limitations': ['Two instruction sentences form one scope-contract change; effect of an individual word was not isolated.',
            'Same client request-body bytes and slot layout do not prove identical server internal scheduling, backend version, numerical execution or other-client traffic. No cause for drift is asserted.',
            'All sixteen sources and old outputs are exposed; every source has only E1. This is not a blind or end-to-end QA evaluation.',
            'Sixteen generic task5/6 pairs remain underspecified and cannot receive fabricated semantic labels. All80 actual calls remain in format/source denominators.',
            'One correct value in invalid raw text is not an accepted evidence selection. No answer or parser repair is performed.',
            'Provider stop does not establish natural completion or reliable output-length classification. Wall times are observations, not performance claims.'],
        'bindings': bindings}
    O.mkdir()
    save(O / 'REVIEW.json', report)
    for name, rows in [('calls.jsonl', all_calls), ('source-unions.jsonl', all_sources)]:
        with (O / name).open('x', encoding='utf-8') as file:
            for row in rows:
                file.write(json.dumps(row, ensure_ascii=False) + '\n')
    md = '''# Reader 明确单任务焦点：独立对照审阅

**不晋级。三组正向来源召回均为0/8；重复控制已出现漂移，不能把格式或严格来源分数的差异隔离归因于focused指令。** 已只读核验240条调用和30个共享HTTP原始字节、槽位、完整输入、原解析器及冻结金标。

| 条件 | 严格格式 | 正例召回 | 有效负例误选 | 严格负例成功 | 严格source成功 |
|---|---:|---:|---:|---:|---:|
| 此前per-task80控制 | 78/80 | 0/8 | 0/8 | 7/8 | 7/16 |
| focused80 | 76/80 | 0/8 | 0/8 | 6/8 | 6/16 |
| 重复原控制80 | 77/80 | 0/8 | 0/8 | 5/8 | 5/16 |

所有合法选择并集仍为空。0个有效负例误选不能把非法输出算作正确拒选；有一个兄弟调用失败，该source严格项就失败，不用其他NONE补救。

## 实际变量与批次核验

focused仅替换PLAN中两句：明确本次只判断单项“子问题”，完整任务仅作对象/指代/限定背景；随后把“支持任务的一部分”限定为“本次子问题的一部分”。它们是一项scope合同改动，不是两个被分别验证的因果因素。80条完整任务JSON、单项子问题文字、source、父级上下文、E单元、采样、state省略、closed前缀、stop[0]和1024输出预算均保留。金标不在客户端输入。

三组实际均为10个8槽batch，按实际HTTP开始顺序重建的每批成员及槽位排列完全相同。此前控制与后控制的**10/10 HTTP请求body逐字相同**；两个控制却只有74/80 raw相同，6条不同，其中1条只增加NONE前换行，另5条改变格式通过状态。不能将这种无指令变化的漂移归因focused文字，也不能把它归因客户端重新分批。服务内部调度、数值路径、版本或其他流量均未核验，不猜具体原因。

六条控制raw变化：held_004-r003-t02（仅前换行）、held_004-r003-t04、held_004-r005-t01、held_004-r005-t02、held_004-r005-t03、held_016-r006-t05。REVIEW.json保存每条前后完整raw及SHA和三组完整批次槽表。

## 失败具体落点

focused有四个非法输出：CAN正例rank4/t1写“11位元以及29位元的訊息ID”，事实字面正确但没有遵守E编号选择，不能救成有效证据；负例rank5/t1、t2写带正文的E1冒号形式；rank6/t2输出“E1换行NONE”。失败source为r4、r5、r6；r4本来就是正例，另两者是负例。

后控制的三个非法输出来自负例CAN rank3/t4、rank5/t3以及Windows NT4.0标题rank6/t5。CAN rank5/t3出现长重复命名串，但没有可靠EOS/输出token使用证明，不擅自标length。其余兄弟调用合法NONE不能掩盖这三个负例source失败。

全部错误和来源并集保存在calls.jsonl/source-unions.jsonl，不改runner的原COMPLETED结果。016泛开发文档task5/6仍有16项underspecified，保留调用/格式/来源分母，不新造task特异标签；Windows侧被原查询遗漏仍沿用原冻结说明。

## 结论边界

本次加强焦点文字仍未产生任何合法非空选择，不支持以这一合同替换生产。可以继续研究更明确的选择协议，但这些结果不能推出下一条提示词必然改善；也不能从正确答案值的raw中回填E1或最终答案。源级选择与全部字段覆盖、Writer事实引用、完整RAG质量是不同指标。

三组耗时约5.99/5.24/13.33秒，仅为本轮观测；重复控制含长非法输出，不作提速结论。数据是两道已曝光题的16个单E1来源，不是新盲测，不能外推多单元定位能力。所有终止原因仍未核验；审核零新API、未改原输出、金标、源码或旧分数。
'''
    with (O / 'REPORT.md').open('x', encoding='utf-8') as file:
        file.write(md)
    save(O / 'FROZEN.json', {'schema': 'reader-focused-review-freeze-v1',
        'artifacts': [bind(p) for p in sorted(O.iterdir()) if p.is_file()] + [bind(Path(__file__))],
        'inputs': bindings, 'new_api_calls': 0, 'original_records_modified': False})
    print(json.dumps({'status': 'PASS', 'summary': summaries,
                      'freeze_sha256': sha((O / 'FROZEN.json').read_bytes())}, ensure_ascii=False))


if __name__ == '__main__':
    main()
