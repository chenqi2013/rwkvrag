"""Read-only raw-wire and frozen-gold audit. Never imports an HTTP client."""
import ast
import base64
from hashlib import sha256
import json
from pathlib import Path
import re

N = Path(__file__).resolve().parent
R = N / 'reader-presentation-v1'
C = N / 'reader-presentation-inputs-v1'
F = N / 'reader-fixtures-v1'
O = R / 'review'
PHASES = ('control-before', 'presentation', 'control-after')
FIXTURE_PIN = '0fd20a0db58f2ce444fc07c9904137e5c6b2809ba595150b550299aaa6560e56'
CANDIDATE_PIN = 'dfdd7064a75952825940165073132248267922a65cd2a391fce4e01e51bcbed0'
SOURCE_PIN = '15d64abc9a9ce960c89b1ae4bfbcc0c8730782e4f3ec3f370fb669716fdc3b9f'


def sha(data):
    return sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def lines(path):
    return list(map(json.loads, path.read_text().splitlines()))


def bind(path):
    raw = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(raw), 'sha256': sha(raw)}


def save(path, value):
    with path.open('x', encoding='utf-8') as file:
        file.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def sections(text):
    # Decode each complete JSON value, so markers inside quoted data cannot split it.
    markers = ('\n任务：', '\n子问题：', '\n来源：', '\n原文父级上下文：', '\n原文：')
    cursor = text.index(markers[0])
    out = {'instruction': text[:cursor]}
    decoder = json.JSONDecoder()
    for name, marker in zip(('task', 'tasks', 'source', 'context', 'units'), markers):
        assert text.startswith(marker, cursor)
        start = cursor + len(marker)
        value, end = decoder.raw_decode(text, start)
        out[name] = {'start': start, 'end': end, 'value': value, 'raw': text[start:end]}
        cursor = end
    assert cursor == len(text)
    return out


def main():
    assert not O.exists(), 'Never overwrite an existing review'
    start = load(R / 'STARTED.json')
    assert sha((R / 'runner.py').read_bytes()) == start['runner_sha256']
    assert sha((R / 'PLAN.json').read_bytes()) == start['plan_sha256']
    assert sha((F / 'FROZEN.json').read_bytes()) == FIXTURE_PIN == start['fixture_freeze_sha256']
    assert sha((C / 'FROZEN.json').read_bytes()) == CANDIDATE_PIN == start['candidate_freeze_sha256']
    bindings = []
    for directory in (F, C):
        bindings.append(bind(directory / 'FROZEN.json'))
        for item in load(directory / 'FROZEN.json')['files']:
            path = directory / item['path']
            spec = bind(path)
            assert spec['bytes'] == item['bytes'] and spec['sha256'] == item['sha256']
            bindings.append(spec)
    source = Path(load(N / 'reader-per-task-v1/PLAN.json')['source_snapshot'])
    manifest = source / 'SOURCE-MANIFEST.json'
    assert sha(manifest.read_bytes()) == SOURCE_PIN == start['source_manifest_sha256']
    for name, item in load(manifest)['files'].items():
        raw = (source / name).read_bytes()
        assert sha(raw) == item['sha256'] and len(raw) == item['bytes']
    parser_path = source / 'src/llamaindex_retrieval/rwkv_pipeline.py'
    fn = next(x for x in ast.parse(parser_path.read_text()).body
              if isinstance(x, ast.FunctionDef) and x.name == 'parse_task_selections')
    scope = {'re': re}
    exec(compile(ast.Module(body=[fn], type_ignores=[]), str(parser_path), 'exec'), scope)
    parse = scope['parse_task_selections']
    bindings += [bind(manifest), bind(parser_path)]
    original = {r['id']: r for r in lines(F / 'inputs.jsonl')}
    gold = {r['id']: r for r in lines(F / 'gold.jsonl')}
    candidate = {r['id']: r for r in lines(C / 'inputs.jsonl')}
    assert set(original) == set(candidate) == set(gold) and len(original) == 16
    input_checks = []
    for rid, old in original.items():
        new = candidate[rid]
        a = old['original_messages'][0]['content']
        b = new['messages'][0]['content']
        sa, sb = sections(a), sections(b)
        expected = a
        replacements = {
            'source': json.dumps({'title': old['source']['title']}, ensure_ascii=False),
            'context': json.dumps([x['text'] for x in old['context']], ensure_ascii=False),
        }
        for key in ('context', 'source'):
            span = sa[key]
            expected = expected[:span['start']] + replacements[key] + expected[span['end']:]
        assert b == expected
        assert sa['instruction'] == sb['instruction']
        for key in ('task', 'tasks', 'units'):
            assert sa[key]['raw'] == sb[key]['raw']
        assert sa['task']['raw'] == old['task']
        assert sa['tasks']['value'] == old['active_tasks']
        assert sa['source']['value'] == {k: old['source'][k] for k in ('id', 'title', 'uri')}
        assert sa['context']['value'] == old['context']
        assert sa['units']['value'] == {x['id']: x['text'] for x in old['units']}
        for unit in old['units']:
            assert old['source']['snippet'][unit['start']:unit['end']] == unit['text']
            assert sha(unit['text'].encode()) == unit['sha256']
        for context in old['context']:
            assert set(context) == {'sha256', 'level', 'kind', 'start', 'end', 'text'}
            assert context['kind'] == 'heading' and context['text'].startswith('#' * context['level'] + ' ')
            assert len(context['text']) == context['end'] - context['start']
            assert sha(context['text'].encode()) == context['sha256']
        for key in ('task', 'active_tasks', 'source', 'context', 'units', 'completion_parameters'):
            assert new[key] == old[key]
        assert new['messages'] == [{'role': 'user', 'content': expected}]
        assert new['prompt'] == 'User: ' + expected + '\n\nAssistant: <think></think>'
        assert sha(new['prompt'].encode()) == new['prompt_sha256']
        assert new['http_payload'] == {**old['original_http_parameters'], 'contents': [new['prompt']]}
        input_checks.append({'id': rid, 'only_declared_sections_change': True,
            'original_prompt_sha256': old['original_prompt_sha256'], 'candidate_prompt_sha256': new['prompt_sha256'],
            'context_texts': len(old['context']), 'unit_text_characters': sum(len(x['text']) for x in old['units'])})
    calls, summaries, schedules, outputs = [], [], {}, {}
    seen_ids = set()
    for phase in PHASES:
        directory = R / phase
        requests = load(directory / 'REQUESTS.json')
        assert len(requests) == 16 and {r['id'] for r in requests} == set(original)
        assert len(list((directory / 'calls').glob('*.started.json'))) == 16
        assert len(list((directory / 'calls').glob('*.completed.json'))) == 16
        assert len(list((directory / 'batch-http').glob('*.batch_started.json'))) == 2
        batches = {}
        for path in (directory / 'batch-http').glob('*.batch_completed.json'):
            pre_path = path.with_name(path.name.replace('batch_completed', 'batch_started'))
            item, pre = load(path), load(pre_path)
            assert item['payload'] == pre['payload'] and item['request_body_sha256'] == pre['request_body_sha256']
            for kind in ('request', 'response'):
                raw = base64.b64decode(item[f'{kind}_body_base64'], validate=True)
                assert sha(raw) == item[f'{kind}_body_sha256']
                assert json.loads(raw) == item['payload' if kind == 'request' else 'response_json']
            assert item['http_status'] == 200 and item['http_attempted'] and item['response_body_complete']
            assert item['response_json']['model'] == item['payload']['model']
            assert len(item['payload']['contents']) == 8
            assert sorted(x['index'] for x in item['response_json']['choices']) == list(range(8))
            assert sorted(x['index'] for x in item['slots']) == list(range(8))
            assert item['batch_id'] not in batches
            batches[item['batch_id']] = item
            bindings += [bind(path), bind(pre_path)]
        assert len(batches) == 2
        by_id, call_to_job = {}, {}
        for req in requests:
            rid = req['id']
            assert req['source_sample_id'] == rid
            old = original[rid]
            exp = candidate[rid] if phase == 'presentation' else {
                'messages': old['original_messages'], 'prompt': old['original_prompt'],
                'prompt_sha256': old['original_prompt_sha256'], 'completion_parameters': old['completion_parameters']}
            for key in ('messages', 'prompt', 'prompt_sha256', 'completion_parameters'):
                assert req[key] == exp[key]
            path = directory / 'calls' / f'{rid}.completed.json'
            pre_path = directory / 'calls' / f'{rid}.started.json'
            row, pre = load(path), load(pre_path)
            trace = row['trace']
            assert row['id'] == pre['id'] == rid and row['source_sample_id'] == pre['source_sample_id'] == rid
            assert trace['messages'] == pre['messages'] == exp['messages']
            assert pre['completion_parameters'] == exp['completion_parameters']
            assert trace['prompt'] == exp['prompt']
            assert sha(trace['prompt'].encode()) == trace['prompt_sha256'] == exp['prompt_sha256']
            assert trace['parameters'] == old['original_http_parameters']
            assert trace['state_id'] is None and trace['prefill'] == '<think></think>'
            assert row['status'] == trace['status'] == 'completed'
            assert trace['termination'] == 'unknown' and trace['termination_verified'] is False
            assert trace['call_id'] not in seen_ids
            seen_ids.add(trace['call_id'])
            call_to_job[trace['call_id']] = rid
            batch = batches[trace['batch_id']]
            assert trace['http'] == [batch]
            assert batch['payload']['contents'][trace['batch_index']] == exp['prompt']
            slot = next(x for x in batch['slots'] if x['index'] == trace['batch_index'])
            assert slot['call_id'] == trace['call_id']
            choice = next(x for x in batch['response_json']['choices'] if x['index'] == trace['batch_index'])
            raw = row['raw_text']
            assert raw == trace['raw_text'] == choice['message']['content']
            assert sha(raw.encode()) == trace['raw_text_sha256']
            assert choice['finish_reason'] == trace['provider_finish_reason'] == 'stop'
            assert trace['envelope'] == {'valid': True, 'answer_span': {'start': 0, 'end': len(raw), 'unit': 'unicode_code_points'}, 'raw_text_modified': False}
            selected, error = [], None
            try:
                selected = [f'E{i}' for i in parse(raw.strip(), len(old['units']))]
            except (ValueError, TypeError) as exc:
                error = str(exc)
            assert row['format_pass'] == (error is None) and row.get('parse_error') == error
            if error is None:
                assert row['selected_units'] == selected
            expected = gold[rid]['expected_full_question_union_unit_ids']
            call = {'phase': phase, 'id': rid, 'label': gold[rid]['label'], 'raw_text': raw,
                'raw_sha256': sha(raw.encode()), 'format_pass': error is None, 'parse_error': error,
                'selected_union': selected, 'expected_union': expected,
                'strict_source_success': error is None and set(selected) == set(expected),
                'positive_recalled': bool(set(selected) & set(expected)) if expected else None,
                'valid_negative_false_selection': bool(selected) if not expected else None,
                'call_receipt': bind(path), 'batch_id': trace['batch_id'], 'batch_index': trace['batch_index'],
                'termination_verified': False}
            calls.append(call)
            by_id[rid] = call
            bindings += [bind(path), bind(pre_path)]
        outputs[phase] = by_id
        schedules[phase] = [{'batch_id': b['batch_id'], 'started_at': b['started_at'],
            'slot_jobs': [call_to_job[x['call_id']] for x in sorted(b['slots'], key=lambda x: x['index'])],
            'request_body_sha256': b['request_body_sha256'], 'response_body_sha256': b['response_body_sha256']}
            for b in sorted(batches.values(), key=lambda x: x['started_at'])]
        s = load(directory / 'COMPLETED.json')
        rows = list(by_id.values())
        summary = {'phase': phase, 'calls': 16, 'http_requests': 2,
            'format_pass': sum(x['format_pass'] for x in rows),
            'valid_nonempty': sum(bool(x['selected_union']) for x in rows),
            'positive_recall': sum(x['positive_recalled'] is True for x in rows), 'positive_denominator': 8,
            'valid_negative_false_selections': sum(x['valid_negative_false_selection'] is True for x in rows), 'negative_denominator': 8,
            'strict_negative_success': sum(x['label'] == 'negative' and x['strict_source_success'] for x in rows),
            'strict_source_success': sum(x['strict_source_success'] for x in rows), 'source_denominator': 16,
            'failed_sources': [x['id'] for x in rows if not x['format_pass']], 'elapsed_ms': s['elapsed_ms']}
        assert s['calls'] == 16 and s['format_pass'] == summary['format_pass']
        assert s['nonempty_selections'] == summary['valid_nonempty']
        assert s['http']['http_requests'] == 2 and s['http']['unknown'] == 0
        summaries.append(summary)
        bindings += [bind(directory / 'REQUESTS.json'), bind(directory / 'COMPLETED.json')]
    comparisons = []
    for left, right in [('control-before', 'control-after'), ('control-before', 'presentation'), ('presentation', 'control-after')]:
        diffs = [{'id': rid, 'left_raw': outputs[left][rid]['raw_text'], 'right_raw': outputs[right][rid]['raw_text'],
            'left_format_pass': outputs[left][rid]['format_pass'], 'right_format_pass': outputs[right][rid]['format_pass']}
            for rid in original if outputs[left][rid]['raw_text'] != outputs[right][rid]['raw_text']]
        comparisons.append({'left': left, 'right': right, 'same_raw_calls': 16 - len(diffs), 'raw_differences': diffs,
            'same_slot_and_batch_order': [x['slot_jobs'] for x in schedules[left]] == [x['slot_jobs'] for x in schedules[right]],
            'same_request_body_batches': sum(a['request_body_sha256'] == b['request_body_sha256']
                for a, b in zip(schedules[left], schedules[right], strict=True))})
    assert [x['format_pass'] for x in summaries] == [15, 14, 15]
    assert [x['strict_source_success'] for x in summaries] == [7, 6, 7]
    assert all(x['positive_recall'] == 0 and x['valid_nonempty'] == 0 for x in summaries)
    assert comparisons[0]['same_raw_calls'] == 15 and comparisons[0]['same_request_body_batches'] == 2
    assert all(x['same_slot_and_batch_order'] for x in comparisons)
    bindings += [bind(R / name) for name in ('STARTED.json', 'PLAN.json', 'COMPLETED.json', 'runner.py')]
    report = {'schema': 'reader-presentation-independent-review-v1',
        'reviewer': 'Codex independent non-blind frozen-gold review',
        'summary': summaries, 'comparisons': comparisons, 'batch_schedules': schedules,
        'input_checks': input_checks, 'calls': calls, 'promotion': False,
        'control_format_and_semantic_scores_stable': True, 'control_raw_bytes_stable': False,
        'checks': {'model_call_receipts_verified': 48, 'batch_http_receipts_verified': 6,
            'all_source_unit_context_input_bytes_verified': True, 'only_declared_metadata_presentations_changed': True,
            'parser_recomputed': 48, 'gold_and_source_freeze_verified': True, 'new_api_calls': 0},
        'limitations': ['Two metadata sections are one presentation intervention; their individual effects are not isolated.',
            'Same body and slot arrangement do not prove identical server scheduling, revision, precision or numerical execution. No backend cause is asserted.',
            'Control scores are stable, but one invalid raw output drifts. The extra candidate format failure is an observation, not a generalized causal effect.',
            'All16 exposed sources have one E1. No blind generalization, multi-unit localization or end-to-end QA improvement is established.',
            'Generic active tasks and omitted Windows scope remain unchanged. Source-union success is not complete fact coverage.',
            'Provider stop remains unverified; apparent loops cannot be classified as length without reliable termination evidence.'],
        'bindings': bindings}
    O.mkdir()
    save(O / 'REVIEW.json', report)
    with (O / 'REPORT.md').open('x', encoding='utf-8') as file:
        file.write('''# Reader 元数据呈现对照：独立审阅

**不晋级。去掉来源追踪字段并把父标题改为原文字符串列表后，8个正向来源仍全部漏选。** 已离线复核48调用、6共享HTTP的原始请求/响应字节、槽位、完整输入、冻结金标与原严格解析器，未发新API或修改原记录。

| 条件 | 格式通过 | 正例召回 | 有效负例误选 | 严格负例成功 | 严格来源成功 |
|---|---:|---:|---:|---:|---:|
| 前控制：原联合任务 | 15/16 | 0/8 | 0/8 | 7/8 | 7/16 |
| 候选：简化元数据呈现 | 14/16 | 0/8 | 0/8 | 6/8 | 6/16 |
| 后控制：原联合任务 | 15/16 | 0/8 | 0/8 | 7/8 | 7/16 |

合法输出全为NONE；错误输出不当成正确拒选。每个source只有一次联合任务调用，故格式失败直接导致该来源严格失败。金标仍为此前逐字审阅的8正/8负，没有根据NONE改成负例。

候选严格只改变两段JSON的呈现：来源由id/title/uri改成同一title；24个父级上下文heading对象改成按原顺序排列的24个text字符串。父标题全部278字符（含Markdown层级与尾换行）、E正文全部3503字符保持。完整指令、任务JSON与history、联合子问题数组、E编号/字面原文、其余模板、1024输出预算、采样、完整闭合前缀、stop[0]与state省略均未变；外层完整source/context追踪信息仍保留。两处改动是一项呈现合同，未分别隔离。

三组实际均为2个8槽batch，成员与槽位排列相同。前后控制的2/2请求body逐字相同，15/16 raw相同，唯一CAN rank5负例的长非法输出发生变化，格式和语义分数仍相同。因此本轮控制在所测指标上稳定，但不能称逐字稳定，也不能猜测后端原因。

候选两个失败均为CAN负例：rank1仅有“# CAN FD”标题，却返回`E1: "# CAN FD\\n"`；rank5只有供应商小标题，却返回E1冒号加问题列表。原解析器拒绝这些正文/编号混写，没有把它们当成有效E1误选；也没有将格式无效当负例成功。rank5在前后控制同样格式失败，且包含原文没有支持的ID位数、字节与冗长线路条件罗列；所有错误raw都保留。

8个正例三个条件全为NONE，包括CAN直接载荷/速率、ID位数/线路条件，以及Windows 8、XML、m4a和Vista来源。省略Windows侧的原模型任务与泛泛开发任务未被补写；本轮主指标仅是完整有效问题的来源选择并集，不宣称所有字段已覆盖。没有从非法答案值、未选择原文或thinking救分。

本次观察到额外1个候选格式失败、未观察到正召回收益；这不足以支持生产采用，也不证明一般元数据简化必然有害。三次耗时约12.31/2.35/12.44秒，控制含长非法重复输出，且提供方stop不能证明自然终止或实际耗满预算，不能把该时差当吞吐提升。

本轮为两道已曝光题的16个来源，且每个来源只有E1；没有验证新题泛化、多E定位或完整RAG质量。独立审阅只重算已冻结标准；源快照、金标、旧分数和原始结果均未改。
''')
    save(O / 'FROZEN.json', {'schema': 'reader-presentation-review-freeze-v1',
        'artifacts': [bind(p) for p in sorted(O.iterdir()) if p.is_file()] + [bind(Path(__file__))],
        'inputs': bindings, 'new_api_calls': 0, 'original_records_modified': False})
    print(json.dumps({'status': 'PASS', 'summary': summaries, 'freeze_sha256': sha((O / 'FROZEN.json').read_bytes())}, ensure_ascii=False))


if __name__ == '__main__':
    main()
