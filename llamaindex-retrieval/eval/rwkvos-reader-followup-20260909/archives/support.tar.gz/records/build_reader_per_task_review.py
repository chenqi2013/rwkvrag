"""Offline replay and source-union scoring against frozen exposed-fixture gold."""
import ast
import base64
from collections import Counter
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import re

N = Path(__file__).resolve().parent
R = N / 'reader-per-task-v1'
F = N / 'reader-fixtures-v1'
O = R / 'review'
FIXTURE_SHA = '0fd20a0db58f2ce444fc07c9904137e5c6b2809ba595150b550299aaa6560e56'
PHASES = ['control-before', 'per-task', 'control-after']


def sha(data):
    return sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_text())


def lines(path):
    return list(map(json.loads, path.read_text().splitlines()))


def bind(path):
    data = path.read_bytes()
    return {'path': str(path.resolve()), 'sha256': sha(data), 'bytes': len(data)}


def save(path, value):
    with path.open('x', encoding='utf-8') as file:
        file.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    assert not O.exists(), 'Do not overwrite a review'
    started = load(R / 'STARTED.json')
    assert sha((F / 'FROZEN.json').read_bytes()) == FIXTURE_SHA == started['fixture_freeze_sha256']
    assert sha((R / 'runner.py').read_bytes()) == started['runner_sha256']
    assert sha((R / 'PLAN.json').read_bytes()) == started['plan_sha256']
    for item in load(F / 'FROZEN.json')['files']:
        raw = (F / item['path']).read_bytes()
        assert sha(raw) == item['sha256'] and len(raw) == item['bytes']
    source = Path(load(R / 'PLAN.json')['source_snapshot'])
    source_manifest = source / 'SOURCE-MANIFEST.json'
    assert sha(source_manifest.read_bytes()) == started['source_manifest_sha256']
    for name, spec in load(source_manifest)['files'].items():
        data = (source / name).read_bytes()
        assert sha(data) == spec['sha256'] and len(data) == spec['bytes']
    parser_path = source / 'src/llamaindex_retrieval/rwkv_pipeline.py'
    nodes = [n for n in ast.parse(parser_path.read_text()).body if isinstance(n, ast.FunctionDef) and n.name == 'parse_task_selections']
    assert len(nodes) == 1
    scope = {'re': re}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(parser_path), 'exec'), scope)
    parse = scope['parse_task_selections']
    inputs = {x['id']: x for x in lines(F / 'inputs.jsonl')}
    tasks = {x['id']: x for x in lines(F / 'per-task.inputs.jsonl')}
    gold = {x['id']: x for x in lines(F / 'gold.jsonl')}
    historical = {x['id']: x for x in lines(F / 'baseline-observations.jsonl')}
    call_rows, source_rows, phase_rows = [], [], []
    bindings = [bind(p) for p in [F / 'FROZEN.json', F / 'inputs.jsonl', F / 'per-task.inputs.jsonl', F / 'gold.jsonl',
        F / 'baseline-observations.jsonl', R / 'PLAN.json', R / 'STARTED.json', R / 'COMPLETED.json', R / 'runner.py', source_manifest, parser_path]]
    unique_call_ids = set()
    phase_outputs = {}
    phase_times = []
    for phase in PHASES:
        directory = R / phase
        requests = load(directory / 'REQUESTS.json')
        expected_ids = set(tasks) if phase == 'per-task' else set(inputs)
        assert {x['id'] for x in requests} == expected_ids and len(requests) == len(expected_ids)
        assert {p.name.removesuffix('.completed.json') for p in (directory / 'calls').glob('*.completed.json')} == expected_ids
        assert {p.name.removesuffix('.started.json') for p in (directory / 'calls').glob('*.started.json')} == expected_ids
        batch_map = {}
        for path in sorted((directory / 'batch-http').glob('*.batch_completed.json')):
            entry = load(path)
            assert entry['batch_id'] not in batch_map
            batch_map[entry['batch_id']] = entry
            pre_path = Path(str(path).replace('.batch_completed.json', '.batch_started.json'))
            pre = load(pre_path)
            assert pre['batch_id'] == entry['batch_id']
            assert pre['payload'] == entry['payload']
            assert pre['request_body_sha256'] == entry['request_body_sha256']
            raw_request = base64.b64decode(entry['request_body_base64'], validate=True)
            raw_response = base64.b64decode(entry['response_body_base64'], validate=True)
            assert sha(raw_request) == entry['request_body_sha256']
            assert sha(raw_response) == entry['response_body_sha256']
            assert json.loads(raw_request) == entry['payload']
            assert json.loads(raw_response) == entry['response_json']
            assert entry['http_attempted'] is True and entry['http_status'] == 200 and entry['response_body_complete'] is True
            assert entry['response_json']['model'] == entry['payload']['model']
            assert sorted(x['index'] for x in entry['response_json']['choices']) == list(range(len(entry['payload']['contents'])))
            bindings += [bind(path), bind(pre_path)]
        outputs = {}
        current_calls = []
        for request in requests:
            rid, sid = request['id'], request['source_sample_id']
            inp = inputs[sid]
            expected = tasks[rid] if phase == 'per-task' else {
                'messages': inp['original_messages'], 'prompt': inp['original_prompt'],
                'prompt_sha256': inp['original_prompt_sha256'], 'completion_parameters': inp['completion_parameters']}
            for key in ['messages', 'prompt', 'prompt_sha256', 'completion_parameters']:
                assert request[key] == expected[key]
            path = directory / 'calls' / (rid + '.completed.json')
            pre_path = directory / 'calls' / (rid + '.started.json')
            row, pre = load(path), load(pre_path)
            trace = row['trace']
            assert pre['messages'] == trace['messages'] == request['messages']
            assert pre['completion_parameters'] == request['completion_parameters']
            assert trace['prompt'] == request['prompt']
            assert sha(trace['prompt'].encode()) == trace['prompt_sha256'] == request['prompt_sha256']
            assert trace['parameters'] == inp['original_http_parameters']
            assert trace['state_id'] is None and trace['prefill'] == '<think></think>'
            assert trace['status'] == row['status'] == 'completed'
            assert trace['termination_verified'] is False and trace['termination'] == 'unknown'
            assert trace['call_id'] not in unique_call_ids
            unique_call_ids.add(trace['call_id'])
            assert len(trace['http']) == 1 and 'token_count_id' not in trace
            batch = batch_map[trace['batch_id']]
            assert trace['http'][0] == batch
            assert batch['payload']['contents'][trace['batch_index']] == trace['prompt']
            actual = next(x for x in batch['response_json']['choices'] if x['index'] == trace['batch_index'])
            raw = row['raw_text']
            assert actual['message']['content'] == trace['raw_text'] == raw
            assert sha(raw.encode()) == trace['raw_text_sha256']
            assert actual['finish_reason'] == trace['provider_finish_reason'] == 'stop'
            assert trace['envelope'] == {'valid': True, 'answer_span': {'start': 0, 'end': len(raw), 'unit': 'unicode_code_points'}, 'raw_text_modified': False}
            error, selected = None, []
            try:
                selected = [f'E{i}' for i in parse(raw.strip(), len(inp['units']))]
            except (ValueError, TypeError) as exc:
                error = str(exc)
            assert row['format_pass'] == (error is None)
            assert row.get('parse_error') == error
            if error is None:
                assert selected == row['selected_units']
            specific = None
            if phase == 'per-task':
                specific = next(t for t in gold[sid]['per_task_diagnostics'] if t['id'] == rid)
            result = {'phase': phase, 'id': rid, 'source_sample_id': sid,
                'source_label': gold[sid]['label'], 'task_index': row['task_index'],
                'raw_text': raw, 'raw_sha256': sha(raw.encode()), 'format_pass': error is None,
                'selected_units': selected, 'parse_error': error,
                'task_specific_expected': None if specific is None else specific['supported_unit_ids'],
                'task_specific_status': None if specific is None else specific['diagnostic_status'],
                'task_specific_match_diagnostic_only': None if specific is None or specific['supported_unit_ids'] is None else error is None and selected == specific['supported_unit_ids'],
                'raw_path': str(path.relative_to(N)), 'prompt_sha256': trace['prompt_sha256'],
                'batch_id': trace['batch_id'], 'batch_index': trace['batch_index'],
                'http_request_sha256': batch['request_body_sha256'], 'http_response_sha256': batch['response_body_sha256'],
                'termination_verified': False}
            call_rows.append(result)
            current_calls.append(result)
            outputs[rid] = row
            bindings += [bind(path), bind(pre_path)]
        phase_outputs[phase] = outputs
        current_sources = []
        for sid in inputs:
            siblings = [c for c in current_calls if c['source_sample_id'] == sid]
            expected_siblings = len(inputs[sid]['active_tasks']) if phase == 'per-task' else 1
            assert len(siblings) == expected_siblings
            selected_union = list(dict.fromkeys(u for c in siblings if c['format_pass'] for u in c['selected_units']))
            expected_union = gold[sid]['expected_full_question_union_unit_ids']
            all_valid = all(c['format_pass'] for c in siblings)
            success = all_valid and set(selected_union) == set(expected_union)
            result = {'phase': phase, 'source_sample_id': sid, 'case_id': inputs[sid]['case_id'],
                'source_label': gold[sid]['label'], 'scheduled_siblings': expected_siblings,
                'observed_siblings': len(siblings), 'sibling_ids': [c['id'] for c in siblings],
                'failed_siblings': [c['id'] for c in siblings if not c['format_pass']],
                'all_siblings_valid': all_valid, 'selected_union': selected_union,
                'expected_full_question_union': expected_union,
                'union_exact_ignoring_sibling_failure': set(selected_union) == set(expected_union),
                'strict_source_success': success,
                'positive_recalled': bool(set(selected_union) & set(expected_union)) if expected_union else None,
                'valid_negative_false_selection': bool(selected_union) if not expected_union else None,
                'not_all_fields_covered_by_selection': True}
            source_rows.append(result)
            current_sources.append(result)
        original_summary = load(directory / 'COMPLETED.json')
        assert original_summary['calls'] == len(current_calls)
        assert original_summary['format_pass'] == sum(c['format_pass'] for c in current_calls)
        assert original_summary['nonempty_selections'] == sum(bool(c['selected_units']) for c in current_calls)
        assert original_summary['http']['http_requests'] == len(batch_map)
        assert original_summary['http']['unknown'] == 0
        phase_times.append({'phase': phase,
            'first_http': min(datetime.fromisoformat(b['started_at']) for b in batch_map.values()),
            'last_http': max(datetime.fromisoformat(b['ended_at']) for b in batch_map.values())})
        phase_rows.append({'phase': phase, 'calls': len(current_calls), 'batch_http': len(batch_map),
            'format_pass': sum(c['format_pass'] for c in current_calls), 'pure_NONE': sum(c['raw_text'] == 'NONE' for c in current_calls),
            'valid_nonempty_calls': sum(bool(c['selected_units']) for c in current_calls),
            'source_denominator': 16, 'positive_denominator': 8, 'negative_denominator': 8,
            'strict_source_success': sum(s['strict_source_success'] for s in current_sources),
            'source_union_match_ignoring_sibling_failure': sum(s['union_exact_ignoring_sibling_failure'] for s in current_sources),
            'positive_recalled': sum(s['positive_recalled'] is True for s in current_sources),
            'negative_false_selections': sum(s['valid_negative_false_selection'] is True for s in current_sources),
            'strict_negative_success': sum(s['strict_source_success'] and s['source_label'] == 'negative' for s in current_sources),
            'sources_with_sibling_errors': [s['source_sample_id'] for s in current_sources if not s['all_siblings_valid']],
            'elapsed_ms': original_summary['elapsed_ms']})
        bindings += [bind(directory / 'REQUESTS.json'), bind(directory / 'COMPLETED.json')]
    for before, after in zip(phase_times, phase_times[1:]):
        assert before['last_http'] < after['first_http']
    controls = []
    for sid in inputs:
        before = phase_outputs['control-before'][sid]
        after = phase_outputs['control-after'][sid]
        controls.append({'source_sample_id': sid,
            'prompt_exact_same': before['trace']['prompt'] == after['trace']['prompt'],
            'parameters_exact_same': before['trace']['parameters'] == after['trace']['parameters'],
            'raw_exact_same': before['raw_text'] == after['raw_text'],
            'status_and_parser_same': all(before.get(k) == after.get(k) for k in ['status', 'format_pass', 'parse_error', 'selected_units']),
            'historical_raw_exact_same': historical[sid]['raw_text'] == before['raw_text']})
    assert all(c['raw_exact_same'] and c['prompt_exact_same'] and c['parameters_exact_same'] and c['status_and_parser_same'] for c in controls)
    assert len(call_rows) == 112 and sum(p['batch_http'] for p in phase_rows) == 14
    assert [p['strict_source_success'] for p in phase_rows] == [7, 7, 7]
    assert [p['positive_recalled'] for p in phase_rows] == [0, 0, 0]
    assert [p['format_pass'] for p in phase_rows] == [15, 78, 15]
    report = {'schema': 'reader-per-task-source-union-review-v1',
        'reviewer': 'Codex independent offline review using pre-run frozen source and task labels',
        'phase_summary': phase_rows, 'control_comparison': controls,
        'contemporaneous_controls_raw_identical': 16,
        'historical_raw_identical': sum(c['historical_raw_exact_same'] for c in controls),
        'task_diagnostics': {'scorable_specific_pairs': 64, 'underspecified_pairs': 16,
            'specific_positive_pairs': 11, 'specific_positive_recalled': 0,
            'specific_negative_pairs': 53, 'specific_negative_valid_NONE': 51, 'specific_negative_format_failure': 2,
            'primary_metric': False},
        'promotion': False,
        'reason': 'No positive source was recalled; all three phases have strict source success 7/16. Improved-looking per-call format proportion uses a different call denominator and did not improve source-level validity.',
        'raw_failures': [r for r in call_rows if not r['format_pass']],
        'limitations': ['Exposed balanced 16-source development set from only two original questions; every source has one E1 unit.',
            'Gold stays separate from client inputs; all four errors remain original and no successful sibling masks a failed call.',
            'No downstream retrieval or Writer ran; this is not an end-to-end QA score.',
            'Per-task specificity is diagnostic because complete task JSON still includes other targets; generic tasks5/6 remain underspecified.',
            'No server weight/revision attestation or EOS proof; reported stop remains unknown termination.',
            'Control-before and after are stable in this interval, while historical raw changed. No cause for historical drift is inferred.',
            'Phase wall times are observed shared API round trips, not an isolated speed benchmark. Long invalid generation in control rank5 dominates elapsed time.'],
        'checks': {'all_original_input_and_source_bindings_verified': True, 'all112_raw_http_choices_and_payloads_verified': True,
                   'all112_started_completed_pairs_present': True, 'source_manifest_verified': True,
                   'phase_http_intervals_nonoverlapping': True, 'new_model_calls_by_reviewer': 0},
        'bindings': bindings}
    O.mkdir()
    save(O / 'REVIEW.json', report)
    for name, rows in [('calls.jsonl', call_rows), ('source-unions.jsonl', source_rows)]:
        with (O / name).open('x', encoding='utf-8') as file:
            for row in rows:
                file.write(json.dumps(row, ensure_ascii=False) + '\n')
    hypotheses = []
    for sid, ti, interpretation in [
        ('held_016-r002', 2, '正文27字符用“首个版本”指代1.0，版本号在单独父级标题JSON中；要求模型跨正文/父级绑定对象，同时还看到四目标完整问题及六项子问题。元数据SHA与另一种长来源ID增加映射负担。这是可能的协议负担，不是证据缺失：实际1.0标题已送入，所需答案在正文。'),
        ('held_016-r064', 4, '正文69字符直接说Media Foundation首次适用Windows Vista，本身语义足够清楚；完整prompt1197字符中绝大部分是多目标任务、指令与元数据。E1选择的编码/任务优先级可能比事实理解更困难，但没有证据证明这是NONE的内部原因。')]:
        inp = inputs[sid]
        taskid = f'{sid}-t{ti:02d}'
        hypotheses.append({'source_sample_id': sid, 'source_characters': len(inp['source']['snippet']),
            'original_prompt_characters': len(inp['original_prompt']), 'unit': 'unicode_code_points, not tokens',
            'original_prompt': inp['original_prompt'], 'original_prompt_sha256': inp['original_prompt_sha256'],
            'source': inp['source'], 'units': inp['units'], 'context': inp['context'],
            'before_raw': phase_outputs['control-before'][sid]['raw_text'],
            'specific_task_prompt': tasks[taskid]['prompt'],
            'specific_task_raw': phase_outputs['per-task'][taskid]['raw_text'],
            'after_raw': phase_outputs['control-after'][sid]['raw_text'],
            'hypothesis_not_cause': interpretation,
            'counterevidence': '本轮仅把子问题列表缩成单项仍然NONE，所以“拆列表”这一实际干预未能解决问题。不能据prompt长于正文就宣称压缩提示一定有效。',
            'possible_next_protocol_test': '另行冻结协议实验可比较明确当前单一查证问题、清楚标注可用于指代的父级正文与唯一E1/NONE选择；保持原文和必要上下文，元数据仍留trace。需要独立变量与全部正负例，不能在本轮追补或补答案。'})
    save(O / 'SHORT-POSITIVE-HYPOTHESES.json', hypotheses)
    md = ['# Reader 单任务列表对照：同期严格来源审阅', '',
        '**未改善正向召回，不晋级生产。** 已核对112条完整原始输出、14个共享HTTP及所有来源/任务/金标绑定。前后控制16/16输出逐字相同；全部三组正例召回均0/8，严格来源成功均7/16。', '',
        '| 条件 | 调用 / HTTP | 严格格式 | 正例来源召回 | 负例有效误选 | 严格负例成功 | 严格来源成功 |',
        '|---|---:|---:|---:|---:|---:|---:|',
        '| control-before | 16 / 2 | 15/16 | 0/8 | 0/8 | 7/8 | 7/16 |',
        '| per-task | 80 / 10 | 78/80 | 0/8 | 0/8 | 7/8 | 7/16 |',
        '| control-after | 16 / 2 | 15/16 | 0/8 | 0/8 | 7/8 | 7/16 |', '',
        '所有合法输出均为NONE，源级并集均为空。若忽略失败，并集表面会与8个负例相同；主口径不能这么计分：CAN厂商标题rank5仍有错误兄弟调用，故只有7个负例严格成功，另1个失败而非正确拒选。0个有效负例误选不等于8个负例都通过。', '',
        '## 来源与错误保留', '',
        '| 来源 | 完整问题预期 | 三组严格情况 |', '|---|---|---|']
    for sid in inputs:
        expected = ','.join(gold[sid]['expected_full_question_union_unit_ids']) or 'NONE'
        situation = '都漏选正向原文' if gold[sid]['label'] == 'positive' else '都有协议失败' if sid == 'held_004-r005' else '均正确NONE'
        md.append(f'| {sid} | {expected} | {situation} |')
    md += ['', '前后控制错误都在 `held_004-r005`：输入只是“订定CAN FD标准的供应商”标题，模型输出大量ID/载荷/线路参数，且不符合编号协议。该raw前后完全相同。逐任务该源t1输出长source_id再换行NONE；t2输出 `E1: "## 訂定CAN FD標準的供應商"`，均非法。t3/t4的NONE不能补救同源的两项失败。四条完整原输出保存在REVIEW.json/raw_failures与原calls文件；没有抽取其中E1或NONE救格式。', '',
        '## 控制稳定性与任务诊断', '',
        '前后控制的完整prompt、参数、raw、状态及解析结果均16/16一致。与上一轮已曝光历史raw相比，只有开发文档题8条一致，CAN题8条均变化；不能把历史格式8/16与本轮15/16的差别归因本次拆任务。未推测远端更新、随机性或状态变化的具体原因。', '',
        '逐task特异标签仍只是诊断：64项有明确标签（11正向全部未召回，53负向中51合法NONE、2格式失败），16项泛开发文档任务保留underspecified但仍在80调用及source并集中。原完整问题仍包含所有目标，不能将支持另一原目标的E1称为幻选。016原查询漏Windows一侧的事实单列，未补改任务。选择原文也不表示覆盖全部用户字段。', '',
        '## 两个最短正例的协议假设', '',
        'WinJS原文27字符，完整prompt1283字符：1.0版本在父级标题，正文写“首个版本…随Windows 8发布”。Media Foundation原文69字符，完整prompt1197字符：正文直接给“首次适用于Windows Vista”。这些字符数不是token数。两例原完整prompt、父级上下文、单任务prompt及前/中/后三个NONE完整保存在SHORT-POSITIVE-HYPOTHESES.json。', '',
        '可能的负担是短证据要与分开的父级标题、多个任务、来源ID与E编号建立对应关系；尤其完整任务与单项子问题并存，没有显式优先级。但MF本身命题十分清楚，不能把模型失败写成问题不可理解。当前真正测过的“只缩子问题列表”仍未改善；更短的单一判定协议或更明确的上下文分工仅可作为另行冻结实验，不能当已证原因，更不能补入答案值或删去必要版本信息。', '',
        '## 边界', '',
        '本次是两道已曝光题的16来源选择实验，正负各8且所有源仅E1，不是盲测、不是端到端QA，也不证明多单元定位。提供方stop不能证明自然结束，终止仍unknown。阶段耗时约13.21/5.99/13.60秒；中间80调用反而较短是本次输出形态的观测，不能声称普遍提速。没有新模型调用、原raw/runner结果/冻结gold/旧QA评分均未改变。', '']
    with (O / 'REPORT.md').open('x', encoding='utf-8') as file:
        file.write('\n'.join(md))
    save(O / 'FROZEN.json', {'schema': 'reader-per-task-review-freeze-v1',
        'artifacts': [bind(p) for p in sorted(O.iterdir()) if p.is_file()] + [bind(Path(__file__))],
        'inputs': bindings, 'fixture_freeze_sha256': FIXTURE_SHA,
        'new_model_calls': 0, 'original_records_modified': False})
    print(json.dumps({'status': 'PASS', 'phases': phase_rows,
                      'frozen_sha256': sha((O / 'FROZEN.json').read_bytes())}, ensure_ascii=False))


if __name__ == '__main__':
    main()
