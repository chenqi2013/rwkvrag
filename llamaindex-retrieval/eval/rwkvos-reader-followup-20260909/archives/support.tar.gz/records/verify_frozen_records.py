from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
N=Path(__file__).resolve().parent
cache={};checks=[];manifests=[]
def hash_file(p):
 p=p.resolve();stat=p.stat();key=(str(p),stat.st_size,stat.st_mtime_ns)
 if key not in cache:
  with p.open("rb") as f:cache[key]=hashlib.file_digest(f,"sha256").hexdigest()
 return cache[key]
def check(p,spec,owner):
 assert p.is_file(),str(p)
 if "bytes" in spec:assert p.stat().st_size==spec["bytes"],str(p)
 assert hash_file(p)==spec["sha256"],str(p)
 checks.append({"manifest":str(owner.relative_to(N)),"path":str(p),"sha256":spec["sha256"]})
for p in sorted(N.rglob("FROZEN.json")):
 if any(part in {"cache",".cache","__pycache__"} for part in p.parts):continue
 r=json.loads(p.read_text());groups=[]
 for name in ("files","artifacts","inputs","input_file_bindings"):
  if name not in r:continue
  fs=r[name];groups.append(name)
  if isinstance(fs,dict):rows=[dict(spec,path=name) for name,spec in fs.items()]
  else:assert isinstance(fs,list);rows=fs
  for spec in rows:
   assert isinstance(spec,dict) and "path" in spec and "sha256" in spec,(str(p),spec)
   q=Path(spec["path"])
   if not q.is_absolute():q=p.parent/q
   check(q,spec,p)
 assert groups,str(p)
 manifests.append({"path":str(p.relative_to(N)),"sha256":hash_file(p),"groups":groups})
result={"at":datetime.now(timezone.utc).isoformat(),"status":"PASS","script_sha256":hash_file(Path(__file__)),"manifest_count":len(manifests),"binding_checks":len(checks),"unique_files_hashed":len(cache),"manifests":manifests,"checks":checks,"scope":"Recheck explicit immutable manifest bindings; no quality or model run."}
with (N/"FROZEN-RECORDS-VERIFICATION.json").open("x") as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write("\n")
print(json.dumps({k:result[k] for k in ["status","manifest_count","binding_checks","unique_files_hashed"]}))
