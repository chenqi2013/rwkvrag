#!/usr/bin/env python3
"""Read-only wire, answer-boundary and frozen source-gold comparison."""
import ast
import base64
from collections import Counter
import hashlib
import json
from pathlib import Path
import re


N = Path(__file__).resolve().parents[2]
B = N.parent / "rwkvrag-bm-29b-20260908"
SOURCE = B / "source-publication-v1"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def repetition(raw):
    grams = Counter(raw[i:i + 12] for i in range(max(0, len(raw) - 11)))
    total = sum(grams.values())
    tail = raw[-600:]
    best = {"period_characters": None, "repeats": 0, "covered_characters": 0, "unit_sha256": None}
    for period in range(4, min(120, len(tail) // 3) + 1):
        unit = tail[-period:]
        count = 1
        while (count + 1) * period <= len(tail) and tail[-(count + 1) * period:-count * period] == unit:
            count += 1
        if count >= 3 and count * period > best["covered_characters"]:
            best = {"period_characters": period, "repeats": count,
                    "covered_characters": count * period, "unit_sha256": sha(unit.encode())}
    return {"unicode_characters": len(raw), "window_characters": 12,
        "repeated_window_excess_fraction": (sum(count - 1 for count in grams.values()) / total if total else 0),
        "maximum_identical_window_occurrences": max(grams.values(), default=0),
        "exact_tandem_tail": best,
        "definition": "Sliding raw 12-codepoint windows; excess occurrences / all windows. Exact suffix repetition scans periods 4..120 within final 600 raw characters, at least three cycles. No raw text altered; descriptive, not a quality score."}


def run_audit(run, mode):
    pins = {}

    def read(path):
        data = path.read_bytes()
        pins[str(path)] = {"bytes": len(data), "sha256": sha(data)}
        return data

    def load(path):
        return json.loads(read(path))

    def load_function(path, name, namespace):
        found = [node for node in ast.parse(read(path)) .body
                 if isinstance(node, ast.FunctionDef) and node.name == name]
        assert len(found) == 1
        exec(compile(ast.Module(body=found, type_ignores=[]), str(path), "exec"), namespace)
        return namespace[name]

    envelope = load_function(SOURCE / "src/llamaindex_retrieval/rwkvos_batch.py", "inspect_batch_envelope", {})
    renderer = load_function(SOURCE / "src/llamaindex_retrieval/rwkvos_batch.py", "render_batch_prompt", {})
    parse = load_function(SOURCE / "src/llamaindex_retrieval/rwkv_pipeline.py", "parse_task_selections", {"re": re})
    manifest = load(SOURCE / "SOURCE-MANIFEST.json")
    for name, spec in manifest["files"].items():
        data = read(SOURCE / name)
        assert len(data) == spec["bytes"] and sha(data) == spec["sha256"]
    plan, started, completed = [load(run / x) for x in ("PLAN.json", "STARTED.json", "COMPLETED.json")]
    assert started["runner_sha256"] == sha(read(run / "runner.py"))
    assert started["plan_sha256"] == sha(read(run / "PLAN.json"))
    assert started["source_manifest_sha256"] == sha(read(SOURCE / "SOURCE-MANIFEST.json"))
    assert started["fixture_freeze_sha256"] == sha(read(N / "reader-fixtures-v1/FROZEN.json"))
    fixtures = load(N / "reader-fixtures-v1/FROZEN.json")
    source_raw = read(N / "reader-fixtures-v1/inputs.jsonl")
    gold_raw = read(N / "reader-fixtures-v1/gold.jsonl")
    for name, raw in (("inputs.jsonl", source_raw), ("gold.jsonl", gold_raw)):
        pin = next(item for item in fixtures["files"] if item["path"] == name)
        assert pin["sha256"] == sha(raw) and pin["bytes"] == len(raw)
    originals = {row["id"]: row for row in map(json.loads, source_raw.splitlines())}
    gold = {row["id"]: row for row in map(json.loads, gold_raw.splitlines())}
    assert set(originals) == set(gold) and len(gold) == 16
    assert Counter(row["label"] for row in gold.values()) == {"positive": 8, "negative": 8}
    for item in originals.values():
        g = gold[item["id"]]
        assert len(item["units"]) == 1 and item["units"][0]["id"] == "E1"
        assert sha(item["source"]["snippet"].encode()) == g["source_text_sha256"]
        for support in g["full_question_fact_support"]:
            span = support["source_span"]
            assert item["source"]["snippet"][span["start"]:span["end"]] == support["quote"]
        assert g["expected_full_question_union_unit_ids"] == (["E1"] if g["label"] == "positive" else [])
    candidate_name = "open.inputs.jsonl" if mode == "open-thinking" else "examples.inputs.jsonl"
    candidate_bytes = read(run / candidate_name)
    assert sha(candidate_bytes) == started["candidate_inputs_sha256"]
    candidates = {row["id"]: row for row in map(json.loads, candidate_bytes.splitlines())}
    assert set(candidates) == set(originals)
    examples = None
    if mode == "examples":
        examples = read(run / "EXAMPLES.txt").decode()
        assert sha(examples.encode()) == started["examples_sha256"]
        interpretation = load(run / "INTERPRETATION-NOTE.json")
    else:
        interpretation = None
    for key, candidate in candidates.items():
        original = originals[key]
        parameters = dict(candidate["completion_parameters"])
        if mode == "open-thinking":
            assert candidate["messages"] == original["original_messages"]
            assert parameters.pop("assistant_prefill") == "<think>"
            old_parameters = dict(original["completion_parameters"])
            assert old_parameters.pop("assistant_prefill") == "<think></think"
            assert parameters == old_parameters
            assert candidate["prompt"] + "</think>" == original["original_prompt"]
        else:
            assert candidate["completion_parameters"] == original["completion_parameters"]
            original_message = original["original_messages"][0]["content"]
            at = original_message.index("\n任务：")
            expected = original_message[:at] + examples + original_message[at:]
            assert candidate["messages"] == [{"role": "user", "content": expected}]
            assert candidate["prompt"] == "User: " + expected + "\n\nAssistant: <think></think>"
        assert sha(candidate["prompt"].encode()) == candidate["prompt_sha256"]

    summary, rows, call_ids = [], [], set()
    for phase in ("control-before", mode, "control-after"):
        phase_root = run / phase
        requests = load(phase_root / "REQUESTS.json")
        phase_complete = load(phase_root / "COMPLETED.json")
        assert len(requests) == 16 and {row["id"] for row in requests} == set(originals)
        batch_records = {}
        for path in sorted((phase_root / "batch-http").glob("*.batch_completed.json")):
            batch = load(path)
            batch_start = load(path.with_name(path.name.replace(".batch_completed.", ".batch_started.")))
            request_bytes = base64.b64decode(batch["request_body_base64"], validate=True)
            response_bytes = base64.b64decode(batch["response_body_base64"], validate=True)
            assert sha(request_bytes) == batch["request_body_sha256"] == batch_start["request_body_sha256"]
            assert request_bytes == base64.b64decode(batch_start["request_body_base64"], validate=True)
            assert sha(response_bytes) == batch["response_body_sha256"]
            payload, response = json.loads(request_bytes), json.loads(response_bytes)
            assert payload == batch["payload"] == batch_start["payload"]
            assert response == batch["response_json"]
            assert batch["http_attempted"] is True and batch["http_status"] == 200
            assert batch["response_body_complete"] is True
            assert len(payload["contents"]) == len(response["choices"]) == len(batch["slots"]) == 8
            assert "error" not in response and response["model"] == payload["model"]
            slots = {row["index"]: row for row in batch["slots"]}
            choices = {}
            for choice in response["choices"]:
                index = choice["index"]
                assert type(index) is int and index not in choices and 0 <= index < 8
                assert choice["message"]["role"] == "assistant" and "error" not in choice
                choices[index] = choice
            assert set(slots) == set(choices) == set(range(8))
            batch_records[batch["batch_id"]] = (batch, payload, slots, choices)
        assert len(batch_records) == 2
        phase_rows = []
        for request in requests:
            key = request["id"]
            original = originals[key]
            expected = candidates[key] if phase == mode else {
                "messages": original["original_messages"], "prompt": original["original_prompt"],
                "prompt_sha256": original["original_prompt_sha256"],
                "completion_parameters": original["completion_parameters"]}
            for field in ("messages", "prompt", "prompt_sha256", "completion_parameters"):
                assert request[field] == expected[field]
            before = load(phase_root / "calls" / (key + ".started.json"))
            call = load(phase_root / "calls" / (key + ".completed.json"))
            trace = call["trace"]
            assert before["messages"] == trace["messages"] == request["messages"]
            assert before["completion_parameters"] == request["completion_parameters"]
            assert before["expected_prompt_sha256"] == request["prompt_sha256"] == trace["prompt_sha256"]
            assert trace["prompt"] == request["prompt"]
            assert sha(trace["prompt"].encode()) == trace["prompt_sha256"]
            batch, payload, slots, choices = batch_records[trace["batch_id"]]
            index = trace["batch_index"]
            assert payload["contents"][index] == request["prompt"]
            assert {k: v for k, v in payload.items() if k != "contents"} == original["original_http_parameters"] == trace["parameters"]
            assert slots[index]["call_id"] == trace["call_id"] and trace["call_id"] not in call_ids
            call_ids.add(trace["call_id"])
            assert slots[index]["evidence_ids"] == trace["evidence_ids"] == request["completion_parameters"]["evidence_ids"]
            raw = choices[index]["message"]["content"]
            assert raw == call["raw_text"] == trace["raw_text"] and sha(raw.encode()) == trace["raw_text_sha256"]
            assert trace["requested_prefill"] == request["completion_parameters"]["assistant_prefill"]
            rendered_prompt, rendered_prefill = renderer(request["messages"], trace["requested_prefill"], "complete")
            assert rendered_prompt == request["prompt"] and rendered_prefill == trace["prefill"]
            assert trace["prefill_mode"] == "complete"
            env = envelope(raw, trace["prefill"])
            assert env == trace["envelope"] and env["raw_text_modified"] is False
            assert call["status"] == ("completed" if env["valid"] else "invalid_response")
            answer = None
            selected = None
            span = env["answer_span"]
            if span:
                answer = raw[span["start"]:span["end"]]
                try:
                    selected = [f"E{i}" for i in parse(answer.strip(), len(original["units"]))]
                except ValueError:
                    pass
            assert call["format_pass"] is (selected is not None)
            assert call.get("selected_units") == selected
            g = gold[key]
            strict = selected is not None and set(selected) == set(g["expected_full_question_union_unit_ids"])
            row = {"phase": phase, "id": key, "label": g["label"],
                "call_id": trace["call_id"], "batch_id": trace["batch_id"], "batch_index": index,
                "source_id": original["source"]["id"], "source_sha256": g["source_text_sha256"],
                "prompt_sha256": trace["prompt_sha256"], "raw_sha256": sha(raw.encode()),
                "raw_characters": len(raw), "status": call["status"],
                "genuine_raw_closing_tag_count": raw.count("</think>"),
                "genuine_raw_first_closing_tag_index": raw.find("</think>"),
                "answer_span": span, "answer_body": answer,
                "formal_selection_valid": selected is not None, "selected_units": selected,
                "positive_recalled": g["label"] == "positive" and bool(selected),
                "negative_misselected": g["label"] == "negative" and bool(selected),
                "strict_source_success": strict,
                "gold_expected_unit_ids": g["expected_full_question_union_unit_ids"],
                "gold_support": g["full_question_fact_support"], "gold_negative_reason": g["negative_reason"],
                "repetition_diagnostic": repetition(raw),
                "requested_max_tokens": payload["max_tokens"],
                "reported_usage": trace["usage"], "actual_generated_token_count_verified": False,
                "provider_finish_reason": trace["provider_finish_reason"], "termination_verified": trace["termination_verified"],
                "thinking_used_to_rescue_score": False}
            assert row["requested_max_tokens"] == 1024 and row["reported_usage"] is None
            assert row["provider_finish_reason"] == "stop" and row["termination_verified"] is False
            rows.append(row)
            phase_rows.append(row)
        counts = {"phase": phase, "calls": 16, "http": 2,
            "statuses": dict(Counter(row["status"] for row in phase_rows)),
            "format_pass": sum(row["formal_selection_valid"] for row in phase_rows),
            "nonempty": sum(bool(row["selected_units"]) for row in phase_rows),
            "positive_recall": {"numerator": sum(row["positive_recalled"] for row in phase_rows), "denominator": 8},
            "negative_false_positive": {"numerator": sum(row["negative_misselected"] for row in phase_rows), "denominator": 8},
            "strict_source_success": {"numerator": sum(row["strict_source_success"] for row in phase_rows), "denominator": 16},
            "repeated_12gram_excess_over_half": [row["id"] for row in phase_rows if row["repetition_diagnostic"]["repeated_window_excess_fraction"] > .5],
            "exact_tandem_tail_at_least_3_cycles": [row["id"] for row in phase_rows if row["repetition_diagnostic"]["exact_tandem_tail"]["repeats"] >= 3]}
        assert counts["format_pass"] == phase_complete["format_pass"] and counts["nonempty"] == phase_complete["nonempty_selections"]
        assert counts["statuses"] == phase_complete["statuses"]
        assert phase_complete["http"]["http_requests"] == 2
        summary.append(counts)
    assert len(rows) == len(call_ids) == 48 and completed["automatic_retries"] == 0
    for path, pin in pins.items():
        data = Path(path).read_bytes()
        assert len(data) == pin["bytes"] and sha(data) == pin["sha256"]
    result = {"schema": "reader-independent-control-review-v1", "status": "PASS", "mode": mode,
        "reviewer": "context_resolution (Codex), read complete source/context and original effective questions; non-blind development review",
        "gold_source_semantic_review": "All 16 labels independently checked against complete actual E text, parent headings, and effective question; source quotes/offsets verified. Title-only and supplier/link/NT4.0 backgrounds do not answer requested CAN/development fields. No external facts or link bodies used.",
        "gold_file_modified": False, "single_variable_verified": True,
        "input_file_bindings": pins, "summary": summary, "rows": rows,
        "model_calls_audited": 48, "http_audited": 6, "new_api_calls": 0,
        "raw_records_modified": False, "all_sources_one_unit": True,
        "limitations": ["Selected development subset, not blind or corpus prevalence estimate.",
            "Source union selection is not full fact coverage or Writer answer correctness.",
            "Open thinking is never used as an answer or recovered selection.",
            "Requested 1024 output tokens and provider stop do not verify actual token usage or natural termination.",
            "Repetition measures are descriptive character statistics, not a quality threshold."],
        "example_design_disclosure": interpretation}
    out = run / "review"
    out.mkdir(exist_ok=True)
    with (out / "REVIEW.json").open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"mode": mode, "status": "PASS", "summary": summary}, ensure_ascii=False))


if __name__ == "__main__":
    run_audit(Path(__file__).resolve().parents[1], "open-thinking")
