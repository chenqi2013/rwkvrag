"""Public fixed-revision checkpoint download, never overwrite final bytes."""
import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import time
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
PLAN_SHA = 'b8272a55d80ec0c90c849f5d8ba3bf0382f3753080982ec647b272058e691fb1'


def now():
    return datetime.now(timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    plan_path = ROOT/'DOWNLOAD-PLAN.json'
    plan = json.loads(plan_path.read_text())
    assert sha256(plan_path.read_bytes()).hexdigest() == PLAN_SHA
    target = ROOT/'checkpoints'
    target.mkdir(exist_ok=True)
    final = target/plan['filename']
    part = target/(plan['filename']+'.part')
    assert not final.exists(), 'Final checkpoint already exists; no overwrite.'
    offset = part.stat().st_size if part.exists() else 0
    assert offset == 0 or args.resume, 'Existing partial requires --resume.'
    assert offset <= plan['bytes']
    attempt = len(list(ROOT.glob('download-attempt-*.jsonl'))) + 1
    log_path = ROOT/f'download-attempt-{attempt:02d}.jsonl'
    begin = time.monotonic()
    digest = sha256()
    if offset:
        with part.open('rb') as stream:
            while chunk := stream.read(4*1024*1024): digest.update(chunk)
    with log_path.open('x') as log:
        def event(kind, **values):
            record = {'event':kind,'at':now(),'elapsed_seconds':time.monotonic()-begin,**values}
            log.write(json.dumps(record,ensure_ascii=False)+'\n');log.flush();os.fsync(log.fileno())
        event('started',plan_sha256=PLAN_SHA,script_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),offset=offset)
        transferred=offset
        try:
            headers={'User-Agent':'rwkvrag-official-checkpoint-download','Accept-Encoding':'identity'}
            if offset:headers['Range']=f'bytes={offset}-'
            with urlopen(Request(plan['url'],headers=headers),timeout=90) as response:
                status=response.status
                if offset:
                    assert status==206 and response.headers.get('Content-Range','').startswith(f'bytes {offset}-')
                else:assert status==200
                event('response',http_status=status,content_length=response.headers.get('Content-Length'),content_range=response.headers.get('Content-Range'))
                mode='ab' if offset else 'xb'
                next_progress=transferred+64*1024*1024
                with part.open(mode) as destination:
                    while chunk := response.read(1024*1024):
                        assert transferred+len(chunk)<=plan['bytes'], 'Unexpected object size.'
                        destination.write(chunk);digest.update(chunk);transferred+=len(chunk)
                        if transferred>=next_progress:
                            destination.flush();os.fsync(destination.fileno())
                            event('progress',bytes=transferred,total_bytes=plan['bytes'])
                            print(f'{transferred}/{plan["bytes"]} bytes',flush=True)
                            next_progress=transferred+64*1024*1024
                    destination.flush();os.fsync(destination.fileno())
            assert transferred==plan['bytes'], 'Incomplete object.'
            assert digest.hexdigest()==plan['sha256'], 'SHA mismatch.'
            os.link(part,final)
            part.unlink()
            directory=os.open(target,os.O_DIRECTORY)
            try:os.fsync(directory)
            finally:os.close(directory)
            result={'status':'PASS','completed_at':now(),'bytes':transferred,'sha256':digest.hexdigest(),
                    'file':str(final),'plan_sha256':PLAN_SHA,'attempt_log':log_path.name,
                    'gpu_or_training_calls':0,'existing_final_overwritten':False}
            with (ROOT/'DOWNLOAD-COMPLETED.json').open('x') as f:
                json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
            event('completed',**result)
            print(json.dumps(result,indent=2),flush=True)
        except Exception as error:
            event('failed',error_type=type(error).__name__,http_status=getattr(error,'code',None),bytes=transferred,
                  partial_preserved=part.exists(),automatic_retry=False)
            print(json.dumps({'status':'FAILED','error_type':type(error).__name__,'bytes':transferred}),flush=True)
            return 1
    return 0


if __name__=='__main__':
    raise SystemExit(main())
