# 本机 G1j 2.9B state tuning 准备度

结论：本机有可供隔离验证的 PEFT 代码与 CUDA 依赖，尚不能声称“2.9B state 反向训练已经跑通”。最初只读盘点未找到匹配基座；父任务随后明确授权取得官方精确权重并冻结实际 PEFT 工作树。本目录 `DOWNLOAD-COMPLETED.json` 出现且为 PASS 才表示下载已完整校验，`PEFT-SNAPSHOT-COMPLETED.json` 记录独立源码准备。这里没有执行模型加载、forward/backward、训练或 state 上传，也未访问旧服务器。

| 项目 | 实际证据 | 仍缺什么 |
|---|---|---|
| 显卡 | RTX5070Ti，16,303MiB；只读时约14,039MiB空闲。nvidia-smi未列compute进程，仍有桌面等占用。 | 这是瞬时资源快照，不是显存预约或2.9B反向峰值实测。 |
| CPU/磁盘 | RAM约33.65GB、可用约27.58GB；该文件系统可用约699.7GB。 | 模型加载和编译临时占用尚未测量。 |
| Python/CUDA | 现有PEFT venv Python3.10.19、Torch2.9.0/CUDA12.8，CUDA可见且编译架构包含sm120；Triton3.5、rwkv-fla0.7.202508221413、Lightning2.5.5、DeepSpeed0.18.1已安装。 | 系统PATH没有nvcc。Triton/FLA state backward与DeepSpeed优化器实际编译/运行未在本轮验证；安装版本不等于可运行证明。 |
| PEFT工作树 | HEAD `5704c39f8ab1d2ac63936ab392aadb6ba526e1a5`，dirty清单与旧盘点逐字一致，旧6个源文件pin仍匹配。 | 不应直接在原工作树开发或按干净HEAD运行；当前实际修改和venv中的PEFT扩展都需保留来源。 |
| 隔离源码 | `../peft-source-v1` 保留89个实际源码文件及dirty diff/untracked清单，92个manifest成员。原工作树逐文件复核未变。 | 新实验应从此不可变副本再建实验运行目录；不要在该源快照里训练输出或改代码。 |

匹配的官方原始checkpoint是 `rwkv7-g1j-2.9b-20260831-ctx16384.pth`，5,896,273,469 bytes，LFS SHA256 `966f3420f833532aae3fb1fd6326533b08d43d23b7b03eaa2f0694a30b64a239`，固定HF revision `53b2ec91e3c68c90fe1ae9b878fc4ce0b15d69f0`。[固定官方文件](https://huggingface.co/BlinkDL/rwkv7-g1/blob/53b2ec91e3c68c90fe1ae9b878fc4ce0b15d69f0/rwkv7-g1j-2.9b-20260831-ctx16384.pth)。官方HF转换版config列出32层、hidden2560、40 heads、head64、FFN10240、vocab65536，decay/a低秩96、v低秩64、gate低秩320。[官方配置](https://huggingface.co/RWKV/RWKV7-G1j-2.9B-20260831/blob/main/config.json)。本目录保留这次小型元数据HTTP的原始正文和SHA；没有用API自报model字符串认证其实际权重SHA。

下载前在 `/home/chase/models`、Linux/Windows HF缓存、PEFT与RWKV-LH本地data范围内，只找到真实G1j1.5B两片safetensors及测试fixture；1.5B不能替代这次2.9B。搜索排除了venv、Git、node_modules和test_runs，并不是对所有可能挂载路径的穷尽证明。后续新下载位于本目录独立 `checkpoints/`，不覆盖旧文件。

现有训练入口与风险：

- `train.py --peft state --my_testing x070 --op fla` 将 `RWKV_TRAIN_TYPE=state`；state attention注册每层 `time_state`。`peft_loading.py` 冻结所有参数，再仅启用精确time_state键，并要求数量等于层数。FLA wrapper把文件语义 `[H,V,K]` 转到其内部state接口，state导出保持canonical `[H,V,K]` 原样。
- 对这份2.9B，预期32个 `blocks.N.att.time_state`，每个 `[40,64,64]`，总5,242,880个可训练标量，BF16 tensor payload约10MiB、FP32约20MiB。小state参数不代表整个反向过程只需这点显存：冻结权重仍参加梯度传递，激活、内核workspace和优化器也占资源。
- **当前权重加载使用 `strict=False`，且未检查返回的missing/unexpected keys。** 最小加载验证必须先独立核所有基座key/shape，仅允许新增time_state缺失，不能以“没有抛异常”认证正确基座。现有state_init默认期望61个tensor来自旧项目；若未来加载已有state，2.9B必须显式设32，当前零state无需沿用61。
- 现有 `tests/test_state_tuning.py` / `test_state_init.py` 是格式、轴序、导出与初始化测试；两个 `state_tuning_*_stress.py` 主要比较FLA/FlashRWKV-vLLM前向数值，依赖另一推理运行时，不是2.9B实际训练成功收据。本轮未执行它们，也未找到匹配2.9B的完整反向/显存/部署state验收记录。
- 导出到当前外部API应保留canonical time_state，不能因文件名含vllm再手工预转置。外部固定上游loader内部另做一次转置，但部署实际revision和训练后兼容性仍需单独验证。[已有上游state加载合同](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv7_fast_v4.cu#L2337-L2420)。

最小可运行验证路径（待父任务选择后执行）：

1. 验证本目录下载完成收据、整个pth SHA和PEFT源码manifest；在新实验目录使用现有venv但将导入路径指向冻结源码，缓存和输出也独立设置，先禁止任何wandb联网。若要改兼容代码，先从快照派生新版本。
2. 先做CPU `torch.load(weights_only=True,mmap=True)` 的全部键、shape、dtype、finite/基座身份检查；模型加载的允许差异仅32个time_state。模型维度应从实际pth交叉确认上方官方配置，不只按文件名猜测。
3. 一张本机GPU、microbatch1、短上下文128或256、BF16、FLA、梯度检查点，固定一小份非计分输入/目标mask。先仅forward+loss+backward不更新参数，记录loss、32层state的梯度存在且finite、全部基座无grad、实际峰值显存。不要一开始使用8K/16K或旧13B脚本。若这一步通过，再单独批准一次optimizer更新，验证只有time_state改变。
4. 将state导出到新文件：全部32层、shape/dtype/finite、文件SHA、训练基座SHA、模板和token序列SHA均绑定；用非对称矩阵验证轴序。外部state上传、实际加载及零state/训练state同题对照另行执行，不能把格式通过率代替事实和逐引用支持改善。

目前最明确的缺口是实际2.9B加载与反向验收、训练/部署数值与模板对齐、独立留出集，以及提供方实际权重/revision认证。下载和代码冻结解决可控本机基座的准备问题，不自动解决这些验证缺口。
