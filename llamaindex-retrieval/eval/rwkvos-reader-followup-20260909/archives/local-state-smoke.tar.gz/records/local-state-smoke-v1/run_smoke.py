"""One generic state-only gradient smoke. No optimizer, generation, or network."""
from __future__ import annotations

import argparse
import ast
import gc
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import sys
import time
import traceback
from datetime import datetime, timezone
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
SOURCE = BASE / 'peft-source-v1'
CHECKPOINT = BASE / 'local-statetune-readiness-v1/checkpoints/rwkv7-g1j-2.9b-20260831-ctx16384.pth'
CHECKPOINT_SHA = '966f3420f833532aae3fb1fd6326533b08d43d23b7b03eaa2f0694a30b64a239'
MANIFEST_SHA = 'aff56d707b53e2af754703dcb577747e70f784ed3b9a529cdb68861d0ce81ce4'
GENERIC_TEXT = 'User: 请复述一句话：清晨的阳光照在窗前。\n\nAssistant: <think></think>\n清晨的阳光照在窗前。'
ENV = {
    'WKV': 'fla', 'RWKV_MY_TESTING': 'x070', 'RWKV_TRAIN_TYPE': 'state',
    'FUSED_KERNEL': '0', 'RWKV_JIT_ON': '0', 'RWKV_HEAD_SIZE_A': '64',
    'PYTHONDONTWRITEBYTECODE': '1', 'HF_HUB_OFFLINE': '1',
    'TRANSFORMERS_OFFLINE': '1', 'WANDB_MODE': 'disabled',
    'TRITON_CACHE_DIR': str(ROOT / 'cache/triton'),
    'TORCH_EXTENSIONS_DIR': str(ROOT / 'cache/torch-extensions'),
    'XDG_CACHE_HOME': str(ROOT / 'cache/xdg'),
}


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def save(path, value):
    with path.open('x', encoding='utf-8') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write('\n'); handle.flush(); os.fsync(handle.fileno())


def tokens(text, vocab):
    # Exact greedy longest-byte matching; no BOS or special tokens inserted.
    by_start = {}
    by_id = {}
    for line in vocab.read_text().splitlines():
        idx, rest = line.split(' ', 1)
        literal, length = rest.rsplit(' ', 1)
        value = ast.literal_eval(literal)
        if isinstance(value, str):
            value = value.encode('utf-8')
        assert isinstance(value, bytes) and len(value) == int(length)
        by_start.setdefault(value[0], []).append((value, int(idx)))
        by_id[int(idx)] = value
    for candidates in by_start.values():
        candidates.sort(key=lambda pair: (len(pair[0]), pair[1]), reverse=True)
    raw = text.encode('utf-8'); cursor = 0; result = []
    while cursor < len(raw):
        piece, idx = next(pair for pair in by_start[raw[cursor]] if raw.startswith(pair[0], cursor))
        result.append(idx); cursor += len(piece)
    assert b''.join(by_id[idx] for idx in result) == raw
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu', action='store_true')
    parser.add_argument('--attempt', required=True)
    args_cli = parser.parse_args()
    assert re.fullmatch(r'[a-z0-9-]+', args_cli.attempt)
    out = ROOT / args_cli.attempt
    out.mkdir(exist_ok=False)
    started = time.monotonic()
    os.environ.update(ENV)
    for key in ('TRITON_CACHE_DIR', 'TORCH_EXTENSIONS_DIR', 'XDG_CACHE_HOME'):
        Path(ENV[key]).mkdir(parents=True, exist_ok=True)
    event_file = out / 'events.jsonl'

    def event(stage, **kwargs):
        value = {'time': now(), 'stage': stage, 'elapsed_seconds': time.monotonic() - started, **kwargs}
        with event_file.open('a', encoding='utf-8') as handle:
            handle.write(json.dumps(value, ensure_ascii=False) + '\n'); handle.flush(); os.fsync(handle.fileno())
        print(json.dumps(value, ensure_ascii=False), flush=True)

    save(out / 'STARTED.json', {'started_at': now(), 'script_sha256': sha(__file__), 'gpu_authorized': args_cli.gpu,
                             'environment': ENV, 'optimizer_steps': 0, 'api_calls': 0})
    try:
        assert sha(SOURCE / 'SOURCE-MANIFEST.json') == MANIFEST_SHA
        manifest = json.loads((SOURCE / 'SOURCE-MANIFEST.json').read_text())
        for name, pin in manifest['files'].items():
            assert sha(SOURCE / name) == pin['sha256'], name
        assert CHECKPOINT.stat().st_size == 5896273469 and sha(CHECKPOINT) == CHECKPOINT_SHA
        event('pins_verified', source_manifest_sha256=MANIFEST_SHA, checkpoint_sha256=CHECKPOINT_SHA)
        import torch
        torch.set_num_threads(8)
        torch.manual_seed(1234)
        state = torch.load(CHECKPOINT, map_location='cpu', weights_only=True, mmap=True)
        assert isinstance(state, dict) and state and all(isinstance(k, str) and isinstance(v, torch.Tensor) for k, v in state.items())
        shapes = {key: {'shape': list(value.shape), 'dtype': str(value.dtype), 'numel': value.numel(),
                        'finite': bool(torch.isfinite(value).all())} for key, value in state.items()}
        assert all(value['finite'] for value in shapes.values())
        layers = sorted({int(re.match(r'blocks\.(\d+)\.', key).group(1)) for key in state if key.startswith('blocks.')})
        assert layers == list(range(32))
        assert state['emb.weight'].shape == state['head.weight'].shape == (65536, 2560)
        for i in layers:
            assert state[f'blocks.{i}.att.r_k'].shape == (40, 64)
            assert state[f'blocks.{i}.ffn.key.weight'].shape == (10240, 2560)
            assert state[f'blocks.{i}.ffn.value.weight'].shape == (2560, 10240)
        save(out / 'CHECKPOINT-TENSORS.json', shapes)
        event('cpu_checkpoint_verified', layers=len(layers), tensor_count=len(shapes), base_numel=sum(v.numel() for v in state.values()))
        sys.path.insert(0, str(SOURCE))
        from rwkvt.rwkv7.model import RWKV7
        cfg = SimpleNamespace(vocab_size=65536, n_layer=32, n_embd=2560, dim_att=2560, dim_ffn=10240,
                              head_size_a=64, head_size_divisor=8, ctx_len=128, grad_cp=1,
                              peft='state', train_type='state', my_testing='x070', dropout=0)
        with torch.device('meta'):
            model = RWKV7(cfg)
        expected = model.state_dict()
        missing = sorted(set(expected) - set(state))
        unexpected = sorted(set(state) - set(expected))
        mismatches = {k: {'expected': list(expected[k].shape), 'checkpoint': list(v.shape)}
                      for k, v in state.items() if k in expected and v.shape != expected[k].shape}
        time_names = [f'blocks.{i}.att.time_state' for i in range(32)]
        # The original module declares layer-0 value-residual parameters but never reads
        # them (layer_id == 0 stores v_first). Only these unused keys may be absent.
        unused_layer_zero = ['blocks.0.att.v0', 'blocks.0.att.v1', 'blocks.0.att.v2']
        allowed = set(time_names + unused_layer_zero)
        compatibility = {'missing': missing, 'unexpected': unexpected, 'shape_mismatches': mismatches,
                         'missing_state_initialized_zero': time_names,
                         'missing_unused_layer0_parameters': sorted(set(missing) & set(unused_layer_zero)),
                         'all_actual_checkpoint_tensors_bound': not unexpected and not mismatches,
                         'configuration': vars(cfg)}
        save(out / 'MODEL-COMPATIBILITY.json', compatibility)
        assert not unexpected and not mismatches and set(missing) <= allowed
        assert set(time_names) <= set(missing)
        for key in missing:
            state[key] = torch.zeros(tuple(expected[key].shape), dtype=torch.bfloat16)
        model.load_state_dict(state, strict=True, assign=True)
        del expected, state
        model.requires_grad_(False)
        selected = [(name, param) for name, param in model.named_parameters() if name in time_names]
        assert len(selected) == 32 and all(tuple(param.shape) == (40, 64, 64) for _, param in selected)
        for _, param in selected:
            param.requires_grad_(True)
        vocab = SOURCE / 'json2binidx_tool/rwkv_vocab_v20230424.txt'
        ids = tokens(GENERIC_TEXT, vocab)
        assert 2 < len(ids) <= cfg.ctx_len
        input_data = {'text': GENERIC_TEXT, 'text_sha256': hashlib.sha256(GENERIC_TEXT.encode()).hexdigest(),
                      'token_ids': ids, 'token_count': len(ids), 'vocab_sha256': sha(vocab),
                      'bos_inserted': False, 'external_deployment_tokenizer_identity_verified': False,
                      'loss': 'mean next-token cross entropy over this generic complete string',
                      'evaluation_gold_read': False}
        save(out / 'INPUT.json', input_data)
        event('cpu_model_compatible', missing=missing, token_count=len(ids))
        if not args_cli.gpu:
            save(out / 'COMPLETED.json', {'status': 'PASS', 'mode': 'cpu-only', 'completed_at': now(),
                                        'checkpoint_sha256': CHECKPOINT_SHA, 'source_manifest_sha256': MANIFEST_SHA,
                                        'base_tensors_compatible': True, 'gpu_forward_count': 0, 'backward_count': 0})
            return
        assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
        torch.cuda.reset_peak_memory_stats()
        event('gpu_load_begin', device=torch.cuda.get_device_name(0), capability=list(torch.cuda.get_device_capability(0)))
        model = model.to(device='cuda:0', dtype=torch.bfloat16)
        model.train()
        base = [(n, p) for n, p in model.named_parameters() if n not in time_names]
        selected = [(n, p) for n, p in model.named_parameters() if n in time_names]
        assert all(not p.requires_grad and p.grad is None for _, p in base)
        assert all(p.requires_grad and p.is_leaf and tuple(p.shape) == (40, 64, 64) for _, p in selected)
        device_ids = torch.tensor([ids], dtype=torch.long, device='cuda:0')
        torch.cuda.synchronize()
        forward_started = time.monotonic()
        event('forward_begin', base_numel=sum(p.numel() for _, p in base), trainable_numel=sum(p.numel() for _, p in selected))
        logits = model(device_ids)
        assert bool(torch.isfinite(logits).all())
        loss = torch.nn.functional.cross_entropy(logits[:, :-1].reshape(-1, cfg.vocab_size).float(), device_ids[:, 1:].reshape(-1))
        assert bool(torch.isfinite(loss))
        torch.cuda.synchronize()
        forward_seconds = time.monotonic() - forward_started
        event('forward_completed', loss=float(loss.detach()), logits_shape=list(logits.shape), forward_seconds=forward_seconds)
        backward_started = time.monotonic()
        loss.backward()
        torch.cuda.synchronize()
        backward_seconds = time.monotonic() - backward_started
        gradients = []
        for name, parameter in selected:
            grad = parameter.grad
            gradients.append({'name': name, 'shape': list(parameter.shape), 'dtype': str(parameter.dtype),
                              'requires_grad': parameter.requires_grad, 'grad_present': grad is not None,
                              'grad_finite': grad is not None and bool(torch.isfinite(grad).all()),
                              'grad_nonzero_count': int(torch.count_nonzero(grad)) if grad is not None else None,
                              'grad_l2_fp32': float(grad.float().norm()) if grad is not None else None,
                              'parameter_unchanged_zero': not bool(torch.count_nonzero(parameter))})
        save(out / 'STATE-GRADIENTS.json', gradients)
        assert all(g['grad_finite'] and g['grad_nonzero_count'] > 0 and g['parameter_unchanged_zero'] for g in gradients)
        assert all(not p.requires_grad and p.grad is None for _, p in base)
        dependencies = {}
        for module_name, module in sorted(sys.modules.items()):
            path = getattr(module, '__file__', None)
            if path and module_name.startswith(('rwkvt', 'rwkvfla')) and Path(path).is_file():
                dependencies[module_name] = {'path': path, 'sha256': sha(path)}
        save(out / 'EXECUTED-MODULE-PINS.json', dependencies)
        # Canonical [H,V,K] zero state, identity export: never transpose at serialization.
        export = {name: parameter.detach().cpu().contiguous() for name, parameter in selected}
        export_path = out / 'untrained-zero-time-state.pth'
        with export_path.open('xb') as handle:
            torch.save(export, handle)
        reloaded = torch.load(export_path, weights_only=True, map_location='cpu')
        assert set(reloaded) == set(time_names) and all(torch.equal(export[k], reloaded[k]) for k in export)
        result = {'status': 'PASS', 'completed_at': now(), 'mode': 'one-local-bf16-forward-state-only-backward',
                  'checkpoint_sha256': CHECKPOINT_SHA, 'source_manifest_sha256': MANIFEST_SHA,
                  'vocab_sha256': sha(vocab), 'script_sha256': sha(__file__),
                  'base_parameter_tensors': len(base), 'base_parameters': sum(p.numel() for _, p in base),
                  'base_requires_grad_count': sum(p.requires_grad for _, p in base),
                  'base_grad_present_count': sum(p.grad is not None for _, p in base),
                  'state_tensors': 32, 'state_parameters': sum(p.numel() for _, p in selected),
                  'all_32_gradients_finite_nonzero': True, 'all_state_parameters_unchanged_zero': True,
                  'forward_count': 1, 'backward_count': 1, 'optimizer_steps': 0, 'generation_or_api_calls': 0,
                  'loss': float(loss.detach()), 'forward_seconds': forward_seconds, 'backward_seconds': backward_seconds,
                  'peak_allocated_bytes': torch.cuda.max_memory_allocated(), 'peak_reserved_bytes': torch.cuda.max_memory_reserved(),
                  'device': torch.cuda.get_device_name(0), 'torch_version': torch.__version__, 'cuda_version': torch.version.cuda,
                  'dependency_versions': {name: importlib.metadata.version(name) for name in ('rwkv-fla', 'triton', 'deepspeed')},
                  'untrained_export': {'path': export_path.name, 'sha256': sha(export_path), 'bytes': export_path.stat().st_size,
                                       'semantic_axes': ['head', 'value', 'key'], 'shape_per_layer': [40, 64, 64],
                                       'serialization_transposes': 0, 'uploaded': False},
                  'limits': ['No optimizer update or quality evaluation.', 'This is a short-input training-readiness smoke, not convergence or generalization evidence.',
                             'Official local checkpoint identity is pinned; external API checkpoint identity is not attested.']}
        save(out / 'COMPLETED.json', result)
        event('completed', status='PASS', peak_allocated_bytes=result['peak_allocated_bytes'])
        del logits, loss, model, base, selected
        gc.collect(); torch.cuda.empty_cache()
    except BaseException as exc:
        save(out / 'FAILED.json', {'status': 'FAIL', 'failed_at': now(), 'type': type(exc).__name__,
                                 'error': str(exc), 'traceback': traceback.format_exc(), 'optimizer_steps': 0})
        event('failed', error_type=type(exc).__name__, error=str(exc))
        raise


if __name__ == '__main__':
    main()
