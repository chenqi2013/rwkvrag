本机官方 G1j 2.9B 的短输入 state 反向检查通过。这里只验证可运行性，没有优化器更新、生成评测、state 上传或正式训练；没有读取 Reader 评测金标，也没有访问旧服务器。

| 检查 | 实际结果 |
|---|---|
| 基座 | 官方 `rwkv7-g1j-2.9b-20260831-ctx16384.pth`，5,896,273,469 bytes，SHA256 `966f3420f833532aae3fb1fd6326533b08d43d23b7b03eaa2f0694a30b64a239` |
| CPU 安全加载 | `torch.load(weights_only=True, mmap=True, map_location='cpu')`；1,062 个张量全部有限，2,948,065,280 基础参数；32 层、hidden 2560、40 heads、head 64、FFN 10240、vocab 65536 |
| 完整性 | 所有基础权重 key/shape 精确匹配；仅新增的 32 个 `time_state` 缺失并显式初始化零；没有 missing 基础权重、unexpected key 或形状不符。随后 `strict=True, assign=True` 加载 |
| 实际输入 | `gpu-01/INPUT.json` 的完整通用复述字符串，40 tokens，无额外 BOS；全串 next-token cross entropy，仅用于检验计算图 |
| 实际环境 | 本机 RTX 5070 Ti 16GB；Torch 2.9.0+cu128、rwkv-fla 0.7.202508221413、Triton 3.5.0；冻结 PEFT 源、非 fused attention、FLA state 内核、非 reentrant activation checkpointing |
| 前向/反向 | 1 次 BF16 前向、1 次 backward；loss 1.448678970336914；前向约 33.668 秒，反向约 46.248 秒，包含首次内核编译，不是暖机吞吐 |
| 基础权重冻结 | 1,062 个基础参数张量全部 `requires_grad=False` 且 `grad is None` |
| state 梯度 | 32 个 `[40,64,64]` 张量全部梯度有限；每层 163,840 个元素全部非零；FP32 L2 范数范围约 0.02528–34.60867 |
| 显存 | PyTorch peak allocated 6,218,369,024 bytes（约 5.79 GiB），reserved 6,473,908,224 bytes（约 6.03 GiB）；这是 **40-token 冷编译 smoke**，不能推为 8K 训练预算。桌面与其他 CUDA 上下文占用不包括在 allocated 里 |
| 参数更新/导出 | optimizer steps=0，所有 state 仍为零；只导出未训练零 state，10,495,555 bytes，canonical `[H,V,K]`、序列化无转置，重读逐 tensor 相等，没有上传 |

`cpu-01` 与 `gpu-01` 是 CPU 检查和唯一 GPU backward 的独立原始记录，均 PASS，没有失败后重试。`gpu-01-console.log` 保留实际完整控制台输出；`events.jsonl` 在阶段边界 fsync。没有安装或修改依赖。Python 3.10 的依赖警告导致 `torch.compile` 包装退回 identity，但 FLA 的 Triton 算子实际完成前向与反向；不能把这条警告写成反向失败。

执行源 manifest 为 `aff56d707b53e2af754703dcb577747e70f784ed3b9a529cdb68861d0ce81ce4`，脚本 SHA 为 `65176c6e0ee48ea1f331955b8691e60330cdbc1aa04a471836509ca530893786`。`POST-RUN-INTEGRITY.json` 复核冻结快照全部 92 成员、原 PEFT 89 源文件和原 dirty 状态均未变；`gpu-01/EXECUTED-MODULE-PINS.json` 记录实际导入 PEFT/FLA 模块 SHA。缓存只写本目录 `cache/`，属于可重新生成的编译产物。

state 文件的轴序依据是实际训练 wrapper 在 FLA 边界执行一次 `[H,V,K]`→内部 `[H,K,V]`，导出对训练参数直接 identity copy。零值本身不能用于辨别两个等长轴是否被转置；本报告的轴序声明来自执行源码与导出操作，并没有用零值相等冒充轴序数值实验。

GPU 进程已经退出 0 并向父任务明确释放；退出后的第一次只读检查 compute 列表为空、显存约 1846 MiB，为桌面等剩余占用。之后父任务已接手独立 local Reader 生成探针，因此不能把稍后的 GPU 忙碌记成本 smoke 未结束。

下一步应先对齐两条本地数值路径，再决定训练：现有 `rwkv` 0.8.30 提供 `RWKV_V7_ON=1`、`RWKV_CUDA_ON=0`、`strategy='cuda bf16'` 的纯 Torch recurrent forward，完整保存 attention shift、FP32 WKV 和 FFN shift，可以逐 token 生成，不需要 nvcc。权重约 5.9GB，预计显存约 6–7GB 加输入/临时缓存，具体生成时延仍需实测。相比 PEFT 重算整个前缀，该路径更适合固定 Reader prompt 的本机复现；它的 decay 常量、舍入和核实现与 FLA 不同，不能预先声称 logits 完全一致。本次没有保存全 logits，后续单独准备同一 40-token 字符串的逐位置 logits 对照，不混入此冻结 smoke。

这个结果证明本机基础依赖、2.9B 形状与 state 梯度通路可用，尚未证明 optimizer/长序列/多 batch 训练、收敛、训练后推理兼容或事实与引用改善。外部 API 权重 SHA 仍未得到部署认证，本地官方 checkpoint 与远端同名模型不能视为已证明字节相同。
