# 按单个原任务读取证据：实现前设计

本文件仅审查现有代码并提出方案，没有修改实现、读取本轮模型输出或调用 API。审查基于提交 `604586bc0a29993046d6af67a68f93ea5bf25c29` 的当前工作区；逐文件 SHA 另存 `SOURCE-REVIEW.json`。这不是收益结论，也不预先晋级候选。

建议增加一个默认关闭的任务调度模式：沿用同一次 Planner 的原任务列表、同一批检索来源、同一切分结果，让每个“来源原文批次 × 原任务位置”产生独立选择调用，再合并逐字片段。先由根代理的精确输入 batch8/batch1 对照确定后端条件，之后才决定是否实施和跑这项结构实验。

根代理已明确当前开发对照只将现有子问题数组拆成单元素，其他 prompt 和完整 task 一字不改。主指标是选中片段对完整有效问题的 union 支持；每个调用携带的任务 ID 仅用于诊断，不能据此认定该片段支持这个子任务。下文把更明确的目标优先级指令列为后续独立变量，不在当前实验混入。

## 当前代码实际做什么

| 位置 | 行为及影响 |
| --- | --- |
| `rwkv_pipeline.py:115`、`:484` | 完整问题和 history 序列化为 JSON；固定 `native_task_source` 从 Planner 的 fields 或 queries 取原列表。代码不恢复遗漏目标、不删撤回目标，也不判断 Planner 的语义正确性。 |
| `rwkv_pipeline.py:322` | `_resolve` 先按来源切 EvidenceUnit，再按原文字符数组成软批。每个批次面对整份任务列表。E1 等编号属于当次批次，不能跨批直接复用。 |
| `rwkv_pipeline.py:36`、`:278` | 正文保留 Unicode 原偏移与 overlap；表行、列表行原子保留。每次都带完整 conversation、来源身份及完整 context_spans。长来源分批后，每次包含该批完整单元，不是每次都包含整篇来源。 |
| `rwkv_pipeline.py:354`、`:359` | 原请求和结果由 transport trace 留存；选择事件额外绑定 source ID、来源全文 SHA、每个 E 单元的原始 start/end/SHA。 |
| `rwkv_pipeline.py:366`、`:375` | 严格解析全部正文。task_units 返回单位编号，fields 返回字段—单位对应；非法、未完成或预算失败不允许把看似有效的前缀送给 Writer。 |
| `rwkv_pipeline.py:375`、`:399` | 精确相同的 `(source_index,start,end)` 去重，保留逐字片段、parent ID/hash 和 field_ids。Writer 只接收选中片段及其父级上下文。相交但不同的范围不自动合并。 |
| `rwkv_pipeline.py:501` | fields 的 uncovered_fields 仅检查有没有选中片段关联该字段；它不是全部必要事实得到支持的证明。task_units 明确将其置 null，field_coverage_assessed=false。 |
| `rwkv_pipeline.py:512` | 即使 Writer 完成，只要存在 Reader 解析/状态错误，整体仍是 resolver_partial_failure；不会由代码补拒答或补引用。 |

当前来源预算只有总量，`per_document_limit=None`（`:490` 附近）。同一文档可占多个原文块；本方案不增加固定每文档配额。

## 最小设置与调用方式

若实验有效，建议只新增 `native_resolver_task_scheduling: Literal["joint", "per_task"] = "joint"`。名字说明任务调度方式，不称严格逐任务验证。joint 保持当前 prompt、任务顺序、解析、来源排序和返回行为。模型、prefill、stop、采样、batch size、输出预算、来源总预算及已有 `native_resolver_protocol` 均分别冻结，不随这个开关隐式改变。

per_task 的工作单元包括 `source_index`、`source_id`、`source_text_sha256`、`source_batch_index`、原 E 单元列表、`task_index`、原任务文本。任务 ID 用原列表的一基位置 `t1`、`t2`，任务文本逐字复制；相同文字出现在两个位置也保留两个位置，不暗中减少任务。检索候选仍是原联合候选集，不顺手改成按查询来源分配或删除与某任务“看似不相关”的来源。

每个工作单元保留完整 conversation、原来源身份、原 batch 的所有 E 单元和完整 context_spans；当前实验只把子问题数组换成一个原任务。现有指令仍说片段可以支持整个当前任务的一部分，因此这是数组组织方式对 union 选择的实验，不是严格限定任务范围的检验。尤其当原任务文字只有一个笼统字段时，不给它推定额外的主体或限定。

后续若确实需要严格单任务选择，可另行测试明确的优先级合同，例如“本次只判断这个子问题，完整历史用于理解它的对象和有效限定”。这会改变指令，必须单独冻结与比较；不能根据当前数组拆分结果声称已验证该方案。

当前数组拆分对照使用已冻结的 task_units 协议。两个协议若将来都实现此调度选项，应保持原语法：

- task_units：仍只接受 `E1,E2` 或 `NONE`，不加 JSON、不接收答案值，不从 thinking 恢复选择。
- fields：本次只有本地 `f1`，用既有严格 parser 的字段数 1 解析；之后通过明确映射把 f1 关联回原任务位置。不能让所有任务都错误落到全局 f1。

整个结构候选需要新的 trace/实验版本。它改变调用图和每次呈现的子问题列表；只有指令正文、完整 task、来源输入等指定部分可以逐字证明相同，不能把两个请求数量不同的批次称为全 wire 相同。原有对照、旧原始输出和旧分数不重写。

## 合并与任务出处

先做身份校验，再按 `(parent_source_id, parent_text_sha256, start, end, span_sha256)` 合并精确重复片段。来源 ID 相同而正文、文档或上下文身份冲突时明确失败，不用后到结果覆盖。不同来源即使文本相同也保留各自身份；同一来源的相交但不相同 span 不拼接、不扩大到未选范围。

输出仍使用既有 `parent@start:end:hash` ID，snippet 必须等于原来源的 Unicode 切片。一个片段在多个任务调度调用中被选中时只给 Writer 一份原文，但在元数据合并全部 provenance：原任务 ID/位置、任务文本 SHA、对应 call_id、source_batch_index、局部 E ID、局部字段映射。这些是输入/选择出处，不等于各子任务获得支持。context_spans 原文本、偏移及 SHA 原样保留。

聚合顺序按预登记工作顺序和原返回选择顺序确定，不受异步完成先后影响。建议固定来源排序 → 来源批次序号 → 原任务序号。不得因为后完成的调用先入队而改变资料编号。若之后改调度顺序，需要独立记录，不能隐瞒其对实际 batch 组成的影响。

task_units 的 `field_ids` 仍为空；新增 `task_ids` 只表示“本次调用呈现了这个单元素任务列表并发生选择”，不写作子任务支持或事实完整覆盖。其 `field_coverage_assessed=false`、`uncovered_fields=null` 保持。fields 的原字段关联如果将来支持可机械映射，但也要标注为 selection association，不能提升为语义覆盖。

Writer 的原任务列表、完整 history 和规则保持不变。任务 provenance 放在返回 SourceItem 元数据及 trace 即可；第一项 Reader 对照不顺便改 Writer prompt。原始 Writer raw、answer_span 和引用解析保持当前行为。

## 预算、并发和失败

设来源 s 的既有原文批数为 B(s)，原任务数为 T。joint 需要 `sum(B(s))` 次 Reader，per_task 需要 `T * sum(B(s))` 次。举例：80 来源、每来源一批、6 任务，Reader 从 80 次变成 480 次；这是计划数，不是实际 HTTP 数。共享 batch HTTP 必须从 batch_id 收据去重，不能简单除以 batch8；启用计数时每个模型项还有独立 count_id 收据。

单次 prompt 去掉其他主动任务文本，但完整历史和父级上下文仍在。每任务的总输入反而重复多次；这不解决超长 history、超长原子行或超长 context_spans，也没有增加跨文档 RNN state 续读。6000 是正文软字符预算，既不含完整 prompt 的所有部分，也不能解释为 token 硬上限。

`native_max_concurrency=32` 由 transport 限制真实在途项；当前 `_resolve` 直接 gather 全部任务，会提前构造全部 prompt。任务维度增加后建议采用有界工作队列，创建模型调用前最多运行相应数量的 Reader worker，仍由共享 model client 限制全局真实在途量。第一版可复用已有并发值，不增加新的配置旋钮，不丢弃队尾工作。

要如实区分两种等待：队列待执行时间与 transport 内等待时间。启用外部 count 时，从 `complete` 入口开始的 deadline 包含计数和其后的排队；count 关闭时，当前外部实现的请求 timeout 不覆盖此前 pending 队列。native 则在取得 semaphore 后进入 timeout。新增有界 worker 的上游排队不能被隐去或声称已属于上述 timeout；应记录 enqueue/dequeue 时间。若要增加整个 Reader 阶段的 deadline，须作为另外的显式策略，而不是悄悄缩短实验。

native 仍校验完整 tokenized prompt + 预留输出 <= 实测服务/配置有效预算。外部 API 的 server limit 仍未知；可选 count 与显式 application_input_limit 按既有实现检查，超限不发该项生成、不截断。禁止把 checkpoint 名称中的 16384 当作 RWKV 理论记忆硬上限。

某个任务的格式、length、timeout、计数或预算失败只产生该工作项的失败，不冒充有效 NONE；已成功的其他任务片段可保留，但整体状态仍须标明部分失败。取消应传播并停止尚未提交的工作；已发出的共享 batch 按现有 adapter 的取消语义收尾，不能宣称远端已停止。意外异常必须清理/等待其余 worker，不能留下后台请求后返回 completed。

## 必需 trace

调用事件建议新增 `resolver_task_scheduling`、`presented_task_id`、`task_index`、`task_text_sha256`、`active_task_source`、`source_index`、`source_batch_index`、`source_batch_count`、稳定 job ID、enqueue/dequeue 时间，以及需要时本地字段到原任务位置的映射。明确 `task_provenance_semantics=input_presentation_only`。原 trace 的完整 messages/raw/status/call_id、batch_id/count_id 和 E 原文偏移/hash 不删。

聚合 trace 建议新增计划/开始/完成/失败/尚未提交工作数、每任务成功选择数、有效 NONE 数及失败数；另给原文去重前后片段数、每片段全部选择出处。把 `tasks_without_selected_evidence` 与 `tasks_with_failed_jobs` 分开。没有片段可能是有效 NONE，也可能是任务根本未成功读完，不能混为模型正确拒答。

所有任务/字段覆盖解释都标 `semantic_support_verified=false`。真实答案正确性、额外断言、引用支持、撤回事项及缺资料判断仍须独立按原合同审阅。

## 建议的有意义测试

1. joint 回归：同输入的 prompt、E 切分/编号、调用数、证据 ID、Writer raw 与当前行为一致。
2. 两任务 × 两来源、其中一来源两批：恰有六个工作项。子问题数组每次只有一个逐字原项，其他 prompt（含完整 conversation）、原 batch 的所有 E 内容与 context_spans 一字不变；全部来源批次被覆盖。
3. 同片段由两个任务选中：仅一份 Writer 证据，任务及 call provenance 都在；不同来源同文本不误合并，不同重叠 span 不扩写。
4. task_units 永远不伪造 field_ids、逐任务语义支持或完整覆盖。任务重复文字但位置不同仍可定位；未来若兼容 fields，另外测本地 f1 映射回 t2/f2。
5. 一个调用输出 `E1,E99`、另一个有效 E1：前者整项无选择且失败，后者保留；分别覆盖 length、超预算、计数失败、timeout，不把它们变成有效 NONE。
6. 长正文、emoji、>900 字尾部事实、长原子表行/QA、父级表头原 span；验证切片及上下文全文一致。同文档超过两块正常入选。
7. 故意打乱完成顺序，返回资料编号和证据集合仍稳定。有限 worker 与真实 MockTransport 在途量不超现有限制，计数与生成收据仍分别按 ID 去重。
8. 取消等待中/已发共享 batch 中任一任务：未发工作不继续发送；已发共同请求保留各项结果/取消收据；Writer 不在未清理 Reader 时执行。
9. 同来源 ID 的冲突正文/metadata 失败，不让相同局部 E1 绑定到另一来源或另一批。
10. Writer 返回额外事实、缺引用或 provider stop：保留原 raw 和既有边界，不因新 Reader trace 执行修复或声明语义通过。

先做以上离线验证。若根代理决定运行，先在固定来源/固定原任务的 Reader 实验上审查每一个新选择的实际原文，再决定是否端到端比较。格式通过率、非空率或选中片段更多都不能单独作为晋级依据。
