# 固定上游批处理审查

结论：当前源码足以说明 batch8 与 batch1 可能走不同计算过程，尚未证明 api-3b 实际部署存在批处理 bug。优先做已计划的完整原 prompt 对照，不改变角色模板、state、输出预算或采样参数。提交 `6253c9e0345a1c5e42bf0a10e722ba09de06a2ac` 的本地 12 份审阅文件均与 Git 固定版本逐字一致，原 14 个 SOURCE-PINS 也全部一致；部署代码版本、权重精度、路由拓扑仍未认证。本轮零 API/模型/网络调用。

| 环节 | 源码确认 | 对照含义 |
|---|---|---|
| 长短输入 | 每项完整编码，按 token 长度降序稳定排序。每次 prefill 的 T 是当前所有活跃项最短剩余长度与配置 chunk 上限的较小值；短项结束后只运行长项。没有给短 prompt 补 token。 | 同一长输入在单项与混批中可有不同 T 序列和活跃 B。比如长260、短13、chunk128：单长为128/128/4；混批长项为13/128/119。 |
| 状态复制 | 每请求新建独立 shift/WKV/elapsed；state_id 初始化时同一份 tuned WKV 复制至每行。缩小 prefill 子批时三种状态和对应 logits 都按行拷贝，未丢 elapsed。 | 未发现本合同下的状态串位证据。任意异构初始逐行 state 的重排序不在目前无 state 请求合同内。 |
| 数值路径 | B=1,T=1 有融合 layer-norm/tmix 路径；其它尺寸拆开运行。FFN 路径依赖 B×T；FP16 WKV 在 T≤16 与更长片段选不同入口。最终 head 先写 FP16 logits 再转 FP32。 | 批大小/混批边界可能改变舍入与最高分次序，这是可检验的数值差异来源，不能据此认定实现错误或部署精度。 |
| 已结束项 | decode 保留原始 B，结束项填 fallback token，其输出被屏蔽；仍生成的项按独立行推进，直到全部结束或预算耗尽。 | 这是 decode 对结束行的占位计算，不是向活跃 prompt 注入 padding；短答案结束后不会自动把余下项改为 B=1。 |
| 输出编号 | 非流式用 sorted_to_original 还原；流式每次 emit 同样还原，API 按还原后的 index 累加。 | 未发现明显编号错配。现有 fake-backend 测试两行输出相同，覆盖变长调度但不足以证明不同答案不会交换。 |
| “贪心” | top_p=0 被改成 top_k=1/top_p=1，仍运行通用随机采样 kernel；最高概率并列时按阈值补偿分摊质量，并读取每行随机状态。每次采样器用时间+random_device 设种子，无请求 seed 接口。 | 唯一最高分时应退化为 top1；并列最高分不保证固定 token。不能把 temperature=.001/top_p=0 写成已验证的逐字确定性。 |

来源：[排序与无 padding prefill](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_inference_engine.cpp#L246-L333)；[状态初始化和逐行复制](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv7_fast_v4.cu#L2308-L2530)；[计算路径与 FP16 head](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv7_fast_v4.cu#L2081-L2216)；[按尺寸选择 FFN](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/include/rwkv7_fast_v4_common.hpp#L245-L265)；[decode与索引还原](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_inference_engine.cpp#L400-L455)；[stream索引还原](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_inference_engine.cpp#L485-L594)；[top_p=0转换](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/utils/sampling.cu#L1064-L1123)；[并列阈值补偿和随机抽取](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/utils/sampling.cu#L775-L851)；[每调用随机种子](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_sampler.cpp#L12-L43)。

跨 HTTP 并发需另外限定：单模型 API 的 admission 是容量/排队控制，没有把不同 HTTP 的 contents 合成一个推理 batch。Forward workspace 和 CUDA stream 归本次 logits 所有，forward 返回前同步；未见共用可写 request state。仓库同时有 Go router，会按在途 bsz/权重和轮转选择后端，原请求正文完整转发且没有自动重试。若部署使用它，8个 batch1 可能落到不同 worker，而一个 batch8 留在同一 worker；仅同 model 字符串不能排除这个变量。[API admission](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_api_service.cpp#L1280-L1328)；[独立 workspace](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv7_fast_v4.cu#L1878-L1892)；[router选后端](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/RWKV_Lightning_CUDA_router/main.go#L91-L141)；[原样转发](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/RWKV_Lightning_CUDA_router/main.go#L180-L249)。

最小对照建议：

1. 先完成父任务已登记的8项原 prompt：一次 batch8 与同8项 batch1。明确 batch1 是顺序 HTTP 还是并发8；前者同时改变 HTTP 并发，不能只称 kernel B 单变量。逐项绑定 prompt SHA、全部采样字段、输出原始字节和 index；记录首个差异字符与事实/引用差异，不改题或救分。
2. 仅在出现差异且另行批准后，用同一组8项倒序，再按 original id 还原。所有 token 长度不同的情况下，内部排序会恢复同一个计算行序，倒序主要检查映射；相同长度的不同输入倒序才会改变行归属。
3. 用同一既有 prompt 复制8份，与已有 batch1 比较，排除长短混批切分差异并检查同批各行是否相等。若仍需定位长短效应，固定目标完整 prompt，仅换同批干扰项长度，特别让最短余段落在1/16/17/128附近；这属于后续诊断，当前报告未新增调用。

不要用 finish_reason=stop 证明自然完成：上游 build_choices 固定返回 stop；此前部署1-token边界探针也已证实该限制。若输出不同，单凭黑盒文本尚不能在随机并列、数值舍入、多worker身份或部署自有实现之间做因果归属。[固定stop](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_api_service.cpp#L637-L648)。

附带的 PREFILL-SCHEDULE-EXAMPLES.json 只做整数调度演示，不证明 GPU 状态、logits 或答案等价；本轮没有执行上游 GPU 测试。
