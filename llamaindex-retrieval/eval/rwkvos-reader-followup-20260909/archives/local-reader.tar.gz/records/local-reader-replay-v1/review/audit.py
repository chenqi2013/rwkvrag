"""Read-only CPU/stdlib audit; never imports torch or runs the model."""
import ast, base64, hashlib, json, re
from datetime import datetime, timezone
from pathlib import Path

N = Path(__file__).resolve().parents[2]
R = N / "local-reader-replay-v1"
OUT = Path(__file__).resolve().parent
SOURCE = N.parent / "rwkvrag-bm-29b-20260908/source-publication-v1"
bindings = {}

def sha(b): return hashlib.sha256(b).hexdigest()
def pin(p):
    p = p.resolve()
    with p.open("rb") as f:
        digest = hashlib.file_digest(f, "sha256").hexdigest()
    value = {"bytes": p.stat().st_size, "sha256": digest}
    if str(p) in bindings: assert bindings[str(p)] == value
    bindings[str(p)] = value
    return value

def data(p):
    pin(p)
    return json.loads(p.read_text())

def lines(p):
    pin(p)
    return [json.loads(s) for s in p.read_text().splitlines()]

def write(name, obj):
    raw = (json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()
    with (OUT / name).open("xb") as f: f.write(raw)

def check_freeze(root):
    frozen = data(root / "FROZEN.json")
    for entry in frozen["files"]:
        got = pin(root / entry["path"])
        assert got == {"bytes":entry["bytes"],"sha256":entry["sha256"]}

# All original local records, including runtime/license bytes, are bound.
for p in sorted(R.rglob("*")):
    if p.is_file() and OUT not in p.parents: pin(p)
plan, started, loaded, completed = [data(R / name) for name in ["PLAN.json","STARTED.json","MODEL-LOADED.json","COMPLETED.json"]]
assert plan["planned_local_model_generations"] == 2 and plan["planned_http_generations"] == 0
assert plan["training"] is False
assert completed["status"] == "complete" and completed["local_model_generations"] == 2
assert completed["http_calls"] == 0 and completed["training"] is False and completed["automatic_retries"] == 0
for field, name in [("runner_sha256","runner.py"),("plan_sha256","PLAN.json"),("runtime_source_manifest_sha256","RUNTIME-SOURCE.json"),("inputs_sha256","inputs.jsonl")]:
    assert started[field] == pin(R/name)["sha256"]
checkpoint = (R / plan["checkpoint"]).resolve()
checkpoint_pin = pin(checkpoint)
assert checkpoint_pin["sha256"] == plan["checkpoint_sha256"] == started["checkpoint_sha256"]
assert loaded["layers"] == 32 and loaded["embedding"] == 2560 and loaded["vocab"] == 65536 and loaded["all_tensors_frozen"] is True
assert started["zero_state_each_sample"] is True and started["actual_eos_stop"] == 0 and started["max_tokens"] == 1024
runtime = data(R/"RUNTIME-SOURCE.json")
assert runtime["installed_version"] == "0.8.30" and runtime["compile_cuda_extension"] is False
for name, entry in runtime["files"].items(): assert pin(R/"runtime-source/rwkv"/name) == entry
runner = (R/"runner.py").read_text()
model = (R/"runtime-source/rwkv/model.py").read_text()
ast.parse(runner)
assert 'RWKV_CUDA_ON="0"' in runner and 'RWKV_V7_ON="1"' in runner
assert 'with torch.inference_mode():' in runner and 'logits,state=model.forward(ids,None)' in runner
assert 'token=int(logits.argmax())' in runner and 'if token==0:eos=True;break' in runner
assert 'strategy="cuda bf16"' in runner
assert not any(isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr in {"backward","step"} for x in ast.walk(ast.parse(runner)))
assert "temp_z = torch.load(" in model and "mmap=True" in model
assert 'dtype=torch.float, requires_grad=False, device=DEVICE' in model
assert 'state = state * w_.view(H,1,N) + state @ ab.float() + vk.float()' in model
assert 'RWKV = RWKV_x070' in model

check_freeze(N/"reader-fixtures-v1")
fixtures = {r["id"]:r for r in lines(N/"reader-fixtures-v1/inputs.jsonl")}
gold = {r["id"]:r for r in lines(N/"reader-fixtures-v1/gold.jsonl")}
inputs = lines(R/"inputs.jsonl")
assert [r["id"] for r in inputs] == plan["samples"]
assert set(p.stem.removesuffix(".completed") for p in R.glob("*.completed.json")) == set(plan["samples"])
assert not (R/"FAILED.json").exists()

# Decode and independently reproduce byte-greedy tokenization from frozen vocabulary.
vocab = {}
for line in (R/"runtime-source/rwkv/rwkv_vocab_v20230424.txt").read_text().splitlines():
    left, right = line.index(" "), line.rindex(" ")
    tid = int(line[:left]); token = ast.literal_eval(line[left:right])
    token = token.encode() if isinstance(token,str) else token
    assert isinstance(token,bytes) and len(token) == int(line[right:]) and tid not in vocab
    vocab[tid] = token
assert vocab[23947] == b"NONE"
buckets = {}
for tid, token in vocab.items(): buckets.setdefault(token[0],[]).append((token,tid))
for bucket in buckets.values(): bucket.sort(key=lambda x:len(x[0]),reverse=True)
def encode(raw):
    pos = 0; ids = []
    while pos < len(raw):
        found = [(b,i) for b,i in buckets[raw[pos]] if raw.startswith(b,pos)]
        assert found
        b,i = found[0]; ids.append(i); pos += len(b)
    return ids

rows = []
for item in inputs:
    cid = item["id"]; fixture = fixtures[cid]; g = gold[cid]
    st, co = data(R/f"{cid}.started.json"), data(R/f"{cid}.completed.json")
    raw_prompt = item["prompt"].encode()
    assert item["source_fixture_id"] == cid
    assert item["prompt"] == fixture["original_prompt"] == st["prompt"]
    assert sha(raw_prompt) == item["prompt_sha256"] == fixture["original_prompt_sha256"] == co["input_prompt_sha256"]
    assert item["prompt"].endswith("Assistant: <think></think>")
    ids = st["input_token_ids"]
    assert ids == encode(raw_prompt) and b"".join(vocab[i] for i in ids) == raw_prompt
    assert len(ids) == st["input_token_count"] == co["input_token_count"]
    actual = base64.b64decode(co["raw_bytes_base64"],validate=True)
    assert actual == b"".join(vocab[i] for i in co["generated_token_ids"]) == co["raw_text"].encode() == b"NONE"
    assert sha(actual) == co["raw_bytes_sha256"] and co["utf8_valid"] is True
    assert co["generated_token_ids"] == [23947] and co["generated_non_eos_tokens"] == 1
    assert [(x["index"],x["token_id"]) for x in co["generation_steps"]] == [(0,23947),(1,0)]
    assert all(s["top_tie_count"] == 1 for s in co["generation_steps"])
    assert co["actual_termination"] == "eos_token_0" and co["termination_verified"] is True
    assert co["initial_top10"][0]["token_id"] == 23947
    assert g["label"] == "positive" and g["expected_full_question_union_unit_ids"] == ["E1"]
    assert len(fixture["units"]) == 1 and item["unit_count"] == 1
    snippet = fixture["source"]["snippet"]
    for evidence in g["full_question_fact_support"]:
        span = evidence["source_span"]
        assert snippet[span["start"]:span["end"]] == evidence["quote"]
    compared = []
    external_paths = [("historical-fixture",N/"reader-fixtures-v1"/fixture["baseline_completed_path"])]
    external_paths += [(phase,N/"reader-open-thinking-v1"/phase/"calls"/f"{cid}.completed.json") for phase in ["control-before","control-after"]]
    for label,p in external_paths:
        e = data(p); tr = e["trace"]
        assert tr["prompt"].encode() == raw_prompt and tr["prompt_sha256"] == sha(raw_prompt)
        assert e["raw_text"] == tr["raw_text"] and sha(e["raw_text"].encode()) == tr["raw_text_sha256"]
        compared.append({"name":label,"path":str(p),"same_prompt_bytes":True,"raw_text":e["raw_text"],"raw_sha256":tr["raw_text_sha256"],"raw_equal_local":e["raw_text"] == co["raw_text"],"provider_finish_reason":tr["provider_finish_reason"],"termination_verified":tr["termination_verified"],"parameters":tr["parameters"]})
    rows.append({"id":cid,"prompt_sha256":sha(raw_prompt),"input_tokens":len(ids),"tokenization_roundtrip_and_greedy_ids_verified":True,"raw_text":co["raw_text"],"raw_bytes_sha256":sha(actual),"generated_token_ids":[23947],"recorded_step_token_ids":[23947,0],"actual_termination":"eos_token_0","termination_evidence":"Runner records actual argmax token IDs and breaks on ID 0; full logits were not independently recomputed during audit.","formal_selection_valid":True,"selected_units":[],"expected_units":["E1"],"positive_source_recalled":False,"gold_support":g["full_question_fact_support"],"semantic_reason":"WinJS 1.0 parent heading and E1 explicitly supply Windows 8." if cid.startswith("held_016") else "E1 explicitly supplies maximum 64 bytes and 5 Mbit/s. Partial support is sufficient under the existing union-selection contract.","external_comparisons":compared,"elapsed_ms":co["elapsed_ms"],"peak_allocated_bytes":co["peak_allocated_bytes"]})

assert len(rows) == 2
for path, entry in list(bindings.items()): assert pin(Path(path)) == entry
report={"schema":"local-reader-replay-independent-review-v1","status":"PASS","reviewer":"Codex context_resolution; independent offline source/receipt review, non-blind developer diagnostic","new_model_calls":0,"new_http_calls":0,"raw_or_gold_modified":False,"observed_generations":2,"observed_http_calls":0,"retry_or_training_observed":False,"format_valid":2,"positive_source_recall":{"numerator":0,"denominator":2},"checkpoint":dict(path=str(checkpoint),**checkpoint_pin),"runtime":runtime,"recorded_runtime_environment":{k:started[k] for k in ["torch_version","cuda_version","device"]},"state_initialization":"Each sample starts state=None; runtime initializes all 32 WKV matrices FP32 zero and previous-token vectors BF16 zero. Sequence recurrence is the pinned pure PyTorch implementation, no custom CUDA WKV extension.","source_review":"Model constructor loads the verified checkpoint, transposes selected weights, converts to BF16 and folds embedding layer norm as the pinned runtime specifies; this is not a claim that in-memory weights retain original serialized bytes.","rows":rows,"limits":["Two deliberately selected, already exposed positive sources only; no new-set or end-to-end RAG score.","Local greedy argmax differs from the remote sampling contract; local checkpoint SHA is verified but remote checkpoint SHA, dtype, kernels, tokenizer and backend revision are not.","Matching NONE output on two prompts does not establish equal weights, equal backends, general model incapacity, or state-tuning efficacy.","Historical CAN output differs from local/current controls; do not attribute the cause without additional evidence.","EOS ID 0 is directly recorded locally; external provider stop metadata is not transferred into a verified remote EOS claim.","No optimizer/backward/retry/network path in this runner; audit does not claim exhaustive absence of unrelated system activity."],"input_file_bindings":dict(bindings)}
write("REVIEW.json",report)
text = """两次本机 Reader 重放已完成独立离线核验。原 prompt 与冻结 fixture 逐字节相同，含完整任务、子问题、原文及父级标题。输入分别为 WinJS 780 token、CAN FD 952 token；按冻结词表独立复算的贪心分词与保存 ID 全等，ID 23947 解码为 `NONE`。两次下一步均实际选择 EOS 0，未用字符串裁切或预算推断结束。审计没有重新执行模型。

两份均是已暴露正例：WinJS 1.0 的父级标题和正文明确给出 Windows 8；CAN FD 正文明确给出最大 64 byte 与 5 Mbit/s。原合同只需支持完整问题中的一部分即可选入，所以两次 `NONE` 均为漏选：格式 2/2，正例召回 0/2。没有检索或 Writer 调用，不能算完整 RAG 分数。

本机 checkpoint SHA 为 `966f3420f833532aae3fb1fd6326533b08d43d23b7b03eaa2f0694a30b64a239`，本次审计重新核对完整文件。运行冻结 rwkv 0.8.30、Torch 2.9.0+cu128，2.9B、32 层、2560 维；BF16 权重、FP32 WKV state，纯 PyTorch 递归且关闭定制 CUDA 扩展，每题零 state 独立开始。原始源码、词表、Apache 2.0 许可副本及环境收据都已绑定 SHA。源码确实读取 checkpoint，并执行其既有权重转置、精度转换和 embedding layer-norm 折叠；不声称内存权重等于原文件字节。

两份本机 `NONE` 都与本轮外部 closed-thinking 前后控制输出逐字相同。历史 WinJS 也相同；历史 CAN 为不同的非法答案值输出，不能把历史漂移忽略。外部采样参数与本机贪心并非相同实现，远端真实 checkpoint SHA、内核、精度、词表仍未验证；这些匹配不能证明两边权重相同、后端等价或模型总体能力上限。

PLAN 仅安排两次本机生成，实际正好两次；runner 没有 API、重试、训练或优化器。输出原字节、全部 token ID、逐步选择、结束标记与原始失败情况均保留。这是 Codex 对已暴露开发来源的非盲诊断审阅。
"""
with (OUT/"REPORT.md").open("x") as f: f.write(text)
artifacts = {p.name:pin(p) for p in sorted(OUT.iterdir()) if p.is_file()}
write("FROZEN.json",{"schema":"independent-review-freeze-v1","at":datetime.now(timezone.utc).isoformat(),"artifacts":artifacts,"input_file_bindings":report["input_file_bindings"],"new_inference_or_network":False})
print(json.dumps({"status":"PASS","local_generations":2,"http_calls":0,"format":"2/2","positive_recall":"0/2","freeze_sha256":sha((OUT/"FROZEN.json").read_bytes())}))
