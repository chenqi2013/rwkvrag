import os
os.environ.update(RWKV_V7_ON="1", RWKV_CUDA_ON="0", RWKV_JIT_ON="1", TORCH_FORCE_WEIGHTS_ONLY_LOAD="1", CUBLAS_WORKSPACE_CONFIG=":4096:8", HF_HUB_OFFLINE="1", WANDB_MODE="disabled", PYTHONDONTWRITEBYTECODE="1")
from pathlib import Path
import base64,hashlib,json,sys,time,traceback
from datetime import datetime,timezone
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT/"runtime-source"))
def sha(raw): return hashlib.sha256(raw).hexdigest()
def save(name,value):
 p=OUT/name
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open("x") as f:
  json.dump(value,f,ensure_ascii=False,indent=2); f.write("\n");f.flush();os.fsync(f.fileno())
def now():return datetime.now(timezone.utc).isoformat()
def main():
 plan=json.loads((OUT/"PLAN.json").read_text())
 ckpt=(OUT/plan["checkpoint"]).resolve()
 with ckpt.open("rb") as f: ckpt_sha=hashlib.file_digest(f,"sha256").hexdigest() if hasattr(hashlib,"file_digest") else None
 if ckpt_sha is None:
  h=hashlib.sha256()
  with ckpt.open("rb") as f:
   for chunk in iter(lambda:f.read(8*1024*1024),b""):h.update(chunk)
  ckpt_sha=h.hexdigest()
 assert ckpt_sha==plan["checkpoint_sha256"]
 pins=json.loads((OUT/"RUNTIME-SOURCE.json").read_text())
 for name,pin in pins["files"].items():
  raw=(OUT/"runtime-source/rwkv"/name).read_bytes();assert len(raw)==pin["bytes"] and sha(raw)==pin["sha256"]
 inputs=[json.loads(x) for x in (OUT/"inputs.jsonl").read_text().splitlines()]
 for row in inputs:assert sha(row["prompt"].encode())==row["prompt_sha256"]
 import torch
 from rwkv.model import RWKV
 from rwkv.rwkv_tokenizer import TRIE_TOKENIZER
 torch.manual_seed(290909)
 torch.backends.cuda.matmul.allow_tf32=False
 torch.backends.cudnn.allow_tf32=False
 torch.set_num_threads(4)
 torch.cuda.reset_peak_memory_stats()
 tok=TRIE_TOKENIZER(str(OUT/"runtime-source/rwkv/rwkv_vocab_v20230424.txt"))
 save("STARTED.json",{"at":now(),"runner_sha256":sha(Path(__file__).read_bytes()),"plan_sha256":sha((OUT/"PLAN.json").read_bytes()),"runtime_source_manifest_sha256":sha((OUT/"RUNTIME-SOURCE.json").read_bytes()),"inputs_sha256":sha((OUT/"inputs.jsonl").read_bytes()),"checkpoint_sha256":ckpt_sha,"torch_version":torch.__version__,"cuda_version":torch.version.cuda,"device":torch.cuda.get_device_name(0),"free_total_memory_bytes":list(torch.cuda.mem_get_info()),"max_tokens":1024,"actual_eos_stop":0,"zero_state_each_sample":True,"http_calls":0,"training":False})
 start=time.perf_counter()
 model=RWKV(model=str(ckpt.with_suffix("")),strategy="cuda bf16")
 torch.cuda.synchronize()
 save("MODEL-LOADED.json",{"at":now(),"elapsed_ms":(time.perf_counter()-start)*1000,"layers":model.args.n_layer,"embedding":model.args.n_embd,"vocab":model.args.vocab_size,"peak_allocated_bytes":torch.cuda.max_memory_allocated(),"peak_reserved_bytes":torch.cuda.max_memory_reserved(),"all_tensors_frozen":all(not v.requires_grad for v in model.z.values())})
 assert model.args.n_layer==32 and model.args.n_embd==2560 and model.args.vocab_size==65536
 results=[]
 for row in inputs:
  ids=tok.encode(row["prompt"]); assert tok.decodeBytes(ids)==row["prompt"].encode()
  save(row["id"]+".started.json",dict(row,at=now(),input_token_ids=ids,input_token_count=len(ids)))
  begin=time.perf_counter()
  with torch.inference_mode():
   logits,state=model.forward(ids,None)
   generated=[]; step_records=[]; initial_top10=None; eos=False
   for step in range(1024):
    assert bool(torch.isfinite(logits).all()), "nonfinite logits"
    token=int(logits.argmax())
    if initial_top10 is None:
     vals,idx=torch.topk(logits.float(),10)
     initial_top10=[{"token_id":int(i),"logit":float(v)} for i,v in zip(idx.cpu(),vals.cpu())]
    step_records.append({"index":step,"token_id":token,"argmax_logit":float(logits[token]),"top_tie_count":int((logits==logits[token]).sum())})
    if token==0:eos=True;break
    generated.append(token)
    if step<1023:logits,state=model.forward([token],state)
  torch.cuda.synchronize()
  raw_bytes=tok.decodeBytes(generated)
  try:raw=raw_bytes.decode("utf-8");decode_valid=True
  except UnicodeDecodeError:raw=None;decode_valid=False
  result={"id":row["id"],"at":now(),"input_prompt_sha256":row["prompt_sha256"],"input_token_count":len(ids),"raw_text":raw,"raw_bytes_base64":base64.b64encode(raw_bytes).decode(),"raw_bytes_sha256":sha(raw_bytes),"utf8_valid":decode_valid,"generated_token_ids":generated,"generation_steps":step_records,"generated_non_eos_tokens":len(generated),"actual_termination":"eos_token_0" if eos else "max_tokens_1024","termination_verified":True,"initial_top10":initial_top10,"elapsed_ms":(time.perf_counter()-begin)*1000,"peak_allocated_bytes":torch.cuda.max_memory_allocated(),"peak_reserved_bytes":torch.cuda.max_memory_reserved(),"semantic_quality_scored":False}
  save(row["id"]+".completed.json",result)
  results.append({k:result[k] for k in ["id","input_token_count","generated_non_eos_tokens","actual_termination","utf8_valid","elapsed_ms","peak_allocated_bytes"]})
  print(json.dumps(results[-1]),flush=True)
  del logits,state
 save("COMPLETED.json",{"at":now(),"status":"complete","local_model_generations":len(results),"http_calls":0,"training":False,"automatic_retries":0,"results":results,"semantic_quality_scored":False})
if __name__=="__main__":
 try:main()
 except BaseException as error:
  save("FAILED.json",{"at":now(),"exception":type(error).__name__,"message":str(error),"traceback":traceback.format_exc()});raise
