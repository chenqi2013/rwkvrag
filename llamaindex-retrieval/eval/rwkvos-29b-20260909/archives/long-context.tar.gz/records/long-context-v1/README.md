# 三档长上下文准备件

状态：只完成离线构造和核验，未获本批执行放行，零 API 调用。

| 档位 | 精确离线 tokens | 完整 Wiki 干扰文档 | 中间事实起点 | 末尾事实距生成 |
|---|---:|---:|---:|---:|
| 约8K | 8168 | 45 | 4156（50.88%） | 84 tokens |
| 约16K | 16374 | 84 | 8360（51.06%） | 84 tokens |
| 约32K | 32622 | 167 | 16392（50.25%） | 84 tokens |

开头事实均位于 token194，距生成分别7952/16158/32406 tokens。实际位置为完整输入UTF-8字节与官方参考分词跨度的交集，详见 frozen/positions.json。没有把分词前缀单独重算数假装成全输入位置。

三个输入使用相同问题和资料1/2/3事实，Wiki干扰按冻结清单顺序抽取完整小文档并分别追加到两侧，不裁剪文档凑长度。所有原文、修订URL、资料编号和SHA在 frozen/inputs.jsonl、sources/ 与 noise-selection.json。干扰文档为 CC-BY-SA-4.0；每文来源与版本保留。其来源为此前已公开的FineWiki中文5000文档冻结语料。本目录没有重新检索或下载Wiki。

未来实际HTTP请求只读取 frozen/requests.jsonl 中payload；独立gold不进入请求。参数固定closed完整`Assistant: <think></think>`、输出2048、stop_tokens[0]、无state。官方fake-think建议省略最后`>`，但此v1按原材料条件保留完整闭合；若根选择新前缀，另建版本，不能覆盖本件。

离线复核：`python3 verify_inputs.py --root .`。重建到新目录：`python3 build_inputs.py --corpus /path/to/finewiki-zh-5000 --output /path/to/new-output`。tokenizer文件SHA与四个远端计数样例匹配，但没有远端词表哈希认证。可后续另记三个服务计数请求；当前未发送。

严格答案与引用审阅合同见 SCORING.md，模板为 review-template.json。保持3输入/9事实分母，HTTP拒绝/超时等原样保留，无补跑；这些3个合成输入不能当作Wiki质量测试。FROZEN.json绑定全部准备文件，未来模型结果与复核另存新目录。
