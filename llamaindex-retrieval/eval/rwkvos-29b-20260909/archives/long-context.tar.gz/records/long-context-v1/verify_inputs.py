"""Offline integrity audit. No API/model/scoring calls."""
import argparse
import json
from hashlib import sha256
from pathlib import Path
from reference_tokenizer import ReferenceTokenizer

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    root = args.root
    tok = ReferenceTokenizer(root / "tokenizer/rwkv_vocab_v20230424.txt")
    load = lambda name: [json.loads(x) for x in (root / "frozen" / name).read_text().splitlines()]
    inputs, requests, gold = load("inputs.jsonl"), load("requests.jsonl"), load("gold.jsonl")
    positions = json.loads((root / "frozen/positions.json").read_text())
    assert len(inputs) == len(requests) == len(gold) == len(positions) == 3
    assert [x["id"] for x in inputs] == ["long_8192", "long_16384", "long_32768"]
    previous_banks = [[], []]
    source_identity = {}
    stable_parameters = None
    for inp, req, g, pos in zip(inputs, requests, gold, positions):
        assert inp["id"] == req["id"] == g["id"] == pos["id"]
        assert inp["history"] == [] and inp["question"] == inputs[0]["question"]
        assert len(inp["messages"]) == 1 and inp["messages"][0]["role"] == "user"
        prompt = "User: " + inp["messages"][0]["content"] + "\n\nAssistant: <think></think>"
        assert inp["prompt"] == prompt and req["payload"]["contents"] == [prompt]
        params = {k: v for k, v in req["payload"].items() if k != "contents"}
        stable_parameters = params if stable_parameters is None else stable_parameters
        assert params == stable_parameters and params["max_tokens"] == 2048 and params["stop_tokens"] == [0]
        assert set(req) == {"id", "method", "path", "payload"}
        assert not {"gold", "facts", "expected", "answer"}.intersection(req["payload"])
        raw = prompt.encode()
        assert sha256(raw).hexdigest() == pos["prompt_sha256"]
        spans = tok.spans(prompt)
        assert len(spans) == pos["actual_reference_tokens"]
        assert .94 * pos["target_tokens"] <= len(spans) <= pos["target_tokens"]
        assert len(inp["sources"]) == pos["source_count"]
        refs = [x["reference"] for x in inp["sources"]]
        assert len(refs) == len(set(refs))
        source_map = {s["reference"]: s for s in inp["sources"]}
        for source in inp["sources"]:
            text = source["text"]
            assert sha256(text.encode()).hexdigest() == source["text_sha256"]
            block = ("\n[" + source["reference"] + "]\n标题：" + source["title"] + "\n来源：" + source["uri"]
                     + "\n原文：\n" + text + "\n[" + source["reference"] + "结束]\n")
            assert prompt.count(block) == 1
            assert source_identity.setdefault(source["reference"], source) == source
            if not source["synthetic"]:
                path = root / "frozen/sources" / (source["id"].replace("/", "_") + ".md")
                assert path.read_bytes() == text.encode()
        for f, fp in zip(g["facts"], pos["facts"]):
            assert source_map[f["reference"]]["text"] == f["support_quote"]
            assert f["value"] in f["support_quote"]
            assert prompt[fp["char_start"]:fp["char_end"]] == f["support_quote"]
            assert raw[fp["byte_start"]:fp["byte_end"]] == f["support_quote"].encode()
            assert sha256(f["support_quote"].encode()).hexdigest() == fp["exact_quote_sha256"]
            hits = [i for i, (_, s, e) in enumerate(spans) if s < fp["byte_end"] and e > fp["byte_start"]]
            assert fp["token_start"] == min(hits) and fp["token_end"] == max(hits) + 1
            assert fp["distance_to_generation_tokens"] == len(spans) - fp["token_end"]
        fractions = [f["start_fraction"] for f in pos["facts"]]
        assert fractions[0] < .03 and .48 < fractions[1] < .53 and fractions[2] > .98
        mid = refs.index("资料2")
        banks = [refs[1:mid], refs[mid + 1:-1]]
        for old, new in zip(previous_banks, banks):
            assert new[:len(old)] == old
        previous_banks = banks
    freeze = root / "FROZEN.json"
    if freeze.exists():
        for rel, info in json.loads(freeze.read_text())["files"].items():
            raw = (root / rel).read_bytes()
            assert len(raw) == info["bytes"] and sha256(raw).hexdigest() == info["sha256"]
    print(json.dumps({"status": "PASS", "cases": 3, "fact_slots": 9, "reference_counts": [p["actual_reference_tokens"] for p in positions],
                      "complete_Wiki_text_and_source_identity": True, "nested_noise": True,
                      "exact_prompt_fact_token_spans": True, "model_requests": 0}))

if __name__ == "__main__":
    main()
