"""One authorized fixed long-context run; sequential HTTP, no retry."""
from pathlib import Path
import base64,datetime,hashlib,json,os,shlex,time,urllib.request,urllib.error
ROOT=Path(__file__).resolve().parent.parent
RUN=Path(__file__).resolve().parent
BASE="https://api-3b.rwkvos.com"
FREEZE="ddf8ea6cb52e88f0ad7b4826cf64b92dc07a1adf1433c1c421b41499b8b70de4"
sha=lambda raw:hashlib.sha256(raw).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,value):
 raw=(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+"\n").encode()
 with (RUN/name).open("xb") as f:f.write(raw);f.flush();os.fsync(f.fileno())
 fd=os.open(RUN,os.O_RDONLY)
 try:os.fsync(fd)
 finally:os.close(fd)
 return sha(raw)

def validate_freeze():
 raw=(ROOT/"FROZEN.json").read_bytes()
 assert sha(raw)==FREEZE
 for name,info in json.loads(raw)["files"].items():
  b=(ROOT/name).read_bytes();assert sha(b)==info["sha256"] and len(b)==info["bytes"]

class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None

def main():
 validate_freeze()
 requests=[json.loads(line) for line in (ROOT/"frozen/requests.jsonl").read_text().splitlines()]
 assert [r["id"] for r in requests]==["long_8192","long_16384","long_32768"]
 parts=shlex.split(Path("/mnt/c/Users/chase/.codex/attachments/5a056a59-9300-4f5d-aace-62d0a1fb046e/pasted-text.txt").read_text().replace("\\\n",""))
 headers={}
 for i,t in enumerate(parts[:-1]):
  if t in ("-H","--header"):
   k,v=parts[i+1].split(":",1);headers[k.strip()]=v.strip()
 secrets=[v.encode() for k,v in headers.items() if k.lower() not in ["accept","content-type","user-agent"]]
 assert len(secrets)>=2
 opener=urllib.request.build_opener(NoRedirect)
 save("STARTED-v2.json",{"started_at":now(),"freeze_sha256":FREEZE,"runner_sha256":sha(Path(__file__).read_bytes()),"authorization":"Root released exactly three frozen long-context-v1 requests after three count requests; no retries, no state, no server","automatic_retries":0,"header_names":list(headers),"parameters_from_frozen_file":True})
 def call(name,path,payload,timeout):
  b=json.dumps(payload,ensure_ascii=False,separators=(",",":"),allow_nan=False).encode()
  record={"name":name,"method":"POST","url":BASE+path,"payload":payload,"request_body_base64":base64.b64encode(b).decode(),"request_body_sha256":sha(b),"request_body_bytes":len(b),"header_names":list(headers),"started_at":now(),"automatic_retries":0,"response_received":False}
  start_sha=save(name+"-started.json",record);start=time.monotonic()
  try:
   req=urllib.request.Request(BASE+path,data=b,headers=headers,method="POST")
   try:r=opener.open(req,timeout=timeout)
   except urllib.error.HTTPError as error:r=error
   with r:
    raw=r.read()
    record.update(status=r.status,response_received=True,response_content_type=r.headers.get("Content-Type"),raw_response_sha256=sha(raw),raw_response_bytes=len(raw))
    safe=raw
    for secret in secrets:safe=safe.replace(secret,b"[REDACTED]")
    record["credential_redaction_applied"]=(safe!=raw)
    record["response_body_base64"]=base64.b64encode(safe).decode()
    record["stored_response_sha256"]=sha(safe)
    try:record["response_json"]=json.loads(safe)
    except (ValueError,UnicodeDecodeError):record["response_text"]=safe.decode("utf-8",errors="replace")
  except Exception as error:
   record["error_type"]=type(error).__name__
   msg=str(error).encode()
   for secret in secrets:msg=msg.replace(secret,b"[REDACTED]")
   record["error"]=msg.decode(errors="replace")
  record.update(completed_at=now(),seconds=time.monotonic()-start,started_receipt_sha256=start_sha)
  save(name+"-completed.json",record)
  print(json.dumps({"name":name,"status":record.get("status"),"seconds":record["seconds"],"error_type":record.get("error_type")}),flush=True)
  return record
 counts=[];results=[]
 for req in requests:
  counts.append(call(req["id"]+"-count","/v1/tokens/count",{"text":req["payload"]["contents"][0]},60))
 for req in requests:
  result=call(req["id"]+"-generation",req["path"],req["payload"],600)
  results.append(result)
  if not result["response_received"]:
   # A connection timeout leaves remote activity unknown; do not overlap next generation.
   break
 validate_freeze()
 save("COMPLETED.json",{"completed_at":now(),"frozen_inputs_unchanged":True,"count_http_attempts":len(counts),"generation_http_attempts":len(results),"expected_generations":3,"automatic_retries":0,"pending_case_ids":[r["id"] for r in requests[len(results):]],"unknown_remote_activity":any(not x["response_received"] for x in results),"raw_stop_not_natural_completion_proof":True})
 # Scan only receipts and runner for exact private header values; disclose no values.
 hits=[p.name for p in RUN.iterdir() if p.is_file() and any(v and v in p.read_bytes() for v in secrets)]
 save("CREDENTIAL-SCAN.json",{"status":"PASS" if not hits else "FAIL","matching_paths":hits,"values_printed_or_written":False})
 assert not hits

if __name__=="__main__":main()
