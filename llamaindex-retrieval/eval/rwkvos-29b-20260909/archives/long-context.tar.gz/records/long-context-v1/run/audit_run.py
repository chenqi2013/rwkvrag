"""Offline raw-byte/request/count/model identity audit; no semantic inference."""
from pathlib import Path
from hashlib import sha256
import base64,datetime,json,sys
RUN=Path(__file__).resolve().parent
ROOT=RUN.parent
sys.path.insert(0,str(ROOT))
from reference_tokenizer import ReferenceTokenizer

def digest(raw):return sha256(raw).hexdigest()
def unique_object(items):
 result={}
 for k,v in items:
  if k in result:raise ValueError("duplicate JSON key")
  result[k]=v
 return result

def audit():
 freeze=(ROOT/"FROZEN.json").read_bytes()
 assert digest(freeze)=="ddf8ea6cb52e88f0ad7b4826cf64b92dc07a1adf1433c1c421b41499b8b70de4"
 for path,info in json.loads(freeze)["files"].items():
  raw=(ROOT/path).read_bytes();assert digest(raw)==info["sha256"] and len(raw)==info["bytes"]
 reqs=[json.loads(x) for x in (ROOT/"frozen/requests.jsonl").read_text().splitlines()]
 positions=json.loads((ROOT/"frozen/positions.json").read_text())
 tok=ReferenceTokenizer(ROOT/"tokenizer/rwkv_vocab_v20230424.txt")
 records=[];rows=[]
 for req,pos in zip(reqs,positions):
  parts={}
  for stage in ["count","generation"]:
   name=req["id"]+"-"+stage
   started=RUN/(name+"-started.json");completed=RUN/(name+"-completed.json")
   start=json.loads(started.read_text());end=json.loads(completed.read_text())
   assert digest(started.read_bytes())==end["started_receipt_sha256"]
   for key,value in start.items():
    if key!="response_received":assert end[key]==value
   body=base64.b64decode(end["request_body_base64"],validate=True)
   assert digest(body)==end["request_body_sha256"] and len(body)==end["request_body_bytes"]
   expected={"text":req["payload"]["contents"][0]} if stage=="count" else req["payload"]
   assert json.loads(body,object_pairs_hook=unique_object)==expected==end["payload"]
   raw=base64.b64decode(end["response_body_base64"],validate=True)
   assert not end["credential_redaction_applied"]
   assert digest(raw)==end["raw_response_sha256"]==end["stored_response_sha256"] and len(raw)==end["raw_response_bytes"]
   parsed=json.loads(raw,object_pairs_hook=unique_object)
   assert parsed==end["response_json"]
   assert end["status"]==200 and end["response_received"] and end["automatic_retries"]==0
   assert datetime.datetime.fromisoformat(end["completed_at"])>=datetime.datetime.fromisoformat(end["started_at"])
   parts[stage]=(end,parsed)
   records.append({"name":name,"started_at":end["started_at"],"completed_at":end["completed_at"],"started_sha256":digest(started.read_bytes()),"completed_sha256":digest(completed.read_bytes())})
  count=parts["count"][1]["tokens"]
  assert type(count) is int and count>0
  record,data=parts["generation"]
  assert data["model"]==req["payload"]["model"] and data["object"]=="chat.completion"
  assert len(data["choices"])==1
  choice=data["choices"][0]
  assert type(choice["index"]) is int and choice["index"]==0 and choice["message"]["role"]=="assistant"
  answer=choice["message"]["content"]
  assert isinstance(answer,str) and isinstance(choice["finish_reason"],str)
  rows.append({"id":req["id"],"http_status":record["status"],"returned_model":data["model"],"prompt_sha256":digest(req["payload"]["contents"][0].encode()),"input_reference_tokens":pos["actual_reference_tokens"],"input_server_count":count,"count_difference":count-pos["actual_reference_tokens"],"generation_seconds":record["seconds"],"raw_answer_characters":len(answer),"raw_answer_bytes":len(answer.encode()),"raw_answer_sha256":digest(answer.encode()),"output_reference_reencoded_tokens":tok.count(answer),"actual_generated_tokens":None,"provider_finish_reason":choice["finish_reason"],"termination_verified":False,"true_termination":"unknown","usage":data.get("usage"),"output_max_tokens":req["payload"]["max_tokens"],"input_server_count_exceeds_16384":count>16384,"answer_raw":answer})
 order=[x["id"]+"-count" for x in reqs]+[x["id"]+"-generation" for x in reqs]
 ordered=[next(r for r in records if r["name"]==n) for n in order]
 for earlier,later in zip(ordered,ordered[1:]):
  assert datetime.datetime.fromisoformat(later["started_at"])>=datetime.datetime.fromisoformat(earlier["completed_at"])
 expected={n+suffix for n in order for suffix in ["-started.json","-completed.json"]}
 assert {p.name for p in RUN.glob("long_*.json")}==expected
 assert json.loads((RUN/"COMPLETED.json").read_text())["pending_case_ids"]==[]
 return {"status":"PASS","input_freeze_sha256":digest(freeze),"count_http":3,"generation_http":3,"all_http_200":True,"all_requests_sequential":True,"all_raw_body_hashes_match":True,"all_payloads_match_frozen":True,"all_returned_models_match":True,"all_frozen_inputs_unchanged":True,"automatic_retries":0,"pre_http_tool_failure_count":1,"pre_http_tool_failure_model_calls":0,"offline_count_equals_server_all":False,"http_accepts_raw_input_with_server_count_above_16384":True,"semantic_scores_automatically_proved":False,"records":ordered,"rows":rows}

if __name__=="__main__":
 result=audit()
 print(json.dumps(result,ensure_ascii=False,indent=2))
