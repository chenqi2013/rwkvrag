# 超长上下文：当前实现与最小下一步

只读审计，2026-09-09。未改生产代码或既有冻结 inputs/run，未调用API、访问服务器或训练。建议先完善完整prompt预算与独立Reader的输入组织；暂不把上传state或session续传当成长文正确性的修复。

## 四种机制不能混称

| 机制 | 状态与证据如何流动 | 当前支持/证据 |
|---|---|---|
| 应用层独立Reader | 每个来源拆成原文unit，再形成多个独立prompt；每次都重发任务、历史和该来源上下文。并发slot之间不共享推理state，返回的是原文编号。 | 当前生产`_resolve`已实现；选中unit保留父source ID、字符跨度、原文SHA。HTTP batch只合并传输，不把资料串成共同记忆。 |
| 单次API的分片prefill | 一条完整prompt分成小token片段，依次更新同一个GenerationState；不是多次独立Reader。 | 固定上游源码明确连续更新，服务status曾报告prefill_chunk_size=128。请求参数chunk_size仅控制**输出刷新**。实际部署revision未知；32,624-token输入已返回200，不代表逐token内部处理已独立认证。 |
| 上传tuned初始WKV state | 每次独立请求在初始WKV矩阵上开始；同batch每slot获得副本。它可承载训练形成的偏好/能力，不是当前文档全文缓存。 | `/v1/state/upload`与batch的state_id存在于上游；只加载blocks.N.att.time_state，shift/elapsed从零开始。2.9B预期32×[40,64,64]。本轮未上传或验证兼容state；过期state_id的400已验证。 |
| 跨调用完整state continuation | session保存WKV、attention/FFN shift和elapsed；后续只输入新增文本。 | 上游`/state/chat/completions`单prompt+session_id支持缓存；无显式state_id时读旧缓存，显式state_id会重建初态。生产adapter尚未接入；外部路由可达、会话亲和、过期、并发隔离、往返等价性均未实测，没有找到HTTP完整state导出接口。 |

连续state仍是有限的循环状态。把相同token流从一次请求改成若干续传请求，主要改变缓存/重传成本；若状态与token完全一致，不能预期仅靠调用边界就恢复已遗忘的信息。state tune也不能自动带来每次新文档的事实记忆。

## 当前预算缺口

外部`RwkvosBatchClient`只登记`context_window_tokens`；`input_tokens/fits/server_context_window`均为unknown，没有token/count调用，也没有总长度门。16,384是配置值，不能描述成已验证的服务硬上限。`evidence_units`注释仍说native tokenizer会兜底硬限制，对当前外部transport不成立。

Reader按原文字符1200窗口、180重叠、6000打包（均可配置）；长表格行允许超过软窗口。6000只累计unit文本，不含任务、完整历史、父级context_spans、JSON编码和提示前后缀。Writer把全部已选片段及其父上下文一次序列化，既未按token分组，也没有总预算；同一父上下文可能重复出现。`ask_materials`也直接进同一Writer。

当前选源上限是全局来源数，trace明确per_document_limit=None；不要为了预算重新引入每文档块数上限。Reader选中unit数量也不等于任务事实覆盖：task_units模式正确地将field_coverage_assessed置false。

## 最小可实现改动（分开实验）

1. **先补预算可观测性与明确策略。**共享render后得到最终prompt bytes，再返回`BudgetAssessment(prompt_sha, count, count_source, configured_policy_limit, output_reserve, policy_fits)`。离线参考计数用于观察；服务`POST /v1/tokens/count {"text":完整prompt}`可做严格应用门，但没有逐项批量count。按完整prompt SHA缓存计数，记录模型/服务身份与有效期。参考计数在本轮实际相差+1/+1/+2，不能固定加2就声称上界保证。输入上限、输出预算和服务硬限制应是不同字段；超限报明确policy状态，不删历史/证据、不临时缩短输出、不开隐式重试。

2. **把Reader的字符打包换成完整prompt的token预算打包。**保留同样全部EvidenceUnit、原文、顺序及来源映射，只在unit边界拆任务；计算固定历史/父上下文/编号/JSON开销。一个原子表格行或任务历史自身超预算时明确报告，不能无声裁剪。仍可跨来源并发，各Reader独立读取；这一步不要求新state端点，也不改变编号选择协议。预算是预登记实验策略，不能从三个合成例子直接断言“8K安全”。

3. **Writer超预算时采用有审计的原文选择层。**先考虑同一父source+SHA中完全重复/重叠跨度的确定性去重，保留每个原unit到合并span的映射和完整父源。还超预算时，新增独立并行选择层只返回既有unit ID，最终Writer仍读这些ID对应的原文，不以生成摘要代替证据。所有看过、选中、未选和错误unit都有记录，编号可追溯；选择过程本身会损失召回，必须真实QA对照。不要同时更换planner、模板、state和采样后声称单一因果改善。

第三步是可选后续，第一步的trace与第二步的完整prompt打包是最小优先实现。原文选择减少的是每个模型调用的负担；原始全文仍保留在索引与trace中，不承诺被丢弃片段已由最终Writer阅读。

## 最小验证设计

- **离线边界**：大历史、重复父上下文、超长表格行、中英混排、特殊空白；验证实际最终prompt计数、所有unit至少分配一次、原文跨度/SHA和引用映射不变。只改每批分组，不隐含每文配额。
- **固定材料对照**：冻结同一批候选原文，保持模型/stop/prefill/输出预算，比较旧字符打包与新token打包。报告Reader原文召回/噪声、Writer事实/逐引用支持、完整原分母、所有失败、调用数和墙钟时延；原文覆盖不是答案分数。
- **长文能力**：当前已曝光三档仅作回归。若要判断位置影响，另建预登记样本，把三事实轮换到开头/中间/末尾，固定干扰来源，再比较单次全文与独立分块阅读。不能用已曝光三档反复调参后称独立验证。
- **continuation另做能力预检**：先验证session生命周期与隔离，再比较一次完整token流和严格delta续传。上游parse_options未拒绝max_tokens=0，generate_one也先prefill后进入生成循环，因此源码上可能用于无输出预填充；**外部部署未验证，当前adapter还拒绝max_tokens<1**，不能当现成可用能力。中间若真的生成了任何确认文本，该文本会改变缓存状态，不能再称与一次prefill等价。跨边界重新tokenize也可能改变token流，字节串拼接相同还不够；同session需串行，不能并发get/put丢更新。

已测事实：三档服务输入8169/16375/32624 tokens，目标事实3/3、0/3、1/3，完整1/3。只证明这些请求被接受并得到这些答案，不证明16K硬门、一般能力上限或续传/训练效果。响应stop仍不可信地表示自然完成。

## 可直接引用的一手来源

上游固定commit：`Alic-Li/rwkv_lightning_cuda@6253c9e0345a1c5e42bf0a10e722ba09de06a2ac`；它是已读源码身份，不是外部部署revision认证。

- [原始编码不加模板；连续分片prefill与state复制](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_inference_engine.cpp#L237)
- [单项token计数路由，contents仅拼接计总数](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_api_service.cpp#L1152)
- [上传state接口](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_api_service.cpp#L419)、[零state与仅time_state加载](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv7_fast_v4.cu#L2307)
- [session续传端点与state_id优先规则](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_api_service.cpp#L1407)、[完整state缓存字段](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/include/rwkv_state_cache.hpp#L40)
- [生成预算解析](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_api_service.cpp#L542)、[prefill后生成循环](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_inference_engine.cpp#L335)
- [stop硬编码，不等于自然完成](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_api_service.cpp#L637)
- [BlinkDL官方G1训练角色及think前缀](https://github.com/BlinkDL/RWKV-LM/blob/9a75f9f037afa4418ee6283b584b92b1adb89ca1/RWKV-v7/RWKV7-G1x-templates.txt)

本地可复查：[长文完整原记录与评分](run/REPORT.md)、[API/state调查](../api-contract-v1/CONTRACT.md)、[模板权威证据](../template-contract-v1/REPORT.md)。

审计时工作树HEAD `213cfa06495fc5a624c163cd59097035cc4629ae`，含未提交外部适配改动；实际SHA：pipeline `8d37da528cce3034ca76d400867c4c08950e3753720088597084275be2a16333`，adapter `a8ffb23fa6139379ce4424ad0e3c9a80215db860529c4a065780b4d1efe62efc`，config `a3b2bb684054ab37a96f92b6474413c5d8de413062bbae92fa7d490b05ca07c7`，factory `abb4b32513072086b5a70e92a096818de6caadbf2312902efccc0d3b42f72e21`。本文是后续只读建议，不纳入或改写先前输入/运行freeze。
