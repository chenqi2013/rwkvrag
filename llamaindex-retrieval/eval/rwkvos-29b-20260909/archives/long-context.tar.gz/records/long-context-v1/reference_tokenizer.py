"""Offline byte trie counter pinned to the observed upstream vocabulary.
No remote tokenizer hash or BOS attestation is claimed.
"""
from __future__ import annotations
import ast
from hashlib import sha256
from pathlib import Path

VOCAB_SHA256 = "e6dee3d4e31b4d5c40ac99508ac6c701ceef4bed681bf2167ce9a908552bca89"

class ReferenceTokenizer:
    def __init__(self, path: Path):
        raw = path.read_bytes()
        if sha256(raw).hexdigest() != VOCAB_SHA256:
            raise ValueError("vocabulary hash mismatch")
        self.trie = {}
        self.vocab = {}
        for line in raw.decode("utf-8").splitlines():
            first, middle, last = line.index(" "), line.rindex(" "), line.rsplit(" ", 1)[1]
            token_id = int(line[:first])
            value = ast.literal_eval(line[first + 1:middle])
            token = value.encode("utf-8") if isinstance(value, str) else value
            if not isinstance(token, bytes) or not token or len(token) != int(last):
                raise ValueError("invalid vocabulary entry")
            if token_id in self.vocab:
                raise ValueError("duplicate vocabulary id")
            self.vocab[token_id] = token
            node = self.trie
            for byte in token:
                node = node.setdefault(byte, {})
            if None in node:
                raise ValueError("duplicate vocabulary token")
            node[None] = token_id

    def spans(self, text: str) -> list[tuple[int, int, int]]:
        raw = text.encode("utf-8")
        found = []
        start = 0
        while start < len(raw):
            node, end, best = self.trie, start, None
            while end < len(raw) and raw[end] in node:
                node = node[raw[end]]
                end += 1
                if None in node:
                    best = (node[None], start, end)
            if best is None:
                raise ValueError("unencoded byte")
            found.append(best)
            start = best[2]
        return found

    def count(self, text: str) -> int:
        return len(self.spans(text))
