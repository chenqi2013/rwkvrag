#!/bin/bash
set -euo pipefail
export OPENSEARCH_JAVA_HOME=/home/chase/GitHub/rwkvrag-bm-29b-20260908/local-index-v1/runtime/opensearch-3.8.0/jdk
export OPENSEARCH_JAVA_OPTS="-Xms2g -Xmx2g -XX:ActiveProcessorCount=4"
export CUDA_VISIBLE_DEVICES=""
cd /home/chase/GitHub/rwkvrag-bm-29b-20260908/local-index-v1/runtime/opensearch-3.8.0
exec /home/chase/GitHub/rwkvrag-bm-29b-20260908/local-index-v1/runtime/opensearch-3.8.0/bin/opensearch
