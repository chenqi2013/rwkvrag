"""Restore original frozen _id/_source records into a new loopback-only CPU index.
No ingestion, tokenization, embedding or model calls; refuse any existing index.
"""
from __future__ import annotations
import collections, hashlib, json, os, platform, subprocess, time
from datetime import datetime, timezone
from pathlib import Path
import httpx
R=Path(__file__).resolve().parent
OLD=Path("/home/chase/GitHub/rwkvrag-bm-rebuild-20260908/index-import-v1")
CORPUS=Path("/home/chase/GitHub/rwkvrag-wiki-rag-20260908/corpus/finewiki-zh-5000")
INDEX="rwkvrag-bm250820-wiki-5000-20260908"
URL="http://127.0.0.1:18438"
KB="wiki-5000-20260908"
PINS={"INDEX-FREEZE.json":"754395da228185952d0102ef46b4324a70fab0f0edc98a8eae5c65dec7d59212","indexed-records.jsonl":"e649fd2991bf7228d0bc73ece4b415cf3f2b14c8d795add1ef27f0054a7077d8","INDEX-CREATED.json":"3a38fb1e0bc34d81b929b2d40171193aa14198574888f6154b796c6e79cc0574"}
MANIFEST_SHA="35563fa6e5d7c9205cea3d9e1cd5476b01774f11a292dafcfed82fe4d8256ced"
GENERATED={"uuid","creation_date","provided_name","version"}
def sha(data): return hashlib.sha256(data).hexdigest()
def file_sha(p):
    with p.open("rb") as f: return hashlib.file_digest(f,"sha256").hexdigest()
def canonical(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode()
def stamp(): return datetime.now(timezone.utc).isoformat()
def check(value,message):
    if not value: raise ValueError(message)
def save(name,value):
    with (R/name).open("x",encoding="utf-8") as f:
        json.dump(value,f,ensure_ascii=False,indent=2); f.write("\n"); f.flush(); os.fsync(f.fileno())
def coverage(spans,length):
    end=0
    for a,b in sorted(spans):
        check(type(a) is int and type(b) is int and 0<=a<b<=length,"invalid coverage span")
        check(a<=end,"original character coverage gap");end=max(end,b)
    check(end==length,"uncovered original suffix");return end
def main():
    start=time.monotonic();save("RESTORE-STARTED.json",{"utc":stamp(),"url":URL,"index":INDEX,"operation":"create only","remote_server_calls":0})
    for name,digest in PINS.items(): check(file_sha(OLD/name)==digest,"frozen input hash changed: "+name)
    check(file_sha(CORPUS/"manifest.jsonl")==MANIFEST_SHA,"corpus manifest hash changed")
    oldfreeze=json.loads((OLD/"INDEX-FREEZE.json").read_bytes());olddef=json.loads((OLD/"INDEX-CREATED.json").read_bytes())[INDEX]
    documents={}
    for line in (CORPUS/"manifest.jsonl").read_text().splitlines():
        m=json.loads(line);raw=(CORPUS/m["text_path"]).read_bytes()
        check(sha(raw)==m["text_sha256"] and len(raw)==m["text_bytes"],"corpus original hash/size changed")
        text=raw.decode();check(len(text)==m["text_characters"],"corpus Unicode length changed")
        check(m["id"] not in documents,"duplicate original document");documents[m["id"]]=(m,text)
    check(len(documents)==5000,"corpus count changed")
    expected={}
    for line in (OLD/"indexed-records.jsonl").open("rb"):
        h=json.loads(line);identity=h["_id"]
        check(identity not in expected,"duplicate old ID");check(h["_index"]==INDEX and h["_version"]==1,"old index/version changed")
        expected[identity]=h["_source"]
    check(len(expected)==45960,"old point count changed")
    settings={k:v for k,v in olddef["settings"]["index"].items() if k not in GENERATED}
    create={"settings":{"index":settings},"mappings":olddef["mappings"],"aliases":olddef["aliases"]}
    save("CREATE-REQUEST.json",create)
    save("INPUT-VALIDATION.json",{"status":"PASS","old_inputs":PINS,"corpus_manifest_sha256":MANIFEST_SHA,"documents":5000,"nodes":45960,"all_frozen_original_texts_verified":True,"method":"Copy each original _id and full _source without rewriting any value; canonical JSON comparisons preserve every string exactly."})
    print(json.dumps({"stage":"input_validated","nodes":len(expected)}),flush=True)
    with httpx.Client(timeout=120,trust_env=False,follow_redirects=False) as http:
        def request(method,path,**kw):
            response=http.request(method,URL+path,**kw);response.raise_for_status();return response.json()
        absent=http.get(URL+"/"+INDEX)
        save("INDEX-ABSENT-RECEIPT.json",{"status_code":absent.status_code,"body":absent.text,"utc":stamp(),"url":str(absent.url)})
        check(absent.status_code==404,"index exists; refusing all writes")
        info=request("GET","");save("OPENSEARCH-INFO.json",info)
        check(info["version"]==oldfreeze["opensearch_version"],"OpenSearch build differs from frozen version")
        save("CREATE-RESPONSE.json",request("PUT","/"+INDEX,json=create))
        created=request("GET","/"+INDEX);save("INDEX-CREATED.json",created)
        newuuid=created[INDEX]["settings"]["index"]["uuid"]
        check(newuuid!=oldfreeze["index_uuid"],"physical UUID unexpectedly identical")
        batch=[];total=0
        with (R/"bulk-receipts.jsonl").open("xb") as receipts:
            def flush():
                nonlocal total
                payload=b"".join(canonical({"create":{"_index":INDEX,"_id":identity}})+b"\n"+canonical(source)+b"\n" for identity,source in batch)
                response=http.post(URL+"/_bulk",content=payload,headers={"Content-Type":"application/x-ndjson"})
                raw=response.content
                receipts.write(canonical({"utc":stamp(),"request_sha256":sha(payload),"request_bytes":len(payload),"ids":[i for i,_ in batch],"http_status":response.status_code,"response_raw":raw.decode()})+b"\n");receipts.flush();os.fsync(receipts.fileno())
                response.raise_for_status();body=response.json();check(body.get("errors") is False,"bulk failure")
                check(len(body["items"])==len(batch),"bulk result count changed")
                for row,(identity,_) in zip(body["items"],batch):
                    item=row["create"];check(item["status"]==201 and item["_id"]==identity and item["_version"]==1,"bulk create identity/version failure")
                total+=len(batch);batch.clear()
                if total%5000==0:print(json.dumps({"stage":"restored","nodes":total}),flush=True)
            for identity,source in expected.items():
                batch.append((identity,source))
                if len(batch)==500:flush()
            if batch:flush()
        request("POST","/"+INDEX+"/_refresh")
        save("RESTORE-COMPLETED.json",{"utc":stamp(),"created_nodes":total,"retries":0,"overwrites":0})
        seen=set();intervals=collections.defaultdict(list);doc_sources={};point_hashes=[];versions=collections.Counter();types=collections.Counter();contexts=0
        query={"size":500,"sort":["_doc"],"version":True,"query":{"match_all":{}}}
        page=request("POST","/"+INDEX+"/_search?scroll=5m",json=query);scrollid=page["_scroll_id"]
        try:
            with (R/"indexed-records.jsonl").open("xb") as output:
                while page["hits"]["hits"]:
                    for h in page["hits"]["hits"]:
                        identity=h["_id"];source=h["_source"]
                        check(identity not in seen and identity in expected,"duplicate/unexpected returned ID")
                        check(source==expected[identity],"full _source differs: "+identity)
                        check(canonical(source)==canonical(expected[identity]),"canonical _source changed")
                        check(h["_index"]==INDEX and source["node_id"]==identity,"wrong source identity")
                        m=source["metadata"];original,text=documents[m["external_id"]]
                        span=m["source_span"];a,b=span["start"],span["end"]
                        check(type(a) is int and type(b) is int and 0<=a<b<=len(text),"invalid source span")
                        check(span["unit"]=="unicode_code_points" and source["text"]==text[a:b],"nonverbatim indexed text")
                        check(span["sha256"]==m["chunk_text_sha256"]==sha(text[a:b].encode()),"chunk SHA mismatch")
                        check(m["source_text_sha256"]==original["text_sha256"],"source SHA mismatch")
                        for k in ("page_id","version","wikiname","in_language","date_modified"):
                            check(m[k]==original[k],"source revision identity changed")
                        for k,v in (("title",original["title"]),("uri",original["url"]),("source","finewiki-zh"),("knowledge_base_id",KB),("document_id",m["document_id"])):
                            check(source[k]==m[k]==v,"source identity changed: "+k)
                        check(m["source_row_index"]==original["source_row"],"source row changed")
                        for c in m["context_spans"]:
                            x,y=c["start"],c["end"]
                            check(type(x) is int and type(y) is int and 0<=x<y<=len(text),"invalid context span")
                            check(c["text"]==text[x:y] and c["sha256"]==sha(text[x:y].encode()),"context original mismatch")
                        doc=m["document_id"];doc_sources.setdefault(doc,m["external_id"]);check(doc_sources[doc]==m["external_id"],"document ID collision")
                        intervals[doc].append((a,b));contexts+=len(m["context_spans"]);seen.add(identity);versions[str(h["_version"])]+=1;types[source["content_type"]]+=1
                        output.write(canonical(h)+b"\n");point_hashes.append({"id":identity,"source_sha256":sha(canonical(source))})
                    page=request("POST","/_search/scroll",json={"scroll":"5m","scroll_id":scrollid});scrollid=page.get("_scroll_id",scrollid)
                output.flush();os.fsync(output.fileno())
        finally:request("DELETE","/_search/scroll",json={"scroll_id":[scrollid]})
        check(seen==set(expected),"missing restored IDs");check(len(intervals)==5000,"missing restored documents")
        check(versions=={"1":45960},"restored index versions changed")
        rows=[]
        for doc,spans in sorted(intervals.items()):
            original,text=documents[doc_sources[doc]];covered=coverage(spans,len(text))
            rows.append({"document_id":doc,"page_id":original["page_id"],"characters":covered,"nodes":len(spans),"source_text_sha256":original["text_sha256"],"all_original_characters_covered":True})
        check(sum(x["characters"] for x in rows)==6437704 and contexts==78551,"coverage totals changed")
        save("DOCUMENT-COVERAGE.json",rows);point_hashes.sort(key=lambda x:x["id"]);save("POINT-HASHES.json",point_hashes)
        final=request("GET","/"+INDEX);definition=final[INDEX]
        check(definition["mappings"]==olddef["mappings"] and definition["aliases"]==olddef["aliases"],"mapping/aliases changed")
        clean={k:v for k,v in definition["settings"]["index"].items() if k not in GENERATED}
        check(clean==settings,"non-generated settings changed");check(definition["settings"]["index"]["uuid"]==newuuid,"UUID changed")
        count=request("GET","/"+INDEX+"/_count");check(count["count"]==45960,"count disagrees")
        save("INDEX-FINAL-STATE.json",{"definition":final,"count":count,"health":request("GET","/_cluster/health/"+INDEX),"stats":request("GET","/"+INDEX+"/_stats")})
        smokequery={"size":5,"query":{"bool":{"must":[{"match":{"body_tokens":"自动化"}}],"filter":[{"term":{"knowledge_base_id":KB}}]}}}
        smokeresult=request("POST","/"+INDEX+"/_search",json=smokequery)
        check(smokeresult["hits"]["hits"],"real BM25 query returned no results")
        save("QUERY-SMOKE.json",{"query":smokequery,"response":smokeresult,"purpose":"Local BM25 operational smoke; no benchmark or answer quality claim."})
        nodes=request("GET","/_nodes/settings,jvm,http,transport");save("LOCAL-NODE-RUNTIME.json",nodes)
        for node in nodes["nodes"].values():
            check(node["jvm"]["mem"]["heap_max_in_bytes"]==2147483648,"heap limit changed")
            for transport in ("http","transport"):
                check(all("127.0.0.1" in a for a in node[transport]["bound_address"]),"non-loopback listener")
        artifacts={p.name:{"bytes":p.stat().st_size,"sha256":file_sha(p)} for p in sorted(R.iterdir()) if p.is_file() and p.name not in {"job.log","INDEX-FREEZE.json"}}
        save("INDEX-FREEZE.json",{"schema":"rwkvrag-local-cpu-restored-index-v1","status":"PASS","completed_utc":stamp(),"elapsed_seconds":time.monotonic()-start,"endpoint":URL,"index":INDEX,"index_uuid":newuuid,"old_index_uuid":oldfreeze["index_uuid"],"same_physical_index":False,"restored_from_local_frozen_scroll":True,"source_freeze_sha256":PINS["INDEX-FREEZE.json"],"source_scroll_sha256":PINS["indexed-records.jsonl"],"corpus_manifest_sha256":MANIFEST_SHA,"source":"finewiki-zh","knowledge_base_id":KB,"documents":5000,"document_count":5000,"nodes":45960,"chunk_count":45960,"original_characters":6437704,"verified_context_spans":contexts,"content_types":dict(types),"all_original_characters_covered":True,"all_indexed_ids_and_full_source_exact":True,"all_indexed_text_and_metadata_exact":True,"mapping_and_analyzer_exact":True,"non_generated_index_settings_exact":True,"source_revision_identity_verified":True,"scroll_all_nodes_verified":True,"identity_comparison":"Canonical complete _source JSON bytes equal; every text and metadata string unchanged. HTTP serialization whitespace is not compared.","canonical_id_source_manifest_sha256":sha(canonical(point_hashes)),"all_versions":dict(versions),"opensearch_version":info["version"],"local_service_unit":"rwkvrag-local-opensearch-29b-20260908.service","heap_bytes":2147483648,"loopback_only":True,"model_calls":0,"embedding_calls":0,"remote_server_calls":0,"settings":{"rag_pipeline":"rwkv","opensearch_url":URL,"opensearch_index":INDEX,"native_ingest_chunk_characters":2400,"native_ingest_overlap_characters":180,"candidate_k":80},"performance_and_tie_order_note":"New local CPU host and physical Lucene index; no claim of identical latency or tie ordering to retired server.","artifacts":artifacts})
        print(json.dumps({"stage":"complete","status":"PASS","index_uuid":newuuid,"freeze_sha256":file_sha(R/"INDEX-FREEZE.json")}),flush=True)
if __name__=="__main__":main()
