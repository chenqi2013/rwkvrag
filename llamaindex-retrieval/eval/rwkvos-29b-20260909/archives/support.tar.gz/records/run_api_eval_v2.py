from pathlib import Path
from datetime import datetime,timezone
import sys,json,os,shlex,subprocess,hashlib
B=Path(__file__).resolve().parent
S=B/'source-api-v2'
PY='/home/chase/GitHub/rwkvrag-bm250820/llamaindex-retrieval/.venv/bin/python'
phase=sys.argv[1]
assert phase in {'materials-api-v1','materials-api-eos-v2','wiki-api-v1-eos','materials-api-prefix-v3','wiki-api-prefix-v2'}
manifest=json.loads((S/'SOURCE-MANIFEST.json').read_text())
def verify():
 for name,spec in manifest['files'].items():
  raw=(S/name).read_bytes();assert len(raw)==spec['bytes'] and hashlib.sha256(raw).hexdigest()==spec['sha256'],name
verify()
parts=shlex.split(Path('/mnt/c/Users/chase/.codex/attachments/5a056a59-9300-4f5d-aace-62d0a1fb046e/pasted-text.txt').read_text().replace('\\\n',''))
headers={}
for i,t in enumerate(parts):
 if t in ('--header','-H'):
  key,value=parts[i+1].split(':',1);headers[key.lower()]=value.strip()
env=dict(os.environ)
env['RWKVRAG_RWKVOS_CF_ACCESS_CLIENT_ID']=headers['cf-access-client-id']
env['RWKVRAG_RWKVOS_CF_ACCESS_CLIENT_SECRET']=headers['cf-access-client-secret']
# No credential values in argv, receipts, stdout or repository files.
base=['--base-url','https://api-3b.rwkvos.com/v1','--model','rwkv7-g1j-2.9b-20260831-ctx16384','--transport','rwkvos_batch','--writer-prefill','<think></think','--batch-size','8','--batch-wait-ms','5']
if phase.startswith('materials'):
 cmd=[PY,str(S/'eval/native-smoke/run_smoke.py'),'--module-root',str(S),'--output',str(B/phase),'--concurrency','8','--max-output-tokens','2048','--timeout-seconds','600',*base]
 if phase in {'materials-api-eos-v2','materials-api-prefix-v3'}:cmd+=['--stop-tokens','[0]']
 if phase=='materials-api-prefix-v3':cmd+=['--prefill-mode','continuation']
else:
 cmd=[PY,str(S/'eval/native-wiki/run_wiki.py'),'--source-root',str(S),'--out',str(B/phase),'--run','--opensearch-url','http://127.0.0.1:18438','--index','rwkvrag-bm250820-wiki-5000-20260908','--expected-index-uuid','lYXmlfpMRPCJ5tyq9YW67g','--knowledge-base-id','wiki-5000-20260908','--question-concurrency','4','--native-concurrency','32','--resolver-sources','80','--candidate-k','80','--max-tokens','2048','--timeout','600','--planner-prefill','<think></think','--resolver-prefill','<think></think','--plan-protocol','queries_fields','--resolver-protocol','task_units','--task-source','queries','--candidate-order','query_round_robin','--stop-tokens','[0]',*base]
if phase=='wiki-api-prefix-v2':cmd+=['--prefill-mode','continuation']
def save(name,value):
 with (B/name).open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
assert not (B/phase).exists()
start=datetime.now(timezone.utc).isoformat()
save(phase+'-PROCESS-STARTED.json',{'started_at':start,'command':cmd,'source_manifest_sha256':hashlib.sha256((S/'SOURCE-MANIFEST.json').read_bytes()).hexdigest(),'credential_values_archived':False,'automatic_retries':0})
r=subprocess.run(cmd,cwd=S,env=env,capture_output=True)
(B/(phase+'-stdout.log')).write_bytes(r.stdout)
(B/(phase+'-stderr.log')).write_bytes(r.stderr)
verify()
save(phase+'-PROCESS-COMPLETED.json',{'started_at':start,'completed_at':datetime.now(timezone.utc).isoformat(),'returncode':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'source_unchanged':True})
print(r.stdout.decode(),flush=True)
if r.stderr:print(r.stderr.decode(),flush=True)
raise SystemExit(r.returncode)
