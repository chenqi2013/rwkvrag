import asyncio
from collections import Counter
from dataclasses import dataclass, replace
from hashlib import sha256
import json
from math import log
import re

import httpx

from .config import Settings
from .generation import EvidenceAnswerGenerator
from .lexical_index import lexical_tokens, normalize_search_text
from .query_planning import QueryPlan
from .schemas import SourceItem


_EVIDENCE_RELATION_MARKERS: tuple[str, ...] = ()
_BROAD_CONTEXT_MARKERS: tuple[str, ...] = ()
_CAUSE_PROGRESSION_MARKERS: tuple[str, ...] = ()
_CAUSE_EVENT_MARKERS: tuple[str, ...] = ()
_SUBJECT_SEPARATORS = re.compile(r"(?:和|与|與|及|以及|、|及其)")


def _relation_variants(relations: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(relation.strip() for relation in relations if relation.strip()))


def _normalize_identity(value: str) -> str:
    normalized = normalize_search_text(value).replace(" ", "").replace("的", "")
    normalized = normalized.translate(str.maketrans({
        "〇": "0", "一": "1", "二": "2", "两": "2", "三": "3",
        "四": "4", "五": "5", "六": "6", "七": "7", "八": "8",
        "九": "9", "十": "10",
    }))
    return normalized


def _identity_variants(value: str) -> tuple[str, ...]:
    normalized = _normalize_identity(value)
    variants = [normalized]
    title_base = re.split(r"[（(]", normalized, maxsplit=1)[0]
    if title_base != normalized:
        variants.append(title_base)
    for suffix in ("事变", "之变", "政变"):
        if normalized.endswith(suffix):
            variants.append(normalized[: -len(suffix)])
    return tuple(dict.fromkeys(variant for variant in variants if variant))


@dataclass(frozen=True)
class EvidenceSpan:
    field_id: str
    source_index: int
    span: str
    content_hash: str


@dataclass(frozen=True)
class _EvidenceUnit:
    source_index: int
    span: str
    content_hash: str
    score: float


def _source_signature(source: SourceItem) -> tuple[str, str]:
    return source.id, sha256(source.snippet.encode("utf-8")).hexdigest()


def _source_identity(source: SourceItem) -> tuple[str, str, str, str, str | None]:
    return source.id, source.document_id, source.source, source.title, source.uri


@dataclass(frozen=True)
class EvidenceExtractionResult:
    candidates: tuple[EvidenceSpan, ...]
    attempted_sources: int
    completed_sources: int
    errors: tuple[str, ...] = ()
    source_signatures: tuple[tuple[str, str], ...] = ()
    strategy: str = "model"
    trace_events: tuple[dict[str, object], ...] = ()
    source_identities: tuple[tuple[str, str, str, str, str | None], ...] = ()

    @property
    def available(self) -> bool:
        return self.completed_sources > 0

    @property
    def has_candidates(self) -> bool:
        return bool(self.candidates)

    def matches_sources(self, sources: list[SourceItem]) -> bool:
        if not self.source_signatures:
            return False
        selected = sources[: len(self.source_signatures)]
        if tuple(_source_signature(source) for source in selected) != self.source_signatures:
            return False
        if self.source_identities and (
            tuple(_source_identity(source) for source in selected) != self.source_identities
        ):
            return False
        resolved = self._resolved_candidates(sources)
        return len(resolved) == len(self.candidates) and all(
            original.source_index == current.source_index
            for original, current in zip(self.candidates, resolved, strict=True)
        )

    def _resolved_candidates(self, sources: list[SourceItem]) -> tuple[EvidenceSpan, ...]:
        """Bind quotes to the exact selected source, never to a shifted list position."""
        indexes: dict[tuple[str, str], list[int]] = {}
        for index, source in enumerate(sources):
            indexes.setdefault(_source_signature(source), []).append(index)
        resolved: list[EvidenceSpan] = []
        for candidate in self.candidates:
            index = candidate.source_index
            if type(index) is not int or index < 0:
                continue
            if (
                not isinstance(candidate.span, str)
                or not candidate.span
                or sha256(candidate.span.encode("utf-8")).hexdigest() != candidate.content_hash
            ):
                continue
            identity = None
            if self.source_identities:
                if index >= len(self.source_identities):
                    continue
                identity = self.source_identities[index]
            if self.source_signatures:
                if index >= len(self.source_signatures):
                    continue
                matches = indexes.get(self.source_signatures[index], [])
                if identity is not None:
                    matches = [i for i in matches if _source_identity(sources[i]) == identity]
                if len(matches) != 1:
                    continue
                index = matches[0]
            elif index >= len(sources):
                continue
            # Unbound legacy/internal results can only use their original position.
            # Even those must contain the exact quote and its authentic content hash.
            source = sources[index]
            if identity is not None and _source_identity(source) != identity:
                continue
            if candidate.span not in source.snippet:
                continue
            resolved.append(replace(candidate, source_index=index))
        return tuple(resolved)

    def remap_sources(
        self,
        sources: list[SourceItem],
    ) -> "EvidenceExtractionResult | None":
        if not self.candidates:
            return None
        remapped = self._resolved_candidates(sources)
        if not remapped:
            return None
        return EvidenceExtractionResult(
            candidates=tuple(remapped),
            attempted_sources=len(sources),
            completed_sources=min(self.completed_sources, len(sources)),
            errors=self.errors,
            source_signatures=tuple(_source_signature(source) for source in sources),
            strategy=f"{self.strategy}_remapped",
            trace_events=self.trace_events,
            source_identities=tuple(_source_identity(source) for source in sources),
        )

    def answer_sources(self, sources: list[SourceItem]) -> list[SourceItem]:
        grouped: dict[int, list[EvidenceSpan]] = {}
        for candidate in self._resolved_candidates(sources):
            grouped.setdefault(candidate.source_index, []).append(candidate)
        output: list[SourceItem] = []
        for source_index in grouped:
            source = sources[source_index]
            candidates = grouped[source_index]
            spans = list(dict.fromkeys(candidate.span for candidate in candidates))
            hashes = [candidate.content_hash for candidate in candidates]
            copied_source = source.model_copy(deep=True)
            metadata = {
                **copied_source.metadata,
                "evidence_span_hashes": hashes,
                "evidence_field_ids": list(dict.fromkeys(
                    candidate.field_id for candidate in candidates
                )),
            }
            output.append(copied_source.model_copy(update={
                "snippet": "\n".join(spans),
                "metadata": metadata,
            }))
        return output


class LanguageModelEvidenceExtractor:
    def __init__(
        self,
        settings: Settings,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.transport = transport

    async def extract(
        self,
        question: str,
        plan: QueryPlan,
        sources: list[SourceItem],
    ) -> EvidenceExtractionResult:
        if not self.settings.evidence_extraction_enabled or not sources:
            return EvidenceExtractionResult((), 0, 0)
        if not self.settings.generation_password:
            return EvidenceExtractionResult(
                (), 0, 0, ("generation_password_not_configured",)
            )
        source_limit = self.settings.evidence_extraction_max_sources
        selected = [source.model_copy(deep=True) for source in sources[:source_limit]]
        signatures = tuple(_source_signature(source) for source in selected)
        identities = tuple(_source_identity(source) for source in selected)
        semaphore = asyncio.Semaphore(self.settings.evidence_extraction_concurrency)

        async def run(source_index: int, source: SourceItem):
            async with semaphore:
                return await self._extract_source(question, plan, source_index, source)

        results = await asyncio.gather(*(
            run(source_index, source)
            for source_index, source in enumerate(selected)
        ), return_exceptions=True)
        candidates: list[EvidenceSpan] = []
        trace_events: list[dict[str, object]] = [{
            "stage": "resolver_selection",
            "source_budget": source_limit,
            "input_source_count": len(sources),
            "selected_sources": [
                {
                    "source_id": source.id,
                    "document_id": source.document_id,
                    "original_source_index": index,
                    "selected_source_index": index,
                    "source_text_sha256": signatures[index][1],
                }
                for index, source in enumerate(selected)
            ],
        }]
        errors: list[str] = []
        completed = 0
        seen: set[tuple[str, int, str]] = set()
        for source_index, result in enumerate(results):
            if isinstance(result, BaseException):
                errors.append(f"source_{source_index + 1}: {type(result).__name__}: {result}")
                continue
            completed += 1
            source_candidates, source_trace = result
            trace_events.append(source_trace)
            for candidate in source_candidates:
                key = (candidate.field_id, candidate.source_index, candidate.span)
                if key in seen:
                    continue
                seen.add(key)
                candidates.append(candidate)
        strategy = "model" if candidates else "model_empty"
        if self.settings.semantic_pipeline_enabled and completed:
            try:
                adjudicated, adjudication_trace = await self._adjudicate(
                    question,
                    plan,
                    selected,
                    candidates,
                )
                candidates = list(adjudicated)
                trace_events.append(adjudication_trace)
                strategy = "model_map_reduce" if candidates else "model_map_reduce_empty"
            except Exception as error:
                errors.append(f"adjudication: {type(error).__name__}: {error}")
                strategy = "model_map_reduce_error_fallback" if candidates else "model_map_reduce_error"
        return EvidenceExtractionResult(
            tuple(candidates),
            attempted_sources=len(selected),
            completed_sources=completed,
            errors=tuple(errors),
            source_signatures=signatures,
            strategy=strategy,
            trace_events=tuple(trace_events),
            source_identities=identities,
        )

    async def _adjudicate(
        self,
        question: str,
        plan: QueryPlan,
        sources: list[SourceItem],
        map_candidates: list[EvidenceSpan],
    ) -> tuple[tuple[EvidenceSpan, ...], dict[str, object]]:
        units = self._adjudication_units(plan, sources, map_candidates)
        if not units:
            return (), {
                "stage": "resolver_adjudication",
                "prompt": "",
                "raw_output": "",
                "selected_count": 0,
            }
        prompt = self._adjudication_prompt(question, plan, sources, units)
        payload = {
            "contents": [prompt],
            "max_tokens": min(self.settings.evidence_extraction_max_tokens, 192),
            "temperature": 0.1,
            "top_k": 20,
            "top_p": 0.4,
            "alpha_presence": 0.0,
            "alpha_frequency": 0.0,
            "alpha_decay": 0.99,
            "stream": True,
            "password": self.settings.generation_password,
        }
        endpoint = f"{self.settings.generation_base_url.rstrip('/')}/chat/completions"
        async with httpx.AsyncClient(
            timeout=self.settings.evidence_extraction_timeout,
            transport=self.transport,
        ) as client:
            async with client.stream("POST", endpoint, json=payload) as response:
                response.raise_for_status()
                raw = await EvidenceAnswerGenerator._read_stream(
                    response,
                    total_timeout=self.settings.evidence_extraction_timeout,
                )
        selections = self._parse_adjudication(
            raw,
            {field.field_id for field in plan.fields},
            len(units),
        )
        if plan.analysis.intent == "cause" and units:
            strongest_index = max(
                range(1, len(units) + 1),
                key=lambda index: units[index - 1].score,
            )
            strongest_selection = (plan.fields[0].field_id, strongest_index)
            if strongest_selection not in selections:
                selections = (strongest_selection, *selections)
            selections = tuple(sorted(
                selections,
                key=lambda item: units[item[1] - 1].score,
                reverse=True,
            ))
        selection_limit = (
            4
            if plan.analysis.intent == "cause"
            else 6 if plan.answer_shape in {"list", "summary", "narrative"} else 3
        )
        selections = selections[:selection_limit]
        output: list[EvidenceSpan] = []
        seen: set[tuple[str, int, str]] = set()
        for field_id, unit_index in selections:
            unit = units[unit_index - 1]
            if sha256(unit.span.encode("utf-8")).hexdigest() != unit.content_hash:
                continue
            if unit.source_index >= len(sources):
                continue
            if unit.span not in sources[unit.source_index].snippet:
                continue
            key = (field_id, unit.source_index, unit.span)
            if key in seen:
                continue
            seen.add(key)
            output.append(EvidenceSpan(
                field_id=field_id,
                source_index=unit.source_index,
                span=unit.span,
                content_hash=unit.content_hash,
            ))
        return tuple(output), {
            "stage": "resolver_adjudication",
            "prompt": prompt,
            "raw_output": raw,
            "prompt_sha256": sha256(prompt.encode("utf-8")).hexdigest(),
            "raw_output_sha256": sha256(raw.encode("utf-8")).hexdigest(),
            "selected_count": len(output),
        }

    def _adjudication_units(
        self,
        plan: QueryPlan,
        sources: list[SourceItem],
        map_candidates: list[EvidenceSpan],
    ) -> tuple[_EvidenceUnit, ...]:
        raw_units: list[tuple[int, str, bool]] = []
        seen: set[tuple[int, str]] = set()
        for candidate in map_candidates:
            key = (candidate.source_index, candidate.span)
            if key in seen or candidate.source_index >= len(sources):
                continue
            if self._is_structural_noise(candidate.span, sources[candidate.source_index]):
                continue
            seen.add(key)
            raw_units.append((candidate.source_index, candidate.span, True))
        for source_index, source in enumerate(sources):
            for span in self._attention_units(plan, source):
                key = (source_index, span)
                if key in seen:
                    continue
                if self._is_structural_noise(span, source):
                    continue
                seen.add(key)
                raw_units.append((source_index, span, False))
        if not raw_units:
            return ()

        tokenized = [tuple(lexical_tokens(span)) for _, span, _ in raw_units]
        document_frequency = Counter(
            token for tokens in tokenized for token in set(tokens)
        )
        query_terms = tuple(dict.fromkeys(lexical_tokens(" ".join((
            plan.subject,
            *(field.question for field in plan.fields),
            *plan.relations,
            *plan.queries,
        )))))
        average_length = sum(map(len, tokenized)) / max(1, len(tokenized))
        corpus_size = len(tokenized)
        ranked: list[_EvidenceUnit] = []
        for (source_index, span, selected_by_map), tokens in zip(
            raw_units,
            tokenized,
            strict=True,
        ):
            frequencies = Counter(tokens)
            length_normalizer = 0.25 + 0.75 * (
                len(tokens) / max(1.0, average_length)
            )
            score = 0.0
            for term in query_terms:
                frequency = frequencies.get(term, 0)
                if not frequency:
                    continue
                document_count = document_frequency.get(term, 0)
                inverse_frequency = log(
                    1.0 + (corpus_size - document_count + 0.5) / (document_count + 0.5)
                )
                score += inverse_frequency * (
                    frequency * 2.2 / (frequency + 1.2 * length_normalizer)
                )
            if selected_by_map:
                score += 0.5
            normalized_span = normalize_search_text(span).replace(" ", "")
            normalized_subject = normalize_search_text(plan.subject).replace(" ", "")
            source_title = normalize_search_text(
                sources[source_index].title
            ).replace(" ", "")
            relation_terms = tuple(
                normalize_search_text(relation).replace(" ", "")
                for field in plan.fields
                for relation in field.relations
                if relation.strip()
            )
            if normalized_subject and normalized_subject in source_title:
                score += 2.5
            if plan.answer_shape == "single_fact" and relation_terms and not any(
                relation in normalized_span for relation in relation_terms
            ):
                score -= 2.0
            if any(marker in normalized_span for marker in _EVIDENCE_RELATION_MARKERS):
                score += 1.0
            if plan.analysis.intent == "cause" and any(
                marker in normalized_span
                for marker in ("因为", "由于", "导致", "造成", "引发", "促成", "因素", "原因")
            ):
                score += 5.0
            if plan.analysis.intent == "cause" and any(
                marker in normalized_span for marker in _CAUSE_PROGRESSION_MARKERS
            ):
                score += 2.0
            if plan.analysis.intent == "cause" and any(
                marker in normalized_span for marker in _CAUSE_EVENT_MARKERS
            ) and not any(
                marker in normalized_span for marker in _CAUSE_PROGRESSION_MARKERS
            ):
                score -= 2.0
            if plan.analysis.intent == "cause" and any(
                marker in normalized_span
                for marker in ("转折点", "轉折點", "时间", "時間")
            ):
                score -= 2.0
            if plan.analysis.intent == "ordinal":
                score += 0.0
            if plan.answer_shape == "single_fact" and any(
                marker in normalized_span for marker in _BROAD_CONTEXT_MARKERS
            ):
                score -= 4.0
            ranked.append(_EvidenceUnit(
                source_index=source_index,
                span=span,
                content_hash=sha256(span.encode("utf-8")).hexdigest(),
                score=score,
            ))

        selected: list[_EvidenceUnit] = []
        used_characters = 0
        per_source: Counter[int] = Counter()
        if plan.analysis.intent == "cause":
            causal_units = [
                unit for unit in ranked
                if any(
                    marker in normalize_search_text(unit.span).replace(" ", "")
                    for marker in (
                        "因为", "由于", "导致", "造成", "引发", "促成", "因素", "原因",
                    )
                )
            ]
            if causal_units:
                ranked = causal_units
        unit_limit = 8 if plan.answer_shape == "single_fact" else 16
        for unit in sorted(ranked, key=lambda item: (-item.score, item.source_index)):
            if len(selected) >= unit_limit:
                break
            if per_source[unit.source_index] >= 6:
                continue
            if selected and used_characters + len(unit.span) > 6_000:
                continue
            selected.append(unit)
            per_source[unit.source_index] += 1
            used_characters += len(unit.span)
        return tuple(selected)

    @staticmethod
    def _is_structural_noise(span: str, source: SourceItem) -> bool:
        normalized = normalize_search_text(span).replace(" ", "")
        if not normalized:
            return True
        title = normalize_search_text(source.title).replace(" ", "")
        if normalized == title and len(normalized) <= 80:
            return True
        keywords = source.metadata.get("keywords")
        if isinstance(keywords, list) and any(
            normalized == normalize_search_text(str(keyword)).replace(" ", "")
            for keyword in keywords
            if str(keyword).strip()
        ):
            return True
        return normalized in {"历史", "歷史", "目录", "目錄"}

    @staticmethod
    def _adjudication_prompt(
        question: str,
        plan: QueryPlan,
        sources: list[SourceItem],
        units: tuple[_EvidenceUnit, ...],
    ) -> str:
        contract = {
            "subject": plan.subject,
            "answer_shape": plan.answer_shape,
            "set_semantics": plan.set_semantics,
            "fields": [
                {
                    "field_id": field.field_id,
                    "question": field.question,
                    "relations": list(field.relations),
                }
                for field in plan.fields
            ],
        }
        evidence = "\n".join(
            f"[e{index}] 标题：{sources[unit.source_index].title or '未命名'}｜{unit.span}"
            for index, unit in enumerate(units, start=1)
        )
        return f"""你是证据裁决器，不回答问题。候选均来自知识库原文，代码会按编号取回原文。
严格按任务契约逐字段选择能够直接填写所求具体值的证据。模型负责判断对象身份、关系含义、答案值类型和事件结果是否与字段完全一致。
仅仅提到对象、关系词相同、属于同一篇长文、描述其他事件，或只给出背景和时间，都不是直接证据。询问原因时，候选中的因果结果必须就是字段所问事件；询问人物、地点、时间、数量、名称或列表时，候选必须实际给出对应类型的具体值。
每个字段最多选择 6 条。按支持强度从高到低，只输出“字段编号:证据编号”，例如 f1:e3,f1:e7；只有一个字段时也可简写为 e3,e7。没有任何直接证据只输出 NONE。不要解释，不要改写原文。

任务契约：{json.dumps(contract, ensure_ascii=False)}
问题：{question}
候选证据：
{evidence}
当前唯一决定：为任务契约中的每个字段选择直接证据编号。
选择："""

    @staticmethod
    def _parse_adjudication(
        raw: str,
        field_ids: set[str],
        unit_count: int,
    ) -> tuple[tuple[str, int], ...]:
        cleaned = re.sub(r"<think>.*?</think>", "", raw, flags=re.IGNORECASE | re.DOTALL)
        cleaned = re.sub(r"```(?:json)?", "", cleaned, flags=re.IGNORECASE).replace("```", "")
        first_line = next(
            (
                line.strip().lstrip(">").strip()
                for line in cleaned.splitlines()
                if line.strip() and line.strip() != ">"
            ),
            "",
        )
        if first_line.upper() in {"NONE", "[]"}:
            return ()
        if len(field_ids) == 1 and re.fullmatch(
            r"e[1-9]\d*(?:\s*[,，;；]\s*e[1-9]\d*)*",
            first_line,
            flags=re.IGNORECASE,
        ):
            field_id = next(iter(field_ids))
            return tuple(
                (field_id, int(unit_id))
                for unit_id in re.findall(
                    r"e([1-9]\d*)",
                    first_line,
                    flags=re.IGNORECASE,
                )
                if int(unit_id) <= unit_count
            )
        contract = r"(?:f[1-9]\d*\s*[:：]\s*e[1-9]\d*(?:\s*[,，;；]\s*)?)+"
        if not re.fullmatch(contract, first_line, flags=re.IGNORECASE):
            compact = re.search(
                r"((?:f[1-9]\d*\s*[:：]\s*e[1-9]\d*"
                r"|e[1-9]\d*)(?:\s*[,，;；]\s*(?:f[1-9]\d*\s*[:：]\s*)?e[1-9]\d*)*)",
                first_line,
                flags=re.IGNORECASE,
            )
            if compact is None:
                raise ValueError("adjudicator response does not match the contract")
            first_line = compact.group(1)
        output: list[tuple[str, int]] = []
        field_groups = re.findall(
            r"(f[1-9]\d*)\s*[:：]\s*"
            r"(e[1-9]\d*(?:\s*[,，;；]\s*e[1-9]\d*)*)",
            first_line,
            flags=re.IGNORECASE,
        )
        for field_id, evidence_ids in field_groups:
            normalized_field_id = field_id.lower()
            for unit_id in re.findall(r"e([1-9]\d*)", evidence_ids, flags=re.IGNORECASE):
                unit_index = int(unit_id)
                if (
                    normalized_field_id not in field_ids
                    or unit_index > unit_count
                    or (normalized_field_id, unit_index) in output
                ):
                    continue
                output.append((normalized_field_id, unit_index))
        if not output:
            raise ValueError("adjudicator selected no valid evidence ids")
        return tuple(output)

    async def _extract_source(
        self,
        question: str,
        plan: QueryPlan,
        source_index: int,
        source: SourceItem,
    ) -> tuple[tuple[EvidenceSpan, ...], dict[str, object]]:
        sentence_units = self._attention_units(plan, source)
        prompt = self._prompt(
            question,
            plan,
            source,
            sentence_units=sentence_units,
        )
        max_tokens = min(
            self.settings.evidence_extraction_max_tokens,
            160 if self.settings.semantic_pipeline_enabled else self.settings.evidence_extraction_max_tokens,
        )
        payload = {
            "contents": [prompt],
            "max_tokens": max_tokens,
            "temperature": 0.1,
            "top_k": 20,
            "top_p": 0.4,
            "alpha_presence": 0.0,
            "alpha_frequency": 0.0,
            "alpha_decay": 0.99,
            "stream": True,
            "password": self.settings.generation_password,
        }
        endpoint = f"{self.settings.generation_base_url.rstrip('/')}/chat/completions"
        async with httpx.AsyncClient(
            timeout=self.settings.evidence_extraction_timeout,
            transport=self.transport,
        ) as client:
            async with client.stream("POST", endpoint, json=payload) as response:
                response.raise_for_status()
                raw = await EvidenceAnswerGenerator._read_stream(
                    response,
                    total_timeout=self.settings.evidence_extraction_timeout,
                )
        candidates = self._parse(
            raw,
            plan,
            source_index,
            source,
            sentence_units=sentence_units,
            semantic_mode=self.settings.semantic_pipeline_enabled,
        )
        return candidates, {
            "stage": "resolver_map",
            "source_id": source.id,
            "source_index": source_index,
            "original_source_index": source_index,
            "source_text_sha256": sha256(source.snippet.encode("utf-8")).hexdigest(),
            "prompt": prompt,
            "raw_output": raw,
            "prompt_sha256": sha256(prompt.encode("utf-8")).hexdigest(),
            "raw_output_sha256": sha256(raw.encode("utf-8")).hexdigest(),
            "selected_count": len(candidates),
        }

    def _prompt(
        self,
        question: str,
        plan: QueryPlan,
        source: SourceItem,
        *,
        sentence_units: tuple[str, ...] | None = None,
    ) -> str:
        fields = [
            {
                "field_id": field.field_id,
                "question": field.question,
                "relations": list(field.relations),
            }
            for field in plan.fields
        ]
        units = sentence_units or self._attention_units(plan, source)
        text = "\n".join(
            f"[s{index}] {unit}"
            for index, unit in enumerate(units, start=1)
        )
        contract = {
            "subject": plan.subject,
            "answer_shape": plan.answer_shape,
            "set_semantics": plan.set_semantics,
            "fields": fields,
        }
        field_targets = "；".join(
            f"{field.field_id}：{field.question}"
            for field in plan.fields
        )
        return f"""你是证据抽取器，不回答问题，也不使用常识。只处理当前这一份资料。
任务契约：{json.dumps(contract, ensure_ascii=False)}
对每个字段查找能够直接支持“所求具体值”的最小编号句子。先根据字段问题判断所求值的类型，例如人物、地点、时间、数量、名称或列表；所选句子必须实际给出该类型的具体值。只出现关系词、讨论该关系、表达某人的观点，但没有给出字段所求具体值时，必须拒绝。
候选必须属于任务对象；同名异物、导航、分类、页眉页脚和仅仅提到关键词的背景文字都不要提取。
当问题包含“第一个、第一位、首位、最早”等序数关系时，所选句必须把该序数关系绑定到问题指定的范围；某个国家、朝代、组织或地区内部的“首位”不能替代更大范围的“第一位”。
问题未指定历史时期时，资料中“曾经、历代、过去”等历史陈述不能替代当前或一般事实；候选必须与问题的时间范围一致。
当 answer_shape=list 且 set_semantics=all 时，只选择明确构成所求集合的列表、表格行或连续枚举行；不要选择路线/过程叙述、历史讨论、举例、图片说明、分类文字，也不要把叙述中偶然出现的名称当成完整列表。列表跨多个连续编号句子时，选择该结构内所有直接承载项目的句子。
当字段询问原因、成因或为何发生时，只选择明确表达因果关系、成因条件或直接导火事件的句子；因果结果必须就是字段中询问的那个事件或结局，同一对象文档内其他事件的因果关系也必须拒绝。仅说明某事件是“转折点”、列出结局或给出发生时间，不能直接回答原因。
不要复制或改写正文，只输出“字段编号:句子编号”，例如 f1:s2。多条证据用逗号分隔，例如 f1:s2,f1:s3；没有直接证据只输出 NONE。不要解释。

问题：{question}
资料标题：{source.title}
编号句子：
{text}
当前唯一任务：为字段“{field_targets}”选择能直接填写具体答案的句子编号。选中的句子如果不能直接回答该字段，就必须输出空数组。
选择："""

    def _attention_window(self, plan: QueryPlan, source: SourceItem) -> str:
        return "\n".join(self._attention_units(plan, source))

    def _attention_units(
        self,
        plan: QueryPlan,
        source: SourceItem,
    ) -> tuple[str, ...]:
        limit = self.settings.evidence_extraction_max_source_characters
        all_units = [
            value.strip()
            for value in re.split(r"(?<=[。！？!?；;])|\n+", source.snippet)
            if value.strip()
        ]
        if len(source.snippet) <= limit and len(all_units) <= 6:
            return tuple(all_units)
        terms = {
            term
            for term in lexical_tokens(" ".join((
                plan.subject,
                *(field.question for field in plan.fields),
                *plan.relations,
            )))
            if len(term.strip()) >= 2
        }
        ranked: list[tuple[float, int, str]] = []
        normalized_subject = normalize_search_text(plan.subject).replace(" ", "")
        for index, unit in enumerate(all_units):
            normalized = normalize_search_text(unit).replace(" ", "")
            unit_terms = set(lexical_tokens(unit))
            score = float(len(terms & unit_terms))
            if normalized_subject and normalized_subject in normalized:
                score += 3.0
            score += sum(
                1.5
                for relation in plan.relations
                if normalize_search_text(relation).replace(" ", "") in normalized
            )
            ranked.append((score, index, unit))
        selected = sorted(
            sorted(ranked, key=lambda item: (-item[0], item[1]))[:8],
            key=lambda item: item[1],
        )
        output: list[str] = []
        used = 0
        for _, _, unit in selected:
            remaining = limit - used
            if remaining <= 0:
                break
            value = unit[:remaining]
            output.append(value)
            used += len(value) + 1
        return tuple(output)

    @staticmethod
    def _source_contains_subject(plan: QueryPlan, source: SourceItem) -> bool:
        subject_value = plan.subject or "和".join(plan.analysis.subjects)
        normalized_subject = _normalize_identity(subject_value)
        normalized_title = _normalize_identity(source.title)
        subject_parts = [
            part for part in _SUBJECT_SEPARATORS.split(normalized_subject)
            if len(part) >= 2
        ]
        subject_variants = tuple(dict.fromkeys(
            variant
            for value in (normalized_subject, *subject_parts)
            for variant in _identity_variants(value)
        ))
        normalized_relations = {
            normalize_search_text(relation).replace(" ", "").replace("的", "")
            for relation in _relation_variants(plan.relations)
            if len(relation.strip()) >= 2
        }
        aliases = source.metadata.get("aliases")
        title_values = {normalized_title}
        if isinstance(aliases, list):
            title_values.update(
                _normalize_identity(str(alias))
                for alias in aliases
                if str(alias).strip()
            )
        title_variants = tuple(dict.fromkeys(
            variant for value in title_values for variant in _identity_variants(value)
        ))
        normalized_body = _normalize_identity(source.snippet)
        title_match = any(
            variant == title
            or (len(title) >= 3 and variant.endswith(title))
            or title.endswith(f"·{variant}")
            or any(
                title == relation
                or title.startswith(f"{variant}{relation}")
                for relation in normalized_relations
            )
            for variant in subject_variants
            for title in title_variants
        )
        relation_title_match = any(
            title == relation or title.endswith(f"·{relation}")
            for title in title_values
            for relation in normalized_relations
        )
        body_subject_match = any(
            variant and variant in normalized_body for variant in subject_variants
        )
        body_relation_match = any(
            relation in normalized_body for relation in normalized_relations
        )
        body_match = body_subject_match and body_relation_match
        transit_match = re.fullmatch(
            r"(?P<network>[\u3400-\u9fff]{2,20}?地铁)(?P<line>\d+号线)",
            normalized_subject,
        )
        transit_companion_match = bool(
            plan.answer_shape == "list"
            and transit_match
            and normalized_title == f"{transit_match.group('network')}车站列表"
            and transit_match.group("line") in normalized_body
        )
        if plan.answer_shape == "single_fact" and plan.analysis.intent != "comparison":
            return len(normalized_subject) >= 2 and (
                body_match
                or (title_match and (body_subject_match or body_relation_match))
            )
        return len(normalized_subject) >= 2 and (
            title_match or relation_title_match or body_match or transit_companion_match
        )

    @staticmethod
    def _parse(
        raw: str,
        plan: QueryPlan,
        source_index: int,
        source: SourceItem,
        *,
        sentence_units: tuple[str, ...] | None = None,
        semantic_mode: bool = False,
    ) -> tuple[EvidenceSpan, ...]:
        if (
            not semantic_mode
            and not LanguageModelEvidenceExtractor._source_contains_subject(plan, source)
        ):
            return ()
        cleaned = re.sub(r"<think>.*?</think>", "", raw, flags=re.IGNORECASE | re.DOTALL)
        cleaned = re.sub(r"```(?:json)?", "", cleaned, flags=re.IGNORECASE).replace("```", "")
        start = cleaned.find("{")
        end = cleaned.rfind("}")
        field_ids = {field.field_id for field in plan.fields}
        if start >= 0 and end > start:
            try:
                payload = json.loads(cleaned[start : end + 1])
            except json.JSONDecodeError as error:
                raise ValueError("extractor response contains invalid JSON") from error
            if not isinstance(payload, dict) or "candidates" not in payload:
                raise ValueError("extractor response must contain candidates")
            values = payload["candidates"]
            if not isinstance(values, list):
                raise ValueError("extractor candidates must be a list")
        else:
            values = LanguageModelEvidenceExtractor._parse_compact_candidates(
                cleaned,
                field_ids,
            )
        normalized_title = normalize_search_text(source.title).replace(" ", "")
        contract_text = normalize_search_text(" ".join((
            plan.subject,
            *(field.question for field in plan.fields),
        ))).replace(" ", "")
        normalized_relations = {
            normalize_search_text(relation).replace(" ", "")
            for relation in _relation_variants(plan.relations)
            if len(relation.replace(" ", "")) >= 2
        }
        explicit_relations = {
            normalize_search_text(relation).replace(" ", "")
            for relation in _relation_variants(plan.relations)
            if len(relation.replace(" ", "")) >= 4
        }
        requested_relations = {
            normalize_search_text(relation).replace(" ", "")
            for relation in _relation_variants(plan.relations)
            if len(relation.replace(" ", "")) >= 2
        }
        summary_markers = (
            "结局", "結局", "结尾", "結尾", "终结", "終結", "结束", "結束",
            "最终", "最終", "最后", "最後", "结果", "結果", "归一", "歸一",
            "一统", "一統", "统一", "統一", "灭亡", "滅亡", "完成",
        )
        candidates: list[EvidenceSpan] = []
        for item in values[:32]:
            if not isinstance(item, dict) or "field_id" not in item:
                continue
            field_id = str(item["field_id"]).strip()
            span = ""
            selected_by_id = False
            if set(item) == {"field_id", "sentence_id"} and sentence_units is not None:
                sentence_match = re.fullmatch(r"s([1-9]\d*)", str(item["sentence_id"]).strip())
                if sentence_match:
                    sentence_index = int(sentence_match.group(1)) - 1
                    if sentence_index < len(sentence_units):
                        span = sentence_units[sentence_index]
                        selected_by_id = True
            elif set(item) == {"field_id", "span"}:
                span = str(item["span"]).strip()
            if field_id not in field_ids or not span:
                continue
            if len(span) > 2_000 or span not in source.snippet:
                continue
            if semantic_mode:
                if LanguageModelEvidenceExtractor._is_structural_noise(span, source):
                    continue
                candidates.append(EvidenceSpan(
                    field_id=field_id,
                    source_index=source_index,
                    span=span,
                    content_hash=sha256(span.encode("utf-8")).hexdigest(),
                ))
                continue
            normalized_span = normalize_search_text(span).replace(" ", "")
            if normalized_span == normalized_title or (
                len(normalized_span) >= 4 and normalized_span in contract_text
            ):
                continue
            if (
                plan.analysis.intent == "agent"
                and len(normalized_span) <= 16
                and not any(marker in normalized_span for marker in (
                    "是", "为", "由", "被", "害死", "杀害", "打死", "处死", "发起",
                ))
                and normalize_search_text(plan.subject).replace(" ", "")
                not in normalized_span
            ):
                continue
            if (
                selected_by_id
                and plan.answer_shape == "single_fact"
                and normalized_relations
                and not any(
                    relation in normalized_span
                    for relation in normalized_relations
                )
            ):
                continue
            if not selected_by_id and explicit_relations and not any(
                relation in normalized_span
                for relation in explicit_relations
            ):
                continue
            if (
                plan.answer_shape in {"summary", "narrative"}
                and not any(
                    relation in normalized_span
                    for relation in requested_relations
                )
                and not any(marker in normalized_span for marker in summary_markers)
            ):
                continue
            candidates.append(EvidenceSpan(
                field_id=field_id,
                source_index=source_index,
                span=span,
                content_hash=sha256(span.encode("utf-8")).hexdigest(),
            ))
        if (
            not semantic_mode
            and not candidates
            and plan.answer_shape == "list"
            and sentence_units
        ):
            subject_terms = {
                normalize_search_text(value).replace(" ", "")
                for value in (plan.subject, source.title)
                if value.strip()
            }
            relation_terms = {
                relation
                for relation in normalized_relations
                if len(relation) >= 2
            }
            for unit in sentence_units:
                normalized_unit = normalize_search_text(unit).replace(" ", "")
                if not any(term in normalized_unit for term in subject_terms):
                    continue
                if not any(relation in normalized_unit for relation in relation_terms):
                    continue
                candidates.append(EvidenceSpan(
                    field_id=next(iter(field_ids)),
                    source_index=source_index,
                    span=unit,
                    content_hash=sha256(unit.encode("utf-8")).hexdigest(),
                ))
                break
        return tuple(candidates)

    @staticmethod
    def _parse_compact_candidates(
        raw: str,
        field_ids: set[str],
    ) -> list[dict[str, str]]:
        cleaned = raw.strip().lstrip(">").strip()
        cleaned = next(
            (line.strip() for line in cleaned.splitlines() if line.strip()),
            "",
        )
        if cleaned.upper() in {"NONE", "[]"}:
            return []
        shared_field = re.fullmatch(
            r"(f[1-9]\d*)\s*[:：]\s*\[?\s*"
            r"(s[1-9]\d*(?:\s*[,，]\s*s[1-9]\d*)*)\s*\]?",
            cleaned,
            flags=re.IGNORECASE,
        )
        if shared_field is not None:
            field_id = shared_field.group(1).lower()
            if field_id not in field_ids:
                return []
            return [
                {"field_id": field_id, "sentence_id": sentence_id.lower()}
                for sentence_id in re.findall(
                    r"s[1-9]\d*",
                    shared_field.group(2),
                    flags=re.IGNORECASE,
                )
            ]
        explicit_contract = (
            r"(?:f[1-9]\d*\s*[:：]\s*\[?s[1-9]\d*\]?\s*[,，;；]?\s*)+"
        )
        explicit = (
            re.findall(
                r"\b(f[1-9]\d*)\s*[:：]\s*\[?(s[1-9]\d*)\]?",
                cleaned,
                flags=re.IGNORECASE,
            )
            if re.fullmatch(explicit_contract, cleaned, flags=re.IGNORECASE)
            else []
        )
        if explicit:
            return [
                {
                    "field_id": field_id.lower(),
                    "sentence_id": sentence_id.lower(),
                }
                for field_id, sentence_id in explicit
                if field_id.lower() in field_ids
            ]
        if len(field_ids) == 1 and re.fullmatch(
            r"(?:\[?s[1-9]\d*\]?\s*[,，;；]?\s*)+",
            cleaned,
            flags=re.IGNORECASE,
        ):
            field_id = next(iter(field_ids))
            return [
                {"field_id": field_id, "sentence_id": sentence_id.lower()}
                for sentence_id in re.findall(r"s[1-9]\d*", cleaned, flags=re.IGNORECASE)
            ]
        raise ValueError("extractor response does not match a supported output contract")
