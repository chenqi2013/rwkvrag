import asyncio
import hashlib
import json
import os
from pathlib import Path
import shlex
import sys
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
SOURCE = OUT.parent / 'source-api-v1'
sys.path.insert(0, str(SOURCE / 'src'))
from llamaindex_retrieval.config import Settings
from llamaindex_retrieval.rwkv_pipeline import planner_prompt, parse_plan, structured_body
from llamaindex_retrieval.rwkvos_batch import RwkvosBatchClient


def save(name, value):
    target = OUT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def verify_source():
    for name, spec in json.loads((SOURCE / 'SOURCE-MANIFEST.json').read_text())['files'].items():
        raw = (SOURCE / name).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == spec['sha256'] and len(raw) == spec['bytes'], name


async def main():
    verify_source()
    cases = json.loads((OUT / 'cases.json').read_text())
    settings = Settings(_env_file=None, native_plan_protocol='queries_fields', native_max_queries=6)
    requests = [{**case, 'messages': [{'role': 'user', 'content': case['candidate_content']}]} for case in cases]
    save('requests.json', requests)
    save('STARTED.json', {'at': datetime.now(timezone.utc).isoformat(), 'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'cases_sha256': hashlib.sha256((OUT / 'cases.json').read_bytes()).hexdigest(), 'plan_sha256': hashlib.sha256((OUT / 'PLAN.json').read_bytes()).hexdigest()})
    attachment = Path('/mnt/c/Users/chase/.codex/attachments/5a056a59-9300-4f5d-aace-62d0a1fb046e/pasted-text.txt')
    parts = shlex.split(attachment.read_text().replace('\\\n', ''))
    headers = {}
    for i, value in enumerate(parts):
        if value in ('--header', '-H'):
            key, content = parts[i + 1].split(':', 1)
            if key.lower().startswith('cf-access-'):
                headers[key] = content.strip()

    def recorder(event, record):
        save(f"batch-http/{record['batch_id']}.{event}.json", record)

    client = RwkvosBatchClient(base_url='https://api-3b.rwkvos.com/v1', model='rwkv7-g1j-2.9b-20260831-ctx16384', headers=headers, timeout_seconds=600, context_window_tokens=16384, max_concurrency=32, batch_size=8, batch_wait_ms=5, stop_tokens=[0], recorder=recorder)

    async def call(case):
        result = await client.complete(case['messages'], **case['parameters'])
        record = {'case_id': case['case_id'], 'raw_text': result.raw_text, 'status': result.status, 'trace': result.trace}
        try:
            record['parsed_plan'] = parse_plan(structured_body(result), settings)
            record['format_pass'] = True
        except (ValueError, TypeError) as error:
            record['parse_error'] = str(error)
            record['format_pass'] = False
        save(f"completed/{case['case_id']}.json", record)
        return record

    results = []
    try:
        for offset in range(0, len(requests), 4):
            results.extend(await asyncio.gather(*(call(case) for case in requests[offset:offset + 4])))
    finally:
        await client.aclose()
    verify_source()
    summary = {'at': datetime.now(timezone.utc).isoformat(), 'cases': len(results), 'format_pass': sum(r['format_pass'] for r in results), 'semantic_scope_reviewed': False, 'automatic_retries': 0, 'source_unchanged': True}
    save('COMPLETED.json', summary)
    print(json.dumps(summary), flush=True)


asyncio.run(main())
