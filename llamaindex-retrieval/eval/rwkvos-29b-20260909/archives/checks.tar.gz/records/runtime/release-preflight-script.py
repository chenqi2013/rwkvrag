from pathlib import Path
import subprocess,json,datetime,hashlib
r={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'operation':'read_only_release_preflight','inference_requests':0,'index_api_requests':0}
units=['rwkvrag-intent-model-20260908.service','rwkvrag-bm250820-opensearch-20260908.service','rwkvrag-coverage-model-20260907.service','rwkvrag-bge-reranker-20260907.service','rwkv-lh-current-zero-executor-20260907.service']
for u in units:
 text=subprocess.run(['systemctl','--user','show',u,'--property=Id,Description,ActiveState,SubState,MainPID,ControlGroup,FragmentPath,ExecStart,WorkingDirectory,Restart,KillMode'],capture_output=True,text=True,check=True).stdout
 row=dict(line.split('=',1) for line in text.splitlines() if '=' in line)
 pid=row['MainPID'];p=Path('/proc')/pid
 if p.exists() and int(pid):
  row['cmdline']=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode();row['cwd']=str((p/'cwd').resolve());row['cgroup']=(p/'cgroup').read_text()
 r.setdefault('units',{})[u]=row
r['gpu_compute']=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory,gpu_uuid','--format=csv,noheader'],capture_output=True,text=True,check=True).stdout
r['gpu_totals']=subprocess.run(['nvidia-smi','--query-gpu=index,uuid,name,memory.total,memory.used,utilization.gpu','--format=csv,noheader'],capture_output=True,text=True,check=True).stdout
r['relevant_connections']=[l for l in subprocess.run(['ss','-tnp'],capture_output=True,text=True,check=True).stdout.splitlines() if any(':'+str(p)+' ' in l for p in [18421,18438,18439])]
r['relevant_listeners']=[l for l in subprocess.run(['ss','-ltnp'],capture_output=True,text=True,check=True).stdout.splitlines() if any(':'+str(p)+' ' in l for p in [18421,18438,18439])]
r['gpu_process_identity']=[]
for pid in [1486361,1665886,1726834,3979071,1505676,1596213]:
 p=Path('/proc')/str(pid)
 r['gpu_process_identity'].append({'pid':pid,'cmdline':(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(),'cgroup':(p/'cgroup').read_text(),'cwd':str((p/'cwd').resolve())})
p=Path('/home/chase/rwkvrag-bm-29b-20260908/runtime/CHECKPOINT-IDENTITY.json')
r['unserved_29b_checkpoint']=json.loads(p.read_text())
print(json.dumps(r,ensure_ascii=False,indent=2))
