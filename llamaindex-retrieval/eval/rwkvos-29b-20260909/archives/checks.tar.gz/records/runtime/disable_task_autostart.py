NAMES = ['rwkvrag-baseline-local-20260907.service', 'rwkvrag-baseline-mongo-20260907.service', 'rwkvrag-baseline-qdrant-20260907.service', 'rwkvrag-baseline-upstream-20260907.service', 'rwkvrag-bge-reranker-20260907.service', 'rwkvrag-bm250820-opensearch-20260908.service', 'rwkvrag-context-20260907.service', 'rwkvrag-context-improvement-112-20260907.service', 'rwkvrag-context-improvement-3000-20260907.service', 'rwkvrag-context-improvement-audit-20260907.service', 'rwkvrag-context-improvement-expanded-20260907.service', 'rwkvrag-context-improvement-original-20260907.service', 'rwkvrag-context-improvement-rerank-112-20260907.service', 'rwkvrag-context-improvement-rerank-3000-20260907.service', 'rwkvrag-context-improvement-rerank-expanded-20260907.service', 'rwkvrag-context-improvement-rerank-original-20260907.service', 'rwkvrag-context-large-20260907.service', 'rwkvrag-coverage-expanded-20260907.service', 'rwkvrag-coverage-model-20260907.service', 'rwkvrag-coverage-model-audit-20260907.service', 'rwkvrag-coverage-original-20260907.service', 'rwkvrag-coverage-v2-expanded-20260907.service', 'rwkvrag-coverage-v2-original-20260907.service', 'rwkvrag-expanded-old-patch-20260907.service', 'rwkvrag-expanded-repaired-20260907.service', 'rwkvrag-intent-model-20260908.service', 'rwkvrag-repair-phase1-probe-20260907.service', 'rwkvrag-repair-phase1-retrieval-20260907.service', 'rwkvrag-repair-phase2-retrieval-20260907.service', 'rwkvrag-wiki-api-v7-20260908.service', 'rwkvrag-wiki-evidence-budget-api-budget-4096-20260908.service', 'rwkvrag-wiki-evidence-budget-api-combined-4096-zero-20260908.service', 'rwkvrag-wiki-evidence-budget-api-selection-zero-20260908.service', 'rwkvrag-wiki-iteration-api-candidate-a-20260908.service', 'rwkvrag-wiki-iteration-api-candidate-b-20260908.service', 'rwkvrag-wiki-iteration-api-candidate-c-20260908.service', 'rwkvrag-wiki-iteration-api-default-fixed-20260908.service']
from pathlib import Path
import subprocess,json,datetime,hashlib
name='rwkvrag-bge-reranker-20260907.service'
link=Path('/home/chase/.config/systemd/user')/name
source=Path('/home/chase/rwkvrag-context-improvement-20260907/reranker')/name
assert link.is_symlink() and link.resolve()==source
original=source.read_bytes();digest=hashlib.sha256(original).hexdigest()
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'operation':'disable linked task BGE registration only','unit':name,'registration':str(link),'preserved_service_file':str(source),'source_sha256_before':digest,'model_requests':0,'index_queries':0,'mask_used':False,'before_target_dependencies':[]}
p=subprocess.run(['systemctl','--user','disable',name],capture_output=True,text=True)
r['disable']={'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
assert p.returncode==0,r
r['registration_removed']=not link.exists() and not link.is_symlink();r['source_sha256_after']=hashlib.sha256(source.read_bytes()).hexdigest();assert r['source_sha256_after']==digest
r['units_after']={}
for u in NAMES:
 p=subprocess.run(['systemctl','--user','show',u,'--property=LoadState,UnitFileState,Transient,ActiveState,SubState,MainPID,WantedBy,RequiredBy,TriggeredBy'],capture_output=True,text=True)
 row=dict(l.split('=',1) for l in p.stdout.splitlines() if '=' in l)
 r['units_after'][u]=row
r['remaining_task_autostart_links']=[]
for directory in ['/home/chase/.config/systemd/user','/run/user/1001/systemd/user','/etc/systemd/user']:
 root=Path(directory)
 if root.exists():
  for p in root.rglob('*'):
   if p.is_symlink() and p.parent.name.endswith(('.wants','.requires')) and (p.name in NAMES or Path(str(p.readlink())).name in NAMES):r['remaining_task_autostart_links'].append(str(p))
r['all_target_pids_zero']=all(v.get('MainPID','0')=='0' for v in r['units_after'].values())
r['auto_enabled_units']=[u for u,v in r['units_after'].items() if v.get('UnitFileState') in ['enabled','enabled-runtime','linked','linked-runtime'] or v.get('WantedBy') or v.get('RequiredBy') or v.get('TriggeredBy')]
r['status']='PASS' if r['registration_removed'] and not r['remaining_task_autostart_links'] and r['all_target_pids_zero'] and not r['auto_enabled_units'] else 'FAIL'
print(json.dumps(r,ensure_ascii=False,indent=2))
