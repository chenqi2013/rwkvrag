from pathlib import Path
import subprocess,json,datetime,re,collections,hashlib
r={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'read_only':True,'inference_requests':0,'index_queries':0,'units':{}}
run=lambda args:subprocess.run(args,capture_output=True,text=True,check=True).stdout
lines=run(['systemctl','--user','list-units','--all','--plain','--no-pager','--no-legend']).splitlines()
units=[line.split()[0] for line in lines if line.split() and line.split()[0].startswith('rwkvrag-')]
for u in units:
 text=run(['systemctl','--user','show',u,'--property=Id,Description,ActiveState,SubState,MainPID,ControlGroup,FragmentPath,ExecStart,WorkingDirectory,Restart,KillMode'])
 row=dict(line.split('=',1) for line in text.splitlines() if '=' in line)
 pid=int(row['MainPID'])
 if not pid: continue
 p=Path('/proc')/str(pid)
 row['cmdline']=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode();row['cwd']=str((p/'cwd').resolve());row['cgroup']=(p/'cgroup').read_text()
 cg=Path('/sys/fs/cgroup')/row['ControlGroup'].lstrip('/')
 row['cgroup_processes']=[int(x) for x in (cg/'cgroup.procs').read_text().split()]
 row['task_ownership_verified']='/home/chase/rwkvrag-' in row['ExecStart']
 r['units'][u]=row
p=Path('/proc/1505676');r['embedding']={'pid':1505676,'cmdline':(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(),'cwd':str((p/'cwd').resolve()),'cgroup':(p/'cgroup').read_text(),'stat':(p/'stat').read_text()}
r['listeners']=run(['ss','-ltnp']);r['connections']=run(['ss','-tnp']);r['gpu_compute']=run(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory,gpu_uuid','--format=csv,noheader']);r['gpu_totals']=run(['nvidia-smi','--query-gpu=index,uuid,name,memory.total,memory.used,utilization.gpu','--format=csv,noheader'])
f=Path('/home/chase/rwkvrag-context-improvement-20260907/reranker/requests.jsonl')
counts=collections.Counter();active=set();last=None
with f.open() as inp:
 for line in inp:
  rec=json.loads(line);event=rec.get('event');rid=rec.get('request_id');counts[event]+=1
  if event=='started':active.add(rid)
  elif event=='completed':active.discard(rid)
  last={k:v for k,v in rec.items() if k in ['event','request_id','timestamp','at','completed_at','started_at']}
r['bge_wire']={'path':str(f),'bytes':f.stat().st_size,'counts':dict(counts),'uncompleted_request_ids':sorted(active),'last_event':last}
r['embedding_directory']=[{'name':p.name,'bytes':p.stat().st_size} for p in Path('/home/chase/rwkvrag-baseline-20260907/embedding').iterdir() if p.is_file()]
print(json.dumps(r,ensure_ascii=False,indent=2))
