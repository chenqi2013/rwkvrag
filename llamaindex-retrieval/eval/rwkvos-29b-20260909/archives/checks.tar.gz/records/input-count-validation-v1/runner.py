import asyncio
import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shlex
import sys

OUT = Path(__file__).resolve().parent
SOURCE = OUT.parent / 'source-publication-v1'
sys.path.insert(0, str(SOURCE / 'src'))
from llamaindex_retrieval.rwkvos_batch import RwkvosBatchClient, render_batch_prompt
from llamaindex_retrieval.batch_receipts import summarize_batch_http, summarize_token_http


def save(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def verify_source():
    for name, spec in json.loads((SOURCE / 'SOURCE-MANIFEST.json').read_text())['files'].items():
        raw = (SOURCE / name).read_bytes()
        assert len(raw) == spec['bytes'] and hashlib.sha256(raw).hexdigest() == spec['sha256'], name


async def main():
    verify_source()
    cases = json.loads((OUT / 'cases.json').read_text())
    for case in cases:
        prompt, _ = render_batch_prompt(case['messages'], '<think></think')
        assert hashlib.sha256(prompt.encode()).hexdigest() == case['expected_prompt_sha256']
    save('STARTED.json', {'at': datetime.now(timezone.utc).isoformat(), 'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'cases_sha256': hashlib.sha256((OUT / 'cases.json').read_bytes()).hexdigest(), 'plan_sha256': hashlib.sha256((OUT / 'PLAN.json').read_bytes()).hexdigest(), 'source_manifest_sha256': hashlib.sha256((SOURCE / 'SOURCE-MANIFEST.json').read_bytes()).hexdigest()})
    attachment = Path('/mnt/c/Users/chase/.codex/attachments/5a056a59-9300-4f5d-aace-62d0a1fb046e/pasted-text.txt')
    parts = shlex.split(attachment.read_text().replace('\\\n', ''))
    headers = {}
    for i, value in enumerate(parts):
        if value in ('--header', '-H'):
            key, content = parts[i + 1].split(':', 1)
            if key.lower().startswith('cf-access-'):
                headers[key] = content.strip()

    def recorder(event, record):
        is_count = event.startswith('token_count_')
        folder, ident = ('token-http', record['count_id']) if is_count else ('batch-http', record['batch_id'])
        save(f'{folder}/{ident}.{event}.json', record)

    traces, results = [], []
    for case in cases:
        async with RwkvosBatchClient(base_url='https://api-3b.rwkvos.com/v1', model='rwkv7-g1j-2.9b-20260831-ctx16384', headers=headers, timeout_seconds=600, max_concurrency=32, batch_size=8, stop_tokens=[0], recorder=recorder, count_input_tokens=True, input_token_limit=case['input_token_limit']) as client:
            result = await client.complete(case['messages'], assistant_prefill='<think></think', stage='writer', max_tokens=2048, evidence_ids=case['evidence_ids'])
        save(f"completed/{case['id']}.json", {'id': case['id'], 'expected_status': case['expected_status'], 'status': result.status, 'raw_text': result.raw_text, 'trace': result.trace})
        traces.append(result.trace)
        budget = result.trace['budget']
        results.append({'id': case['id'], 'status': result.status, 'status_as_planned': result.status == case['expected_status'], 'input_tokens': budget.get('input_tokens'), 'prompt_identity_verified': budget.get('counted_prompt_sha256') == case['expected_prompt_sha256'], 'completion_attempted': result.trace['completion_attempted'], 'application_policy_fits': budget.get('application_policy_fits')})
    verify_source()
    batch = summarize_batch_http(OUT / 'batch-http', traces)
    counts = summarize_token_http(OUT / 'token-http', traces)
    raw_bytes_valid = True
    for directory in ['batch-http', 'token-http']:
        for path in (OUT / directory).glob('*completed.json'):
            record = json.loads(path.read_text())
            for kind in ['request', 'response']:
                raw = base64.b64decode(record[kind + '_body_base64'])
                raw_bytes_valid &= hashlib.sha256(raw).hexdigest() == record[kind + '_body_sha256']
            raw_bytes_valid &= json.loads(base64.b64decode(record['request_body_base64'])) == record['payload']
            if record.get('response_json') is not None:
                raw_bytes_valid &= json.loads(base64.b64decode(record['response_body_base64'])) == record['response_json']
    valid = all(r['status_as_planned'] and r['prompt_identity_verified'] for r in results) and batch['http_requests'] == 1 and counts['http_requests'] == 3 and raw_bytes_valid and all(not r['completion_attempted'] for r in results[1:])
    summary = {'at': datetime.now(timezone.utc).isoformat(), 'results': results, 'batch_http': batch, 'token_http': counts, 'raw_bytes_verified': raw_bytes_valid, 'source_unchanged': True, 'validation_pass': valid, 'semantic_quality_scored': False, 'automatic_retries': 0}
    save('COMPLETED.json', summary)
    print(json.dumps({'validation_pass': valid, 'results': results, 'generation_http': batch['http_requests'], 'count_http': counts['http_requests']}), flush=True)
    if not valid:
        raise SystemExit(1)


asyncio.run(main())
