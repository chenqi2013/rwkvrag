# 外部 G1j 2.9B API / state 合同调查

本轮确认外部 API 自报模型 `rwkv7-g1j-2.9b-20260831-ctx16384`、API 1.3、engine albatross-1.3.0。其原始 batch 接口可接现有 RAG，但结束原因、上下文预算和 state 类型须分别记录。提供方实际权重 SHA 与部署源码 revision 未公开，不能把上游源码一致性写成部署身份认证。

本调查仅新增 **7 次 HTTP：1 次输出 1 token 的边界生成、6 次状态/计数请求**，无重试、无 state 上传、无训练、无 rwkv-8222 访问。先前根线程的模型/普通生成探针另存于 `../external-api-probe`，不混入本次计数。认证值仅由附件在运行时解析，没有写入目录或源码。语义问答与长文能力未在这些探针中评分。

## 可直接实现的接口

`POST /v1/batch/completions` 接受 `contents: list[str]`，每项是最终完整原始 prompt；`model` 为兼容/标识字段，单模型服务中不能靠它切权重。普通请求显式冻结 `max_tokens, temperature, top_k, top_p, alpha_presence, alpha_frequency, alpha_decay, stop_tokens, chunk_size, stream`。temperature 最小 .001；top_p=0 在上游会转为 top_k=1。`chunk_size` 是生成文本输出刷新的 token 频率，不是输入分块大小。不同 sampling/state 参数不能合并到一个 batch。

响应 `object="chat.completion"`，每项 `choices[i].index` 对应原 contents 位置，文本在 `choices[i].message.content`。严格验证数量、唯一 index 集合与 model，任何错位不能补齐或顺序猜配。`state_id` 为整个 batch 共用的初始 state，各 slot 使用独立副本；零 state 应省略，而非悄悄复用上一次 state。

上游默认 stop_tokens 为 `[0,261,24281]`。该词表中 261 是连续两个换行，24281 是 `User`，0 是词表外特殊 EOS；`✿` 为 10060。默认 stop 可能终止正常多段回答或正文中的 User，因此必须将实际 stop 配置作为实验变量记录。此表来自冻结官方词表，未声称远端词表 SHA 已认证。[参数解析](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_api_service.cpp#L538)、[batch 路由](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_api_service.cpp#L1189)、[词表](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_vocab_v20230424.txt)。

## finish_reason 不能证明自然完成

上游 `build_choices` 对所有非流式 batch 结果无条件写 `finish_reason="stop"`；单项 chat 的 `build_openai_response` 同样硬编码 stop。因此改走单项 chat 不能修复该问题；没有找到 `/v1/completions` 路由。`completion:true` 能力标志不等于存在那个 URL。[构建 choices](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_api_service.cpp#L637)、[chat response](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_api_service.cpp#L805)。

本次唯一生成将 `max_tokens=1`、`stop_tokens=[]`，要求输出多个词，实际仅返回一个换行。输出原样计数为 1，响应仍为 stop，直接证明预算耗尽也报告 stop。完整 started/completed 收据见 `finish-boundary-*`；188 字节响应 SHA 为 `a3b865212252fb08eb1eba2eabb7dea882d49565706d526f94ee2f3798d75ed2`。`finish-boundary-response.bin` 从解析对象机械恢复，且与调用时原始 SHA/字节数完全相等；恢复过程没有再次发请求。

`metrics/report_metrics/include_metrics` 只打开共享 RequestRegistry 的计数统计，batch 响应仍不返回 usage 或终止原因。GET status 在探针后显示的最近请求并不是本次 max1 请求，所以它不能绑定成该调用的统计。单项 chat usage 由完成文本重新 tokenize 得到，仍不是逐步生成 token 计数。没有找到 `return_usage` 或 `return_stats` 可解决这一缺口的实现。[统计选项](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_api_service.cpp#L568)、[batch 非流式返回](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_api_service.cpp#L1280)、[公开 CUDA 文档](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/rwkv_lightning_api_doc.md#L1038)。

客户端保留 provider_finish_reason；将 termination 及真实 usage 标为 unknown，termination_verified=false。结构完整的 JSON 可单独通过格式规则，但不能据 stop 宣称自然完成。原始输出与错误不修改；计数达到输出上限可标记风险，低于上限也不能倒推出 EOS。

## 输入计数、模板与超长输入

准确单项计数请求：`POST /v1/tokens/count {"text": 完整原始prompt}`，返回 `{"tokens": 整数}`，无 token IDs。`contents` 数组只将所有项无分隔拼接后得到一个总数，不能做逐 slot 预算；`messages` 会加 chat 模板，也不能替代 raw batch 的完整字符串。上游 count_tokens 与 encode_prompt 都直接调用同一个 tokenizer.encode；raw batch 不加 BOS、不 strip，也不会自动应用 Assistant/think 模板。[计数路由](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_api_service.cpp#L1152)、[原始编码](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_inference_engine.cpp#L237)、[计数实现](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_inference_engine.cpp#L727)。

官方原生 chat 是 System/User/Assistant，消息间双换行，尾部 `Assistant: `。free 为 `<think`，fast 为 `<think></think`，两者末尾均未包含 `>`。已有外部成功探针则发送完整闭合 `<think></think>`，属于明确的 raw prompt 选择，不能与原生 chat 或旧 vLLM 的 Bot/flower 模板混称。两种路径都应保存最终 prompt bytes。[模板构造](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_inference_engine.cpp#L680)。

冻结词表 SHA `e6dee3d4e31b4d5c40ac99508ac6c701ceef4bed681bf2167ce9a908552bca89` 的离线 UTF-8 byte trie，与四个实际观测计数 0/12/11/1 全一致；详见 `TOKENIZER-CROSSCHECK.json`。这支持低成本离线预估，但不是远端全词表证明，更不是 single-BOS 认证。

**没有发现 16384 总长硬拒绝或静默裁剪。**上游 encode_prompt 仅拒绝空输入；prefill 循环直到全部原始 tokens 被处理。模型名 ctx16384 不能作为 provider 硬上限。实际部署可能另有 HTTP body、超时、资源限制，且超训练长度的事实保持能力未验证。应用可定义自己的测试/资源预算策略，但不能将其写成服务器硬限制。

实际 status 的 `prefill_chunk_size=128` 属于服务内部输入分片参数。每片持续更新同一个 GenerationState；较短样本退出后，剩余子批次先复制原 state，再前向并复制回去，不会重置。这解决计算分片，不保证任意长文本的信息保持或答案质量。[连续分片实现](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_inference_engine.cpp#L275)。

## 上传 state 与完整会话状态分别处理

`POST /v1/state/upload` 是 multipart 单文件（示例字段 file），最大 512MiB，需 PyTorch zip `.pth`。响应含 state_id/filename/size_bytes/tensor_count/created。上传阶段仅确认存在 time_state 命名张量；真正生成加载时才校验全部 layer、shape、dtype，因此 upload 200 不等于与当前模型兼容。过期/不存在 state_id 返回 400，不应静默退回零 state。[上传路由](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_api_service.cpp#L419)、[上传仓库](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_uploaded_state_store.cpp#L16)。

G1j 2.9B 的可训练导出应为 32 个 `blocks.N.att.time_state`，每个 `[40,64,64]`，BF16 或 FP32，分别约 10MiB/20MiB tensor payload。文件语义轴序为 `[H,V,K]`，CUDA loader 内部转为 `[H,K,V]` 一次，不应在 PEFT canonical 导出后又人为预转置。API 未绑定 checkpoint SHA，仍需在客户端记录训练基座权重和导出约定。[加载/检查/转置](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv7_fast_v4.cu#L2337)。

上传仅初始化 WKV time_state。create_state 的 shift 与 elapsed 仍为零，因而它不是完整对话状态恢复。完整 GenerationState 还包含 shift（attention/FFN 前一 token 状态）和 elapsed。[新状态初始化](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv7_fast_v4.cu#L2307)、[结构定义](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/include/rwkv_server_backend.hpp#L46)。

另有 `/state/chat/completions`：必须有 session_id，contents 恰好一项；无显式 state_id 时读会话缓存，有 state_id 时优先重建初态，完成后写回该 session。缓存保存 shift/WKV/elapsed，可在 GPU、host、SQLite 间迁移；没有发现 HTTP 下载/导出完整推理 state 的路由。该接口并未在本轮实际调用；部署多 worker 的会话亲和、同 session 并发更新、过期恢复均未知。后续若使用，应串行更新同一 session，只送新增 token 文本，不能每次重复全历史再声称等价。[会话端点](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_api_service.cpp#L1407)、[完整状态缓存](https://github.com/Alic-Li/rwkv_lightning_cuda/blob/6253c9e0345a1c5e42bf0a10e722ba09de06a2ac/src/rwkv_state_cache.cpp#L128)。

## 本机 statetune 的可行性边界

本机 `/home/chase/GitHub/RWKV-PEFT` 在 commit `5704c39f8ab1d2ac63936ab392aadb6ba526e1a5` 之上有既有未提交修改；已逐文件记录，不改动。环境具有 torch2.9、Triton3.5、rwkv-fla、DeepSpeed、Lightning，GPU 为 RTX5070Ti 16GB。state 参数约 524 万，当前 PEFT 的 canonical `[H,V,K]` 与上游上传文件约定相符；FLA 调用边界另外做内部转置。

这只是结构与工具准备度：没有验证 G1j 2.9B 全 checkpoint key/shape 加载、当前显存下反向传播、外部 upload/load 往返，也没有训练。下一步应先完成零 state 材料和 Wiki 基线，再冻结训练/留出集与完整模板，从 trace 中确定错误目标。训练前独立冻结 PEFT 代码、确切基座 SHA，检查 state 全 layer/shape/dtype/finite 与非对称矩阵方向。格式改善不能替代事实正确与逐引用支持评估。详见 `LOCAL-PEFT-INVENTORY.json`。

容量方面，GET status 当时报告 hard/dynamic max batch=399、active=0，只是共享服务瞬时值。客户端采用 batch8/global slots32 是自己的并发控制；不把该 status 当作长期吞吐/隔离保证。

## 冻结记录

`CONTRACT.json` 是机器可读结论；`SOURCE-PINS.json` 绑定上述 14 个官方文件及 commit；`FROZEN.json` 绑定本调查顶层全部记录。`upstream/source` 是只读源码缓存，完整 cache 及 .git 不作为发布必需品；上述文件 SHA 与 GitHub commit 可复取。`CREDENTIAL-SCAN.json` 只记录认证值扫描结果，不包含任何认证值。冻结后不覆盖原探针，不补跑模型。
