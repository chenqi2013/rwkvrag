from pathlib import Path
import json,shlex,urllib.request,urllib.error,hashlib,time,datetime,os,re
ROOT=Path(__file__).resolve().parent
parts=shlex.split(Path('/mnt/c/Users/chase/.codex/attachments/5a056a59-9300-4f5d-aace-62d0a1fb046e/pasted-text.txt').read_text().replace('\\\n',''))
headers={}
for i,t in enumerate(parts):
 if t in ('-H','--header'):
  k,v=parts[i+1].split(':',1);headers[k.strip()]=v.strip()
secrets=[v for k,v in headers.items() if k.lower() not in ['accept','content-type','user-agent']]
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(NoRedirect)
def safe_text(value):
 for secret in secrets:
  if secret:value=value.replace(secret,'[REDACTED]')
 return value
def redact(obj):
 if isinstance(obj,dict):return {k:('[REDACTED]' if any(s in k.lower() for s in ['authorization','password','secret','cookie','api_key','cf-access']) else '[OTHER_REQUEST_CONTENT_OMITTED]' if k.lower() in ['prompt','contents','content','messages','text'] else redact(v)) for k,v in obj.items()}
 if isinstance(obj,list):return [redact(x) for x in obj]
 if isinstance(obj,str):return safe_text(obj)
 return obj
def save(name,data):
 with (ROOT/name).open('x') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
payload={'contents':['User: Write the words one two three four five, separated by spaces.\n\nAssistant: <think></think>'],'model':'rwkv7-g1j-2.9b-20260831-ctx16384','max_tokens':1,'temperature':0.001,'top_k':1,'top_p':1.0,'alpha_presence':0.0,'alpha_frequency':0.0,'alpha_decay':0.99,'stop_tokens':[],'chunk_size':8,'stream':False,'metrics':True}
save('FINISH-BOUNDARY-PLAN.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Single generated-token boundary with stop_tokens=[]; verifies provider finish_reason truthfulness and optional metrics, not model quality','generation_requests':1,'automatic_retries':0,'requests':[{'method':'POST','path':'/v1/batch/completions','payload':payload},{'method':'GET','path':'/v1/server/status'},{'method':'POST','path':'/v1/tokens/count','payload':'actual returned output text only'}]})
def call(name,method,path,obj):
 req={'method':method,'url':'https://api-3b.rwkvos.com'+path,'payload':obj,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'automatic_retries':0};save(name+'-started.json',req)
 start=time.monotonic();result=dict(req)
 try:
  b=json.dumps(obj,ensure_ascii=False).encode() if obj is not None else None
  try:r=opener.open(urllib.request.Request(req['url'],data=b,headers=headers,method=method),timeout=30)
  except urllib.error.HTTPError as e:r=e
  raw=r.read();clean=safe_text(raw.decode());result.update(status=r.status,raw_response_sha256=hashlib.sha256(raw).hexdigest(),raw_response_bytes=len(raw),response=json.loads(clean),credentials_redacted=clean!=raw.decode())
 except Exception as e:result.update(error_type=type(e).__name__,error=safe_text(str(e)))
 result.update(completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=time.monotonic()-start);save(name+'-completed.json',result);return result
reply=call('finish-boundary','POST','/v1/batch/completions',payload)
status=call('finish-status','GET','/v1/server/status',None)
if reply.get('status')==200:
 text=reply['response']['choices'][0]['message']['content'];count=call('finish-output-count','POST','/v1/tokens/count',{'text':text})
else:count=None
print(json.dumps({'reply':reply,'status_last_request':status.get('response',{}).get('last_request'),'output_count':count},ensure_ascii=False,indent=2))
