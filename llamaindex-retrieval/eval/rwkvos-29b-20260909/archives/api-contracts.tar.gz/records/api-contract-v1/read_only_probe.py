from pathlib import Path
import json,shlex,urllib.request,urllib.error,hashlib,time,datetime,os,re
ROOT=Path(__file__).resolve().parent
parts=shlex.split(Path('/mnt/c/Users/chase/.codex/attachments/5a056a59-9300-4f5d-aace-62d0a1fb046e/pasted-text.txt').read_text().replace('\\\n',''))
headers={}
for i,t in enumerate(parts):
 if t in ('-H','--header'):
  k,v=parts[i+1].split(':',1);headers[k.strip()]=v.strip()
secrets=[v for k,v in headers.items() if k.lower() not in ['accept','content-type','user-agent']]
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(NoRedirect)
def safe_text(value):
 for secret in secrets:
  if secret:value=value.replace(secret,'[REDACTED]')
 return value
def redact(obj):
 if isinstance(obj,dict):return {k:('[REDACTED]' if any(s in k.lower() for s in ['authorization','password','secret','cookie','api_key','cf-access']) else '[OTHER_REQUEST_CONTENT_OMITTED]' if k.lower() in ['prompt','contents','content','messages','text'] else redact(v)) for k,v in obj.items()}
 if isinstance(obj,list):return [redact(x) for x in obj]
 if isinstance(obj,str):return safe_text(obj)
 return obj
def save(name,data):
 with (ROOT/name).open('x') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
plan=[('server-status','GET','/v1/server/status',None),('count-empty','POST','/v1/tokens/count',{'text':''}),('count-native','POST','/v1/tokens/count',{'text':'User: 你好\n\nAssistant: <think>'}),('count-chat','POST','/v1/tokens/count',{'messages':[{'role':'user','content':'你好'}],'think_type':'free'})]
save('PLAN.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Read-only API capability and tokenizer probes; zero model generations and no state uploads','requests':[{'name':n,'method':m,'path':p,'payload':b} for n,m,p,b in plan],'automatic_retries':0,'credential_values_persisted':False,'server_8222_access':False})
for name,method,path,payload in plan:
 req={'name':name,'method':method,'url':'https://api-3b.rwkvos.com'+path,'payload':payload,'header_names':list(headers),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'automatic_retries':0};save(name+'-started.json',req)
 start=time.monotonic();result=dict(req)
 try:
  b=json.dumps(payload,ensure_ascii=False).encode() if payload is not None else None
  try:r=opener.open(urllib.request.Request(req['url'],data=b,headers=headers,method=method),timeout=20)
  except urllib.error.HTTPError as e:r=e
  raw=r.read();result.update(status=r.status,raw_response_sha256=hashlib.sha256(raw).hexdigest(),raw_response_bytes=len(raw),response_content_type=r.headers.get('Content-Type'))
  try:original=json.loads(raw);safe=redact(original);result['response']=safe;result['response_redacted']=safe!=original
  except Exception:result['response_text']=safe_text(raw.decode(errors='replace'))
 except Exception as e:result['error_type']=type(e).__name__;result['error']=safe_text(str(e))
 result['seconds']=time.monotonic()-start;result['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(name+'-completed.json',result)
 print(json.dumps({'name':name,'status':result.get('status'),'error_type':result.get('error_type'),'response':result.get('response')},ensure_ascii=False))
