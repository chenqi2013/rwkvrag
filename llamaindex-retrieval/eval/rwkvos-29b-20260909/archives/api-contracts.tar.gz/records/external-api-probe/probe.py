from pathlib import Path
import shlex,json,re,urllib.request,urllib.error,hashlib,time,concurrent.futures
from datetime import datetime,timezone
B=Path(__file__).resolve().parent
attachment=Path('/mnt/c/Users/chase/.codex/attachments/5a056a59-9300-4f5d-aace-62d0a1fb046e/pasted-text.txt')
parts=shlex.split(attachment.read_text().replace("\\\n", ""))
url=next(x for x in parts if x.startswith('https://'))
headers={}
for i,t in enumerate(parts):
 if t in ('--header','-H'):
  k,v=parts[i+1].split(':',1);headers[k]=v.strip()
data=parts[parts.index('--data')+1]
corrected=re.sub(r',\s*}\s*$', '\n}', data)
payload=json.loads(corrected)
assert url=='https://api-3b.rwkvos.com/v1/batch/completions'
secrets=[v for k,v in headers.items() if k.lower() in {'cf-access-client-id','cf-access-client-secret','authorization','cookie','x-api-key'}]
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs): return None
opener=urllib.request.build_opener(NoRedirect)
def save(path,data):
 with path.open('xb') as f:f.write(data)
def run(name,method,path,body=None):
 request_bytes=json.dumps(body,ensure_ascii=False).encode() if body is not None else None
 target='https://api-3b.rwkvos.com'+path
 receipt={'method':method,'url':target,'header_names':list(headers),'authenticated_from_user_attachment':True,'started_at':datetime.now(timezone.utc).isoformat(),'automatic_retries':0}
 if request_bytes is not None:save(B/(name+'-request.json'),request_bytes)
 started=time.monotonic()
 try:
  try:response=opener.open(urllib.request.Request(target,data=request_bytes,headers=headers,method=method),timeout=60)
  except urllib.error.HTTPError as e:response=e
  raw=response.read();safe=raw
  for secret in secrets:safe=safe.replace(secret.encode(),b'[REDACTED]')
  receipt.update(status=response.status,seconds=time.monotonic()-started,response_sha256=hashlib.sha256(raw).hexdigest(),response_bytes=len(raw),credentials_redacted_from_response=safe!=raw,content_type=response.headers.get('Content-Type'))
  save(B/(name+'-response.bin'),safe)
  try:
   obj=json.loads(safe)
   receipt['response_keys']=list(obj) if isinstance(obj,dict) else 'list'
  except Exception:pass
 except Exception as e:receipt.update(error_type=type(e).__name__,error=str(e),seconds=time.monotonic()-started)
 save(B/(name+'-receipt.json'),json.dumps(receipt,ensure_ascii=False,indent=2).encode())
 return receipt
save(B/'PROBE-PLAN.json',json.dumps({'created_at':datetime.now(timezone.utc).isoformat(),'sample_payload_trailing_comma_removed':corrected!=data,'sample_contents_unchanged':True,'sample_state_id_preserved':True,'credential_values_never_saved':True,'requests':['GET /v1/models','GET /openapi.json','POST /v1/batch/completions (provided sample, JSON trailing comma removed)'],'model_output_is_not_model_identity_proof':True},ensure_ascii=False,indent=2).encode())
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 results=list(pool.map(lambda x:run(*x),[('models','GET','/v1/models'),('openapi','GET','/openapi.json'),('provided-sample','POST','/v1/batch/completions',payload)]))
print(json.dumps(results,ensure_ascii=False,indent=2))
