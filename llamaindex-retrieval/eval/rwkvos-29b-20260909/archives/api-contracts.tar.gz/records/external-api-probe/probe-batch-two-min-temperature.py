from pathlib import Path
import shlex,json,urllib.request,urllib.error,hashlib,time
from datetime import datetime,timezone
B=Path(__file__).resolve().parent
parts=shlex.split(Path('/mnt/c/Users/chase/.codex/attachments/5a056a59-9300-4f5d-aace-62d0a1fb046e/pasted-text.txt').read_text().replace("\\\n", ""))
headers={}
for i,t in enumerate(parts):
 if t in ('--header','-H'):
  k,v=parts[i+1].split(':',1);headers[k]=v.strip()
secrets=[v for k,v in headers.items() if k.lower() in {'cf-access-client-id','cf-access-client-secret','authorization','cookie','x-api-key'}]
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs): return None
opener=urllib.request.build_opener(NoRedirect)
def save(name,data):
 with (B/name).open('xb') as f:f.write(data)
payload={"contents":["System: 只根据给定资料回答，不添加资料以外的事实。\n\nUser: 资料1：青杉号于2024年5月首航。请回答首航时间，并用[资料 1]引用。\n\nAssistant: <think></think>","System: 只根据给定资料回答，不添加资料以外的事实。\n\nUser: 资料1：试验电池容量为72千瓦时。请回答容量，并用[资料 1]引用。\n\nAssistant: <think></think>"],"max_tokens":128,"temperature":0.001,"top_k":20,"top_p":0,"alpha_presence":0,"alpha_frequency":0,"alpha_decay":0.99,"chunk_size":8,"stream":False}
body=json.dumps(payload,ensure_ascii=False).encode()
save('batch-two-min-temperature-request.json',body)
receipt={'url':'https://api-3b.rwkvos.com/v1/batch/completions','started_at':datetime.now(timezone.utc).isoformat(),'purpose':'Two independent synthetic grounded Chinese prompts; verify batch choice correspondence only, not RAG quality; new request temperature0.001 following explicit400minimum constraint','automatic_retries':0}
save('batch-two-min-temperature-started.json',json.dumps(receipt,ensure_ascii=False,indent=2).encode())
started=time.monotonic()
try:
 try:response=opener.open(urllib.request.Request(receipt['url'],data=body,headers=headers,method='POST'),timeout=60)
 except urllib.error.HTTPError as e:response=e
 raw=response.read();safe=raw
 for secret in secrets:safe=safe.replace(secret.encode(),b'[REDACTED]')
 save('batch-two-min-temperature-response.bin',safe)
 receipt.update(status=response.status,seconds=time.monotonic()-started,response_bytes=len(raw),response_sha256=hashlib.sha256(raw).hexdigest(),credentials_redacted_from_response=safe!=raw)
 try:
  obj=json.loads(safe);receipt['response_keys']=list(obj) if isinstance(obj,dict) else 'list'
 except Exception:pass
except Exception as e:receipt.update(error_type=type(e).__name__,error=str(e),seconds=time.monotonic()-started)
save('batch-two-min-temperature-receipt.json',json.dumps(receipt,ensure_ascii=False,indent=2).encode())
print(json.dumps(receipt,ensure_ascii=False,indent=2))
