# G1j 原始角色与前缀：一手证据

BlinkDL 的 `RWKV7-G1x-templates.txt` 明确标为 G1 系列训练模板，使用 `User:/Assistant:`（可加System），而不是User✿/Bot✿。已将官方文件按commit `9a75f9f037afa4418ee6283b584b92b1adb89ca1` 原样保存，SHA `21dd0a38bc907c1d070742c19a8f83fcc57eec462f62dfabb84569851256d441`。

官方fake-think是`Assistant: <think></think`，末尾没有`>`；本次外部材料v1是完整`<think></think>`，所以这一字符的前缀控制值得单变量对照。当前资料不足以断言它会改善，更不足以断言现有plain角色模板不匹配。官方模型卡中的✿用于FIM prefix/suffix/middle；此前vLLM flower角色只能证明那套adapter实际怎样渲染。

官方CUDA raw batch在输入侧不加聊天模板；输出侧直接拼接tokenizer.decode结果，不strip或移除think标签，stop token自身不包含在返回正文。已冻结源码证据沿用api-contract-v1/source pins。客户端可能另做envelope范围定位，必须区别于服务端改写。

建议后续材料对照只去掉最后`>`，其余消息、证据、角色、双换行、显式stop[0]保持字节不变。官方建议清理内部双换行，但会改变我们的原文；本轮不能静默采用。长文本v1准备件继续保留完整闭合，若改格式另建版本。

[官方训练模板](https://github.com/BlinkDL/RWKV-LM/blob/9a75f9f037afa4418ee6283b584b92b1adb89ca1/RWKV-v7/RWKV7-G1x-templates.txt)，[官方模型卡](https://huggingface.co/BlinkDL/rwkv7-g1/blob/main/README.md)。特定2.9B HF tokenizer_config本次下载SSL失败，未冒充读取成功；本机HF缓存也未发现该模型。

此调查零模型/API推理、零服务器访问。原冻结api-contract-v1未改。
