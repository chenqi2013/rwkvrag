"""Offline planner control review; explicit observations, no semantic repair."""
import ast
import base64
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

B = Path(__file__).resolve().parents[1]
O = B / "review/planner-controls-v1"
RUNS = ["wiki-api-v1-eos", "planner-shared-tasks-v1", "planner-contract-last-v1"]

# Each tuple: raw requested scope retained, independent useful partition, explanation.
# Invalid syntax is never repaired or sent downstream for this diagnostic.
JUDGMENTS = {
    "held_004": [
        (True, True, "原四目标各自保留，ID/载荷/资料率Mbit/s/线路影响关系正确。"),
        (False, False, "六段【子问题】递增重复；将载荷错误地绑定到每种ID位数、将线路影响转成这些数据的影响原因，并遗漏明确的最高资料率Mbit/s目标。非JSON。"),
        (True, True, "四个有效目标与基线相同；仅从可见原文内容看范围保留，但外层代码围栏使严格解析失败。"),
    ],
    "held_010": [
        (True, True, "四标准分别关联语言、事件模型、书颜色、阶段数，虽有重复检索式但未换对象；代码围栏失败。"),
        (True, False, "四个目标和不做认证的限制均保留，但每个字符串重复整道四对象问题，去重后仍是两条高度重叠总问题，没有分别拆分对象。仅格式通过不等于完成子问题组织。"),
        (True, True, "四个对象及各自目标保留；最外层为单元素数组而非所要求对象，严格解析失败。"),
    ],
    "held_012": [
        (True, True, "ICE-1可否组合、ICE-2指定路线的合体站、305系总辆数/动力车数绑定完整；实际外层为query/fields对象数组，严格失败。"),
        (True, True, "三条独立字符串准确保留车型、ICE-2科隆/杜塞尔多夫往柏林路线，以及305系总数与动力车子目标。"),
        (False, True, "把车厢数量加到ICE-1与ICE-2，原题只对305系问数量；ICE-2仅剩合体关键词、未明确所求站点。代码围栏失败。"),
    ],
    "held_014": [
        (True, True, "queries保持Ghost许可证、Discuz!NT语言/技术、Gearman三角色及执行者；unused fields额外许可证链接/版本不作为本次queries驱动链路的主动请求，但记录冗余风险。外层数组失败。"),
        (True, True, "三个独立对象/目标完整，Discuz!NT命名明确，无需逐字复述不要套主版本的否定句才算保留范围。"),
        (True, True, "三对象及Gearman角色/实际执行者保留；单元素对象数组不符合顶层对象合同。"),
    ],
    "held_016": [
        (False, True, "RPG Maker MV查询只剩手机版音乐格式，漏Windows一侧，另加RPG与Media Foundation泛开发文档；其他三个主目标保留。"),
        (True, True, "四个对象与属性分别保留，特别WinJS1.0、RPG的Windows/手机两平台、Media Foundation首次适用版本均准确。"),
        (True, True, "queries已保留四目标及RPG双平台，较基线范围完整；但顶层单元素数组导致不能使用。"),
    ],
    "held_017": [
        (False, False, "复制多轮历史与助手文本为9条queries，仍含最初待确认对象和已撤回公司名单旁支；未整理成Ghost首次Kickstarter筹资三格的独立任务。字段三格虽在，不能救无效queries/围栏。"),
        (False, False, "第一段把区分Ghost/GhostBSD恢复为所求属性；后段虽保留Ghost、目标/实际额/天数与英镑，也混入格式指令及排版旁支，整个输出非JSON且后半句未完。"),
        (False, False, "仅写旧博客软件，丢已确定Ghost身份、首次Kickstarter事件和英镑限定；加软件名称与倍数，不能用本来的三格代替这些新增目标。非JSON。"),
    ],
    "held_019": [
        (False, False, "queries复制历史：开头仍带旧3.51及Server讨论，中间有正确3.5工作站但没有统一解除冲突；打印/图示旁支混入、共7条且有围栏。"),
        (False, False, "八段文本首先保留旧NT3.51，未明确恢复已确认NT3.5工作站；复制助手/打印/图示文字，只有后段列三个字段，不能使各段成为独立正确任务。"),
        (False, False, "明确反复查询NT3.51并同时要Server与Workstation，违背已确认3.5仅工作站；还漏开发代号目标。围栏+数组都不合法。"),
    ],
    "held_021": [
        (True, True, "六条重复同一有效查询：美国海岸警卫队红级中成为人工鱼礁的两艘名称及置放日期；未恢复红雪松/退役排序。完整history仍保留年月日粒度。围栏使实际失败。"),
        (False, False, "输出【子问题】后直接复制未完的history JSON，混入旧红雪松及被撤回旁支；未形成可独立执行的两艘鱼礁/置放日期任务。原文字提到正确约束不等于完成规划。"),
        (False, True, "主动恢复红雪松单船，新增退役日/建造厂/舷号字段；既错对象集合，又恢复明确撤回或可选要求。Python赋值文本不是JSON。"),
    ],
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(p):
    return json.loads(p.read_text())


def bind(p):
    data = p.read_bytes()
    return {"path": str(p.relative_to(B)), "sha256": sha(data), "bytes": len(data)}


def save(p, value):
    with p.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def main():
    assert not O.exists()
    source = B / "source-api-v1/src/llamaindex_retrieval/rwkv_pipeline.py"
    scope = {"json": json, "Settings": object}
    functions = [n for n in ast.parse(source.read_text()).body if isinstance(n, ast.FunctionDef) and n.name in {"parse_plan", "planner_prompt"}]
    assert len(functions) == 2
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(source), "exec"), scope)
    fixturepath = B / "wiki-api-v1-eos/frozen/fixtures.jsonl"
    fixtures = [json.loads(x) for x in fixturepath.read_text().splitlines()]
    bindings = [bind(fixturepath), bind(source)]
    request_maps = {}
    for name in RUNS[1:]:
        directory = B / name
        freeze = read(directory / "RAW-FREEZE.json")
        for rel, spec in freeze["files"].items():
            data = (directory / rel).read_bytes()
            assert sha(data) == spec["sha256"] and len(data) == spec["bytes"]
        bindings.append(bind(directory / "RAW-FREEZE.json"))
        request_maps[name] = {x["case_id"]: x for x in read(directory / "requests.json")}
    rows = []
    for f in fixtures:
        cid = f["id"]
        baseline_path = B / RUNS[0] / "completed" / (cid + ".json")
        baseline = read(baseline_path)["response"]["generation"]["model_calls"][0]
        for index, name in enumerate(RUNS):
            path = B / name / "completed" / (cid + ".json")
            original = read(path)
            call = baseline if index == 0 else original["trace"]
            raw = call["raw_text"]
            assert sha(raw.encode()) == call["raw_text_sha256"]
            if index:
                assert original["raw_text"] == raw
                req = request_maps[name][cid]
                task = json.dumps({"history": f["history"], "latest_question": f["question"]}, ensure_ascii=False)
                assert req["task"] == task
                base_content = baseline["messages"][0]["content"]
                assert base_content.endswith("任务：" + task)
                settings = SimpleNamespace(native_plan_protocol="shared_tasks" if index == 1 else "queries_fields", native_max_queries=6, native_max_fields=12)
                expected = scope["planner_prompt"](task, settings) if index == 1 else "任务：" + task + "\n" + base_content.split("\n任务：", 1)[0]
                assert req["messages"] == call["messages"] == [{"role": "user", "content": expected}]
                assert call["parameters"] == baseline["parameters"]
                assert call["state_id"] == baseline["state_id"] is None
                assert call["prefill"] == baseline["prefill"]
                http = call["http"][0]
                request_bytes = base64.b64decode(http["request_body_base64"], validate=True)
                response_bytes = base64.b64decode(http["response_body_base64"], validate=True)
                assert sha(request_bytes) == http["request_body_sha256"]
                assert sha(response_bytes) == http["response_body_sha256"]
                payload, body = json.loads(request_bytes), json.loads(response_bytes)
                assert payload == http["payload"] and body == http["response_json"]
                assert payload["contents"][call["batch_index"]] == call["prompt"]
                assert sorted(c["index"] for c in body["choices"]) == list(range(len(payload["contents"])))
                choice = next(x for x in body["choices"] if x["index"] == call["batch_index"])
                assert choice["message"]["content"] == raw
            settings = SimpleNamespace(native_plan_protocol="shared_tasks" if index == 1 else "queries_fields", native_max_queries=6, native_max_fields=12)
            error, plan = None, None
            assert call["envelope"] == {"valid": True, "answer_span": {"start": 0, "end": len(raw), "unit": "unicode_code_points"}, "raw_text_modified": False}
            try:
                # Existing structured_body uses the validated full span then
                # strips only outside whitespace; raw receipts stay unchanged.
                plan = scope["parse_plan"](raw.strip(), settings)
            except (ValueError, TypeError) as exc:
                error = str(exc)
            assert error == (call.get("parse_error") if index == 0 else original.get("parse_error"))
            if index:
                assert bool(plan) == original["format_pass"]
                if plan:
                    assert plan == original["parsed_plan"]
            retained, independent, reason = JUDGMENTS[cid][index]
            rows.append({"case_id": cid, "condition": name, "raw_file": str(path.relative_to(B)),
                         "raw_pointer": "/response/generation/model_calls/0/raw_text" if index == 0 else "/raw_text",
                         "raw_sha256": sha(raw.encode()), "raw_text": raw,
                         "format_pass": error is None, "parse_error": error,
                         "raw_requested_scope_retained": retained,
                         "useful_independent_partition": independent,
                         "format_and_scope_and_partition_pass": error is None and retained and independent,
                         "review": reason, "termination_verified": False,
                         "downstream_quality_assessed": False})
            bindings.append(bind(path))
    summary = {name: {
        "cases": 8,
        "format_pass": sum(r["format_pass"] for r in rows if r["condition"] == name),
        "raw_requested_scope_retained": sum(r["raw_requested_scope_retained"] for r in rows if r["condition"] == name),
        "format_and_scope_and_partition_pass": sum(r["format_and_scope_and_partition_pass"] for r in rows if r["condition"] == name),
    } for name in RUNS}
    O.mkdir(parents=True)
    save(O / "REVIEW.json", {"reviewer": "Codex independent non-blind review of exposed eight-case controls", "conditions": summary, "rows": rows,
        "boundaries": ["Raw semantic observations do not bypass parse errors or rewrite plans.", "This is diagnostic task organization, not an additional QA score.", "Source-backed recall and full answers were not evaluated for these planner-only runs.", "Repeated whole multi-object questions preserve targets but do not meet the requested independent partition.", "Externally reported stop does not establish EOS or rule out length termination.", "Changes in task protocol/position and batching are not an isolated model-size comparison."], "bindings": bindings})
    lines = ["# 两个外部 2.9B Planner-only 对照审阅", "", "只读冻结八题，未调用 API，未修补原输出，也未改变旧 Wiki 的 8 题 / 29 事实评分。两个新增对照各 8 次生成、按 4+4 两个 contents 批次执行；没有检索或 Writer。严格语法均按实际冻结 parse_plan 重算，完整历史与最新问题、采样/状态/prefill/预算和 wire 槽位已核对。", "", "| 条件 | 严格格式 | 可见原文目标/范围保留（不救格式） | 同时满足格式、范围及独立组织 |", "|---|---:|---:|---:|"]
    for name in RUNS:
        s = summary[name]
        lines.append(f"| {name} | {s['format_pass']}/8 | {s['raw_requested_scope_retained']}/8 | {s['format_and_scope_and_partition_pass']}/8 |")
    lines += ["", "范围诊断与可执行计划分开。shared 的 held_010 虽保留全部内容并能解析，却把四对象整题重复成多个字符串，故不记为已完成独立任务组织；这不是金标事实评分变更。", ""]
    for f in fixtures:
        lines += [f"## {f['id']}", ""]
        for row in (r for r in rows if r["case_id"] == f["id"]):
            lines.append(f"- [{row['condition']} 原输出](../../{row['raw_file']})：{row['review']}")
        lines.append("")
    lines += ["## 可以支持的结论", "", "字符串数组合同把列车、软件组件、开发文档三题组织正确，且修复了开发文档题中 RPG 双平台目标；但 CAN FD 比基线退化，三道长历史仍不合格，不能用 4/8 格式通过率直接晋级。末尾合同对照严格格式 0/8；对 NT 3.5 工作站错误恢复 3.51/Server，对红级两艘鱼礁错误恢复红雪松单船及退役日/建造厂，未满足预登记的范围不退化条件。", "", "完整历史未被 transport 截掉，不等于模型已正确执行历史更正。复制历史、格式指令或助手文本不是独立查证任务。记录不能证明状态微调、换模板、放宽 JSON 或再增加提示词必然有效；下一步应把有效对象/事件/单位/撤回范围与语法分别验证，避免只有更高解析率。", "", "本轮没有对两个候选做下游完整 RAG，不能给它们 QA 提升分。provider finish_reason=stop 的终止限制照旧；有尾部未完句的输出只描述可见现象，不冒充已证 length。", ""]
    with (O / "REPORT.md").open("x", encoding="utf-8") as file:
        file.write("\n".join(lines))
    save(O / "FROZEN.json", {"schema": "planner-controls-review-freeze-v1", "artifacts": [bind(O / "REPORT.md"), bind(O / "REVIEW.json"), bind(Path(__file__))], "inputs": bindings, "new_model_calls": 0, "original_records_modified": False})
    print(json.dumps({"summary": summary, "frozen_sha256": sha((O / "FROZEN.json").read_bytes())}, ensure_ascii=False))


if __name__ == "__main__":
    main()
