"""Serialize explicit Codex judgments; does not automatically judge semantics."""
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def write(path, data):
    with path.open("x", encoding="utf-8") as out:
        out.write(json.dumps(data, ensure_ascii=False, indent=2) + "\n")

def span(text, quote):
    if quote is None:
        return None
    start = text.index(quote)
    return {"start": start, "end": start + len(quote), "unit": "unicode_code_points"}

def build(run_name, judgments):
    run = ROOT / run_name
    target = ROOT / "review" / run_name
    target.mkdir(exist_ok=False)
    cases = [json.loads(line) for line in (run / "frozen/fixtures.jsonl").read_text().splitlines()]
    assert digest(run / "frozen/fixtures.jsonl") == "36ca2a895139b3e361e661896a347322818d52295e74ea44d8cc9d55321f37da"
    assert len(cases) == len(judgments) == 8
    assert sum(len(c["expected_facts"]) for c in cases) == 28
    protocol = json.loads((ROOT / "qa-protocol/materials/PROTOCOL.json").read_text())
    rows = []
    for case, explicit in zip(cases, judgments, strict=True):
        case_id = case["id"]
        assert explicit["id"] == case_id
        receipt_path = run / "completed" / f"{case_id}.json"
        receipt = json.loads(receipt_path.read_text())
        result = receipt["response"]
        generation = result["generation"]
        raw = generation["raw_model_answer"]
        bounds = generation["answer_span"]
        answer = raw[bounds[0]:bounds[1]] if bounds is not None else ""
        assert raw == result["answer"]  # Immutable API returns full raw; score only declared body span.
        assert result["sources"] == case["materials"]
        assert generation["termination_verified"] is False
        assert generation["transport"] == "rwkvos_batch"
        materials = {i + 1: material for i, material in enumerate(result["sources"])}
        occurrences = []
        for cite in explicit["citations"]:
            label = cite["label"]
            occurrence_start = [m.start() for m in re.finditer(re.escape(label), answer)][cite.get("occurrence", 0)]
            number = cite["number"]
            material = materials.get(number)
            support = []
            for quote in cite.get("source_quotes", []):
                assert material is not None
                support.append({**span(material["snippet"], quote), "quote": quote,
                                "material_id": material["id"],
                                "source_sha256": sha256(material["snippet"].encode()).hexdigest()})
            occurrences.append({**cite, "answer_span": {"start": occurrence_start,
                "end": occurrence_start + len(label), "unit": "unicode_code_points"},
                "claim_span": span(answer, cite["claim_quote"]), "actual_support_spans": support,
                "source_id": material["id"] if material else None})
        # Enumerate references only; semantic associations are all explicit above.
        numbered = list(re.finditer(r"资料\s*[1-9][0-9]*", answer))
        assert len(numbered) == len(occurrences), (case_id, numbered, occurrences)
        facts = []
        assert len(case["expected_facts"]) == len(explicit["facts"])
        for oracle, judgment in zip(case["expected_facts"], explicit["facts"], strict=True):
            assert oracle["id"] == judgment["id"]
            for reference in oracle["supporting_quotes"]:
                material = next(m for m in materials.values() if m["id"] == reference["material_id"])
                assert material["snippet"][reference["start"]:reference["end"]] == reference["quote"]
            supporting = [c for c in occurrences if oracle["id"] in c["supported_fact_ids"]
                          and c["support"] in {"supported", "partially_supported"}]
            facts.append({**judgment, "expected_claim": oracle["claim"],
                "answer_span": span(answer, judgment.get("answer_quote")),
                "formal_supported": judgment["status"] == "correct" and any(c["formal"] for c in supporting),
                "human_readable_supported": judgment["status"] == "correct" and bool(supporting),
                "oracle_actual_material_spans": oracle["supporting_quotes"]})
        extras = []
        for extra in explicit["extra_claims"]:
            extras.append({**extra, "answer_span": span(answer, extra["answer_quote"])})
        core = explicit["decision_correct"] and all(f["status"] == "correct" for f in facts)
        error_free = not any(e["material_error"] for e in extras)
        no_bad_citations = all(c["support"] == "supported" for c in occurrences)
        human = core and error_free and no_bad_citations and all(f["human_readable_supported"] for f in facts)
        formal = core and error_free and no_bad_citations and all(f["formal_supported"] for f in facts)
        rows.append({"id": case_id, "record_sha256": digest(receipt_path),
            "transport_status": receipt["status"], "transport": "rwkvos_batch",
            "provider_finish_reason": generation["provider_finish_reason"], "termination_verified": False,
            "termination": "unknown", "raw_answer_sha256": sha256(raw.encode()).hexdigest(),
            "final_answer_span": {"start": bounds[0], "end": bounds[1], "unit": "unicode_code_points"},
            "api_answer_equals_raw": True, "api_answer": result["answer"],
            "final_answer": answer, "final_answer_sha256": sha256(answer.encode()).hexdigest(),
            "thinking_used_for_facts_or_citations": False, "expected_decision": case["expected_decision"],
            "actual_decision": explicit["decision"], "decision_correct": explicit["decision_correct"],
            "decision_reason": explicit["decision_reason"], "facts": facts,
            "citation_occurrences": occurrences, "extra_claims": extras, "scope": explicit["scope"],
            "observable_output_limitations": explicit.get("observable_output_limitations", []),
            "core_facts_and_decision_pass": core, "full_pass": formal,
            "exact_format_full_pass": formal, "human_readable_citation_full_pass": human})
    facts = [f for row in rows for f in row["facts"]]
    cites = [c for row in rows for c in row["citation_occurrences"]]
    run_summary = json.loads((run / "summary.json").read_text())
    summary = {"cases": 8, "required_facts": 28, "fact_status_counts": dict(Counter(f["status"] for f in facts)),
        "formal_supported_facts": sum(f["formal_supported"] for f in facts),
        "human_readable_supported_correct_facts": sum(f["human_readable_supported"] for f in facts),
        "exact_format_full_pass": sum(row["exact_format_full_pass"] for row in rows),
        "human_readable_citation_full_pass": sum(row["human_readable_citation_full_pass"] for row in rows),
        "exact_format_passed_ids": [r["id"] for r in rows if r["exact_format_full_pass"]],
        "human_readable_citation_passed_ids": [r["id"] for r in rows if r["human_readable_citation_full_pass"]],
        "core_facts_and_decision_pass": sum(row["core_facts_and_decision_pass"] for row in rows),
        "decision_correct": sum(row["decision_correct"] for row in rows),
        "formal_citation_occurrences": sum(c["formal"] for c in cites),
        "human_readable_citation_occurrences": len(cites),
        "human_readable_citation_support_counts": dict(Counter(c["support"] for c in cites)),
        "automatic_semantic_grading": False, "termination_unknown_cases": 8,
        "http_requests": run_summary["http_requests"], "model_calls": run_summary["model_calls"],
        "run_elapsed_ms": run_summary["elapsed_ms"]}
    paths = [run / name for name in ["manifest.json", "summary.json", "results.json", "frozen/fixtures.jsonl", "frozen/run_smoke.py"]]
    paths += [ROOT / "qa-protocol/materials/PROTOCOL.json", ROOT / "qa-protocol/materials/FROZEN.json",
              ROOT / "api-contract-v1/CONTRACT.json", ROOT / "api-contract-v1/FROZEN.json", Path(__file__)]
    bindings = [{"path": str(p.relative_to(ROOT)), "sha256": digest(p)} for p in paths]
    limitations = [
        "Eight exposed development material cases and 28 fixed facts; four Wiki-derived and four synthetic. No new blind or full-retrieval quality claim.",
        "The external API self-reports rwkv7-g1j-2.9b-20260831-ctx16384; no remotely attested weight hash, deployment revision or tokenizer hash. The unused local checkpoint does not prove provider identity.",
        "Provider finish_reason=stop is demonstrably unconditional at the output budget. completed denotes a returned valid body, not verified natural completion. All eight termination states remain unknown.",
        "The reviewer scores visible actual answer-span content, including visibly unfinished output; no inferred length/EOS flag, no thinking rescue, no output repair.",
        "A single contents[8] HTTP batch was used. Shared round-trip elapsed times do not measure individual item latency or isolated throughput.",
        "Formal bracket citations and separately reported unambiguous readable citations are different interfaces; neither source presence nor exact quote matching proves semantic support.",
        "This run changed model/provider/template/transport relative to old 13.3B experiments and is not an isolated model-size causal comparison."]
    review = {"schema": "native-materials-smoke-semantic-review-v1", "reviewed_at": datetime.now(timezone.utc).isoformat(),
        "reviewer": "Codex independent non-blind development review; not human expert acceptance",
        "run": run_name, "summary": summary, "criteria": protocol["criteria"], "bindings": bindings,
        "rows": rows, "limitations": limitations}
    write(target / "review.json", review)
    write(target / "judgments.json", judgments)
    write(target / "summary.json", summary)
    with (target / "rows.jsonl").open("x", encoding="utf-8") as out:
        for row in rows:
            out.write(json.dumps(row, ensure_ascii=False) + "\n")
    (target / "summary.md").write_text(
        f"# {run_name}：固定材料独立审阅\n\n"
        f"保留全部 8 题 / 28 项事实。正确 {summary['fact_status_counts'].get('correct',0)}，"
        f"遗漏 {summary['fact_status_counts'].get('omitted',0)}，错误 {summary['fact_status_counts'].get('incorrect',0)}。\n\n"
        f"正式引用完整通过 {summary['exact_format_full_pass']}/8；可明确辨认来源号的可读引用口径 "
        f"{summary['human_readable_citation_full_pass']}/8。正式支持事实 {summary['formal_supported_facts']}/28，"
        f"可读引用支持事实 {summary['human_readable_supported_correct_facts']}/28。\n\n"
        "8 项均仅确认响应返回；提供方 stop 不能证明自然结束，终止状态全部 unknown。"
        "没有从思考过程补答案，也没有把未明确拒答的指令回声算作拒答。详见逐题 rows.jsonl。\n", encoding="utf-8")
    write(target / "PROVIDER-LIMITATIONS.json", {"scope": run_name, "amends_old_protocol": False,
        "new_addendum_only": True, "bindings": bindings[-5:-1], "limitations": limitations})
    write(target / "FROZEN.json", {"schema": "explicit-review-freeze-v1", "run": run_name,
        "files": [{"path": p.name, "sha256": digest(p), "bytes": p.stat().st_size} for p in sorted(target.iterdir())],
        "bindings": bindings, "semantic_judgments_are_explicit_not_automatically_proven": True})
    print(json.dumps(summary, ensure_ascii=False))
    print("FROZEN", digest(target / "FROZEN.json"))


def fact(fid, status, answer_quote, reason):
    return {"id": fid, "status": status, "answer_quote": answer_quote, "reason": reason}

