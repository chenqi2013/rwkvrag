"""Controlled EOS review: exact material/answer reuse plus one explicit re-review."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path

from build_materials_api_review import ROOT, build, digest, write

old = ROOT / "materials-api-v1"
new = ROOT / "materials-api-eos-v2"
original_judgments_path = ROOT / "review/materials-api-v1/judgments.json"
judgments = deepcopy(json.loads(original_judgments_path.read_text()))
controls = []
for judgment in judgments:
    cid = judgment["id"]
    a = json.loads((old / "completed" / f"{cid}.json").read_text())
    b = json.loads((new / "completed" / f"{cid}.json").read_text())
    ga, gb = a["response"]["generation"], b["response"]["generation"]
    ta, tb = ga["model_calls"][0], gb["model_calls"][0]
    assert a["response"]["sources"] == b["response"]["sources"]
    assert ta["messages"] == tb["messages"]
    assert ta["prompt"] == tb["prompt"]
    assert ta["prefill"] == tb["prefill"] == "<think></think>"
    params_a, params_b = deepcopy(ta["parameters"]), deepcopy(tb["parameters"])
    assert "stop_tokens" not in params_a
    assert params_b.pop("stop_tokens") == [0]
    assert params_a == params_b
    same = a["response"]["answer"] == b["response"]["answer"]
    if cid == "smoke_002":
        assert not same
        assert a["response"]["answer"].replace("5000番台，", "5000番台车辆，").replace(
            "车尾为223系，", "车尾为223系车辆，") == b["response"]["answer"]
        for extra in judgment["extra_claims"]:
            if extra["answer_quote"] == "另一节为无动力车（223系），车头为5000番台，车尾为223系":
                extra["answer_quote"] = "另一节为无动力车（223系），车头为5000番台车辆，车尾为223系车辆"
        method = "Explicitly re-read full candidate answer against actual materials: two added 车辆 words do not change any wrong quantity/model binding or citation outcome."
    else:
        assert same
        method = "Reused explicit prior judgments only after exact final answer/raw answer/source/messages/status/citation_audit equality checks."
        assert ga["raw_model_answer"] == gb["raw_model_answer"]
        assert ga["citation_audit"] == gb["citation_audit"]
        assert a["status"] == b["status"]
    controls.append({"id": cid, "same_answer": same, "same_full_raw_answer": ga["raw_model_answer"] == gb["raw_model_answer"],
                     "same_full_materials": True, "same_full_messages": True, "same_prompt": True,
                     "only_wire_parameter_difference": {"stop_tokens": {"before": "omitted", "after": [0]}},
                     "review_method": method, "prior_judgments_sha256": digest(original_judgments_path),
                     "prior_response_sha256": a["response_sha256"], "candidate_response_sha256": b["response_sha256"]})
build("materials-api-eos-v2", judgments)
comparison_dir = ROOT / "review/materials-api-stop-comparison"
comparison_dir.mkdir(exist_ok=False)
summary_a = json.loads((ROOT / "review/materials-api-v1/summary.json").read_text())
summary_b = json.loads((ROOT / "review/materials-api-eos-v2/summary.json").read_text())
score_keys = ["fact_status_counts", "formal_supported_facts", "human_readable_supported_correct_facts",
              "exact_format_full_pass", "human_readable_citation_full_pass", "exact_format_passed_ids",
              "human_readable_citation_passed_ids", "core_facts_and_decision_pass", "decision_correct"]
assert all(summary_a[k] == summary_b[k] for k in score_keys)
paths = [Path(__file__), original_judgments_path,
         ROOT / "review/materials-api-v1/FROZEN.json", ROOT / "review/materials-api-eos-v2/FROZEN.json",
         ROOT / "MATERIALS-EOS-CONTROL-PLAN.json"]
assert all(p.is_file() for p in paths)
comparison = {"schema": "materials-api-stop-only-comparison-v1", "original_denominator_per_run": {"cases": 8, "facts": 28},
    "source_weights_attested": False, "provider_reported_model": "rwkv7-g1j-2.9b-20260831-ctx16384",
    "baseline": summary_a, "candidate": summary_b, "same_answer_cases": sum(c["same_answer"] for c in controls),
    "changed_answer_cases": [c["id"] for c in controls if not c["same_answer"]], "all_semantic_scores_unchanged": True,
    "rows": controls, "conclusion": "Explicit EOS-only stops did not improve required facts, citations or complete tasks in these eight exposed material cases. The sole textual change leaves existing wrong train claims intact.",
    "limitations": ["No stop field can prove natural completion for this provider; termination remains unknown in both runs.",
        "The long repeated smoke004 answer is identical, and short smoke003/008 instruction echoes remain identical. Default double-newline stop is not established as the cause of these observed defects.",
        "Round-trip wall times differ, but this single sequential pair is not an isolated throughput or repeated randomized performance experiment.",
        "No model/prompt/fixture/sampling or raw answer correction was performed during this review."],
    "bindings": [{"path": str(p.relative_to(ROOT)), "sha256": digest(p)} for p in paths]}
write(comparison_dir / "COMPARISON.json", comparison)
(comparison_dir / "README.md").write_text(
    "# 固定材料 stop 对照\n\n两轮各8题/28事实：均19正确、6遗漏、3错误；正式完整0/8，可读引用完整1/8（smoke005）。"
    "正式支持事实0/28，可读引用支持6/28。\n\n只将请求stop_tokens从省略改为[0]。7/8答案逐字相同；smoke002仅多两处‘车辆’，"
    "错误编组和型号仍相同。smoke004循环长答案、003/008指令回声完全不变。本轮未观察到质量改善，不能据此把所有问题归因于默认双换行停止符。"
    "\n\n外部提供方stop不能证明自然完成，两轮16个输出的终止状态均unknown。29.72s/26.58s是一次真实contents8批次的整轮墙钟记录，不是逐项延迟或性能因果结论。\n", encoding="utf-8")
write(comparison_dir / "FROZEN.json", {"files": [{"path": p.name, "sha256": digest(p)} for p in sorted(comparison_dir.iterdir())],
                                      "bindings": comparison["bindings"]})
print("COMPARISON", digest(comparison_dir / "FROZEN.json"))
