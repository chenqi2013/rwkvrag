"""Serialize explicit Codex judgments; does not automatically judge semantics."""
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def write(path, data):
    with path.open("x", encoding="utf-8") as out:
        out.write(json.dumps(data, ensure_ascii=False, indent=2) + "\n")

def span(text, quote):
    if quote is None:
        return None
    start = text.index(quote)
    return {"start": start, "end": start + len(quote), "unit": "unicode_code_points"}

def build(run_name, judgments):
    run = ROOT / run_name
    target = ROOT / "review" / run_name
    target.mkdir(exist_ok=False)
    cases = [json.loads(line) for line in (run / "frozen/fixtures.jsonl").read_text().splitlines()]
    assert digest(run / "frozen/fixtures.jsonl") == "36ca2a895139b3e361e661896a347322818d52295e74ea44d8cc9d55321f37da"
    assert len(cases) == len(judgments) == 8
    assert sum(len(c["expected_facts"]) for c in cases) == 28
    protocol = json.loads((ROOT / "qa-protocol/materials/PROTOCOL.json").read_text())
    rows = []
    for case, explicit in zip(cases, judgments, strict=True):
        case_id = case["id"]
        assert explicit["id"] == case_id
        receipt_path = run / "completed" / f"{case_id}.json"
        receipt = json.loads(receipt_path.read_text())
        result = receipt["response"]
        generation = result["generation"]
        raw = generation["raw_model_answer"]
        bounds = generation["answer_span"]
        answer = raw[bounds[0]:bounds[1]] if bounds is not None else ""
        assert answer == result["answer"]
        assert result["sources"] == case["materials"]
        assert generation["termination_verified"] is False
        assert generation["transport"] == "rwkvos_batch"
        materials = {i + 1: material for i, material in enumerate(result["sources"])}
        occurrences = []
        for cite in explicit["citations"]:
            label = cite["label"]
            occurrence_start = [m.start() for m in re.finditer(re.escape(label), answer)][cite.get("occurrence", 0)]
            number = cite["number"]
            material = materials.get(number)
            support = []
            for quote in cite.get("source_quotes", []):
                assert material is not None
                support.append({**span(material["snippet"], quote), "quote": quote,
                                "material_id": material["id"],
                                "source_sha256": sha256(material["snippet"].encode()).hexdigest()})
            occurrences.append({**cite, "answer_span": {"start": occurrence_start,
                "end": occurrence_start + len(label), "unit": "unicode_code_points"},
                "claim_span": span(answer, cite["claim_quote"]), "actual_support_spans": support,
                "source_id": material["id"] if material else None})
        # Enumerate references only; semantic associations are all explicit above.
        numbered = list(re.finditer(r"资料\s*[1-9][0-9]*", answer))
        assert len(numbered) == len(occurrences), (case_id, numbered, occurrences)
        facts = []
        assert len(case["expected_facts"]) == len(explicit["facts"])
        for oracle, judgment in zip(case["expected_facts"], explicit["facts"], strict=True):
            assert oracle["id"] == judgment["id"]
            for reference in oracle["supporting_quotes"]:
                material = next(m for m in materials.values() if m["id"] == reference["material_id"])
                assert material["snippet"][reference["start"]:reference["end"]] == reference["quote"]
            supporting = [c for c in occurrences if oracle["id"] in c["supported_fact_ids"]
                          and c["support"] == "supported"]
            facts.append({**judgment, "expected_claim": oracle["claim"],
                "answer_span": span(answer, judgment.get("answer_quote")),
                "formal_supported": judgment["status"] == "correct" and any(c["formal"] for c in supporting),
                "human_readable_supported": judgment["status"] == "correct" and bool(supporting),
                "oracle_actual_material_spans": oracle["supporting_quotes"]})
        extras = []
        for extra in explicit["extra_claims"]:
            extras.append({**extra, "answer_span": span(answer, extra["answer_quote"])})
        core = explicit["decision_correct"] and all(f["status"] == "correct" for f in facts)
        error_free = not any(e["material_error"] for e in extras)
        no_bad_citations = all(c["support"] == "supported" for c in occurrences)
        human = core and error_free and no_bad_citations and all(f["human_readable_supported"] for f in facts)
        formal = core and error_free and no_bad_citations and all(f["formal_supported"] for f in facts)
        rows.append({"id": case_id, "record_sha256": digest(receipt_path),
            "transport_status": receipt["status"], "transport": "rwkvos_batch",
            "provider_finish_reason": generation["provider_finish_reason"], "termination_verified": False,
            "termination": "unknown", "raw_answer_sha256": sha256(raw.encode()).hexdigest(),
            "final_answer_span": {"start": bounds[0], "end": bounds[1], "unit": "unicode_code_points"},
            "final_answer": answer, "final_answer_sha256": sha256(answer.encode()).hexdigest(),
            "thinking_used_for_facts_or_citations": False, "expected_decision": case["expected_decision"],
            "actual_decision": explicit["decision"], "decision_correct": explicit["decision_correct"],
            "decision_reason": explicit["decision_reason"], "facts": facts,
            "citation_occurrences": occurrences, "extra_claims": extras, "scope": explicit["scope"],
            "observable_output_limitations": explicit.get("observable_output_limitations", []),
            "core_facts_and_decision_pass": core, "full_pass": formal,
            "exact_format_full_pass": formal, "human_readable_citation_full_pass": human})
    facts = [f for row in rows for f in row["facts"]]
    cites = [c for row in rows for c in row["citation_occurrences"]]
    run_summary = json.loads((run / "summary.json").read_text())
    summary = {"cases": 8, "required_facts": 28, "fact_status_counts": dict(Counter(f["status"] for f in facts)),
        "formal_supported_facts": sum(f["formal_supported"] for f in facts),
        "human_readable_supported_correct_facts": sum(f["human_readable_supported"] for f in facts),
        "exact_format_full_pass": sum(row["exact_format_full_pass"] for row in rows),
        "human_readable_citation_full_pass": sum(row["human_readable_citation_full_pass"] for row in rows),
        "exact_format_passed_ids": [r["id"] for r in rows if r["exact_format_full_pass"]],
        "human_readable_citation_passed_ids": [r["id"] for r in rows if r["human_readable_citation_full_pass"]],
        "core_facts_and_decision_pass": sum(row["core_facts_and_decision_pass"] for row in rows),
        "decision_correct": sum(row["decision_correct"] for row in rows),
        "formal_citation_occurrences": sum(c["formal"] for c in cites),
        "human_readable_citation_occurrences": len(cites),
        "human_readable_citation_support_counts": dict(Counter(c["support"] for c in cites)),
        "automatic_semantic_grading": False, "termination_unknown_cases": 8,
        "http_requests": run_summary["http_requests"], "model_calls": run_summary["model_calls"],
        "run_elapsed_ms": run_summary["elapsed_ms"]}
    paths = [run / name for name in ["manifest.json", "summary.json", "results.json", "frozen/fixtures.jsonl", "frozen/run_smoke.py"]]
    paths += [ROOT / "qa-protocol/materials/PROTOCOL.json", ROOT / "qa-protocol/materials/FROZEN.json",
              ROOT / "api-contract-v1/CONTRACT.json", ROOT / "api-contract-v1/FROZEN.json", Path(__file__)]
    bindings = [{"path": str(p.relative_to(ROOT)), "sha256": digest(p)} for p in paths]
    limitations = [
        "Eight exposed development material cases and 28 fixed facts; four Wiki-derived and four synthetic. No new blind or full-retrieval quality claim.",
        "The external API self-reports rwkv7-g1j-2.9b-20260831-ctx16384; no remotely attested weight hash, deployment revision or tokenizer hash. The unused local checkpoint does not prove provider identity.",
        "Provider finish_reason=stop is demonstrably unconditional at the output budget. completed denotes a returned valid body, not verified natural completion. All eight termination states remain unknown.",
        "The reviewer scores visible actual answer-span content, including visibly unfinished output; no inferred length/EOS flag, no thinking rescue, no output repair.",
        "A single contents[8] HTTP batch was used. Shared round-trip elapsed times do not measure individual item latency or isolated throughput.",
        "Formal bracket citations and separately reported unambiguous readable citations are different interfaces; neither source presence nor exact quote matching proves semantic support.",
        "This run changed model/provider/template/transport relative to old 13.3B experiments and is not an isolated model-size causal comparison."]
    review = {"schema": "native-materials-smoke-semantic-review-v1", "reviewed_at": datetime.now(timezone.utc).isoformat(),
        "reviewer": "Codex independent non-blind development review; not human expert acceptance",
        "run": run_name, "summary": summary, "criteria": protocol["criteria"], "bindings": bindings,
        "rows": rows, "limitations": limitations}
    write(target / "review.json", review)
    write(target / "judgments.json", judgments)
    write(target / "summary.json", summary)
    with (target / "rows.jsonl").open("x", encoding="utf-8") as out:
        for row in rows:
            out.write(json.dumps(row, ensure_ascii=False) + "\n")
    (target / "summary.md").write_text(
        f"# {run_name}：固定材料独立审阅\n\n"
        f"保留全部 8 题 / 28 项事实。正确 {summary['fact_status_counts'].get('correct',0)}，"
        f"遗漏 {summary['fact_status_counts'].get('omitted',0)}，错误 {summary['fact_status_counts'].get('incorrect',0)}。\n\n"
        f"正式引用完整通过 {summary['exact_format_full_pass']}/8；可明确辨认来源号的可读引用口径 "
        f"{summary['human_readable_citation_full_pass']}/8。正式支持事实 {summary['formal_supported_facts']}/28，"
        f"可读引用支持事实 {summary['human_readable_supported_correct_facts']}/28。\n\n"
        "8 项均仅确认响应返回；提供方 stop 不能证明自然结束，终止状态全部 unknown。"
        "没有从思考过程补答案，也没有把未明确拒答的指令回声算作拒答。详见逐题 rows.jsonl。\n", encoding="utf-8")
    write(target / "PROVIDER-LIMITATIONS.json", {"scope": run_name, "amends_old_protocol": False,
        "new_addendum_only": True, "bindings": bindings[-5:-1], "limitations": limitations})
    write(target / "FROZEN.json", {"schema": "explicit-review-freeze-v1", "run": run_name,
        "files": [{"path": p.name, "sha256": digest(p), "bytes": p.stat().st_size} for p in sorted(target.iterdir())],
        "bindings": bindings, "semantic_judgments_are_explicit_not_automatically_proven": True})
    print(json.dumps(summary, ensure_ascii=False))
    print("FROZEN", digest(target / "FROZEN.json"))


def fact(fid, status, answer_quote, reason):
    return {"id": fid, "status": status, "answer_quote": answer_quote, "reason": reason}


def judgments_v1():
    return [
        {"id":"smoke_001", "decision":"answer", "decision_correct":True,
         "decision_reason":"实际对资料作肯定回答，但其中两项未回答所问事实。", "scope":"四个IEC主体均保留；语言名称与执行模型目标未完成。",
         "facts":[fact("F1","omitted","IEC 61131-3标准定义了五种编程语言。","只说有五种，未列所需五个名称。"),
                  fact("F2","omitted","IEC 61499-1定义了功能模块类型","回答模块类型而非事件驱动替代循环执行。"),
                  fact("F3","correct","分别称为绿皮书、黄皮书和蓝皮书。","三种颜色名称完整。"),
                  fact("F4","correct","IEC 61508的安全生命周期包含16个阶段","阶段数正确。")],
         "citations":[], "extra_claims":[]},
        {"id":"smoke_002", "decision":"answer", "decision_correct":True,
         "decision_reason":"尝试肯定回答；数量、车型绑定与缺失站名另行计分。", "scope":"305系混入Marine Liner的223/5000信息；ICE2未回答所问Hamm站。",
         "facts":[fact("F1","correct","ICE-1列车不能与其他列车组合运行","不能重联符合实际材料1。"),
                  fact("F2","omitted",None,"没有Hamm/哈姆合体站名。"),
                  fact("F3","incorrect","JR九州305系电联车的编组为两节车厢","材料8明确六节，回答两节错误。"),
                  fact("F4","incorrect","其中一节为动力车（305系）","材料8明确中间四辆动力车；回答一辆，后续七节字母串也与此矛盾，不能救分。")],
         "citations":[], "extra_claims":[
             {"answer_quote":"两节动力车（402型）和一节乘客车厢（805型）组成", "material_error":True,
              "reason":"材料4前后车头型号402/808，回答两节均402；将试验型一辆乘客车卡泛化为通常编组。"},
             {"answer_quote":"例如柏林至汉堡的线路上，ICE-2列车会与另一列ICE-2合体", "material_error":True,
              "reason":"实际所给资料5举科隆/杜塞尔多夫到Hamm合体及汉诺威分体去汉堡，不支持这条另造合体例子。"},
             {"answer_quote":"另一节为无动力车（223系），车头为5000番台，车尾为223系", "material_error":True,
              "reason":"将Marine Liner车型参数错误归给305系。"},
             {"answer_quote":"编组形式为T-M-M-T-M-M-T", "material_error":True,
              "reason":"材料8六辆为两端无动力、中间四动力，回答七辆字母串且与自身两辆说法冲突。"}]},
        {"id":"smoke_003", "decision":"instruction_echo", "decision_correct":False,
         "decision_reason":"仅复述补齐三格指令，没有数据或明确拒答。", "scope":"未实际恢复Ghost筹资三目标。",
         "facts":[fact(f"F{i}","omitted",None,"实际正文未给出该筹资数据。") for i in range(1,4)],
         "citations":[], "extra_claims":[]},
        {"id":"smoke_004", "decision":"answer", "decision_correct":True,
         "decision_reason":"尝试回答工作站参数，错误/额外内容另计。", "scope":"保留3.5工作站主体，但恢复已撤回发布日期/打印/TCPIP背景且大量重复。",
         "facts":[fact("F1","correct","支持客户端并发访问文件服务器：10个","确实给出正确10客户端上限。"),
                  fact("F2","incorrect","支持Mac客户端：是","原文明确不支持，正反颠倒。"),
                  fact("F3","correct","开发代号：Daytona","前文完整给出英文代号；尾部重复截断不取消已出现正确值。")],
         "citations":[], "extra_claims":[
             {"answer_quote":"发布日期：1995年9月21日", "material_error":True,"reason":"材料1为1994年9月21日；同时属于用户明确撤回的旁支。"},
             {"answer_quote":"共享打印机支持：不支持", "material_error":True,"reason":"所给原文写通过LPR共享打印机，回答反向且用户已排除打印话题。"},
             {"answer_quote":"文件共享工具：Windows NT File Sharing", "material_error":True,"reason":"实际材料没有给出此指定工具名称，不能从FTP文件分享推造产品工具名。"}],
         "observable_output_limitations":["大量模板循环；可见正文末尾为未填值的‘开发代号：’。provider仍报stop，不能凭此确定实际length/EOS。"]},
        {"id":"smoke_005", "decision":"answer", "decision_correct":True,
         "decision_reason":"六项都实际回答。", "scope":"同文档六块均使用，未遗漏后续节。",
         "facts":[fact(f"F{i}","correct",q,"数值/单位/否定状态与对应说明书小节一致。") for i,q in enumerate(
             ["12 V","被动散热，不装风扇","68 °C","每14天一次","kPa","**出厂时远程上传功能**：关闭"],1)],
         "citations":[{"number":i,"label":f"（资料 {i}）","formal":False,"support":"supported",
             "supported_fact_ids":[f"F{i}"],"claim_quote":q,"source_quotes":[source],
             "reason":"圆括号来源号可明确绑定当前字段；实际该小节直接支持，不是API正式方括号。"}
             for i,(q,source) in enumerate(zip(
                ["12 V","被动散热，不装风扇","68 °C","每14天一次","kPa","**出厂时远程上传功能**：关闭"],
                ["栖光 R6 记录仪说明书，第1节：额定输入电压为12 V。","栖光 R6 记录仪说明书，第2节：冷却方式为被动散热，不装风扇。",
                 "栖光 R6 记录仪说明书，第3节：报警温度为68 °C。","栖光 R6 记录仪说明书，第4节：滤网检查周期为每14天一次。",
                 "栖光 R6 记录仪说明书，第5节：气压记录统一使用kPa。","栖光 R6 记录仪说明书，第6节：出厂时远程上传功能关闭。"],strict=True),1)], "extra_claims":[]},
        {"id":"smoke_006", "decision":"answer", "decision_correct":True,
         "decision_reason":"按长说明尾部实际回答两个字段。", "scope":"维护码逐字准确，未将中段背景当最终参数。",
         "facts":[fact("F1","correct","恢复键需要连续按住11秒","11秒正确。"),
                  fact("F2","correct","维护码是LARCH-482","代码逐字准确。")], "citations":[], "extra_claims":[]},
        {"id":"smoke_007", "decision":"answer", "decision_correct":True,
         "decision_reason":"三个对象年份各两项实际回答。", "scope":"对象/年份/体积与质量单位及离线否定均保留。",
         "facts":[fact(f"F{i}","correct",q,"原对象年份绑定、数值单位或离线状态正确。") for i,q in enumerate(
             ["额定流量为8 L/min","必须联网运行，不能离线","额定流量改为6 L/min","支持离线运行",
              "额定质量流量为4 kg/min","**B款2023年**：额定质量流量为4 kg/min，不能离线运行"],1)],
         "citations":[], "extra_claims":[]},
        {"id":"smoke_008", "decision":"instruction_echo", "decision_correct":False,
         "decision_reason":"回声重述‘没有资料就明确说明资料不足’这一用户指令，附逐字证据[]；没有实际向用户断言资料不足/无法给出销量。不能将引用的条件指令当已执行拒答。",
         "scope":"无编造销量，但未交付实际拒答。", "facts":[], "citations":[], "extra_claims":[]},
    ]

if __name__ == "__main__":
    build("materials-api-v1", judgments_v1())
