# 外部 2.9B Wiki 基线：160 次 Reader 调用诊断

本报告只读重放 `wiki-api-v1-eos` 的冻结记录，没有模型调用、重新检索、输出修补或评分变更。它诊断的是服务自报的 `rwkv7-g1j-2.9b-20260831-ctx16384` 外部端点；没有把旧 13.3B 或未运行的本地权重当成该端点的模型身份。

**主要结论：两道真正进入 Reader 的题，所需 8/8 事实均已在实际输入中。CAN FD 的两块有效正文因输出语法错误被拒绝；四份开发文档的六次有效正文输入全部返回 `NONE`。这两题的零证据不能用候选漏召回或总来源预算 80 截断解释。**

全 8 题 / 29 事实保留：另外六题在 Planner 解析阶段停止，涉及 21 事实，没有 Reader 调用。不能把它们并入 Reader 的错误率，也不能据本次未执行的检索推断数据库缺少文章。

| 题目 | Reader 调用 | 纯 NONE | 语法错误 | 未知 E 编号 | 必需事实确实到达 Reader | 最后选中 |
|---|---:|---:|---:|---:|---:|---:|
| held_004 | 80 | 67 | 12 | 1 | 4/4 | 0 |
| held_010 | 0 | 0 | 0 | 0 | 0/4 | 0 |
| held_012 | 0 | 0 | 0 | 0 | 0/4 | 0 |
| held_014 | 0 | 0 | 0 | 0 | 0/4 | 0 |
| held_016 | 80 | 79 | 1 | 0 | 4/4 | 0 |
| held_017 | 0 | 0 | 0 | 0 | 0/3 | 0 |
| held_019 | 0 | 0 | 0 | 0 | 0/3 | 0 |
| held_021 | 0 | 0 | 0 | 0 | 0/3 | 0 |

160 次中共有 146 次纯 `NONE`，13 次非法选择语法、1 次引用本次不存在的 E 编号，0 次合法非空选择。**146 个 NONE 不能当成 146 个语义错误。** 本次逐事实核实了 8 个正向来源调用：2 个格式失败、6 个错误 NONE。其余 152 次只完成输入/输出/语法核验，没有冒充穷尽语义负例标注。

## 按事实定位

| 题目 / 事实 | 实际 Reader 排名 | 原文内容与失败边界 |
|---|---|---|
| held_004 F1：11 / 29 位 ID | 4 | 正文明确两种 ID 位数；输出为改写正文，未按 E 编号协议提交。 |
| held_004 F2：最多 64 字节 | 2、4 | 两块均明确 64；一块输出 `E1: ...64字节`，另一块改写正文，均不合法。 |
| held_004 F3：5 Mbit/s | 2 | 原文“將資料率擴展到5Mbit/s”；输出答值 5 而非选择编号。 |
| held_004 F4：电气与组态条件 | 4 | 节点个数、总线长、电磁因素都在原文；输出改写、局部乱码，不合法。 |
| held_016 F1：XML | 1、5 | 两处都明确 XML 文件，均纯 NONE。 |
| held_016 F2：WinJS 1.0 / Windows 8 | 2 | 27 字符短正文给 Windows 8；实际父级上下文包含 `### WinJS 1.0`。模型看到了两者，仍纯 NONE。 |
| held_016 F3：Windows ogg / 手机 m4a | 35 | 同一原文明确双平台及格式，纯 NONE。 |
| held_016 F4：Windows Vista | 8、64 | 排名 8 明确仅支持 Vista 或更新系统；排名 64 直接写“首次適用於Windows Vista”，均纯 NONE。 |

原文身份按 page ID、revision 和整篇正文 SHA 对应冻结金标；八项所需金标证据集合都能在实际输入正文/父级标题中逐字找到。另行人工语义判断保存在 `verified_support_for`，含片段内与整篇 Unicode 字符偏移。这里的“人工”指 Codex 非盲逐项审阅，并非真人专家验收；逐字匹配自身不证明语义支持。WinJS 标题是实际可见父级上下文，不是伪造的 E2，也没有把候选排序 148 的另一个标题块当成送入 Reader 的单独来源。

## 四个原始实例

### held_004，排名 2：答对部分值也不能当合法证据选择

- 原始模型收据：[`000009.completed.json`](../../wiki-api-v1-eos/model-calls/000009.completed.json)；`trace.prompt` 是完整实际发送字符串，`raw_text` 是原始输出。
- 完整来源 / prompt / output 副本：[example-held_004-rank-02.json](example-held_004-rank-02.json)。
- 原题完整收据：[`held_004.json`](../../wiki-api-v1-eos/completed/held_004.json)，来源指针 `/response/retrieval/candidates/1`，模型指针 `/response/generation/model_calls/2`。
- 页面字符范围 `9:471`，原文 SHA `745db75f0077179c6155fddd9705c0feb823ac7ed42ae1c322d6730d9834bb66`。

模型原输出：

```text
E1: CAN FD支持的两种消息ID位数: 11位, 29位
E1: CAN FD每帧最大实际数据字节数: 64字节
E1: CAN FD条目给出的最高资料率（Mbit/s）: 5
E1: CAN FD最高速率受哪些线路条件影响: 线路条件
```

### held_004，排名 4：有效原文被改写，不能只抽 E 或宽松接收正文

- 原始模型收据：[`000011.completed.json`](../../wiki-api-v1-eos/model-calls/000011.completed.json)；`trace.prompt` 是完整实际发送字符串，`raw_text` 是原始输出。
- 完整来源 / prompt / output 副本：[example-held_004-rank-04.json](example-held_004-rank-04.json)。
- 原题完整收据：[`held_004.json`](../../wiki-api-v1-eos/completed/held_004.json)，来源指针 `/response/retrieval/candidates/3`，模型指针 `/response/generation/model_calls/4`。
- 页面字符范围 `484:1091`，原文 SHA `06d6e3d54549fca44c53f242583115021dfd6aa19ff77e5b4d93343a0a87783e`。

模型原输出：

```text
11位元以及29位元的訊息ID，每一個CAN頁框（frame）的實際資料量可以超過傳統CAN限制的8位元組，最大可到64位元組。CAN FD的資料率（每秒可以傳輸的位元數）最高可到傳統CAN的5倍。CAN FD通訊協定也有其他性能的提昇，例如比較容易偵測接收到CAN訊息的錯誤，也可以用軟體動態選擇較快或是較慢的資料率。在同一個CAN網路上的一些感測器可以用較的資料率，有些感感測器則用較慢的資料率傳送實際資料。CAN BUS的電氣條件及組態（例如節點個數、總線長、或是其他電磁因素）最快速率會受到CAN電氣條件及組態（例如節點個數、總線長、或是其他電磁因素）的影響，因此這些因素也會影響CAN FD可達到的最快速率。
```

### held_016，排名 2：极短、带准确版本父级标题的正文仍被判 NONE

- 原始模型收据：[`000090.completed.json`](../../wiki-api-v1-eos/model-calls/000090.completed.json)；`trace.prompt` 是完整实际发送字符串，`raw_text` 是原始输出。
- 完整来源 / prompt / output 副本：[example-held_016-rank-02.json](example-held_016-rank-02.json)。
- 原题完整收据：[`held_016.json`](../../wiki-api-v1-eos/completed/held_016.json)，来源指针 `/response/retrieval/candidates/1`，模型指针 `/response/generation/model_calls/2`。
- 页面字符范围 `772:799`，原文 SHA `9a5cf68fcbdf09b554257d8a84fbd310ea5303f3c97dfdfa77e06d09ecce37ca`。

模型原输出：

```text
NONE
```

### held_016，排名 35：规划漏一部分目标，但完整问题与双平台事实仍在输入

- 原始模型收据：[`000123.completed.json`](../../wiki-api-v1-eos/model-calls/000123.completed.json)；`trace.prompt` 是完整实际发送字符串，`raw_text` 是原始输出。
- 完整来源 / prompt / output 副本：[example-held_016-rank-35.json](example-held_016-rank-35.json)。
- 原题完整收据：[`held_016.json`](../../wiki-api-v1-eos/completed/held_016.json)，来源指针 `/response/retrieval/candidates/34`，模型指针 `/response/generation/model_calls/35`。
- 页面字符范围 `508:852`，原文 SHA `a5cc4ced9061c4d72f95ec98bf7e304aa3d59b5947943d3e6488d1d8e36152e4`。

模型原输出：

```text
NONE
```

## 任务遗漏和协议错误不能混为一类

`held_004` 四条检索任务保留了四个目标，八块 CAN FD 文章全部进入 Reader；其中两块有本题事实。部分只有标题的输入反而生成 11/12 位、8 字节等无据或错误值，且出现长数字循环。外链块返回 `E1, E2, E3, E4`，实际上只有 E1。因此不能用“从任意输出抽 E1”或“看起来像答案就接收”作为修复，格式放宽会同时引入错误证据。

`held_016` 的规划确有独立问题：RPG Maker MV 检索式只剩“手机版音乐格式”，遗漏 Windows 目标，还额外增加两条泛泛“开发文档”检索式。但所有 80 次 Reader 提示词仍带完整最新问题，明确要求 Windows 和手机版分别回答；排名 35 同时包含 ogg/m4a 原文，原指令也明说“只需支持任务中的一部分”。本次记录证明模型丢弃了这段正向证据，不能证明它内心为何选择 NONE。也不能把 WinJS 排名 116 的其他标题块误认为首个有效命中：真正的 WinJS 1.0 发布正文在排名 2，且标题父级已送入。

当前 `task_units` 只要求“E 编号列表或单个 NONE”，不输出逐字段覆盖表。故不能从 NONE 再细分出模型具体忽略了哪个字段，或把旧 `fields` 的逐字段解析错误强套到这里。016 唯一格式错误是另一 RPG Maker MV 片段输出 `NONE,NONE,NONE,NONE,NONE`，不是那块音乐格式正向正文。

## 下一步可据此选择的验证方向

1. 将“正向来源召回”和“严格语法完成”分开验证，保留这两类正向失败及仅标题/无关正文负例；只降低 JSON 错误率不足以解决错误 NONE。可以评估更短且只有一个判定职责的任务协议，但本报告没有验证任何新提示词有效。
2. 子问题与对象/限定的绑定应保持明确，并保留完整有效任务，避免又一次语义改写丢失 Windows 一侧。若改按子问题单独选择，应统一应用全部题，不能按题选用旧 queries 或 fields。
3. 继续保持来源 ID、E 编号、原文范围和完整 raw。不要自动接收未知编号、改写值、thinking 或循环尾部，不能用一次诊断回填旧答案。
4. 对这两题，先扩大来源预算没有得到记录支持：八个必需事实早已到达。WinJS 的短正文加父级上下文已实现，仍返回 NONE，也不是单靠拼接标题就能宣称解决。

## 重放与限制

运行 `python3 ../build_wiki_api_reader_diagnosis.py` 会只读原记录，并要求输出目录尚不存在；不覆盖本次冻结诊断。脚本复用 SHA 绑定源码中两个纯函数，重建全部 160 个 Reader 提示词，核对来源/单元/父级上下文 SHA、完整 history 和当前问题，复核单次 HTTP 原始字节 / 哈希 / 槽位到 raw 的映射，再按冻结严格解析器重算分类。源收据保存时有 JSON key 排序；重建仅从原 wire 还原字典序，先验证所有值完全一致，没有改 prompt 字节。

外部提供方的 `stop` 已证不能证明自然终止。160 条均保留 `termination_verified=false`；输入 token 数、fits 和远端实际长度边界未知，不能把循环输出称作已证 length，也不能声称 16K 窗口完全核验。共享 HTTP 的槽位映射已核，但未虚构每槽独立 HTTP 或可靠每项终止原因。6 道 Planner 失败题不作下游反事实推断。旧 8/29 语义分数及原始输出保持不变。
