"""Offline receipt/source/selection audit. Explicit semantic observations are not a new scorer."""
import ast
import base64
import collections
import hashlib
import json
import pathlib
import re
from types import SimpleNamespace

B = pathlib.Path(__file__).resolve().parents[1]
R = B / "wiki-api-v1-eos"
OUT = B / "review/wiki-api-reader-diagnosis-v1"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_text())


def write(path, value):
    with path.open("x", encoding="utf-8") as file:
        file.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def bind(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(B)), "sha256": sha(data), "bytes": len(data)}


# These are explicit reviewer decisions about the actual input, not keyword scoring.
# Evidence strings are checked for literal presence solely to locate those decisions.
SUPPORT = {
    ("held_004", 2): {
        "F2": "較大的資料頁框（最大到64位元組（byte），是原來CAN標準的8倍）",
        "F3": "將資料率擴展到5Mbit/s",
    },
    ("held_004", 4): {
        "F1": "CAN FD支援11位元以及29位元的訊息ID",
        "F2": "最大可到64位元組",
        "F4": "其最快速率會受到CAN電氣條件及組態（例如節點個數、總線長、或是其他電磁因素）的影響",
    },
    ("held_016", 1): {"F1": "NativeScript使用XML文件定義不同平台的用戶界面"},
    ("held_016", 2): {"F2": "WinJS的首个版本。它随Windows 8发布。"},
    ("held_016", 5): {"F1": "NativeScript使用XML文件定義不同平台的用戶界面"},
    ("held_016", 8): {"F4": "Media Foundation僅支援Windows Vista或更新的系統"},
    ("held_016", 35): {"F3": "Windows版使用ogg格式、手機板使用m4a格式"},
    ("held_016", 64): {"F4": "Media Foundation首次適用於Windows Vista"},
}


def main():
    assert not OUT.exists(), "Never overwrite a completed diagnosis"
    fixtures = [json.loads(line) for line in (R / "frozen/fixtures.jsonl").read_text().splitlines()]
    source_manifest = load(R / "source-manifest.json")
    for name, metadata in source_manifest.items():
        data = (R / "source" / name).read_bytes()
        assert sha(data) == metadata["sha256"] and len(data) == metadata["bytes"]
    parser_path = R / "source/src/llamaindex_retrieval/rwkv_pipeline.py"
    tree = ast.parse(parser_path.read_text())
    wanted = {"parse_task_selections", "task_resolver_prompt"}
    functions = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in wanted]
    assert len(functions) == 2
    scope = {"re": re, "json": json, "SourceItem": object}
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(parser_path), "exec"), scope)
    model_receipts = {}
    for path in sorted((R / "model-calls").glob("*.completed.json")):
        row = load(path)
        cid = row["trace"]["call_id"]
        assert cid not in model_receipts
        model_receipts[cid] = (path, row)
    inventory, cases, examples = [], [], []
    bindings = {str(path): bind(path) for path in [
        R / "frozen/fixtures.jsonl", R / "source-manifest.json", R / "manifest.json",
        R / "settings.json", parser_path,
        B / "review/wiki-api-v1-eos/FROZEN.json", B / "api-contract-v1/FROZEN.json",
    ]}
    fact_rows = []
    example_keys = {("held_004", 2), ("held_004", 4), ("held_016", 2), ("held_016", 35)}
    for fixture in fixtures:
        cid = fixture["id"]
        casepath = R / "completed" / (cid + ".json")
        bindings[str(casepath)] = bind(casepath)
        response = load(casepath)["response"]
        retrieval = response["retrieval"]
        candidates = retrieval.get("candidates", [])
        sources = {s["id"]: (rank, s) for rank, s in enumerate(candidates, 1)}
        calls = [(i, c) for i, c in enumerate(response["generation"]["model_calls"])
                 if c.get("stage") == "resolver"]
        actual_ids = [c["source_id"] for _, c in calls]
        assert len(actual_ids) == len(set(actual_ids))
        assert actual_ids == retrieval.get("resolver_source_ids", [])
        case_inventory = []
        for case_index, call in calls:
            rank, source = sources[call["source_id"]]
            source_text = source["snippet"]
            assert sha(source_text.encode()) == call["source_sha256"]
            assert sha(source_text.encode()) == source["metadata"]["source_span"]["sha256"]
            units = []
            for u in call["units"]:
                value = source_text[u["start"]:u["end"]]
                assert sha(value.encode()) == u["sha256"]
                units.append(SimpleNamespace(text=value))
            assert len(units) == 1 and call["units"][0]["start"] == 0
            assert call["units"][0]["end"] == len(source_text)
            for context in source["metadata"].get("context_spans", []):
                assert sha(context["text"].encode()) == context["sha256"]
            task = json.dumps({"history": fixture["history"], "latest_question": fixture["question"]}, ensure_ascii=False)
            # Receipt pretty-printing sorts metadata keys. Recover the original
            # JSON insertion order from the wire text, while checking its values
            # against the complete persisted source before rebuilding bytewise.
            actual_message = call["messages"][0]["content"]
            wire_context = json.loads(actual_message.split("\n原文父级上下文：", 1)[1].split("\n原文：", 1)[0])
            assert wire_context == source["metadata"].get("context_spans", [])
            ordered_source = dict(source, metadata=dict(source["metadata"], context_spans=wire_context))
            rebuilt = scope["task_resolver_prompt"](task, retrieval["active_tasks"], SimpleNamespace(**ordered_source), units)
            assert call["messages"] == [{"role": "user", "content": rebuilt}]
            assert call["prompt"] == "User: " + rebuilt + "\n\nAssistant: <think></think>"
            assert sha(call["prompt"].encode()) == call["prompt_sha256"]
            raw = call["raw_text"]
            assert sha(raw.encode()) == call["raw_text_sha256"]
            assert call["envelope"] == {"valid": True, "answer_span": {"start": 0, "end": len(raw), "unit": "unicode_code_points"}, "raw_text_modified": False}
            assert call["termination_verified"] is False and call["termination"] == "unknown"
            assert call["budget"]["input_tokens"] is None and call["budget"]["fits"] is None
            modelpath, modelrow = model_receipts[call["call_id"]]
            assert modelrow["raw_text"] == raw and modelrow["case_id"] == cid
            assert modelrow["trace"]["prompt"] == call["prompt"]
            startpath = pathlib.Path(str(modelpath).replace(".completed.json", ".started.json"))
            startrow = load(startpath)
            assert startrow["messages"] == call["messages"] and startrow["case_id"] == cid
            for path in [modelpath, startpath]:
                bindings[str(path)] = bind(path)
            assert len(call["http"]) == 1
            http = call["http"][0]
            request_bytes = base64.b64decode(http["request_body_base64"], validate=True)
            response_bytes = base64.b64decode(http["response_body_base64"], validate=True)
            assert sha(request_bytes) == http["request_body_sha256"]
            assert sha(response_bytes) == http["response_body_sha256"]
            payload = json.loads(request_bytes)
            body = json.loads(response_bytes)
            assert payload == http["payload"] and body == http["response_json"]
            assert http["http_status"] == 200 and http["response_body_complete"] is True
            assert payload["contents"][call["batch_index"]] == call["prompt"]
            choices = body["choices"]
            assert sorted(x["index"] for x in choices) == list(range(len(payload["contents"])))
            choice = next(x for x in choices if x["index"] == call["batch_index"])
            assert choice["message"]["content"] == raw
            assert choice["finish_reason"] == call["provider_finish_reason"]
            error = None
            try:
                selected = scope["parse_task_selections"](raw, len(units))
            except ValueError as exc:
                error = str(exc)
                selected = []
            assert error == call.get("parse_error")
            if error is None:
                assert [f"E{x}" for x in selected] == call["selected_units"]
            assert not selected
            outcome = "pure_NONE" if raw == "NONE" else "unknown_unit" if error == "unknown evidence unit" else "invalid_selection_syntax"
            supports = []
            for fid, quote in SUPPORT.get((cid, rank), {}).items():
                at = source_text.index(quote)
                supports.append({"fact_id": fid, "quote": quote,
                    "source_span": {"start": at, "end": at + len(quote), "unit": "unicode_code_points"},
                    "page_span": {"start": source["metadata"]["source_span"]["start"] + at,
                                  "end": source["metadata"]["source_span"]["start"] + at + len(quote), "unit": "unicode_code_points"},
                    "unit_id": "E1", "basis": "explicit Codex non-blind semantic review of actual source"})
            if cid == "held_016" and rank == 2:
                assert any(x["text"] == "### WinJS 1.0\n" for x in source["metadata"]["context_spans"])
                supports[0]["requires_context"] = "Actual prompt parent heading ### WinJS 1.0; heading is not an additional selectable E unit."
            entry = {"case_id": cid, "reader_rank": rank, "call_id": call["call_id"],
                "case_path": str(casepath.relative_to(B)), "case_pointer": f"/response/generation/model_calls/{case_index}",
                "source_pointer": f"/response/retrieval/candidates/{rank - 1}",
                "model_completed_path": str(modelpath.relative_to(B)), "model_started_path": str(startpath.relative_to(B)),
                "source_id": source["id"], "title": source["title"], "page_id": source["metadata"]["page_id"],
                "source_span": source["metadata"]["source_span"], "source_text_sha256": call["source_sha256"],
                "units": call["units"], "prompt_sha256": call["prompt_sha256"],
                "raw_text": raw, "raw_text_sha256": call["raw_text_sha256"],
                "batch_id": call["batch_id"], "batch_index": call["batch_index"],
                "request_body_sha256": http["request_body_sha256"], "response_body_sha256": http["response_body_sha256"],
                "parse_outcome": outcome, "parse_error": error, "selected_units": [],
                "verified_support_for": supports,
                "other_support_status": "not exhaustively semantically classified" if not supports else None,
                "raw_units_and_prompt_and_http_verified": True, "termination_verified": False,
                "gold_not_sent": all(k not in payload for k in ["oracle", "gold", "expected_facts"])}
            inventory.append(entry)
            case_inventory.append(entry)
            if (cid, rank) in example_keys:
                examples.append({"case_id": cid, "reader_rank": rank, "source": source,
                    "prompt": call["prompt"], "raw_output": raw, "diagnostic": entry})
        counts = dict(collections.Counter(x["parse_outcome"] for x in case_inventory))
        fact_detail = []
        for fact in fixture["oracle"]["required_facts"]:
            supports = [x for x in case_inventory if any(p["fact_id"] == fact["id"] for p in x["verified_support_for"])]
            coverage = []
            for rank, source in enumerate(candidates, 1):
                channels = [{"channel": "snippet", "text": source["snippet"]}]
                channels += [{"channel": "parent_context", "text": c["text"]} for c in source["metadata"].get("context_spans", [])]
                for set_index, evidence_set in enumerate(fact["evidence_sets"]):
                    matched = []
                    for evidence in evidence_set:
                        md = source["metadata"]
                        if md.get("external_id") != evidence["document_id"] or md.get("version") != evidence["revision_id"] or md.get("source_text_sha256") != evidence["body_sha256"]:
                            break
                        locations = [{"channel": channel["channel"], "start": channel["text"].find(evidence["quote"])} for channel in channels if evidence["quote"] in channel["text"]]
                        if not locations:
                            break
                        matched.append({"gold_quote": evidence["quote"], "locations": locations})
                    if len(matched) == len(evidence_set):
                        coverage.append({"candidate_rank": rank, "reader_received": source["id"] in actual_ids,
                                         "source_id": source["id"], "evidence_set": set_index, "matches": matched})
            detail = {"case_id": cid, "fact_id": fact["id"], "claim": fact["claim"],
                      "exact_gold_set_coverage": coverage, "verified_semantic_support_ranks": [x["reader_rank"] for x in supports],
                      "selected_support_count": 0,
                      "loss_at": "planner_not_parsed_no_retrieval" if not calls else "reader_protocol_rejection" if cid == "held_004" else "reader_false_NONE"}
            if calls:
                assert any(x["reader_received"] for x in coverage)
                assert supports
            fact_detail.append(detail)
            fact_rows.append(detail)
        cases.append({"case_id": cid, "required_facts": len(fact_detail), "generation_status": response["generation"]["status"],
                      "candidate_count": len(candidates), "reader_calls": len(calls), "parse_counts": counts,
                      "verified_positive_source_calls": sum(bool(x["verified_support_for"]) for x in case_inventory),
                      "selected_source_count": 0, "writer_source_count": len(response["sources"]),
                      "reader_fact_coverage": sum(bool(x["verified_semantic_support_ranks"]) for x in fact_detail),
                      "missing_fact_at_candidate_or_source_budget": 0 if calls else None,
                      "active_tasks": retrieval.get("active_tasks"),
                      "scope_observation": "All four requested targets retained." if cid == "held_004" else
                        "Plan queries omit RPG Maker MV Windows music-format target and add two broad development-document queries; full latest question still reaches every Reader, including Windows/mobile distinction." if cid == "held_016" else
                        "No Reader call exists: planner parsing failed. Candidate availability cannot be inferred from this run."})
    assert len(inventory) == 160
    assert collections.Counter(x["parse_outcome"] for x in inventory) == {"pure_NONE": 146, "invalid_selection_syntax": 13, "unknown_unit": 1}
    assert sum(bool(x["verified_support_for"]) for x in inventory) == 8
    report = {"schema": "rwkvos-reader-diagnosis-v1", "run": str(R.relative_to(B)),
        "reviewer": "Codex independent non-blind diagnostic review; no model calls or original score changes",
        "model_identity": "External service reported rwkv7-g1j-2.9b-20260831-ctx16384; remote weights/revision unverified",
        "counts": {"cases": 8, "required_facts": 29, "planner_blocked_cases": 6,
                   "planner_blocked_facts": 21, "reader_cases": 2, "reader_calls": 160,
                   "pure_NONE": 146, "syntax_errors": 13, "unknown_unit_errors": 1,
                   "valid_nonempty_selections": 0, "verified_positive_source_calls": 8,
                   "positive_calls_rejected_by_protocol": 2, "positive_calls_false_NONE": 6,
                   "required_facts_in_reader_cases": 8, "all_required_facts_reached_reader": 8,
                   "fact_losses_explained_by_missing_candidates_or_source_budget_in_reader_cases": 0},
        "cases": cases, "facts": fact_rows,
        "scope_limitations": [
            "Only eight explicitly reviewed source calls are labeled positive; the other 152 are not assigned exhaustive semantic relevance judgments.",
            "146 NONE values are not treated as 146 mistakes. Six verified positive NONE calls are a lower bound and cover all four held_016 facts.",
            "For WinJS the body and actual parent heading jointly resolve 1.0. The parent heading is visible model input, not an E unit.",
            "Input tokens, fits, deployed model revision, termination and length completion remain unverified. Reported stop does not prove natural completion.",
            "Observed output shape proves the failure boundary, not the model's internal causal reason. No raw-output rescue or downstream quality improvement is claimed.",
            "Gold exact matches establish arrival, while explicit reviewer decisions establish semantic support. No new scoring rule or score update is applied.",
        ],
        "recommendations": [
            "Evaluate a smaller selection-only task contract using positive and negative sources together; preserve strict existing IDs. Format-only success must be accompanied by recall on verified positive inputs.",
            "Do not silently accept E1: answer values or extract IDs from prose. CAN heading-only outputs invent incorrect values and E1,E2,E3,E4 includes unknown IDs.",
            "Test a universal binding between each independent query and its requested target or preserve whole-task context explicitly; avoid another lossy rewrite. RPG Windows omission is real but does not alone explain the observed NONE.",
            "Keep short version body plus parent headings together in input. WinJS already satisfies this condition and still fails, so additional retrieval depth is not a demonstrated fix for these two cases.",
            "If investigating post-JSON placement or state tuning, freeze full positive/negative receipts before new calls and retain original parser and first-attempt failures. These offline observations do not establish improvement.",
        ], "bindings": list(bindings.values())}
    OUT.mkdir(parents=True)
    write(OUT / "DIAGNOSIS.json", report)
    with (OUT / "calls.jsonl").open("x", encoding="utf-8") as file:
        for row in inventory:
            file.write(json.dumps(row, ensure_ascii=False) + "\n")
    for example in examples:
        write(OUT / f"example-{example['case_id']}-rank-{example['reader_rank']:02d}.json", example)
    print(json.dumps({"output": str(OUT), "counts": report["counts"], "checks": "160 source/unit/prompt/rawHTTP/strict-parser chains verified"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
