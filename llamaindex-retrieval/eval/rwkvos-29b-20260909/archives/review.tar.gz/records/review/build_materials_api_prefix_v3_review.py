"""Explicit prefix control review; final JSON body is evaluated in full."""
from copy import deepcopy
import json
from pathlib import Path
from _materials_prefix_serializer import ROOT, build, digest, fact, write

run = ROOT / "materials-api-prefix-v3"
base = ROOT / "materials-api-eos-v2"
cases = {c["id"]: c for c in [json.loads(x) for x in (run / "frozen/fixtures.jsonl").read_text().splitlines()]}
judgments = deepcopy(json.loads((ROOT / "review/materials-api-eos-v2/judgments.json").read_text()))

def body(cid):
    g = json.loads((run / "completed" / f"{cid}.json").read_text())["response"]["generation"]
    return g["raw_model_answer"][g["answer_span"][0]:g["answer_span"][1]]

def actual(cid, number):
    return cases[cid]["materials"][number - 1]["snippet"]

def cite(number, label, claim, status, fact_ids, quotes, reason):
    return {"number": number, "label": label, "formal": False, "support": status,
            "supported_fact_ids": fact_ids, "claim_quote": claim, "source_quotes": quotes, "reason": reason}

judgments[0] = {"id":"smoke_001", "decision":"answer", "decision_correct":True,
    "decision_reason":"实际输出answer及自生成evidence JSON，按完整真实正文判断，不能只抽answer键忽略其他事实或错误。",
    "scope":"未完整回答四卡：编程语言列表错误、颜色缺失；新增大量未问章节且伪称来源正文。",
    "facts":[
        fact("F1","incorrect","指令列表语言（IL）、结构化文本语言（STL）、功能块图（FBD）、顺序功能图（SFC）、结构化文本语言（STL）","把STL重复成第五种，漏阶梯图，称五种的列表错误。后续自生成资料段中的流程/状态/数据流图不补救。"),
        fact("F2","correct","IEC61131的循环执行模型被事件驱动模型所取代。","真实最终正文evidence[资料2].text明确给出正确模型替换，未从thinking读取。"),
        fact("F3","omitted",None,"整个真实正文没有DLMS三书颜色。"),
        fact("F4","correct","IEC 61508标准定义的安全生命周期包含16个阶段","真实最终正文evidence[资料1].text明确给出正确阶段数。")],
    "citations":[
        cite(1,"资料 1","IEC 61508标准定义的安全生命周期包含16个阶段","partially_supported",["F4"],
             [actual("smoke_001",1)[401:455]],"该源支持16阶段及多数概述；整个附着text同时扩称所有功能安全标准的基础，实际片段没有该全称量化。不能把该模型重写text当输入原文。"),
        cite(2,"资料 2","IEC61131的循环执行模型被事件驱动模型所取代。","partially_supported",["F2"],
             [actual("smoke_001",2)[167:309]],"实际资料2支持事件驱动替换，但不支持此label下额外虚构全名/第三第四部分等文本。"),
        cite(3,"资料 3","IEC 61131-3标准定义了可编程逻辑控制器（PLC）的语言，包括指令列表图、结构化文本图、功能块图、顺序功能图、流程图、状态图、数据流图","partially_supported",[],
             [actual("smoke_001",3)[53:259]],"部分编程名称在实际资料3存在，但模型加入流程/状态/数据流图并长循环，未忠实列出所问五种，不能给F1支持。")],
    "extra_claims":[
        {"answer_quote":"IEC61499 全名为《电气/电子/可编程电子系统的功能模块网络》","material_error":True,"reason":"实际输入资料没有这个正式全名；模型放进自生成text当作源文。"},
        {"answer_quote":"IEC61499-3定义了IEC61499的程序组织单元","material_error":True,"reason":"实际输入资料10第三部分为2008年撤销的教程信息，不能改成程序组织单元规范。"},
        {"answer_quote":"IEC61499-4定义了IEC61499的开发环境","material_error":True,"reason":"实际资料12第四部分是兼容文件规则，不是模型新增的开发环境章节。"},
        {"answer_quote":"流程图、状态图、数据流图","material_error":True,"reason":"把非所列五种PLC语言项扩入定义列表并重复，与实际资料3不符。"}],
    "observable_output_limitations":["最终JSON未闭合，尾部数据流图长循环；保留原文及unknown终止，不推定provider length。"]}

judgments[2] = {"id":"smoke_003", "decision":"answer", "decision_correct":True,
    "decision_reason":"真正恢复Ghost博客平台三项筹资数据并给出明确可读出处。",
    "scope":"正确Ghost主体、目标/实际/用时及英镑；旁述资料2不含三值是在解释证据范围，没有恢复托管价格或安装任务。",
    "facts":[fact("F1","correct","首次Kickstarter筹款目标金额£25,000","目标金额和英镑正确。"),
             fact("F2","correct","实际筹到£196,362","实际金额和英镑正确。"),
             fact("F3","correct","用时29天","明确原文用时正确。")],
    "citations":[
        cite(1,"资料1","资料1明确给出三个数字：目标£25,000、实际£196,362、用时29天。","supported",["F1","F2","F3"],
             [actual("smoke_003",1)[362:469]],"实际资料1直接给三项数字；裸资料1在人读justification中绑定完整答句，未形成API方括号。"),
        cite(2,"资料2","资料2提供项目背景和商业模式，但不包含这三个数字。","supported",[],
             [actual("smoke_003",2).split("## 相关信息")[0]],"实际资料2含基金会/商业模式，完整核阅确实没有三项筹资数字。仅排除证据来源，不用于补救其他事实。")],
    "extra_claims":[]}

judgments[3] = {"id":"smoke_004", "decision":"answer", "decision_correct":True,
    "decision_reason":"在真实最终JSON中明确答10、无Mac并写Daytona；错误日期和改写来源同样是对用户可见的主张。",
    "scope":"保留NT3.5工作站三目标，但恢复已撤回日期并循环伪造source正文。",
    "facts":[fact("F1","correct","并发客户端数10个","开头实际answer字符串给出正确上限。"),
             fact("F2","correct","不支持Mac客户端","开头实际answer字符串给出正确否定。"),
             fact("F3","correct","Windows NT 3.5开发代号为“Daytona”","真实最终sources.text里明确值正确；后续空洞循环不反向改成其他代号。")],
    "citations":[cite(1,"资料 1","工作站版，并发客户端数10个，不支持Mac客户端。","partially_supported",["F1","F2","F3"],
         [actual("smoke_004",1)[234:378],actual("smoke_004",1)[99:178]],
         "唯一sources条目的label1与完整JSON答案明确关联，实际资料1支持三事实；同条模型重写text的1995日期/赛道国家称呼等并不受支持。")],
    "extra_claims":[
        {"answer_quote":"于1995年9月21日发布","material_error":True,"reason":"实际源1为1994年9月21日，且用户已撤回发布日期；每次重复均保留。"},
        {"answer_quote":"代托纳国家赛道","material_error":True,"reason":"实际原文为代托纳国际赛道，模型改名后伪称源内容。"}],
    "observable_output_limitations":["自生成sources.text循环且JSON未闭合，末尾截在‘开发代号是微’；实际终止原因不可确认。"]}

controls = []
for j in judgments:
    cid=j["id"]
    a=json.loads((base/"completed"/f"{cid}.json").read_text())
    c=json.loads((run/"completed"/f"{cid}.json").read_text())
    at=a["response"]["generation"]["model_calls"][0];ct=c["response"]["generation"]["model_calls"][0]
    assert at["prompt"] == ct["prompt"] + ">"
    assert at["parameters"] == ct["parameters"]
    assert at["messages"] == ct["messages"]
    assert a["response"]["sources"] == c["response"]["sources"]
    samebody = body(cid) == a["response"]["answer"]
    if cid not in {"smoke_001","smoke_003","smoke_004"}:
        assert samebody
    controls.append({"id":cid,"only_prompt_difference":"last > removed", "same_parameters":True,
                     "same_messages_and_materials":True, "same_final_body_as_eos_v2":samebody,
                     "candidate_raw_real_leading_gt":c["response"]["generation"]["raw_model_answer"].startswith(">"),
                     "api_keeps_full_raw":c["response"]["answer"]==c["response"]["generation"]["raw_model_answer"]})
build("materials-api-prefix-v3", judgments)
comparison = ROOT / "review/materials-api-prefix-comparison"
comparison.mkdir(exist_ok=False)
summary=json.loads((ROOT/"review/materials-api-prefix-v3/summary.json").read_text())
assert summary["fact_status_counts"] == {"incorrect":3,"correct":23,"omitted":2}
assert summary["exact_format_full_pass"]==0 and summary["human_readable_citation_full_pass"]==2
sources=[Path(__file__),ROOT/"review/_materials_prefix_serializer.py",ROOT/"review/build_materials_api_review.py",
         ROOT/"review/materials-api-eos-v2/FROZEN.json",ROOT/"review/materials-api-prefix-v3/FROZEN.json",
         ROOT/"MATERIALS-PREFIX-CONTROL-PLAN.json"]
data={"schema":"materials-prefix-control-review-v1","rows":controls,"candidate_summary":summary,
      "numerical_fact_and_full_threshold_met":True,"no_new_extra_unsupported_claims_met":False,
      "promotion_criterion_met":False,
      "reason":"23 correct / 3 incorrect and readable2 beat numerical threshold, but smoke001 introduces unsupported official-name/chapters and smoke004 adds a wrong raceway-name in rewritten purported source text. Preserve all extra claims; do not advance based only on aggregate facts.",
      "serializer_projection_change":{"baseline_code_sha256":digest(ROOT/"review/build_materials_api_review.py"),
        "new_code_sha256":digest(ROOT/"review/_materials_prefix_serializer.py"),
        "changes":["Assert API answer equals raw; score only declared immutable answer_span (here raw[1:]). Keep API full raw separately.",
                   "For partially-supported compound citation, explicit supported_fact_ids can support the specified correct facts while the unsupported attached claim still fails full case; no keyword semantic grading."],
        "whole_final_json_scored":True,"model_generated_sources_not_treated_as_actual_evidence":True},
      "limits":["Every provider finish is stop but termination remains unknown.","Only eight exposed development cases; not model potential ceiling or isolated provider weight proof.","Source text in generated JSON is model output; actual supplied materials alone determine semantic support.","No thinking rescued facts and no source/gold/parser changes by reviewer."],
      "bindings":[{"path":str(p.relative_to(ROOT)),"sha256":digest(p)} for p in sources]}
write(comparison/"COMPARISON.json",data)
(comparison/"README.md").write_text("# 不完整prefill材料对照\n\n实际8项prompt均仅移除末尾 >，其余输入材料、历史、排序、sampling和stop[0]全部相同。"
    "5项正文投影与EOS-v2相同；原始API答案保留模型真实生成的 >，审阅只按原trace声明的[1,n]正文。\n\n"
    "候选23/28事实正确、2遗漏、3错误；正式完整0/8，可读完整2/8（003、005）。"
    "尽管达到了数字门槛，新增加的章节/名称错误和伪造来源内容未满足‘无新增无据主张’条件，因此不晋级。"
    "所有完整JSON正文都接受审阅，没有仅抽answer字段隐藏错误，也没有将模型生成sources当真实证据。\n",encoding="utf-8")
write(comparison/"FROZEN.json",{"files":[{"path":p.name,"sha256":digest(p)} for p in sorted(comparison.iterdir())],"bindings":data["bindings"]})
print("COMPARISON",digest(comparison/"FROZEN.json"))
