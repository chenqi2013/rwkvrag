"""Offline explicit review of the fixed external-API Wiki baseline.
No requests; no relaxation of frozen planner parsing or answer semantics.
"""
import ast
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import re
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "wiki-api-v1-eos"
OUT = ROOT / "review/wiki-api-v1-eos"

def digest(p): return sha256(p.read_bytes()).hexdigest()
def text_hash(s): return sha256(s.encode()).hexdigest()
def write(p, value):
    with p.open("x", encoding="utf-8") as f:
        f.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
def bounds(text, quote):
    start=text.index(quote)
    return {"start":start,"end":start+len(quote),"unit":"unicode_code_points"}

CASES = [json.loads(line) for line in (RUN / "frozen/fixtures.jsonl").read_text().splitlines()]
assert digest(RUN / "frozen/fixtures.jsonl") == "469dec3deb84115dceaec16af72a9f98f0ee51db503d4cfeeeed73e27e46a258"
assert len(CASES)==8 and sum(len(c["oracle"]["required_facts"]) for c in CASES)==29
EXPLICIT = {
    "held_004":{"facts":["omitted"]*4,"decision":"abstain","reason":"Writer实际未收到任何sources，因此不编造值的拒答选择有依据；在原完整语料任务仍遗漏全部四项，不能算端到端通过。",
                "given_evidence_decision":"abstain_choice_justified_but_explanation_misattributed",
                "scope":"保留CAN FD四个问题，不回答具体值。","extras":[
                    {"quote":"原文仅提到“CAN FD 支持的两种消息ID位数”这一表述", "material_error":True,
                     "reason":"实际Writer sources=[]；此表述只来自问题/任务，不来自原文。拒答结论可理解，解释把问题误称成资料。"}]},
    "held_010":{"facts":["omitted"]*4,"decision":"not_executed","reason":"规划格式失败，API最终正文为空。","given_evidence_decision":"not_assessable","scope":"无最终答复，不能从planner内容补答案。","extras":[]},
    "held_012":{"facts":["omitted"]*4,"decision":"not_executed","reason":"规划顶层结构失败，API最终正文为空。","given_evidence_decision":"not_assessable","scope":"无最终答复，不能从planner内容补答案。","extras":[]},
    "held_014":{"facts":["omitted"]*4,"decision":"not_executed","reason":"规划顶层结构失败，API最终正文为空。","given_evidence_decision":"not_assessable","scope":"无最终答复，不能从planner内容补答案。","extras":[]},
    "held_016":{"facts":["incorrect"]*4,"decision":"answer","reason":"没有证据仍肯定给出四项错误值；形式上选择answer不等于证据条件下恰当决策。",
                "given_evidence_decision":"unsupported_answer","scope":"RPG Maker MV仅答手机版且答错，Windows版遗漏；另添未问开发文档概述。",
                "quotes":["NativeScript 使用 JavaScript 和 TypeScript 编写的跨平台用户界面定义文件","WinJS 1.0 随 Windows 8.1 发布。","RPG Maker MV 手机版使用 MP3 格式。","Media Foundation 首次适用于 Windows 8。"],
                "fact_reasons":["所问UI定义文件是XML。回答用JS/TS作定义文件，未给XML且属于明确冲突值。",
                                "固定原文为Windows8，答8.1错误。",
                                "原事实对要求Windows ogg/手机版m4a，答手机版MP3错误且没有Windows部分，整原子事实判incorrect。",
                                "固定原文首次适用WindowsVista，答Windows8错误。"],
                "extras":[{"quote":"RPG Maker MV 开发文档包括官方文档和社区文档。","material_error":True,"reason":"没有实际证据支持这条新增文档范围断言，也不是所问音乐格式。"},
                          {"quote":"Media Foundation 开发文档包括官方文档和社区文档。","material_error":True,"reason":"没有实际证据支持这条新增文档范围断言，也不是所问首次适用版本。"}]},
    "held_017":{"facts":["omitted"]*3,"decision":"not_executed","reason":"规划格式/数量不合约，API最终正文为空。","given_evidence_decision":"not_assessable","scope":"无最终答复，不用模型复述的历史救三项筹资数。","extras":[]},
    "held_019":{"facts":["omitted"]*3,"decision":"not_executed","reason":"规划格式/数量不合约，API最终正文为空。","given_evidence_decision":"not_assessable","scope":"无最终答复，不用模型复述的历史救工作站事实。","extras":[]},
    "held_021":{"facts":["omitted"]*3,"decision":"not_executed","reason":"规划带代码围栏，API最终正文为空。","given_evidence_decision":"not_assessable","scope":"无最终答复；planner虽提到两船鱼礁目标但不是最终答案。","extras":[]},
}
SHAPES = {
    "held_004":{"shape":"json_object", "issues":[], "semantic_scope_note":"四个queries包含CAN FD主体和四目标，范围正确。"},
    "held_010":{"shape":"markdown_fenced_json_object", "issues":["outer_code_fence"],"queries":6,"fields":11,
                "semantic_scope_note":"包含四个正确主题，但末两queries重复，fields多次重复。重复本身不是当前parse_plan的拒绝规则，真实首要拒绝是代码围栏。"},
    "held_012":{"shape":"json_array_of_query_fields_objects", "issues":["top_level_list_not_queries_fields_object"],"objects":3,
                "semantic_scope_note":"三个query按三类列车分别问，主体/目标总体保留；但不是约定的两个字符串数组。不可从字典抽values自动救成计划。"},
    "held_014":{"shape":"json_array_of_query_fields_objects", "issues":["top_level_list_not_queries_fields_object"],"objects":3,
                "semantic_scope_note":"三个query保留Ghost/Discuz!NT/Gearman。内层fields额外要许可证类型/链接、版本，不能忽略结构差异当现有合同已成功。"},
    "held_016":{"shape":"json_object", "issues":[],"queries":6,"fields":6,
                "semantic_scope_note":"格式通过但RPG Maker MV只保留手机版音乐，丢Windows版；另加RPG/MF开发文档泛化目标。查询格式成功不证明语义完整。"},
    "held_017":{"shape":"markdown_fenced_json_object", "issues":["outer_code_fence","queries_9_over_limit_6"],"queries":9,"fields":3,
                "semantic_scope_note":"大量照搬多轮历史段而非完整独立检索式，混入已撤回/仅讨论的公司logo、旧对象背景。fields三项仍在，不能抵销queries范围问题。"},
    "held_019":{"shape":"markdown_fenced_json_object", "issues":["outer_code_fence","queries_7_over_limit_6"],"queries":7,"fields":3,
                "semantic_scope_note":"照搬历史，连已更正NT3.51、打印旁支、示意图背景都进入queries；没有把工作站3.5当前三个目标压成独立任务。"},
    "held_021":{"shape":"markdown_fenced_json_object", "issues":["outer_code_fence"],"queries":6,"fields":2,
                "semantic_scope_note":"六条query完全重复同一有效鱼礁两船任务，没有恢复撤回的其他去向；重复是冗余，当前解析会按原规则去重，但代码围栏仍导致实际失败。"},
}
settings=json.loads((RUN/"settings.json").read_text())
source=RUN/"source/src/llamaindex_retrieval/rwkv_pipeline.py"
manifest=json.loads((RUN/"source-manifest.json").read_text())
assert digest(source)==manifest["src/llamaindex_retrieval/rwkv_pipeline.py"]["sha256"]
function=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=="parse_plan")
namespace={"json":json,"Settings":SimpleNamespace}
exec(compile(ast.Module(body=[function],type_ignores=[]),str(source),"exec"),namespace)
rows=[];planner=[];allcalls=[]
for case in CASES:
    cid=case["id"];e=EXPLICIT[cid]
    receipt_path=RUN/"completed"/f"{cid}.json";record=json.loads(receipt_path.read_text())
    response=record["response"];g=response["generation"]
    assert response["sources"]==[] and g["evidence_count"]==0
    raw=g["raw_model_answer"]
    span=g["answer_span"]
    answer=raw[span[0]:span[1]] if span is not None else ""
    assert response["answer"]==answer
    assert not re.search(r"资料\s*[1-9][0-9]*",answer)
    assert g["citation_audit"]["label_ids"]==[]
    facts=[]
    for i,(oracle,status) in enumerate(zip(case["oracle"]["required_facts"],e["facts"],strict=True)):
        q=e.get("quotes",[None]*len(e["facts"]))[i]
        facts.append({"id":oracle["id"],"expected_claim":oracle["claim"],"status":status,
                      "answer_quote":q,"answer_span":bounds(answer,q) if q else None,
                      "formal_supported":False,"human_readable_supported":False,"actual_support_spans":[],
                      "reason":e.get("fact_reasons",[e["reason"]]*len(e["facts"]))[i]})
    extra=[{**x,"answer_span":bounds(answer,x["quote"])} for x in e["extras"]]
    calls=g["model_calls"];allcalls+=calls
    writer=[c for c in calls if c["stage"]=="writer"]
    assert len(writer)==(1 if cid in {"held_004","held_016"} else 0)
    if writer:
        assert writer[0]["evidence_ids"]==[] and writer[0]["termination_verified"] is False
    rows.append({"id":cid,"receipt_sha256":digest(receipt_path),"generation_status":g["status"],
        "model":g["model"],"transport":"rwkvos_batch","writer_attempted":bool(writer),
        "writer_termination":"unknown" if writer else "not_attempted",
        "provider_finish_reason":g["provider_finish_reason"],"termination_verified":g["termination_verified"],
        "raw_answer_sha256":text_hash(raw),"final_answer":answer,"final_answer_sha256":text_hash(answer),
        "final_answer_span":span,"raw_answer_modified":False,"thinking_used_for_facts_or_citations":False,
        "sources":[],"citation_occurrences":[],"facts":facts,"extra_claims":extra,
        "actual_decision":e["decision"],"expected_decision":"answer",
        "decision_correct":e["decision"]=="answer","decision_given_selected_evidence":e["given_evidence_decision"],
        "decision_reason":e["reason"],"scope":e["scope"],"full_pass":False,
        "formal_full_pass":False,"human_readable_full_pass":False,"core_facts_and_decision_pass":False})
    pt=next(c for c in calls if c["stage"]=="planner");assert pt["termination_verified"] is False
    plan_raw=pt["raw_text"];envelope=pt["envelope"]["answer_span"]
    original_body=plan_raw[envelope["start"]:envelope["end"]]
    parsed=None;error=None
    try:parsed=namespace["parse_plan"](original_body.strip(),SimpleNamespace(**settings))
    except ValueError as ex:error={"type":type(ex).__name__,"message":str(ex)}
    assert (error is not None)==(g["status"]=="planner_failed")
    planner.append({"id":cid,**SHAPES[cid],"call_id":pt["call_id"],"raw_output":plan_raw,
        "raw_output_sha256":text_hash(plan_raw),"prompt_sha256":pt["prompt_sha256"],
        "original_body_span":envelope,"strict_frozen_parser_accepted":error is None,
        "strict_original_error":error,"actual_parsed_plan":parsed,
        "no_code_fence_stripping_or_shape_repair":True,"affects_QA_score":False})
assert len(allcalls)==170 and all(t["termination_verified"] is False for t in allcalls)
resolvers=[t for t in allcalls if t["stage"]=="resolver"]
resolverstats={"calls":len(resolvers),"parse_error":sum("parse_error" in t for t in resolvers),
               "strict_parsed_empty_selections":sum(t.get("selected_units")==[] and "parse_error" not in t for t in resolvers),
               "selected_units_total":sum(len(t.get("selected_units",[])) for t in resolvers)}
summary={"original_cases":8,"required_facts":29,"fact_status_counts":dict(Counter(f["status"] for r in rows for f in r["facts"])),
         "formal_full_pass":0,"human_readable_full_pass":0,"formal_supported_facts":0,"human_readable_supported_facts":0,
         "decision_correct":sum(r["decision_correct"] for r in rows),"core_facts_and_decision_pass":0,
         "formal_citation_occurrences":0,"human_readable_citation_occurrences":0,
         "planner_failed_cases":6,"writer_attempted_cases":2,"writer_empty_sources_cases":2,
         "model_calls":len(allcalls),"stage_counts":dict(Counter(t["stage"] for t in allcalls)),
         "termination_unverified_model_calls":170,"writer_termination_unknown_cases":2,
         "not_attempted_writers":6,"http_requests":json.loads((RUN/"result.json").read_text())["summary"]["model_http_requests"],
         "resolver_diagnostics":resolverstats,"semantic_grading":"Codex explicit non-blind review; not automatic or expert-human verification"}
paths=[Path(__file__),ROOT/"qa-protocol/PROTOCOL.json",ROOT/"qa-protocol/FROZEN.json",
       ROOT/"api-contract-v1/CONTRACT.json",ROOT/"api-contract-v1/FROZEN.json",ROOT/"WIKI-API-V1-PLAN.json"]
paths += [RUN/n for n in ["manifest.json","settings.json","settings-freeze.json","source-manifest.json","result.json",
                        "index-before.json","index-after.json","frozen/fixtures.jsonl","frozen/run_wiki.py"]]
bindings=[{"path":str(p.relative_to(ROOT)),"sha256":digest(p)} for p in paths]
review={"schema":"native-wiki-smoke-semantic-review-v1","run":"wiki-api-v1-eos","reviewed_at":datetime.now(timezone.utc).isoformat(),
        "reviewer":"Codex independent non-blind development review; not human expert acceptance",
        "summary":summary,"rows":rows,"bindings":bindings,"criteria":json.loads((ROOT/"qa-protocol/PROTOCOL.json").read_text())["criteria"],
        "limitations":["All eight exposed cases and 29 original facts are retained; no new blind or production accuracy estimate.",
            "External API self-reported2.9B identity is not verified weight/tokenizer/deployment revision identity. No old13.3B score is relabeled.",
            "Provider stop remains unverified termination for170 calls; six absent Writer calls are not mislabeled unknown completed writers.",
            "Selected Writer sources were empty for both attempted writers. Full corpus answerability and justified evidence-conditioned refusal remain distinct.",
            "Every final-body source-number occurrence was checked; none occurred. No evidence from a planner, resolver, whole article or oracle was credited as a citation.",
            "Root's independent HTTP/source audit may be added as a separate binding; this explicit QA freeze does not claim to replace that audit."]}
OUT.mkdir(exist_ok=False)
write(OUT/"review.json",review);write(OUT/"summary.json",summary)
with (OUT/"rows.jsonl").open("x",encoding="utf-8") as f:
    for row in rows:f.write(json.dumps(row,ensure_ascii=False)+"\n")
write(OUT/"PLANNER-SHAPE-DIAGNOSIS.json",{"schema":"frozen-plan-contract-diagnostic-v1","rows":planner,
    "strict_pass":2,"strict_fail":6,"failure_shapes":{"fenced_json_object":4,"array_of_objects":2},
    "additional_count_failures":{"held_017":9,"held_019":7},"original_query_limit":settings["native_max_queries"],
    "parser_source_sha256":digest(source),"qa_scores_unchanged":True,
    "recommendations":["Train or validate the exact top-level output contract including no code fences, rather than accepting arbitrary shapes after seeing results.",
        "Separate exact formatting from semantic scope checks; the accepted held016 plan still lost a requested platform and added unrelated document goals.",
        "Current long-history failures copy historical utterances into queries; training examples must distinguish active object/targets from retracted or logistical conversation.",
        "Do not silently raise query limits, strip wrappers, extract values from objects or use intermediates to repair this completed baseline."]})
write(OUT/"PROVIDER-LIMITATIONS.json",{"amends_old_protocol":False,"termination_unverified_model_calls":170,
     "writer_attempted":2,"writers_not_attempted":6,"stop_evidence_binding":"api-contract-v1/FROZEN.json",
     "scope":"completed transport is not reliable natural-completion proof; no inferred16K hard gate or provider weight hash."})
(OUT/"summary.md").write_text("# 外部2.9B完整Wiki基线独立审阅\n\n固定8题/29事实：0正确、25遗漏、4错误；正式/可读引用完整均0/8，支持事实均0/29。"
    "6题在planner严格格式校验失败后没有Writer正文。另两题Writer实际sources均为空：CAN FD选择拒答，端到端四事实仍遗漏；开发文档题则给出四个错误值。"
    "\n\n规划失败是4个Markdown JSON围栏与2个顶层对象数组；其中两个长历史输出同时有9/7条queries超过原6条上限。没有放宽解析救分。格式通过的开发文档计划也漏掉RPG Windows目标，另加泛化开发文档。"
    "\n\n共170个模型调用、28次共享批次HTTP；全部provider终止原因不可靠。2个Writer仅确认返回，6个Writer未执行。"
    "训练上下文名称ctx16384不代表这轮已验证API硬上限；这些结果也不是2.9B模型潜力上限。\n",encoding="utf-8")
write(OUT/"FROZEN.json",{"schema":"explicit-review-freeze-v1","bindings":bindings,
    "files":[{"path":p.name,"sha256":digest(p),"bytes":p.stat().st_size} for p in sorted(OUT.iterdir())]})
print(json.dumps(summary,ensure_ascii=False));print("FROZEN",digest(OUT/"FROZEN.json"))
