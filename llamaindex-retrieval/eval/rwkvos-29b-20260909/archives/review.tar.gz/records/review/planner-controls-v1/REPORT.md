# 两个外部 2.9B Planner-only 对照审阅

只读冻结八题，未调用 API，未修补原输出，也未改变旧 Wiki 的 8 题 / 29 事实评分。两个新增对照各 8 次生成、按 4+4 两个 contents 批次执行；没有检索或 Writer。严格语法均按实际冻结 parse_plan 重算，完整历史与最新问题、采样/状态/prefill/预算和 wire 槽位已核对。

| 条件 | 严格格式 | 可见原文目标/范围保留（不救格式） | 同时满足格式、范围及独立组织 |
|---|---:|---:|---:|
| wiki-api-v1-eos | 2/8 | 5/8 | 1/8 |
| planner-shared-tasks-v1 | 4/8 | 4/8 | 3/8 |
| planner-contract-last-v1 | 0/8 | 4/8 | 0/8 |

范围诊断与可执行计划分开。shared 的 held_010 虽保留全部内容并能解析，却把四对象整题重复成多个字符串，故不记为已完成独立任务组织；这不是金标事实评分变更。

## held_004

- [wiki-api-v1-eos 原输出](../../wiki-api-v1-eos/completed/held_004.json)：原四目标各自保留，ID/载荷/资料率Mbit/s/线路影响关系正确。
- [planner-shared-tasks-v1 原输出](../../planner-shared-tasks-v1/completed/held_004.json)：六段【子问题】递增重复；将载荷错误地绑定到每种ID位数、将线路影响转成这些数据的影响原因，并遗漏明确的最高资料率Mbit/s目标。非JSON。
- [planner-contract-last-v1 原输出](../../planner-contract-last-v1/completed/held_004.json)：四个有效目标与基线相同；仅从可见原文内容看范围保留，但外层代码围栏使严格解析失败。

## held_010

- [wiki-api-v1-eos 原输出](../../wiki-api-v1-eos/completed/held_010.json)：四标准分别关联语言、事件模型、书颜色、阶段数，虽有重复检索式但未换对象；代码围栏失败。
- [planner-shared-tasks-v1 原输出](../../planner-shared-tasks-v1/completed/held_010.json)：四个目标和不做认证的限制均保留，但每个字符串重复整道四对象问题，去重后仍是两条高度重叠总问题，没有分别拆分对象。仅格式通过不等于完成子问题组织。
- [planner-contract-last-v1 原输出](../../planner-contract-last-v1/completed/held_010.json)：四个对象及各自目标保留；最外层为单元素数组而非所要求对象，严格解析失败。

## held_012

- [wiki-api-v1-eos 原输出](../../wiki-api-v1-eos/completed/held_012.json)：ICE-1可否组合、ICE-2指定路线的合体站、305系总辆数/动力车数绑定完整；实际外层为query/fields对象数组，严格失败。
- [planner-shared-tasks-v1 原输出](../../planner-shared-tasks-v1/completed/held_012.json)：三条独立字符串准确保留车型、ICE-2科隆/杜塞尔多夫往柏林路线，以及305系总数与动力车子目标。
- [planner-contract-last-v1 原输出](../../planner-contract-last-v1/completed/held_012.json)：把车厢数量加到ICE-1与ICE-2，原题只对305系问数量；ICE-2仅剩合体关键词、未明确所求站点。代码围栏失败。

## held_014

- [wiki-api-v1-eos 原输出](../../wiki-api-v1-eos/completed/held_014.json)：queries保持Ghost许可证、Discuz!NT语言/技术、Gearman三角色及执行者；unused fields额外许可证链接/版本不作为本次queries驱动链路的主动请求，但记录冗余风险。外层数组失败。
- [planner-shared-tasks-v1 原输出](../../planner-shared-tasks-v1/completed/held_014.json)：三个独立对象/目标完整，Discuz!NT命名明确，无需逐字复述不要套主版本的否定句才算保留范围。
- [planner-contract-last-v1 原输出](../../planner-contract-last-v1/completed/held_014.json)：三对象及Gearman角色/实际执行者保留；单元素对象数组不符合顶层对象合同。

## held_016

- [wiki-api-v1-eos 原输出](../../wiki-api-v1-eos/completed/held_016.json)：RPG Maker MV查询只剩手机版音乐格式，漏Windows一侧，另加RPG与Media Foundation泛开发文档；其他三个主目标保留。
- [planner-shared-tasks-v1 原输出](../../planner-shared-tasks-v1/completed/held_016.json)：四个对象与属性分别保留，特别WinJS1.0、RPG的Windows/手机两平台、Media Foundation首次适用版本均准确。
- [planner-contract-last-v1 原输出](../../planner-contract-last-v1/completed/held_016.json)：queries已保留四目标及RPG双平台，较基线范围完整；但顶层单元素数组导致不能使用。

## held_017

- [wiki-api-v1-eos 原输出](../../wiki-api-v1-eos/completed/held_017.json)：复制多轮历史与助手文本为9条queries，仍含最初待确认对象和已撤回公司名单旁支；未整理成Ghost首次Kickstarter筹资三格的独立任务。字段三格虽在，不能救无效queries/围栏。
- [planner-shared-tasks-v1 原输出](../../planner-shared-tasks-v1/completed/held_017.json)：第一段把区分Ghost/GhostBSD恢复为所求属性；后段虽保留Ghost、目标/实际额/天数与英镑，也混入格式指令及排版旁支，整个输出非JSON且后半句未完。
- [planner-contract-last-v1 原输出](../../planner-contract-last-v1/completed/held_017.json)：仅写旧博客软件，丢已确定Ghost身份、首次Kickstarter事件和英镑限定；加软件名称与倍数，不能用本来的三格代替这些新增目标。非JSON。

## held_019

- [wiki-api-v1-eos 原输出](../../wiki-api-v1-eos/completed/held_019.json)：queries复制历史：开头仍带旧3.51及Server讨论，中间有正确3.5工作站但没有统一解除冲突；打印/图示旁支混入、共7条且有围栏。
- [planner-shared-tasks-v1 原输出](../../planner-shared-tasks-v1/completed/held_019.json)：八段文本首先保留旧NT3.51，未明确恢复已确认NT3.5工作站；复制助手/打印/图示文字，只有后段列三个字段，不能使各段成为独立正确任务。
- [planner-contract-last-v1 原输出](../../planner-contract-last-v1/completed/held_019.json)：明确反复查询NT3.51并同时要Server与Workstation，违背已确认3.5仅工作站；还漏开发代号目标。围栏+数组都不合法。

## held_021

- [wiki-api-v1-eos 原输出](../../wiki-api-v1-eos/completed/held_021.json)：六条重复同一有效查询：美国海岸警卫队红级中成为人工鱼礁的两艘名称及置放日期；未恢复红雪松/退役排序。完整history仍保留年月日粒度。围栏使实际失败。
- [planner-shared-tasks-v1 原输出](../../planner-shared-tasks-v1/completed/held_021.json)：输出【子问题】后直接复制未完的history JSON，混入旧红雪松及被撤回旁支；未形成可独立执行的两艘鱼礁/置放日期任务。原文字提到正确约束不等于完成规划。
- [planner-contract-last-v1 原输出](../../planner-contract-last-v1/completed/held_021.json)：主动恢复红雪松单船，新增退役日/建造厂/舷号字段；既错对象集合，又恢复明确撤回或可选要求。Python赋值文本不是JSON。

## 可以支持的结论

字符串数组合同把列车、软件组件、开发文档三题组织正确，且修复了开发文档题中 RPG 双平台目标；但 CAN FD 比基线退化，三道长历史仍不合格，不能用 4/8 格式通过率直接晋级。末尾合同对照严格格式 0/8；对 NT 3.5 工作站错误恢复 3.51/Server，对红级两艘鱼礁错误恢复红雪松单船及退役日/建造厂，未满足预登记的范围不退化条件。

完整历史未被 transport 截掉，不等于模型已正确执行历史更正。复制历史、格式指令或助手文本不是独立查证任务。记录不能证明状态微调、换模板、放宽 JSON 或再增加提示词必然有效；下一步应把有效对象/事件/单位/撤回范围与语法分别验证，避免只有更高解析率。

本轮没有对两个候选做下游完整 RAG，不能给它们 QA 提升分。provider finish_reason=stop 的终止限制照旧；有尾部未完句的输出只描述可见现象，不冒充已证 length。
