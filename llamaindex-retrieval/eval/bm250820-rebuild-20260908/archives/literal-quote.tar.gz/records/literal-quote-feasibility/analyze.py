"""Offline strict literal-quote feasibility. No network or production mutation."""
from pathlib import Path
import ast
import base64
from collections import Counter
import hashlib
import json
import re

B = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
PINS = {
    'wiki-smoke-v1/manifest.json': 'b42c0ca6f1fe67bd16a3bb156d3d7a1137e7f4ed66a7e6371e5ee824f990b6b2',
    'wiki-smoke-v2/manifest.json': '3724bee8f0dceb1aa526686387da70db5e21957bc7af0a3489f48c4c0343e15c',
    'wiki-smoke-v2/source/src/llamaindex_retrieval/rwkv_pipeline.py': 'cf27c70a66beb1cf096d5f2213dc87599f6619b065c6e3920d6fabb7bda96c67',
    'wiki-smoke-v2/source/src/llamaindex_retrieval/native_rwkv.py': '355e044319331cc5fa25b5c44f7a67552821d399aa1f1f8b083cfaec1179b921',
}

def digest(data):
    return hashlib.sha256(data if isinstance(data, bytes) else data.encode('utf-8')).hexdigest()


def frozen_function(path, name):
    key=str(path.relative_to(B))
    assert digest(path.read_bytes()) == PINS[key], key
    tree=ast.parse(path.read_text())
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
    scope={'re':re}
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'),scope)
    return scope[name]


PARSE = frozen_function(B/'wiki-smoke-v2/source/src/llamaindex_retrieval/rwkv_pipeline.py','parse_selections')
ENVELOPE = frozen_function(B/'wiki-smoke-v2/source/src/llamaindex_retrieval/native_rwkv.py','inspect_envelope')


def occurrences(text,value):
    result=[]; start=0
    while True:
        pos=text.find(value,start)
        if pos<0: return result
        result.append(pos); start=pos+1


def locate(value,source_text,units):
    positions=occurrences(source_text,value) if value else []
    result={'value':value,'source_occurrences':positions,'unit_ids':[], 'accepted':False}
    if not value:
        result['error']='empty_literal'; return result
    if len(positions)!=1:
        result['error']='literal_not_present' if not positions else 'literal_nonunique'; return result
    start=positions[0]; end=start+len(value)
    candidates=[u['id'] for u in units if u['start']<=start and end<=u['end']]
    result.update(start=start,end=end,unit_ids=candidates,unit='unicode_code_points_in_source_chunk')
    if len(candidates)!=1:
        result['error']='literal_not_in_one_unique_presented_unit'; return result
    result.update(accepted=True,unit_id=candidates[0])
    return result


def extend(text,fields,source_text,units):
    """All-or-nothing. Only a new literal value branch; original E grammar intact."""
    try:
        selected=PARSE(text,fields,len(units))
        return {'accepted':True,'mode':'original_strict','selections':[{'field':f'f{f}','unit_id':f'E{u}','via':'original_id'} for f,u in selected], 'errors':[], 'literal_probes':[]}
    except (ValueError,TypeError) as exc:
        original_error=str(exc)
    selected=[]; errors=[]; probes=[]; seen=set()
    for number,line in enumerate(text.splitlines(),1):
        line=line.strip()
        if not line: continue
        match=re.fullmatch(r'f([1-9]\d*):[ \t]*(.*)',line)
        if not match:
            errors.append({'line':number,'reason':'invalid_field_line'}); continue
        field=int(match[1]); value=match[2]
        if field>fields or field in seen:
            errors.append({'line':number,'reason':'unknown_or_repeated_field','field':field});continue
        seen.add(field)
        if value=='NONE': continue
        if re.fullmatch(r'E[1-9]\d*(?:\s*,\s*E[1-9]\d*)*',value):
            ids=[int(x) for x in re.findall(r'E([1-9]\d*)',value)]
            if any(index>len(units) for index in ids):
                errors.append({'line':number,'reason':'unknown_evidence_id','value':value});continue
            selected.extend({'field':f'f{field}','unit_id':f'E{index}','via':'original_id'} for index in dict.fromkeys(ids))
            continue
        # Reserved reference/inline-field shapes must never fall back to literal.
        if re.search(r'(?<!\w)[Ee]\s*\d',value) or re.search(r'(?<!\w)[fF]\d+\s*:',value) or value.startswith('NONE'):
            errors.append({'line':number,'reason':'malformed_reserved_syntax','value':value});continue
        probe=locate(value,source_text,units)
        probe.update(field=f'f{field}',line=number)
        probes.append(probe)
        if not probe['accepted']:
            errors.append({'line':number,'reason':probe['error'],'value':value});continue
        selected.append({'field':f'f{field}','unit_id':probe['unit_id'],'via':'literal','quote':value,
                         'quote_start':probe['start'],'quote_end':probe['end']})
    if seen!=set(range(1,fields+1)):
        errors.append({'reason':'omitted_fields','fields':[f'f{i}' for i in range(1,fields+1) if i not in seen]})
    return {'accepted':not errors,'mode':'literal_extension' if not errors else 'rejected',
            'selections':selected if not errors else [],'errors':errors,'literal_probes':probes,
            'original_parse_error':original_error,'semantic_support_verified':False}


def verify_call(call,source,fields):
    assert digest(call['raw_text'])==call['raw_text_sha256']
    assert digest(call['prompt'])==call['prompt_sha256']
    assert digest(source['snippet'])==call['source_sha256']
    assert call['source_id']==source['id'] and call['evidence_ids']==[source['id']]
    # Verify the actual HTTP request/response bytes, not merely interpreted trace.
    for wire in call['http']:
        request=base64.b64decode(wire['request_body_base64'],validate=True)
        response=base64.b64decode(wire['response_body_base64'],validate=True)
        assert digest(request)==wire['request_body_sha256']
        assert digest(response)==wire['response_body_sha256']
        assert json.loads(request)==wire['payload'] and wire['http_status']==200 and wire['response_body_complete']
        if wire['stage']=='completion':
            data=json.loads(response)
            assert data['choices'][0]['text']==call['raw_text']
            assert data['choices'][0]['finish_reason']==call['finish_reason']
            assert wire['payload']['prompt']==call['prompt']
    content=call['messages'][0]['content']
    assert call['messages'][0]['role']=='user' and len(call['messages'])==1
    assert call['prompt']=='User✿'+content+'✿\nBot✿'+call['prefill']
    # These sections are line-delimited JSON in the frozen original request.
    for label,expected in [('字段：',{f'f{i}':f for i,f in enumerate(fields,1)}),
                           ('来源：',{'id':source['id'],'title':source['title'],'uri':source['uri']}),
                           ('原文父级上下文：',source['metadata'].get('context_spans',[]))]:
        lines=[line[len(label):] for line in content.splitlines() if line.startswith(label)]
        assert len(lines)==1 and json.loads(lines[0])==expected
    presented=json.loads(content.rsplit('\n原文：',1)[1]); units=call['units']
    assert list(presented)==[f'E{i}' for i in range(1,len(units)+1)]
    for unit in units:
        text=source['snippet'][unit['start']:unit['end']]
        assert digest(text)==unit['sha256'] and presented[unit['id']]==text
    bounds=ENVELOPE(call['raw_text'],call['prefill'])
    if bounds:
        assert call['envelope']['answer_span']=={'start':bounds[0],'end':bounds[1],'unit':'unicode_code_points'}
    else:
        assert call['envelope'].get('answer_span') is None
    return bounds


def analyze_case(run,case_id,only_ranks=None):
    path=B/run/'completed'/f'{case_id}.json'; record=json.loads(path.read_text()); response=record['response']
    fields=response['retrieval']['plan']['fields']; candidates={s['id']:s for s in response['retrieval']['candidates']}
    rows=[]
    for rank,call in enumerate((c for c in response['generation']['model_calls'] if c['stage']=='resolver'),1):
        if only_ranks is not None and rank not in only_ranks: continue
        source=candidates[call['source_id']]; bounds=verify_call(call,source,fields)
        original_accepted='parse_error' not in call
        if call['status']!='completed' or call['finish_reason']!='stop' or bounds is None:
            body=None; result={'accepted':False,'mode':'rejected_incomplete','selections':[],
                              'errors':[{'reason':'not_completed_natural_final_body'}],'literal_probes':[]}
        else:
            body=call['raw_text'][bounds[0]:bounds[1]]
            result=extend(body,len(fields),source['snippet'],call['units'])
            assert original_accepted==(result['mode']=='original_strict')
            if original_accepted:
                assert [[s['field'],s['unit_id']] for s in result['selections']]==call['selections']
        units_by_id={u['id']:u for u in call['units']}
        selected_units=[]
        for unit_id in dict.fromkeys(s['unit_id'] for s in result['selections']):
            unit=units_by_id[unit_id]
            selected_units.append({**unit,'text':source['snippet'][unit['start']:unit['end']],
                                   'source_document_start':source['metadata']['source_span']['start']+unit['start'],
                                   'source_document_end':source['metadata']['source_span']['start']+unit['end']})
        rows.append({'run':run,'case_id':case_id,'resolver_rank':rank,'call_id':call['call_id'],
                     'record_path':str(path.relative_to(B)),'record_sha256':digest(path.read_bytes()),
                     'status':call['status'],'finish_reason':call['finish_reason'],'original_parse_error':call.get('parse_error'),
                     'original_accepted':original_accepted,'raw_text_sha256':call['raw_text_sha256'],
                     'prompt_sha256':call['prompt_sha256'],'final_body_span':list(bounds) if bounds else None,'final_body':body,
                     'fields':{f'f{i}':f for i,f in enumerate(fields,1)},'source':source,
                     'units':call['units'],'input_wire_and_units_verified':True,
                     'hypothetical':result,'selected_units':selected_units,
                     'newly_accepted':not original_accepted and result['accepted'], 'qa_score_changed':False})
    return rows


def write_new(path,value):
    with path.open('x',encoding='utf-8') as out: out.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


def main():
    for key,expected in PINS.items(): assert digest((B/key).read_bytes())==expected
    rows=[]
    for path in sorted((B/'wiki-smoke-v2/completed').glob('*.json')):
        rows.extend(analyze_case('wiki-smoke-v2',path.stem))
    assert len(rows)==192
    controls=analyze_case('wiki-smoke-v1','held_017',{4,7})
    with (OUT/'rows.jsonl').open('x',encoding='utf-8') as out:
        for row in rows: out.write(json.dumps(row,ensure_ascii=False)+'\n')
    write_new(OUT/'v1-targeted-controls.json',controls)
    # Explicitly marked diagnostics; not promoted as valid recovered fields.
    row=next(row for row in rows if row['case_id']=='held_017' and row['resolver_rank']==4)
    diagnostic={'run':'wiki-smoke-v2','case_id':'held_017','resolver_rank':4,
                'original_final_body':row['final_body'],'strict_call_accepted':row['hypothetical']['accepted'],
                'original_field_binding':'all values emitted under f1; f2/f3 absent',
                'rule':'These three author-selected diagnostic substrings are NOT a generic parser or accepted selections; do not split lists or assign missing fields.',
                'separate_substring_probes':[locate(value,row['source']['snippet'],row['units']) for value in ['£25,000','£196,362','29天']]}
    assert not diagnostic['strict_call_accepted']
    write_new(OUT/'v2-ghost-not-accepted-diagnostic.json',diagnostic)
    summary={'scope':'192 v2 Resolver calls; v1 targeted controls excluded from all v2 counts',
             'calls':192,'status_counts':dict(Counter(r['status'] for r in rows)),
             'original_accepted_calls':sum(r['original_accepted'] for r in rows),
             'hypothetical_accepted_calls':sum(r['hypothetical']['accepted'] for r in rows),
             'newly_accepted_calls':sum(r['newly_accepted'] for r in rows),
             'newly_accepted':[{k:r[k] for k in ['case_id','resolver_rank','call_id']} for r in rows if r['newly_accepted']],
             'new_literal_field_unit_links':sum(len(r['hypothetical']['selections']) for r in rows if r['newly_accepted']),
             'all_original_e_id_decisions_unchanged':True,'all_wire_source_unit_identities_verified':True,
             'semantic_support_verified':False,'new_model_calls':0,'qa_scores_modified':False,
             'v1_controls':[{k:r[k] for k in ['resolver_rank','newly_accepted']} for r in controls],
             'bindings':[{'path':key,'sha256':value} for key,value in PINS.items()]}
    write_new(OUT/'summary.json',summary)
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__': main()
