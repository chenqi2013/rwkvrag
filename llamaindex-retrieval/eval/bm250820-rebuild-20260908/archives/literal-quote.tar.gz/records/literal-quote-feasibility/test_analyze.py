"""Focused offline safety and grammar fixtures; no model calls."""
import unittest
from analyze import extend, locate


def units(text):
    return [{'id':'E1','start':0,'end':len(text)}]


class LiteralFeasibilityTests(unittest.TestCase):
    def test_original_e_and_none_unchanged(self):
        text='abcdef'
        out=extend('f1: E1,E1\nf2: NONE',2,text,units(text))
        self.assertEqual(out['mode'],'original_strict')
        self.assertEqual(out['selections'],[{'field':'f1','unit_id':'E1','via':'original_id'}])

    def test_exact_singleton_unicode_offsets(self):
        text='开头🙂，目标£25,000，历时29天。'
        out=extend('f1: £25,000  \nf2: 29天',2,text,units(text))
        self.assertTrue(out['accepted'])
        for row in out['selections']:
            self.assertEqual(text[row['quote_start']:row['quote_end']],row['quote'])

    def test_no_paraphrase_or_normalization(self):
        self.assertFalse(extend('f1: 在Hamm合体',1,'兩組車將於Hamm合體',units('兩組車將於Hamm合體'))['accepted'])

    def test_nonunique_rejected(self):
        text='Worker passes to Worker'
        self.assertFalse(extend('f1: Worker',1,text,units(text))['accepted'])

    def test_overlapping_repeated_matches_counted(self):
        self.assertEqual(locate('aaa','aaaa',units('aaaa'))['source_occurrences'],[0,1])

    def test_unknown_e_never_literal_even_if_it_exists(self):
        text='E99'
        self.assertFalse(extend('f1: E99',1,text,units(text))['accepted'])

    def test_malformed_e_never_literal(self):
        for text in ['E0','E01','e1','E1;E2']:
            with self.subTest(value=text):
                self.assertFalse(extend('f1: '+text,1,text,units(text))['accepted'])

    def test_missing_and_unknown_fields_rejected(self):
        text='literal'
        for body,fields in [('f1: literal',2),('f2: literal',1),('f1: literal\nf1: literal',1)]:
            with self.subTest(body=body):
                self.assertFalse(extend(body,fields,text,units(text))['accepted'])

    def test_any_bad_field_rejects_all(self):
        text='correct'
        out=extend('f1: correct\nf2: invented',2,text,units(text))
        self.assertFalse(out['accepted']);self.assertEqual(out['selections'],[])

    def test_unique_source_match_in_two_overlap_units_rejected(self):
        text='abcdef'
        u=[{'id':'E1','start':0,'end':5},{'id':'E2','start':1,'end':6}]
        self.assertFalse(extend('f1: cd',1,text,u)['accepted'])

    def test_source_only_outside_actual_units_rejected(self):
        self.assertFalse(extend('f1: hidden',1,'shown hidden',[{'id':'E1','start':0,'end':5}])['accepted'])

    def test_combined_fields_and_amount_list_not_repaired(self):
        text='目标£25,000。29天内获得£196,362。'
        for body in ['f1: £25,000, £196,362, 29天','f1: NONE, f2: NONE, f3: NONE']:
            with self.subTest(body=body):
                self.assertFalse(extend(body,3,text,units(text))['accepted'])

    def test_wrong_semantic_field_can_pass_literal_locator(self):
        # The locator cannot establish that the role executes work.
        text='流程：Client -> Job -> Worker。'
        self.assertTrue(extend('f1: Worker',1,text,units(text))['accepted'])

    def test_fabricated_amounts_rejected(self):
        text='## 商业模式\n'
        out=extend('f1: 5,000英镑\nf2: 10,000英镑\nf3: 30天',3,text,units(text))
        self.assertFalse(out['accepted'])
        self.assertTrue(all(p['source_occurrences']==[] for p in out['literal_probes']))


if __name__=='__main__': unittest.main()
