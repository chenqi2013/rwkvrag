#!/bin/bash
set -euo pipefail
exec /home/chase/rwkvrag-bm-rebuild-20260908/source-wiki-v2/.venv/bin/python -u \
  /home/chase/rwkvrag-bm-rebuild-20260908/resolver-reminder-experiment/run_replay.py \
  --root /home/chase/rwkvrag-bm-rebuild-20260908/resolver-reminder-experiment --run
