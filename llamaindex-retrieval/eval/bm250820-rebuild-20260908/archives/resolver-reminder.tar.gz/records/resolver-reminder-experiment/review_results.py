"""Offline audit and transparent author review of the frozen 24-input replay."""
import base64
import collections
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).parent
CORPUS = Path('/home/chase/GitHub/rwkvrag-wiki-rag-20260908/corpus/finewiki-zh-5000')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    spec = importlib.util.spec_from_file_location('replay_review_helpers', ROOT / 'run_replay.py')
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    plan, requests, native, parser, _ = runner.preflight(ROOT)
    files = json.loads((ROOT / 'run/FILES.json').read_bytes())
    for name, binding in files.items():
        data = (ROOT / 'run' / name).read_bytes()
        assert len(data) == binding['bytes'] and sha(data) == binding['sha256'], name
    expected = {row['id']: row for row in json.loads((ROOT / 'expected-review.json').read_bytes())}
    rows = []
    totals = {'baseline': collections.Counter(), 'candidate': collections.Counter()}
    source_manifest = {row['page_id']: row for row in
        map(json.loads, (CORPUS / 'manifest.jsonl').read_text().splitlines())}
    for request in requests:
        case = request['id']
        gold = expected[case]
        source = gold['source']
        page = source_manifest[source['metadata']['page_id']]
        body = (CORPUS / page['text_path']).read_bytes().decode('utf-8')
        source_span = source['metadata']['source_span']
        assert body[source_span['start']:source_span['end']] == source['snippet']
        assert sha(body.encode()) == page['text_sha256'] == source['metadata']['source_text_sha256']
        for context in source['metadata']['context_spans']:
            assert body[context['start']:context['end']] == context['text']
            assert sha(context['text'].encode()) == context['sha256']
        baseline_path = ROOT / 'baseline' / Path(request['baseline_completed']).name
        candidate_path = ROOT / 'run/completed' / f'{case}.json'
        baseline = json.loads(baseline_path.read_bytes())
        candidate = json.loads(candidate_path.read_bytes())
        by_arm = {'baseline': baseline, 'candidate': candidate}
        judgments = {}
        for arm, receipt in by_arm.items():
            trace = receipt['trace']
            raw = receipt['raw_text']
            bounds = native.inspect_envelope(raw)
            final = raw[bounds[0]:bounds[1]] if bounds else ''
            try:
                assert receipt['status'] == 'completed'
                selections = [[f'f{f}', f'E{e}'] for f, e in parser(final.strip(), 3, 1)]
                valid = True
                error = None
            except (AssertionError, ValueError) as exc:
                selections = None
                valid = False
                error = str(exc)
            semantic_pass = valid and selections == gold['expected_selections']
            judgments[arm] = {'status': receipt['status'], 'protocol_valid': valid,
                'selections': selections, 'complete_selection_pass': semantic_pass,
                'parse_error': error, 'final_output': final,
                'semantic_reason': gold['reason'] if semantic_pass else
                    'No accepted selection record under the frozen protocol; raw text does not rescue the result.'}
            totals[arm].update({'calls': 1, 'protocol_valid': valid, 'complete_selection_pass': semantic_pass,
                'prompt_tokens': trace['usage']['prompt_tokens'],
                'completion_tokens': trace['usage']['completion_tokens'],
                'accepted_positive_field_links': len(selections or []),
                'true_positive_field_links': len(selections or []) if semantic_pass else 0,
                'valid_negative_sources': semantic_pass and not gold['expected_selections']})
        assert candidate['trace']['messages'] == request['messages']
        assert candidate['trace']['parameters'] == baseline['trace']['parameters']
        assert candidate['trace']['prefill'] == baseline['trace']['prefill'] == '<think'
        assert len(candidate['trace']['http']) == len(baseline['trace']['http']) == 2
        for old_http, new_http in zip(baseline['trace']['http'], candidate['trace']['http']):
            old_payload = json.loads(base64.b64decode(old_http['request_body_base64']))
            new_wire = base64.b64decode(new_http['request_body_base64'])
            assert sha(new_wire) == new_http['request_body_sha256']
            new_payload = json.loads(new_wire)
            assert old_http['url'] == new_http['url']
            assert {k: v for k, v in old_payload.items() if k != 'prompt'} == {
                k: v for k, v in new_payload.items() if k != 'prompt'}
            tail = '✿\nBot✿<think'
            assert new_payload['prompt'] == old_payload['prompt'][:-len(tail)] + plan['suffix'] + tail
            response = base64.b64decode(new_http['response_body_base64'])
            assert sha(response) == new_http['response_body_sha256']
            assert new_http['http_status'] == 200 and new_http['response_body_complete']
            http_receipt = json.loads((ROOT / 'run/http' / f"{case}.{new_http['stage']}.completed.json").read_bytes())
            assert http_receipt['trace'] == new_http
            if new_http['stage'] == 'completion':
                assert json.loads(response)['choices'][0]['text'] == candidate['raw_text']
        literal = judgments['candidate']['final_output']
        if case == 'resolver_04':
            diagnostic = ('Final text identifies E1 for all three fields, matching the actual complete '
                          '£25,000 / £196,362 / 29-day source; the one-line field layout fails the '
                          'unchanged parser. Diagnostic only, no accepted positive evidence.')
        elif case == 'resolver_07':
            diagnostic = ('Final text now says NONE for all fields, consistent with the heading-only '
                          'source. It no longer invents the baseline amounts, but one-line layout '
                          'still fails; no score is restored.')
        else:
            diagnostic = ('Final NONE decisions match the actual source and context lacking these '
                          'three fundraising facts; only syntactically accepted rows count as passes.')
        rows.append({'id': case, 'source_id': source['id'], 'source_type': source['metadata']['content_type'],
            'page_id': source['metadata']['page_id'], 'original_source_span': source_span,
            'expected_selections': gold['expected_selections'], **judgments,
            'manual_final_text_diagnostic': diagnostic,
            'candidate_nonconforming_single_line': not judgments['candidate']['protocol_valid'] and '\n' not in literal,
            'baseline_receipt_sha256': sha(baseline_path.read_bytes()),
            'candidate_receipt_sha256': sha(candidate_path.read_bytes())})
    assert len(rows) == 24
    review = ROOT / 'review'
    review.mkdir(exist_ok=True)
    with (review / 'rows.jsonl').open('w') as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False) + '\n')
    summary = {'reviewer': 'Codex context_resolution, experiment author; transparent non-blind source review',
        'scope': 'One exposed case, 24 existing resolver source inputs: 1 positive and 23 negatives; not end-to-end.',
        'plan_sha256': sha((ROOT / 'PLAN.json').read_bytes()),
        'run_files_sha256': sha((ROOT / 'run/FILES.json').read_bytes()),
        'input_wire_and_source_audit': 'PASS', 'raw_http_requests': 48, 'model_generations': 24,
        'original_source_input_denominator': 24, 'field_slot_denominator': 72,
        'baseline': dict(totals['baseline']), 'candidate': dict(totals['candidate']),
        'candidate_all_status_completed': True, 'candidate_single_line_protocol_failures': 17,
        'positive_source_deliverable_before': False, 'positive_source_deliverable_after': False,
        'formal_selection_regressions': [r['id'] for r in rows
            if r['baseline']['complete_selection_pass'] and not r['candidate']['complete_selection_pass']],
        'formal_selection_improvements': [r['id'] for r in rows
            if not r['baseline']['complete_selection_pass'] and r['candidate']['complete_selection_pass']],
        'decision': 'Reject this suffix as a production candidate under the frozen protocol.',
        'interpretation': 'The reminder fixes value-vs-ID behavior in the positive raw final text and removes the heading hallucination, but promotes comma-separated fields on one line. This is not accepted by the original parser; no parser edits or thinking score rescue were applied.',
        'limitations': ['24 inputs come from one previously exposed question; negative-heavy sample.',
            'Comparison uses original baseline receipts, not a fresh concurrent baseline; GPU batching and timing differ.',
            'No new Planner/BM25/Writer calls; no end-to-end quality improvement can be claimed.',
            'One startup attempt failed before Python with exit209/STDOUT and zero model calls; retained separately.']}
    (review / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == '__main__':
    main()
