"""Serialize explicit, non-blind semantic judgments; no HTTP or automatic semantics."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json

B = Path(__file__).resolve().parents[1]
M = Path('/home/chase/GitHub/rwkvrag-bm250820/llamaindex-retrieval')
def sha(data): return hashlib.sha256(data).hexdigest()
def write(path, value):
    with path.open('x', encoding='utf-8') as out:
        out.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def source_span(source, quote, reason, fact_ids):
    text=source['snippet']; start=text.index(quote)
    assert text.count(quote)==1
    return {'source_id':source['id'], 'document_id':source['document_id'],
            'page_id':source['metadata']['page_id'], 'source_text_sha256':source['metadata']['source_text_sha256'],
            'source_snippet_sha256':sha(text.encode()), 'start':start, 'end':start+len(quote),
            'unit':'unicode_code_points_in_actual_source_snippet', 'quote':quote,
            'original_document_start':source['metadata']['source_span']['start']+source['metadata']['span_start']+start,
            'original_document_end':source['metadata']['source_span']['start']+source['metadata']['span_start']+start+len(quote),
            'fact_ids':fact_ids, 'reason':reason}

CRITERIA={
 'oracle':'All 8 exposed development smoke cases and all 29 frozen required facts. This is not a fresh blind test or a production accuracy estimate.',
 'answer_boundary':'Only generation.answer_span within the unchanged response.answer/raw Writer text; never rescue facts or citations from thinking, a planner, or a resolver.',
 'fact_status':'Each frozen required fact judged semantically as correct, omitted, or incorrect independently of citations. A refusal omits requested positive facts; an affirmative conflicting value or denial is incorrect.',
 'formal_full':'Expected decision, every required fact correct and supported by its actual numbered source through literal [资料 N], and no material extra error or unsupported extra citation.',
 'human_readable_full':'Separate diagnostic with the same factual/support constraints; explicit unambiguous naked or round-parenthesis source numbers may count even when not parsed by the current API. This does not change the formal score.',
 'alternatives':'A different actual quoted passage may support the same fact. Record its identity and Unicode offsets; full-page knowledge or oracle text absent from the Writer input cannot supply a citation.',
 'decision_layers':'Frozen corpus answerability is distinct from justified abstention given the selected Writer evidence. All cases require answer at E2E; refusal does not become a successful corpus-level decision merely because upstream selected no evidence.',
 'citation_occurrences':'Every actual final-body citation occurrence is assessed, including extra citations and reused labels. No citations are inferred from a correct uncited fact.',
 'semantic_grading':'Codex explicit non-blind judgment, not keyword matching, automated semantic proof, or human expert acceptance. This script only binds bytes, offsets, and counts.'}

for run in ('wiki-smoke-v1','wiki-smoke-v2'):
    runpath=B/run; out=B/'review'/run
    out.mkdir(exist_ok=False)
    rawfixtures=(runpath/'frozen/fixtures.jsonl').read_bytes()
    assert rawfixtures==(M/'eval/native-wiki/fixtures.jsonl').read_bytes()
    fixtures=[json.loads(line) for line in rawfixtures.decode().splitlines()]
    manifest=json.loads((runpath/'manifest.json').read_text())
    assert manifest['fixtures_sha256']==sha(rawfixtures)
    assert manifest['oracle_required_fact_count']==29
    rows=[]
    for f in fixtures:
        id=f['id']; recordpath=runpath/'completed'/f'{id}.json'; record=json.loads(recordpath.read_text())
        response=record['response']; generation=response['generation']; raw=response['answer']; bounds=generation['answer_span']
        writers=[call for call in generation['model_calls'] if call['stage']=='writer']
        if bounds is None:
            final=''; assert not writers and raw=='' and generation['status']=='planner_failed'
        else:
            assert len(writers)==1 and writers[0]['raw_text']==raw==generation['raw_model_answer']
            env=writers[0]['envelope']; assert env['valid'] and bounds==[env['answer_span']['start'],env['answer_span']['end']]
            assert writers[0]['status']=='completed' and writers[0]['finish_reason']=='stop'
            final=raw[bounds[0]:bounds[1]]
        sources=response['sources']; facts=[]
        for fact in f['oracle']['required_facts']:
            facts.append({'id':fact['id'],'claim':fact['claim'],'status':'omitted','answer_quote':None,
                          'formal_supported':False,'human_readable_supported':False,
                          'reason':'未提供这一必需事实；原始最终正文为空。' if not final else '最终正文未回答这一必需事实；拒答不算提供事实。'})
        citations=[]; available=[]; extra=[]; diagnostic=[]
        action='no_answer' if not final else 'abstain'
        writer_handling='unassessable' if not final else 'correct_given_selected_evidence'
        if run=='wiki-smoke-v1':
            if not final:
                planner=generation['model_calls'][0]
                assert planner['status']==planner['finish_reason']=='length'
                diagnostic.append('Planner 输出达到1024 token上限，没有可用完整计划；Writer没有运行。原始Planner thinking不计答案。')
            else:
                assert id=='held_017' and not sources
                diagnostic.append('Writer收到零证据并明确拒答；这一判断符合当前空材料，但固定5000篇语料中的Ghost条目可回答三事实，因此E2E仍失败。')
        else:
            assert len(writers)==1
            if id=='held_010':
                action='partial_abstain'
                facts[1].update(status='correct',answer_quote='事件驱动模型。',formal_supported=True,human_readable_supported=True,
                                reason='回答事件驱动模型，随后逐字引出循环模型被该模型取代的原句；与F2等价且正式[资料 1]实际支持。')
                assert len(sources)==1
                quote='在IEC 61499中，IEC61131的循环执行模型被事件驱动模型所取代。'
                evidence=source_span(sources[0],quote,'实际Writer片段直接说明循环执行模型被事件驱动模型取代。',['F2'])
                available.append(evidence)
                token='[资料 1]'; start=final.index(token); assert final.count(token)==1
                citations.append({'text':token,'start':start,'end':start+len(token),'unit':'unicode_code_points_in_final_answer',
                                  'formal_api_recognized':True,'human_readable':True,'label_id':1,'source_id':sources[0]['id'],
                                  'attached_claim':'执行模型名称为事件驱动模型，并以此取代循环执行模型。',
                                  'support':'supported','supported_fact_ids':['F2'],'supporting_spans':[evidence]})
                diagnostic.append('只有IEC 61499一个实际证据片段；其余三个问题拒答。部分回答与当前材料一致，未完成原多文档任务。')
            elif id=='held_012':
                assert len(sources)==1 and sources[0]['snippet']=='# JR九州305系電聯車\n'
                diagnostic.append('Resolver保留的唯一来源只有14字符标题，无法证明305编组/动力车数量，也没有ICE事实；Writer拒答有当前材料依据，完整检索任务仍失败。')
            elif id=='held_014':
                assert len(sources)==1
                quote='Worker 通過 Job Server 的分派，開始執行 Client 端的工作。'
                evidence=source_span(sources[0],quote,'实际句子同时标明Worker、Job Server与Client三者，以及Worker经Job Server分派执行Client工作的职责关系；是原长金标之外可直接核查的等价支持。',['F3','F4'])
                available.append(evidence)
                writer_handling='incorrect_over_abstention'
                extra.append({'claim':'原文未涉及三个角色的具体名称。','answer_quote':'以及三个角色的具体名称。',
                              'status':'incorrect','material':True,'reason':'实际唯一片段逐字出现Worker、Job Server、Client，并明确Worker执行职责；所称没有名称不成立。',
                              'contradicting_actual_spans':[evidence]})
                diagnostic.append('F3/F4已有实际Writer原文支持但最终不提供，均记omitted；不能用原文或raw thinking补成回答正确。另将错误的来源不足概括单列。')
            elif id=='held_019':
                assert not sources
                action='answer_with_uncertainty'
                writer_handling='incorrect_unsupported_generation'
                facts[0].update(status='incorrect',answer_quote='Windows NT 3.5工作站版本本身不提供固定的并发连接上限。',
                                reason='不是仅缺少数字：最终正文肯定否认固定并发连接上限，和工作站版10客户端这一冻结事实冲突。')
                facts[1].update(status='correct',answer_quote='Mac客户端支持：不支持',
                                reason='不支持Mac这一必需事实正确；实际sources为空、正文没有引用，不能登记证据支持。随后仅支持Windows的额外泛化另记。')
                facts[2].update(status='incorrect',answer_quote='开发代号：Cairo（需核实，但历史资料中未提供直接证据）。',
                                reason='在答案字段给出Cairo而非Daytona；需核实限定不撤回已提出的错误代号，不降为omitted。')
                extra.append({'claim':'Windows NT 3.5仅支持Windows客户端。','answer_quote':'Windows NT 3.5仅支持Windows客户端。',
                              'status':'unsupported','material':True,'reason':'将所问的Mac不支持扩张为排除所有其他客户端，没有任何实际来源；不改变F2本身正确但无引用的独立判断。'})
                diagnostic.append('当前Writer零证据却从模型自身给出具体结论，其中两项错误。Cairo的需核实不是正式澄清，也没有撤销错误答案。')
            elif id=='held_021':
                assert not sources
                plan=response['retrieval']['plan']
                diagnostic.append('虽然Planner输出为合法JSON，但恢复了用户明确排除的退役日期、下水日期、建造厂、舰长、照片拍摄地点、潜水/参观/当前现场信息等字段。最终Writer未展开这些内容而是拒答；这是独立的计划语义失误，不虚构最终答案已包含这些错误。')
            else:
                assert not sources
                diagnostic.append('实际Writer输入没有逐字证据；最终拒答符合当前材料不足，但原语料题目可回答，原分母不删题。')
        for fact in facts:
            if fact['answer_quote'] is not None: assert fact['answer_quote'] in final
        assert generation['citation_audit']['label_ids']==([1] if citations else [])
        assert generation['citation_audit']['unknown_label_ids']==[]
        for cite in citations:
            assert generation['citation_map'][str(cite['label_id'])]==cite['source_id']
        row={'id':id,'record_path':str(recordpath.relative_to(B)),'record_sha256':sha(recordpath.read_bytes()),
             'fixture_row_sha256':sha(json.dumps(f,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()),
             'pipeline_status':generation['status'],'writer_status':generation.get('writer_status'),
             'raw_answer_sha256':sha(raw.encode()),'answer_modified':False,'final_answer_span':bounds,'final_answer':final,
             'expected_decision':f['oracle']['expected_action'],'observed_decision':action,
             'decision_review':{'e2e_task_satisfied':False,'writer_handling_of_actual_selected_evidence':writer_handling,
                                'reason':'固定完整语料中的题目可回答；是否在空或不足材料下合理拒答与是否完成原任务分开记录。'},
             'source_count':len(sources),'actual_sources':sources,'facts':facts,
             'citation_audit_original':generation['citation_audit'],'citations':citations,
             'available_actual_evidence_spans':available,'extra_claims':extra,
             'full_pass':False,'exact_format_full_pass':False,'human_readable_citation_full_pass':False,
             'diagnostics':diagnostic}
        if run=='wiki-smoke-v2' and id=='held_021': row['planner_scope_diagnostic']={'original_plan':response['retrieval']['plan'],'semantic_scope_correct':False,'only_final_answer_scored':True}
        rows.append(row)
    counts=Counter(f['status'] for row in rows for f in row['facts'])
    summary={'cases':len(rows),'required_facts':sum(len(row['facts']) for row in rows),
             'fact_status_counts':{key:counts[key] for key in ('correct','omitted','incorrect')},
             'formal_supported_correct_facts':sum(f['status']=='correct' and f['formal_supported'] for row in rows for f in row['facts']),
             'human_readable_supported_correct_facts':sum(f['status']=='correct' and f['human_readable_supported'] for row in rows for f in row['facts']),
             'exact_format_full_pass':0,'human_readable_citation_full_pass':0,'exact_format_passed_ids':[],'human_readable_citation_passed_ids':[],
             'formal_citation_occurrences':sum(c['formal_api_recognized'] for row in rows for c in row['citations']),
             'human_readable_citation_occurrences':sum(c['human_readable'] for row in rows for c in row['citations']),
             'pipeline_status_counts':dict(Counter(row['pipeline_status'] for row in rows)),
             'observed_decision_counts':dict(Counter(row['observed_decision'] for row in rows)),
             'writer_selected_evidence_handling_counts':dict(Counter(row['decision_review']['writer_handling_of_actual_selected_evidence'] for row in rows)),
             'e2e_satisfied_cases':0,'automatic_semantic_grading':False}
    assert summary['cases']==8 and summary['required_facts']==29
    assert summary['fact_status_counts']==({'correct':0,'omitted':29,'incorrect':0} if run=='wiki-smoke-v1' else {'correct':2,'omitted':25,'incorrect':2})
    bindpaths=[runpath/path for path in ['manifest.json','result.json','settings.json','source-manifest.json','frozen/fixtures.jsonl','frozen/run_wiki.py']]
    bindpaths += sorted(B.glob(run+'*AUDIT.json'))
    bindpaths += [B/'review/build_wiki_smoke_reviews.py']
    bindings=[{'path':str(path.relative_to(B)),'sha256':sha(path.read_bytes()),'bytes':path.stat().st_size} for path in bindpaths]
    report={'schema':'native-wiki-smoke-semantic-review-v1','reviewed_at':datetime.now(timezone.utc).isoformat(),
            'reviewer':'Codex independent non-blind development review; not human expert acceptance',
            'run':run,'criteria':CRITERIA,'summary':summary,'bindings':bindings,'rows':rows,
            'limitations':['Only 8 previously exposed cases; no new blind validation and no production-quality claim.',
                           'The dual citation criteria are identical here: the sole final-body citation in v2 is a supported formal [资料 1]; neither arm completes any case.',
                           'Stage completion and JSON validity do not establish semantic intent correctness, evidence sufficiency, or answer quality.',
                           'Source/transport/byte integrity comes from bound independent audit receipts, while semantic judgments are explicit Codex review.',
                           'This review does not infer full-corpus retrieval recall from final selected evidence and does not rerun any model.']}
    write(out/'review.json',report); write(out/'summary.json',summary)
    with (out/'rows.jsonl').open('x',encoding='utf-8') as target:
        for row in rows: target.write(json.dumps(row,ensure_ascii=False)+'\n')
    text=f'# {run} 独立语义审阅\n\n全部 8 题、29 个必需事实保留，已曝光开发 smoke，非新盲测。仅审原始 answer_span 正文，不从 thinking 补事实。\n\n事实：正确 {counts["correct"]}/29，遗漏 {counts["omitted"]}，错误 {counts["incorrect"]}。正式引用与明确人读引用两口径完整通过均 0/8；实际支持的正确事实为 {summary["formal_supported_correct_facts"]}/29。\n\n'
    text+='| 题目 | 正确/遗漏/错误 | 正式完整 | 人读完整 | 诊断 |\n|---|---|---|---|---|\n'
    for row in rows:
        count=Counter(f['status'] for f in row['facts'])
        text+=f'| {row["id"]} | {count["correct"]}/{count["omitted"]}/{count["incorrect"]} | 失败 | 失败 | {row["diagnostics"][0]} |\n'
    text+='\n详细每事实判断、唯一实际引用、替代原文位置与全部原收据哈希见 review.json。原输出、金标和源码均未修改。\n'
    with (out/'summary.md').open('x',encoding='utf-8') as target: target.write(text)
    write(out/'FROZEN.json',{'schema':'native-wiki-review-freeze-v1','run':run,'semantic_review_complete':True,
                            'original_case_count':8,'original_required_fact_count':29,
                            'files':[{'path':str(p.relative_to(B)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file()]})
    print(run,json.dumps(summary,ensure_ascii=False));print('review',sha((out/'review.json').read_bytes()),'freeze',sha((out/'FROZEN.json').read_bytes()))
