# wiki-smoke-v1 独立语义审阅

全部 8 题、29 个必需事实保留，已曝光开发 smoke，非新盲测。仅审原始 answer_span 正文，不从 thinking 补事实。

事实：正确 0/29，遗漏 29，错误 0。正式引用与明确人读引用两口径完整通过均 0/8；实际支持的正确事实为 0/29。

| 题目 | 正确/遗漏/错误 | 正式完整 | 人读完整 | 诊断 |
|---|---|---|---|---|
| held_004 | 0/4/0 | 失败 | 失败 | Planner 输出达到1024 token上限，没有可用完整计划；Writer没有运行。原始Planner thinking不计答案。 |
| held_010 | 0/4/0 | 失败 | 失败 | Planner 输出达到1024 token上限，没有可用完整计划；Writer没有运行。原始Planner thinking不计答案。 |
| held_012 | 0/4/0 | 失败 | 失败 | Planner 输出达到1024 token上限，没有可用完整计划；Writer没有运行。原始Planner thinking不计答案。 |
| held_014 | 0/4/0 | 失败 | 失败 | Planner 输出达到1024 token上限，没有可用完整计划；Writer没有运行。原始Planner thinking不计答案。 |
| held_016 | 0/4/0 | 失败 | 失败 | Planner 输出达到1024 token上限，没有可用完整计划；Writer没有运行。原始Planner thinking不计答案。 |
| held_017 | 0/3/0 | 失败 | 失败 | Writer收到零证据并明确拒答；这一判断符合当前空材料，但固定5000篇语料中的Ghost条目可回答三事实，因此E2E仍失败。 |
| held_019 | 0/3/0 | 失败 | 失败 | Planner 输出达到1024 token上限，没有可用完整计划；Writer没有运行。原始Planner thinking不计答案。 |
| held_021 | 0/3/0 | 失败 | 失败 | Planner 输出达到1024 token上限，没有可用完整计划；Writer没有运行。原始Planner thinking不计答案。 |

详细每事实判断、唯一实际引用、替代原文位置与全部原收据哈希见 review.json。原输出、金标和源码均未修改。
