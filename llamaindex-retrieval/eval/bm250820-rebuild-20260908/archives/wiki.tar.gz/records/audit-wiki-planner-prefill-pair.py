from pathlib import Path
import json,hashlib
B=Path(__file__).resolve().parent;A=B/'wiki-smoke-v1';C=B/'wiki-smoke-v2'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def calls(r):
 out={}
 for p in (r/'model-calls').glob('*.started.json'):
  start=read(p)
  if start['parameters']['stage']=='planner':out[start['case_id']]=(start,read(p.with_name(p.name.replace('.started.','.completed.'))))
 return out
a,c=calls(A),calls(C);assert set(a)==set(c) and len(a)==8
rows=[]
for id,(start,end) in c.items():
 oldstart,oldend=a[id];assert start['messages']==oldstart['messages']
 oldt,newt=oldend['trace'],end['trace'];assert newt['prompt']==oldt['prompt']+'></think'
 assert newt['parameters']==oldt['parameters']
 assert newt['prefill']=='<think></think' and oldt['prefill']=='<think'
 for oldhttp,newhttp in zip(oldt['http'],newt['http']):
  assert oldhttp['stage']==newhttp['stage'] and oldhttp['url']==newhttp['url']
  x,y=dict(oldhttp['payload']),dict(newhttp['payload']);assert y.pop('prompt')==x.pop('prompt')+'></think';assert x==y
 row=read(C/'completed'/f'{id}.json');events=row['response']['generation']['model_calls'];parsed='parse_error' not in events[0]
 rows.append({'id':id,'same_original_planner_messages':True,'only_planner_prefill_changed_in_wire':True,'planner_status':newt['status'],'finish_reason':newt['finish_reason'],'usage':newt.get('usage'),'strict_plan_accepted':parsed,'whole_case_status':row['response']['generation']['status'],'case_receipt_sha256':sha(C/'completed'/f'{id}.json')})
for p in (C/'model-calls').glob('*.completed.json'):
 row=read(p);t=row['trace']
 if t['stage']!='planner':assert t['prefill']=='<think'
x,y=read(A/'settings.json'),read(C/'settings.json');new=y.pop('native_planner_prefill');assert new=='<think></think';assert x==y
report={'status':'PASS_SINGLE_VARIABLE_CONTROL','cases':sorted(rows,key=lambda x:x['id']),'original_case_count':8,'predeclared_all_eight_valid_planners_pass':all(r['planner_status']=='completed' and r['strict_plan_accepted'] for r in rows),'settings_equal_except_new_planner_prefill':True,'resolver_writer_prefill_unchanged':True,'default_in_production_remains_open':True,'quality_proved_by_this_audit':False,'downstream_prompts_may_differ_as_a_result_of_changed_plans':True,'baseline_manifest_sha256':sha(A/'manifest.json'),'candidate_manifest_sha256':sha(C/'manifest.json')}
p=B/'wiki-smoke-v2-SINGLE-VARIABLE-AUDIT.json'
with p.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps(report,indent=2))
