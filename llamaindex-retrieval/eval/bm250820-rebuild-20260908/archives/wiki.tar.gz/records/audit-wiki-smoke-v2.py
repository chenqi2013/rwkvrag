from pathlib import Path
import base64,json,hashlib,importlib.util,sys
from collections import Counter
B=Path(__file__).resolve().parent;R=B/'wiki-smoke-v2'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(p):return json.loads(p.read_text())
def verify(condition,msg):
 if not condition:raise AssertionError(msg)
def body(entry,kind):
 data=base64.b64decode(entry[kind+'_body_base64'],validate=True)
 verify(sha(data)==entry[kind+'_body_sha256'],kind+' body SHA')
 return data
manifest=read(R/'manifest.json');source=read(R/'source-manifest.json');settings=read(R/'settings.json')
for rel,meta in source.items():
 data=(R/'source'/rel).read_bytes();verify(len(data)==meta['bytes'] and sha(data)==meta['sha256'],rel)
verify(sha((R/'source-manifest.json').read_bytes())==manifest['source_manifest_sha256'],'source manifest')
verify(sha((R/'frozen/run_wiki.py').read_bytes())==manifest['runner_sha256'],'runner')
verify(sha((R/'frozen/fixtures.jsonl').read_bytes())==manifest['fixtures_sha256'],'fixture')
verify(sha((R/'requests.json').read_bytes())==manifest['requests_sha256'],'requests')
spec=importlib.util.spec_from_file_location('frozen_wiki_runner',R/'frozen/run_wiki.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
verify(runner.summarize(R,manifest['case_ids'])==read(R/'result.json')['summary'],'summary replay')
binding={'manifest_sha256':sha((R/'manifest.json').read_bytes()),'settings_sha256':sha((R/'settings.json').read_bytes())}
fixtures=[json.loads(line) for line in (R/'frozen/fixtures.jsonl').read_text().splitlines()]
requests=read(R/'requests.json');verify(len(requests)==8,'original 8')
for row,req in zip(fixtures,requests):verify(req=={'id':row['id'],'payload':runner.request_payload(row,80,'wiki-5000-20260908')},'original input/oracle isolation')
starts={p.stem:read(p) for p in (R/'started').glob('*.json')};ends={p.stem:read(p) for p in (R/'completed').glob('*.json')}
verify(set(starts)==set(ends)==set(manifest['case_ids']),'8 exact case receipts')
calls={};stage=Counter();statuses=Counter();http=Counter();callids=set();inputs=[];outputs=[]
startfiles=sorted((R/'model-calls').glob('*.started.json'));endfiles=sorted((R/'model-calls').glob('*.completed.json'))
verify({p.name.split('.')[0] for p in startfiles}=={p.name.split('.')[0] for p in endfiles},'complete call receipts')
for p in startfiles:
 started=read(p);completed=read(p.with_name(p.name.replace('.started.','.completed.')));t=completed['trace'];key=t['call_id']
 verify(key not in callids,'duplicate model call');callids.add(key);calls[key]=completed
 verify(started['run_binding']==completed['run_binding']==binding,'call binding')
 verify(started['case_id']==completed['case_id'],'call case binding')
 verify(t.get('raw_text')==completed.get('raw_text') and t.get('finish_reason')==completed.get('finish_reason'),'raw unchanged')
 stage[started['parameters']['stage']]+=1;statuses[(started['parameters']['stage'],completed['status'])]+=1
 hs=t['http'];verify(sum(e['stage']=='completion' for e in hs)<=1,'no completion retry')
 for entry in hs:
  wire=json.loads(body(entry,'request'));verify(wire==entry['payload'],'wire request payload')
  http[(entry['stage'],entry.get('http_status'))]+=1
  if 'response_body_base64' in entry:
   responsebody=body(entry,'response')
   if entry.get('http_status')==200 and entry.get('response_body_complete'):
    parsed=json.loads(responsebody)
    if entry['stage']=='completion':
     verify(parsed['choices'][0]['text']==completed['raw_text'],'actual response raw text')
     verify(parsed['choices'][0]['finish_reason']==completed['finish_reason'],'actual finish')
    elif entry['stage']=='tokenize':
     toks=parsed['tokens'];verify(toks[0]==0 and toks.count(0)==1 and len(toks)==parsed['count'],'single BOS/token length')
  if entry['stage']=='completion':
   verify(wire['prompt']==t['prompt'],'prompt wire identical');verify(wire['max_tokens']==(2048 if t['stage']=='writer' else 1024),'output budget')
 if t.get('budget'):inputs.append(t['budget']['input_tokens'])
indexrows={};needed=set()
for row in ends.values():
 for source in row.get('response',{}).get('retrieval',{}).get('candidates',[]):needed.add(source['id'])
for line in (B/'index-import-v1/indexed-records.jsonl').open():
 row=json.loads(line)
 if row['_id'] in needed:indexrows[row['_id']]=row['_source']
verify(set(indexrows)==needed,'candidate IDs belong to frozen index')
for id,row in ends.items():
 verify(row['run_binding']==starts[id]['run_binding']==binding,'case binding')
 verify(row['request_sha256']==sha(runner.encoded(starts[id]['request'])),'case request SHA')
 if row['outcome']!='response':continue
 response=row['response'];gen=response['generation'];ret=response['retrieval'];candidates={x['id']:x for x in ret.get('candidates',[])}
 for sid,item in candidates.items():
  raw=indexrows[sid];verify(item['snippet']==raw['text'] and item['document_id']==raw['document_id'],'candidate index exact')
 for item in response['sources']:
  meta=item['metadata'];parent=candidates[meta['parent_source_id']]
  verify(item['snippet']==parent['snippet'][meta['span_start']:meta['span_end']],'evidence continuous source span')
  verify(sha(item['snippet'].encode())==meta['span_sha256'],'evidence span SHA')
 for event in gen['model_calls']:
  actual=calls[event['call_id']];verify(actual['case_id']==id,'event call case')
  for key,value in actual['trace'].items():verify(event[key]==value,'response event raw trace '+key)
 writers=[e for e in gen['model_calls'] if e['stage']=='writer']
 if writers:verify(len(writers)==1 and gen['raw_model_answer']==writers[0]['raw_text'] and response['answer']==(writers[0]['raw_text'] if writers[0]['raw_text'] is not None else ''),'immutable final answer')
 verify(gen['answer_modified'] is False,'answer immutable flag')
 verify(gen['citation_map']=={str(i):s['id'] for i,s in enumerate(response['sources'],1)},'citation source map')
indexstarts=sorted((R/'index-http').glob('*.started.json'));indexends=sorted((R/'index-http').glob('*.completed.json'))
verify({p.name.split('.')[0] for p in indexstarts}=={p.name.split('.')[0] for p in indexends},'index receipts complete')
for p in indexstarts:
 a=read(p);z=read(p.with_name(p.name.replace('.started.','.completed.')));verify(a['run_binding']==z['run_binding']==binding,'index binding');body(a,'request')
 if 'response_body_base64' in z:body(z,'response')
verify(read(R/'index-before.json')==read(R/'index-after.json'),'index UUID/documents/sequence unchanged')
report={'status':'PASS','run':str(R),'original_case_count':8,'source_manifest_sha256':manifest['source_manifest_sha256'],'runner_sha256':manifest['runner_sha256'],'complete_case_receipts':len(ends),'model_call_receipts':len(calls),'calls_by_stage':dict(stage),'statuses_by_stage':{str(k):v for k,v in statuses.items()},'model_http':{str(k):v for k,v in http.items()},'actual_generation_attempts':read(R/'result.json')['summary']['generation_attempts'],'index_http_receipts':len(indexstarts),'candidate_ids_verified_against_frozen_index':len(needed),'input_token_range':[min(inputs),max(inputs)] if inputs else None,'index_unchanged':True,'source_unchanged':True,'answer_immutable':True,'oracle_sent':False,'semantic_quality_scored':False,'all_failures_retained':True}
output=B/'wiki-smoke-v2-INDEPENDENT-AUDIT.json'
with output.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps(report,indent=2))
