from pathlib import Path
import os,json,hashlib,subprocess,tarfile,datetime
B=Path('/home/chase/rwkvrag-bm-rebuild-20260908')
def save(name,data):
 p=B/name
 with p.open('x') as f:json.dump(data,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
S=B/'source-wiki-v2';S.mkdir()
with tarfile.open(B/'source-wiki-v2.tar.gz') as t:t.extractall(S,filter='data')
manifest=json.loads((S/'SOURCE-MANIFEST.json').read_text())
def verify():
 for rel,entry in manifest['files'].items():
  data=(S/rel).read_bytes();assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'],rel
verify()
result=subprocess.run(['/home/chase/.local/bin/uv','sync','--frozen','--python','3.13'],cwd=S,capture_output=True,text=True)
save('wiki-v2-venv-RESULT.json',dict(completed_at=now(),returncode=result.returncode,stdout=result.stdout,stderr=result.stderr))
if result.returncode:raise SystemExit(result.returncode)
verify()
base=[str(S/'.venv/bin/python'),str(S/'eval/native-wiki/run_wiki.py'),'--base-url','http://127.0.0.1:18421/v1','--opensearch-url','http://127.0.0.1:18438','--index','rwkvrag-bm250820-wiki-5000-20260908','--model','rwkv7-g1j-13.3b-zero-state-capability-ctx16384','--expected-index-uuid','AaG0YmAZT5i8EHEhJHyNYw','--expected-source-sha256','df70a1e27d8141682584eb1b5d524208fd4fc84cec78d58cbcb206b884b82b8b','--knowledge-base-id','wiki-5000-20260908','--question-concurrency','4','--native-concurrency','32','--resolver-sources','24','--candidate-k','80','--max-tokens','2048','--timeout','600']
cmd=base+['--preflight','--out',str(B/'wiki-preflight-v2')]
start=now();result=subprocess.run(cmd,cwd=S,capture_output=True,text=True)
save('wiki-preflight-v2-process.json',dict(started_at=start,completed_at=now(),command=cmd,returncode=result.returncode,stdout=result.stdout,stderr=result.stderr))
print(result.stdout,result.stderr,flush=True)
if result.returncode:raise SystemExit(result.returncode)
verify()
assert not (B/'wiki-smoke-v1').exists()
unit='rwkvrag-bm250820-wiki-smoke-v1-20260908'
check=subprocess.run(['systemctl','--user','show',unit+'.service','-p','LoadState','--value'],capture_output=True,text=True)
assert check.stdout.strip() in {'','not-found'},check.stdout
cmd=['systemd-run','--user','--unit',unit,'--property=Restart=no','--property=StandardOutput=append:'+str(B/'wiki-smoke-v1.log'),'--property=StandardError=append:'+str(B/'wiki-smoke-v1.log'),'--working-directory='+str(S)]+base+['--run','--out',str(B/'wiki-smoke-v1')]
save('wiki-smoke-v1-LAUNCH-INTENT.json',dict(created_at=now(),command=cmd,unit=unit,source_manifest_sha256=hashlib.sha256((S/'SOURCE-MANIFEST.json').read_bytes()).hexdigest(),execution_sha256=hashlib.sha256((B/'wiki-smoke-v1-EXECUTION-v2.json').read_bytes()).hexdigest(),zero_retries=True))
result=subprocess.run(cmd,capture_output=True,text=True)
save('wiki-smoke-v1-LAUNCH-RESULT.json',dict(completed_at=now(),returncode=result.returncode,stdout=result.stdout,stderr=result.stderr))
print(json.dumps(dict(launch_returncode=result.returncode,stdout=result.stdout,stderr=result.stderr)),flush=True)
raise SystemExit(result.returncode)
