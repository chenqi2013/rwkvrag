"""Read existing receipts only: exact gold-span coverage and ranking diagnostics."""
import base64
import collections
import hashlib
import json
from pathlib import Path

B = Path('/home/chase/GitHub/rwkvrag-bm-rebuild-20260908')
RUN = B / 'wiki-smoke-v1'
OUT = B / 'wiki-smoke-v1-trace-review'
SOURCE = B / 'source-wiki-v2'
FIXTURES = SOURCE / 'eval/native-wiki/fixtures.jsonl'
CORPUS = Path('/home/chase/GitHub/rwkvrag-wiki-rag-20260908/corpus/finewiki-zh-5000')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def source_ranges(source):
    meta = source['metadata']
    page = meta['page_id']
    span = meta['source_span']
    start, end = span['start'], span['end']
    if 'parent_source_id' in meta:
        start, end = start + meta['span_start'], start + meta['span_end']
    body = (CORPUS / 'texts' / f'{page}.md').read_bytes().decode()
    assert body[start:end] == source['snippet']
    assert sha(body.encode()) == meta['source_text_sha256']
    intervals = [(page, start, end)]
    for context in meta.get('context_spans', []):
        assert body[context['start']:context['end']] == context['text']
        assert sha(context['text'].encode()) == context['sha256']
        intervals.append((page, context['start'], context['end']))
    return intervals


def contains(intervals, quote):
    right = quote['start']
    for start, end in sorted((a, b) for page, a, b in intervals if page == quote['page_id']):
        if end <= right:
            continue
        if start > right:
            return False
        right = max(right, end)
        if right >= quote['end']:
            return True
    return False


def fact_covered(intervals, fact):
    return any(all(contains(intervals, quote) for quote in group)
               for group in fact['evidence_sets'])


def stage_report(sources, facts):
    ranges = [interval for source in sources for interval in source_ranges(source)]
    return {
        'sources': len(sources),
        'documents': len({source['document_id'] for source in sources}),
        'content_types': dict(collections.Counter(source['metadata']['content_type'] for source in sources)),
        'whitespace_only': sum(not source['snippet'].strip() for source in sources),
        'covered_facts': [fact['id'] for fact in facts if fact_covered(ranges, fact)],
        'missing_facts': [fact['id'] for fact in facts if not fact_covered(ranges, fact)],
    }


def first_coverage(sources, fact):
    ranges = []
    for rank, source in enumerate(sources, 1):
        ranges.extend(source_ranges(source))
        if fact_covered(ranges, fact):
            return rank
    return None


def main():
    fixtures = [json.loads(line) for line in FIXTURES.read_text().splitlines()]
    raw_queries = collections.defaultdict(list)
    for started_path in sorted((RUN / 'index-http').glob('*.started.json')):
        started = json.loads(started_path.read_bytes())
        completed_path = started_path.with_name(started_path.name.replace('.started.', '.completed.'))
        if not completed_path.exists():
            continue
        completed = json.loads(completed_path.read_bytes())
        body = base64.b64decode(started['request_body_base64'])
        assert sha(body) == started['request_body_sha256']
        if not body or not started.get('case_id'):
            continue
        query = json.loads(body)
        if not query.get('query', {}).get('bool', {}).get('must'):
            continue
        raw = base64.b64decode(completed['response_body_base64'])
        assert sha(raw) == completed['response_body_sha256']
        response = json.loads(raw)
        raw_queries[started['case_id']].append({
            'receipt': str(started_path.relative_to(RUN)),
            'query': query, 'hits': response['hits']['hits'],
        })
    results = []
    for fixture in fixtures:
        case = fixture['id']
        receipt_path = RUN / 'completed' / f'{case}.json'
        if not receipt_path.exists():
            results.append({'id': case, 'receipt_missing': True})
            continue
        receipt = json.loads(receipt_path.read_bytes())
        response = receipt.get('response', {})
        retrieval = response.get('retrieval', {})
        generation = response.get('generation', {})
        facts = fixture['oracle']['required_facts']
        candidates = retrieval.get('candidates', [])
        candidate_by_id = {source['id']: source for source in candidates}
        selected = [candidate_by_id[identity] for identity in retrieval.get('resolver_source_ids', [])]
        final = response.get('sources', [])
        groups = [[candidate_by_id[identity] for identity in group]
                  for group in retrieval.get('query_results', [])]
        round_robin = []
        seen = set()
        for rank in range(max(map(len, groups), default=0)):
            for group in groups:
                if rank < len(group) and group[rank]['id'] not in seen:
                    seen.add(group[rank]['id'])
                    round_robin.append(group[rank])
        row = {
            'id': case, 'receipt_sha256': sha(receipt_path.read_bytes()),
            'generation_status': generation.get('status'),
            'plan': retrieval.get('plan'),
            'fact_count': len(facts),
            'candidates': stage_report(candidates, facts),
            'resolver_input': stage_report(selected, facts),
            'final_sources': stage_report(final, facts),
            'counterfactual_round_robin24': stage_report(round_robin[:24], facts),
            'counterfactual_note': 'Only selection from already observed query lists; no model run or quality claim.',
            'fact_ranks': [{
                'id': fact['id'], 'claim': fact['claim'],
                'fused_first_full_exact_coverage_rank': first_coverage(candidates, fact),
                'per_query_first_full_exact_coverage_rank': [first_coverage(group, fact) for group in groups],
            } for fact in facts],
            'resolver_events': [{key: event.get(key) for key in (
                'stage', 'source_id', 'status', 'finish_reason', 'parse_error', 'selections',
                'units', 'prompt_tokens', 'completion_tokens',
            )} for event in generation.get('model_calls', []) if event.get('stage') == 'resolver'],
            'resolver_top_sources': [{
                'rank': rank, 'id': source['id'], 'title': source['title'],
                'characters': len(source['snippet']), 'type': source['metadata']['content_type'],
                'source_span': source['metadata']['source_span'], 'rrf_score': source['score'],
                'per_query_rank': [next((i for i, item in enumerate(group, 1)
                                        if item['id'] == source['id']), None) for group in groups],
            } for rank, source in enumerate(selected, 1)],
            'raw_bm25_queries': [{
                'receipt': query['receipt'], 'query': query['query'],
                'hits': [{
                    'rank': rank, 'id': hit['_id'], 'score': hit['_score'],
                    'title': hit['_source']['metadata']['title'],
                    'type': hit['_source']['metadata']['content_type'],
                    'characters': len(hit['_source']['text']),
                    'source_span': hit['_source']['metadata']['source_span'],
                } for rank, hit in enumerate(query['hits'], 1)],
            } for query in raw_queries[case]],
        }
        results.append(row)
    report = {'scope': 'Eight exposed development cases; exact original gold-span AND/OR coverage is not semantic quality.',
              'source_manifest_sha256': sha((SOURCE / 'SOURCE-MANIFEST.json').read_bytes()),
              'index_freeze_sha256': sha((B / 'index-import-v1/INDEX-FREEZE.json').read_bytes()),
              'fixtures_sha256': sha(FIXTURES.read_bytes()), 'rows': results}
    (OUT / 'exact-ranking-analysis.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps([{'id': row['id'], 'status': row.get('generation_status'),
                       **{stage: row.get(stage, {}).get('covered_facts') for stage in
                          ('candidates', 'resolver_input', 'final_sources', 'counterfactual_round_robin24')}}
                      for row in results], ensure_ascii=False))


if __name__ == '__main__':
    main()
