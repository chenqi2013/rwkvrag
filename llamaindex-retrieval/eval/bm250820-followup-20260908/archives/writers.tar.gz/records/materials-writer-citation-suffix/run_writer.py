"""Replay eight frozen Writer messages; append only the frozen final citation reminder."""
import argparse
import asyncio
import base64
from collections import Counter
import importlib.util
import json
from pathlib import Path
import sys
import time

PLAN_SHA = "e6d38789d846c6b7438b94a6a8fb57e02938b293cb241bec7c7ab34772c215cf"


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def preflight(root):
    recorder = load(root / "frozen/recording_runner.py", "writer_original_recorder")
    assert recorder.sha256((root / "PLAN.json").read_bytes()) == PLAN_SHA
    plan = json.loads((root / "PLAN.json").read_bytes())
    for name, record in plan["bindings"].items():
        data = (root / name).read_bytes()
        assert len(data) == record["bytes"] and recorder.sha256(data) == record["sha256"], name
    native = load(root / "frozen/native_rwkv.py", "writer_original_native")
    rows = json.loads((root / "requests.json").read_bytes())
    assert len(rows) == 8 and len({r["id"] for r in rows}) == 8
    checks = []
    for row in rows:
        old = json.loads((root / "baseline" / (row["id"] + ".completed.json")).read_bytes())["trace"]
        suffix = (root / "SUFFIX.txt").read_text()
        assert len(row["messages"]) == len(old["messages"]) == 1
        assert row["messages"][0] == {**old["messages"][0], "content": old["messages"][0]["content"] + suffix}
        assert row["baseline_parameters"] == old["parameters"]
        assert old["prefill"] == "<think" and old["stage"] == "writer"
        assert row["kwargs"]["assistant_prefill"] == "<think"
        assert row["kwargs"]["evidence_ids"] == old["evidence_ids"]
        assert row["kwargs"]["stage"] == "writer"
        for key in ("max_tokens", "temperature", "top_p", "top_k", "presence_penalty", "frequency_penalty"):
            assert row["kwargs"][key] == old["parameters"][key]
        assert row["kwargs"]["max_tokens"] == 2048
        assert ("seed" in row["kwargs"]) == ("seed" in old["parameters"])
        if "seed" in row["kwargs"]:
            assert row["kwargs"]["seed"] == old["parameters"]["seed"]
        before = native.render_native_prompt(old["messages"], "<think")
        after = native.render_native_prompt(row["messages"], "<think")
        assert before.prompt == old["prompt"] == row["baseline_prompt"]
        assert after.prompt == before.prompt.replace(old["messages"][0]["content"], row["messages"][0]["content"], 1)
        assert before.prompt.count(old["messages"][0]["content"]) == 1
        assert before.delimiter_escape == after.delimiter_escape
        checks.append({"id": row["id"], "original_messages_unchanged_before_suffix": True, "parameters_identical": True,
                       "only_final_user_suffix_added": True, "prompt_sha256": recorder.sha256(after.prompt.encode())})
    return recorder, native, plan, rows, checks


async def execute(root, recorder, native, plan, rows, checks):
    release = root / "GPU-RELEASE.json"
    assert release.is_file(), "explicit previous-job GPU release required"
    out = root / "run"
    out.mkdir(exist_ok=False)
    for name in ("model-started", "model-completed", "http-started", "http-completed", "completed"):
        (out / name).mkdir()
    bindings = {"plan_sha256": PLAN_SHA, "runner_sha256": recorder.sha256(Path(__file__).read_bytes()),
                "gpu_release_sha256": recorder.sha256(release.read_bytes())}
    recorder.write_new(out / "MANIFEST.json", {**bindings, "started_at": recorder.utc_now(),
        "case_count": 8, "preflight": checks, "automatic_retries": 0,
        "inference_inputs": "requests.json only; gold/review never loaded during inference"})
    cls = recorder.recording_client_class(native.NativeRWKVClient)
    client = cls(out, base_url=plan["base_url"], model=plan["model"],
                 timeout_seconds=plan["timeout_seconds"], context_window_tokens=plan["context_window_tokens"],
                 max_concurrency=8)
    active = peak = 0
    start = time.perf_counter()

    async def one(row, check):
        nonlocal active, peak
        context = recorder.CASE_ID.set(row["id"])
        trace = {}
        record = {**bindings, "id": row["id"]}
        active += 1
        peak = max(peak, active)
        try:
            result = await client.complete(row["messages"], trace=trace, **row["kwargs"])
            record.update(status=result.status, raw_text=result.raw_text, finish_reason=result.finish_reason)
            assert trace["messages"] == row["messages"]
            assert trace["parameters"] == row["baseline_parameters"]
            assert trace["prefill"] == "<think"
            assert trace["prompt_sha256"] == check["prompt_sha256"]
            for event in trace["http"]:
                raw = base64.b64decode(event["request_body_base64"])
                assert recorder.sha256(raw) == event["request_body_sha256"]
                assert json.loads(raw) == event["payload"]
                if "response_body_base64" in event:
                    assert recorder.sha256(base64.b64decode(event["response_body_base64"])) == event["response_body_sha256"]
            record["wire_input_audit"] = "PASS"
        except BaseException as error:
            record.update(exception_type=type(error).__name__)
            if isinstance(error, asyncio.CancelledError):
                raise
        finally:
            active -= 1
            record.update(trace=trace, completed_at=recorder.utc_now())
            recorder.write_new(out / "completed" / (row["id"] + ".json"), record)
            recorder.CASE_ID.reset(context)
        return record
    try:
        results = await asyncio.gather(*(one(row, check) for row, check in zip(rows, checks)))
    finally:
        await client.aclose()
    summary = {**bindings, "completed_at": recorder.utc_now(), "original_denominator": 8,
        "required_fact_denominator": 28, "receipts": len(results),
        "statuses": dict(Counter(r.get("status", "exception") for r in results)),
        "generation_attempts": sum(r["trace"].get("completion_attempted") is True for r in results),
        "http_requests": sum(len(r["trace"].get("http", [])) for r in results),
        "peak_active_calls": peak, "elapsed_seconds": time.perf_counter() - start,
        "semantic_quality_reviewed": False, "end_to_end_quality_claim": False}
    recorder.write_new(out / "SUMMARY.json", summary)
    hashes = {str(p.relative_to(out)): {"bytes": p.stat().st_size, "sha256": recorder.sha256(p.read_bytes())}
              for p in sorted(out.rglob("*")) if p.is_file()}
    recorder.write_new(out / "FILES.json", hashes)
    print(json.dumps(summary), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--run", action="store_true")
    args = parser.parse_args()
    prepared = preflight(args.root)
    if args.run:
        asyncio.run(execute(args.root, *prepared))
    else:
        print(json.dumps({"status": "PASS", "plan_sha256": PLAN_SHA, "checks": prepared[-1]}))


if __name__ == "__main__":
    main()
