#!/bin/sh
set -eu
cd /home/chase/rwkvrag-bm-rebuild-20260908/materials-writer-citation-suffix
exec /home/chase/rwkvrag-bm-rebuild-20260908/source-wiki-v2/.venv/bin/python run_writer.py --root /home/chase/rwkvrag-bm-rebuild-20260908/materials-writer-citation-suffix --run
