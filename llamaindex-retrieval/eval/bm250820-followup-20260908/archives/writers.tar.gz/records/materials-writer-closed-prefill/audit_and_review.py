"""Offline byte audit and mechanical serialization of explicit Codex judgments."""
import argparse, base64, collections, hashlib, importlib.util, json, re, sys
from datetime import datetime, timezone
from pathlib import Path

def sha(b): return hashlib.sha256(b).hexdigest()
def enc(v): return (json.dumps(v, ensure_ascii=False, indent=2, sort_keys=True)+'\n').encode()
def read(p): return json.loads(p.read_bytes())
def write(p,v): p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(enc(v))
def pin(p): return {'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
def main(r):
 spec=importlib.util.spec_from_file_location('offline_runner',r/'run_writer.py'); runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
 recorder,native,plan,requests,checks=runner.preflight(r)
 files=read(r/'run/FILES.json')
 actual={str(p.relative_to(r/'run')) for p in (r/'run').rglob('*') if p.is_file()}-{'FILES.json'}
 assert actual==set(files)
 for name,expected in files.items(): assert pin(r/'run'/name)==expected,name
 fixtures=[json.loads(line) for line in (r/'frozen/fixtures.jsonl').read_text().splitlines()]
 judgments=read(r/'judgments.json'); out=[]; audit=[]
 assert {x['id'] for x in fixtures}==set(judgments['cases'])
 for case,req,check in zip(fixtures,requests,checks):
  cid=case['id']; assert cid==req['id']==check['id']
  c=read(r/f'run/completed/{cid}.json'); t=c['trace']
  mc=read(r/f'run/model-completed/{cid}.001.json'); ms=read(r/f'run/model-started/{cid}.001.json')
  assert mc['trace']==t and mc['trace_sha256']==sha(recorder.encode(t))
  assert ms['messages']==req['messages'] and ms['arguments']==req['kwargs']
  assert ms['automatic_retry'] is False and t['messages']==req['messages'] and t['parameters']==req['baseline_parameters']
  assert t['prompt_sha256']==check['prompt_sha256']==sha(t['prompt'].encode())
  assert t['prefill']==req['kwargs']['assistant_prefill']
  for stage,event in zip(('tokenize','completion'),t['http']):
   n=1 if stage=='tokenize' else 2
   hs=read(r/f'run/http-started/{cid}.{n:03d}.{stage}.json'); hc=read(r/f'run/http-completed/{cid}.{n:03d}.{stage}.json')
   assert hc['event']==event and hc['pre_send_body_matches'] is True
   assert hs['payload']==event['payload'] and hs['request_body_sha256']==event['request_body_sha256']
   assert hs['automatic_retry'] is False and event['http_status']==200
   for direction in ('request','response'):
    body=base64.b64decode(event[direction+'_body_base64'],validate=True)
    assert sha(body)==event[direction+'_body_sha256']
    if direction=='request': assert json.loads(body)==event['payload']
   assert event['payload']['prompt']==t['prompt']
  assert len(t['http'])==2
  # Decode only the frozen original user data prefix, which remains unchanged by either experimental suffix.
  old=read(r/f'baseline/{cid}.completed.json')['trace']['messages'][0]['content']
  task=json.loads(old.split('\n任务：',1)[1].split('\n字段：',1)[0])
  assert task=={'history':case.get('history',[]),'latest_question':case['question']}
  materials=json.loads(old.split('\n逐字证据：',1)[1]); assert len(materials)==len(case['materials'])
  for n,(mat,goldmat) in enumerate(zip(materials,case['materials']),1):
   assert mat['text']==goldmat['snippet'] and mat['id']==goldmat['id']
   assert mat['label']==f'资料 {n}' and mat['title']==goldmat['title'] and mat['uri']==goldmat['uri']
  byid={m['id']:m for m in materials}
  for fact in case['expected_facts']:
   for q in fact['supporting_quotes']: assert byid[q['material_id']]['text'][q['start']:q['end']]==q['quote']
  raw=c['raw_text']; bounds=native.inspect_envelope(raw,t['prefill']); envelope={'valid':bounds is not None,'answer_span':{'start':bounds[0],'end':bounds[1],'unit':'unicode_code_points'} if bounds else None,'raw_text_modified':False}; assert envelope==t['envelope']
  span=envelope.get('answer_span'); answer=raw[span['start']:span['end']] if span else ''
  j=judgments['cases'][cid]; assert len(j['answers'])==len(j['statuses'])==len(case['expected_facts'])
  formal_ranges={(m.start(1),m.end(1)) for m in re.finditer(r'\[(资料\s*[1-9][0-9]*)\]',answer)}
  citations=[]
  for m in re.finditer(r'资料\s*([1-9][0-9]*)',answer):
   number=int(m.group(1)); info=j['cites'][str(number)]; mat=materials[number-1]
   support=[q for f in case['expected_facts'] if f['id'] in info['facts'] for q in f['supporting_quotes'] if q['material_id']==mat['id']] if info['support']=='supported' else []
   if info['support']=='supported': assert support, (cid,number,'explicit alternative spans required')
   citations.append(dict(surface=m.group(),start=m.start(),end=m.end(),formal_api_syntax=(m.start(),m.end()) in formal_ranges,human_readable_binding=True,material_number=number,material_id=mat['id'],title=mat['title'],material_sha256=sha(mat['text'].encode()),bound_fact_ids=info['facts'],support=info['support'],reason=info['reason'],supporting_actual_spans=support))
  assert {str(x['material_number']) for x in citations}==set(j['cites'])
  facts=[]
  for f,status,quote in zip(case['expected_facts'],j['statuses'],j['answers']):
   at=answer.index(quote) if quote else None
   supports=[c for c in citations if c['support']=='supported' and f['id'] in c['bound_fact_ids']]
   facts.append(dict(id=f['id'],expected_claim=f['claim'],status=status,answer_quote=quote,answer_span={'start':at,'end':at+len(quote)} if quote else None,formal_supported=status=='correct' and any(c['formal_api_syntax'] for c in supports),human_readable_supported=status=='correct' and bool(supports),human_readable_supporting_material_numbers=sorted({c['material_number'] for c in supports}),oracle_actual_material_spans=f['supporting_quotes'],reason=j['reason']))
  extras=[]
  for e in j['extra_errors']:
   at=answer.index(e['quote']);extras.append({**e,'start':at,'end':at+len(e['quote']),'material':True})
  core=c['status']=='completed' and j['decision_correct'] and all(f['status']=='correct' for f in facts)
  clean=core and not extras and all(c['support']=='supported' for c in citations)
  exact=clean and all(f['formal_supported'] for f in facts)
  readable=clean and all(f['human_readable_supported'] for f in facts)
  out.append(dict(id=cid,record_sha256=sha((r/f'run/completed/{cid}.json').read_bytes()),transport_status=c['status'],raw_answer_sha256=sha(raw.encode()),final_answer_span=span,final_answer=answer,final_answer_sha256=sha(answer.encode()),thinking_used_for_facts_or_citations=False,expected_decision=case['expected_decision'],actual_decision=j['decision'],decision_correct=j['decision_correct'],decision_reason=j['reason'],facts=facts,citations=citations,extra_claim_errors=extras,core_facts_and_decision_pass=core,exact_format_full_pass=exact,human_readable_citation_full_pass=readable,full_pass=exact))
  audit.append({'id':cid,'wire':'PASS','original_task_and_full_materials':'PASS','gold_spans':'PASS','raw_envelope':'PASS','status':c['status'],'prompt_tokens':t['budget']['input_tokens'],'completion_tokens':t.get('usage',{}).get('completion_tokens')})
 count=collections.Counter(f['status'] for row in out for f in row['facts']); citations=[c for row in out for c in row['citations']]
 summary=dict(cases=8,required_facts=28,fact_status_counts={s:count[s] for s in ('correct','omitted','incorrect')},formal_supported_facts=sum(f['formal_supported'] for row in out for f in row['facts']),human_readable_supported_correct_facts=sum(f['human_readable_supported'] for row in out for f in row['facts']),exact_format_full_pass=sum(x['exact_format_full_pass'] for x in out),human_readable_citation_full_pass=sum(x['human_readable_citation_full_pass'] for x in out),exact_format_passed_ids=[x['id'] for x in out if x['exact_format_full_pass']],human_readable_citation_passed_ids=[x['id'] for x in out if x['human_readable_citation_full_pass']],core_facts_and_decision_pass=sum(x['core_facts_and_decision_pass'] for x in out),decision_correct=sum(x['decision_correct'] for x in out),formal_citation_occurrences=sum(x['formal_api_syntax'] for x in citations),human_readable_citation_occurrences=len(citations),human_readable_citation_support_counts=dict(collections.Counter(x['support'] for x in citations)),automatic_semantic_grading=False)
 write(r/'INDEPENDENT-AUDIT.json',dict(status='PASS',checks=audit,files=len(files),model_calls=8,http_requests=16,bytes_only_not_semantic=True))
 bindings={n:pin(r/n) for n in ['PLAN.json','run_writer.py','frozen/fixtures.jsonl','judgments.json','INDEPENDENT-AUDIT.json','run/FILES.json','baseline/review.json','audit_and_review.py']}
 report=dict(schema='writer-materials-explicit-review-v1',reviewed_at=datetime.now(timezone.utc).isoformat(),reviewer=judgments['reviewer'],run=str(r),summary=summary,baseline_summary=read(r/'baseline/review.json')['summary'],criteria=plan['criteria'],bindings=bindings,rows=out,limitations=plan['limits'],automatic_promotion=False)
 write(r/'review/review.json',report);write(r/'review/summary.json',summary)
 (r/'review/rows.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in out))
 text=['# 固定材料 Writer 开发审阅','',f"正式引用完整通过 {summary['exact_format_full_pass']}/8，人读引用诊断 {summary['human_readable_citation_full_pass']}/8。事实正确 {count['correct']}/28，遗漏 {count['omitted']}，错误 {count['incorrect']}。",'', '每个引用均逐项核对实际材料，仅评原始 answer_span；代码只校验与汇总明确审阅。该实验只重放 Writer，不能说明检索或端到端质量。','', '|题目|正确事实|正式完整|人读完整|原因|','|---|---:|---|---|---|']
 for row in out: text.append(f"|{row['id']}|{sum(f['status']=='correct' for f in row['facts'])}/{len(row['facts'])}|{row['exact_format_full_pass']}|{row['human_readable_citation_full_pass']}|{row['decision_reason']}|")
 (r/'review/summary.md').write_text('\n'.join(text)+'\n')
 write(r/'review/FROZEN.json',{'frozen_at':datetime.now(timezone.utc).isoformat(),'bindings':{**bindings,**{str(p.relative_to(r)):pin(p) for p in (r/'review').iterdir() if p.is_file() and p.name!='FROZEN.json'}},'no_model_calls_during_review':True})
 print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);main(p.parse_args().root)
