"""Read-only byte/source/envelope/strict-parser replay of all eight receipts."""
from pathlib import Path
import base64
import json
from types import SimpleNamespace
import run_planner as runner


def main():
    root=Path(__file__).resolve().parent
    plan,requests,native,parse,checks=runner.preflight(root)
    pre=json.loads((root/'PRE-RUN-FREEZE.json').read_text())
    for rel,value in pre['files'].items():
        raw=(root/rel).read_bytes()
        assert runner.sha(raw)==value['sha256'] and len(raw)==value['bytes']
    assert runner.sha((root/'run_planner.py').read_bytes())==pre['runner_sha256']
    fs=json.loads((root/'run/FILES.json').read_text())
    for rel,value in fs.items():
        raw=(root/'run'/rel).read_bytes()
        assert runner.sha(raw)==value['sha256'] and len(raw)==value['bytes']
    settings=SimpleNamespace(**json.loads((root/'settings.json').read_text()))
    rows=[]
    for item,check in zip(requests,checks):
        id=item['id'];path=root/'run/completed'/f'{id}.json';r=json.loads(path.read_text());trace=r['trace']
        started=json.loads((root/'run/started'/f'{id}.json').read_text())
        assert started['messages']==trace['messages']==item['messages']
        assert started['kwargs']==item['kwargs']
        assert trace['parameters']==item['baseline_parameters']
        assert trace['prefill']==item['kwargs']['assistant_prefill']=='<think></think'
        assert trace['prompt_sha256']==check['candidate_prompt_sha256']==runner.sha(trace['prompt'].encode())
        assert trace['raw_text']==r['raw_text']
        assert trace['raw_text_sha256']==runner.sha(r['raw_text'].encode())
        assert len(trace['http'])==2 and trace['completion_attempted']
        for h in trace['http']:
            req=base64.b64decode(h['request_body_base64'],validate=True)
            res=base64.b64decode(h['response_body_base64'],validate=True)
            assert runner.sha(req)==h['request_body_sha256'] and runner.sha(res)==h['response_body_sha256']
            assert json.loads(req)==h['payload'] and h['http_status']==200 and h['response_body_complete']
            hs=json.loads((root/'run/http'/f'{id}.{h["stage"]}.started.json').read_text())
            hc=json.loads((root/'run/http'/f'{id}.{h["stage"]}.completed.json').read_text())
            assert hs['payload']==h['payload'] and hc['trace']==h
            if h['stage']=='completion':
                body=json.loads(res)
                assert body['choices'][0]['text']==r['raw_text']
                assert body['choices'][0]['finish_reason']==r['finish_reason']==trace['finish_reason']
        bounds=native.inspect_envelope(r['raw_text'],trace['prefill'])
        assert trace['envelope']['answer_span']=={'start':bounds[0],'end':bounds[1],'unit':'unicode_code_points'}
        final=r['raw_text'][bounds[0]:bounds[1]]
        try:
            if r['status']!='completed':raise ValueError('not completed')
            parsed=parse(final.strip(),settings);valid=True;error=None
        except (ValueError,TypeError) as exc:
            parsed=None;valid=False;error=str(exc)
        assert r['protocol_valid']==valid
        assert error==r.get('parse_error')
        if valid:assert parsed==r['parsed_plan'] and parsed['fields']==parsed['queries']
        assert 'exception' not in r
        rows.append({'id':id,'receipt_sha256':runner.sha(path.read_bytes()),'status':r['status'],'finish_reason':r['finish_reason'],
                     'protocol_valid':valid,'parse_error':error,'raw_final_body':final,'usage':trace['usage'],
                     'task_json_unchanged':True,'parameters_and_prefill_unchanged':True,'wire_bytes_verified':True})
    summary=json.loads((root/'run/SUMMARY.json').read_text())
    assert summary['original_denominator']==summary['receipts']==len(rows)==8
    assert summary['protocol_valid']==sum(r['protocol_valid'] for r in rows)==0
    result={'status':'PASS','meaning':'Byte/transport/source/frozen-parser integrity passed; model strict plan validity is separately0/8.',
            'original_cases':8,'generation_attempts':8,'native_http':16,'http200':16,'natural_completed':8,'strict_plans_accepted':0,
            'original_raw_unchanged':True,'same_task_json':True,'only_planner_contract_changed':True,'retry_count':0,'rows':rows}
    with (root/'INDEPENDENT-AUDIT.json').open('x') as out:out.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='rows'},ensure_ascii=False))


if __name__=='__main__':main()
