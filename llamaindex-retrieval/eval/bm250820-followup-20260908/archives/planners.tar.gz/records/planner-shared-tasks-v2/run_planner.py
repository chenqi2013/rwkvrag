"""Single-variable planner contract replay, using frozen client/parser and fsynced receipts."""
from __future__ import annotations

import argparse
import ast
import asyncio
import base64
import collections
import contextvars
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time
from types import SimpleNamespace
from datetime import datetime, timezone

PLAN_SHA = "0cce525480b5d56c54320ab81a97f652d80b5e1e0dbcbe69ef29615ed8d3f74d"
SLOT = contextvars.ContextVar("planner_contract_slot")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2).encode() + b"\n"


def now():
    return datetime.now(timezone.utc).isoformat()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(encoded(value))
        stream.flush()
        os.fsync(stream.fileno())
    descriptor = os.open(path.parent, os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def load_modules(root):
    path = root / "frozen/native_rwkv.py"
    spec = importlib.util.spec_from_file_location("frozen_planner_native", path)
    native = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = native
    spec.loader.exec_module(native)
    tree = ast.parse((root / "frozen/rwkv_pipeline.py").read_text())
    selected = [node for node in tree.body if isinstance(node, ast.FunctionDef)
                and node.name in {"planner_prompt", "parse_plan"}]
    if len(selected) != 2:
        raise ValueError("frozen planner contract missing or ambiguous")
    scope = {"json": json, "Settings": SimpleNamespace}
    exec(compile(ast.Module(body=selected, type_ignores=[]), "frozen-planner-contract", "exec"), scope)
    return native, scope["parse_plan"], scope["planner_prompt"]


def preflight(root):
    assert sha((root / "PLAN.json").read_bytes()) == PLAN_SHA
    plan = json.loads((root / "PLAN.json").read_bytes())
    for name, record in plan["bindings"].items():
        raw = (root / name).read_bytes()
        assert len(raw) == record["bytes"] and sha(raw) == record["sha256"], name
    requests = json.loads((root / "requests.json").read_bytes())
    assert len(requests) == 8 and [item["id"] for item in requests] == plan["case_ids"]
    assert len(set(plan["case_ids"])) == 8
    settings = SimpleNamespace(**json.loads((root / "settings.json").read_bytes()))
    assert settings.native_plan_protocol == "shared_tasks"
    native, parse, builder = load_modules(root)
    checks = []
    for item in requests:
        old = json.loads((root / item["baseline_completed"]).read_bytes())
        trace = old["trace"]
        assert item["baseline_messages"] == trace["messages"]
        assert item["baseline_parameters"] == trace["parameters"]
        assert item["baseline_prompt"] == trace["prompt"]
        assert trace["stage"] == item["kwargs"]["stage"] == "planner"
        assert item["kwargs"]["evidence_ids"] == trace["evidence_ids"] == []
        assert item["kwargs"]["assistant_prefill"] == trace["prefill"] == "<think></think"
        assert item["kwargs"]["max_tokens"] == 1024
        for key in ("max_tokens", "temperature", "top_p", "top_k", "presence_penalty", "frequency_penalty"):
            assert item["kwargs"][key] == trace["parameters"][key]
        assert ("seed" in item["kwargs"]) == ("seed" in trace["parameters"])
        if "seed" in item["kwargs"]:
            assert item["kwargs"]["seed"] == trace["parameters"]["seed"]
        assert item["task_json"] == trace["messages"][0]["content"].split("\n任务：", 1)[1]
        assert set(json.loads(item["task_json"])) == {"history", "latest_question"}
        expected = [{"role": "user", "content": builder(item["task_json"], settings)}]
        assert item["messages"] == expected
        assert expected[0]["content"].split("\n任务：", 1)[1] == item["task_json"]
        old_render = native.render_native_prompt(trace["messages"], trace["prefill"])
        new_render = native.render_native_prompt(item["messages"], item["kwargs"]["assistant_prefill"])
        assert old_render.prompt == trace["prompt"]
        assert old_render.delimiter_escape == new_render.delimiter_escape
        checks.append({"id": item["id"], "same_task_json": True, "same_parameters_and_prefill": True,
                       "contract_only_changed": True, "candidate_prompt_sha256": sha(new_render.prompt.encode())})
    example = ["产品甲的桌面版支持什么格式？", "产品甲的手机版支持什么格式？"]
    parsed = parse(json.dumps(example, ensure_ascii=False), settings)
    assert parsed["queries"] == parsed["fields"] == example
    for invalid in ({"queries": ["x"]}, [{"query": "x"}], [{"question": "x"}], [], ["  "], [1]):
        try:
            parse(json.dumps(invalid), settings)
        except (ValueError, TypeError):
            pass
        else:
            raise AssertionError("frozen planner parser accepted invalid schema")
    return plan, requests, native, parse, checks


async def execute(root, plan, requests, native, parse, checks):
    output = root / "run"
    output.mkdir(exist_ok=False)
    if not (root / "GPU-RELEASE.json").is_file():
        raise ValueError("explicit prior job completion/release receipt required")
    bindings = {"plan_sha256": PLAN_SHA, "runner_sha256": sha(Path(__file__).read_bytes()),
                "gpu_release_sha256": sha((root / "GPU-RELEASE.json").read_bytes())}
    save(output / "MANIFEST.json", {"started_at": now(), **bindings, "calls": 8,
         "run_parameters": {key: plan[key] for key in ("base_url", "model", "timeout_seconds",
             "context_window_tokens", "native_concurrency", "automatic_retries")},
         "preflight": checks, "inference_inputs": "Original frozen requests only; no question gold or semantic review is included or loaded."})

    class RecordedClient(native.NativeRWKVClient):
        async def _post(self, url, payload, stage, trace):
            slot = SLOT.get()
            save(output / "http" / f"{slot}.{stage}.started.json",
                 {**bindings, "id": slot, "stage": stage, "url": url,
                  "payload": payload, "started_at": now()})
            try:
                return await super()._post(url, payload, stage, trace)
            finally:
                save(output / "http" / f"{slot}.{stage}.completed.json",
                     {**bindings, "id": slot, "completed_at": now(),
                      "trace": copy.deepcopy(trace["http"][-1])})

    client = RecordedClient(base_url=plan["base_url"], model=plan["model"],
                            timeout_seconds=plan["timeout_seconds"],
                            context_window_tokens=plan["context_window_tokens"],
                            max_concurrency=plan["native_concurrency"])
    active = 0
    peak = 0
    started = time.perf_counter()

    async def one(item, check):
        nonlocal active, peak
        token = SLOT.set(item["id"])
        trace = {}
        begin = time.perf_counter()
        save(output / "started" / f"{item['id']}.json",
             {**bindings, "id": item["id"], 
              "messages": item["messages"], "kwargs": item["kwargs"], "started_at": now()})
        active += 1
        peak = max(peak, active)
        receipt = {**bindings, "id": item["id"], 
                   "case_id": item["id"]}
        try:
            result = await client.complete(item["messages"], trace=trace, **item["kwargs"])
            receipt.update(status=result.status, raw_text=result.raw_text, finish_reason=result.finish_reason)
            assert trace["messages"] == item["messages"]
            assert trace["parameters"] == item["baseline_parameters"]
            assert trace["prompt_sha256"] == check["candidate_prompt_sha256"]
            for http in trace["http"]:
                request = base64.b64decode(http["request_body_base64"])
                assert sha(request) == http["request_body_sha256"]
                assert json.loads(request) == http["payload"]
                if "response_body_base64" in http:
                    assert sha(base64.b64decode(http["response_body_base64"])) == http["response_body_sha256"]
            receipt["wire_input_audit"] = "PASS"
            try:
                if result.status != "completed":
                    raise ValueError(f"model stage did not complete: {result.status}")
                bounds = native.inspect_envelope(result.raw_text, item["kwargs"]["assistant_prefill"])
                if bounds is None:
                    raise ValueError("missing closed thinking envelope")
                body = result.raw_text[bounds[0]:bounds[1]].strip()
                receipt["parsed_plan"] = parse(body, SimpleNamespace(**json.loads((root / "settings.json").read_bytes())))
                assert receipt["parsed_plan"]["queries"] == receipt["parsed_plan"]["fields"]
                receipt["protocol_valid"] = True
            except (ValueError, TypeError) as error:
                receipt.update(protocol_valid=False, parse_error=str(error))
        except BaseException as error:
            receipt.update(exception_type=type(error).__name__, exception=str(error))
            if isinstance(error, asyncio.CancelledError):
                raise
        finally:
            active -= 1
            receipt.update(trace=trace, elapsed_ms=(time.perf_counter() - begin) * 1000, completed_at=now())
            save(output / "completed" / f"{item['id']}.json", receipt)
            SLOT.reset(token)
        return receipt

    semaphore = asyncio.Semaphore(plan["job_concurrency"])

    async def limited(item, check):
        async with semaphore:
            return await one(item, check)

    try:
        receipts = await asyncio.gather(*(limited(item, check) for item, check in zip(requests, checks)))
    finally:
        await client.aclose()
    summary = {**bindings, "completed_at": now(), "original_denominator": 8,
               "receipts": len(receipts), "statuses": dict(collections.Counter(r.get("status", "exception") for r in receipts)),
               "protocol_valid": sum(r.get("protocol_valid") is True for r in receipts),
               "generation_attempts": sum(r["trace"].get("completion_attempted") is True for r in receipts),
               "http_requests": sum(len(r["trace"].get("http", [])) for r in receipts),
               "actual_peak_active_calls": peak, "elapsed_seconds": time.perf_counter() - started,
               "semantic_quality_reviewed": False, "end_to_end_quality_claim": False}
    save(output / "SUMMARY.json", summary)
    hashes = {str(path.relative_to(output)): {"bytes": path.stat().st_size, "sha256": sha(path.read_bytes())}
              for path in sorted(output.rglob("*")) if path.is_file()}
    save(output / "FILES.json", hashes)
    print(json.dumps(summary), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--run", action="store_true")
    args = parser.parse_args()
    plan, requests, native, strict_parser, checks = preflight(args.root)
    if args.run:
        asyncio.run(execute(args.root, plan, requests, native, strict_parser, checks))
    else:
        print(json.dumps({"status": "PASS", "plan_sha256": PLAN_SHA,
                          "calls": len(checks), "checks": checks}), flush=True)


if __name__ == "__main__":
    main()
