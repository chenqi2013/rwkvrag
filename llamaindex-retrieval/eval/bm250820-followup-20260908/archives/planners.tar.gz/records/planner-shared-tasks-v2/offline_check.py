"""Eight in-process fake HTTP responses exercise the actual frozen transport."""
import asyncio
import contextlib
import io
import json
from pathlib import Path
import shutil
import tempfile
import httpx
import run_planner as runner


def main():
    source=Path(__file__).resolve().parent
    count={'tokenize':0,'completion':0}
    def handler(request):
        if request.url.path.endswith('/tokenize'):
            count['tokenize']+=1
            return httpx.Response(200,json={'count':2,'tokens':[0,1],'max_model_len':16384})
        assert request.url.path.endswith('/completions')
        count['completion']+=1
        n=count['completion']
        body='>["已知产品的指定属性是什么？"]'
        finish='stop'
        if n==2: body='>{"queries":["x"],"fields":["different"]}'
        if n==3: finish='length'
        return httpx.Response(200,json={'choices':[{'index':0,'text':body,'finish_reason':finish}],
                                      'usage':{'prompt_tokens':2,'completion_tokens':12,'total_tokens':14}})
    with tempfile.TemporaryDirectory() as temporary:
        root=Path(temporary)/'fixture'
        shutil.copytree(source,root,ignore=shutil.ignore_patterns('__pycache__'))
        plan,requests,native,parse,checks=runner.preflight(root)
        original=native.NativeRWKVClient
        class MockClient(original):
            def __init__(self,**kwargs):super().__init__(transport=httpx.MockTransport(handler),**kwargs)
        native.NativeRWKVClient=MockClient
        (root/'GPU-RELEASE.json').write_text('{"mock_only":true}')
        with contextlib.redirect_stdout(io.StringIO()):
            asyncio.run(runner.execute(root,plan,requests,native,parse,checks))
        summary=json.loads((root/'run/SUMMARY.json').read_text())
        assert summary['receipts']==8 and summary['protocol_valid']==6
        assert summary['statuses']=={'completed':7,'length':1}
        assert count=={'tokenize':8,'completion':8}
        assert len(list((root/'run/started').glob('*.json')))==8
        assert len(list((root/'run/completed').glob('*.json')))==8
        try:asyncio.run(runner.execute(root,plan,requests,native,parse,checks))
        except FileExistsError:pass
        else:raise AssertionError('run overwrote previous records')
        assert count=={'tokenize':8,'completion':8}
        target=root/'requests.json';target.write_text(target.read_text()+' ')
        try:runner.preflight(root)
        except AssertionError:pass
        else:raise AssertionError('mutated frozen inputs accepted')
    print(json.dumps({'status':'PASS','real_network_calls':0,'mock_tokenize':8,'mock_completion':8,
                      'checks':['full8 durable receipts','length retained','fields schema rejected','no retry','existing run rejected before HTTP','frozen input mismatch rejected','original actual-prefill transport and parser executed']}))


if __name__=='__main__':main()
