import re

def parse_selections(text: str, fields: int, units: int) -> list[tuple[int, int]]:
    """Selection syntax v2: fully consumed assignments, each field once.

    assignment := FIELD ':' (NONE | EVIDENCE (',' EVIDENCE)*)
    separator  := NEWLINE+ | (',' | ';') NEWLINE*

    Spaces/tabs are insignificant. A comma followed by another evidence ID
    continues the current value; otherwise it separates field assignments.
    Line breaks after a comma are allowed in either case. This only interprets
    syntax: it neither changes raw output nor verifies evidence relevance.
    """
    token_pattern = re.compile(
        r"[ \t]+|\r\n?|\n|f[1-9][0-9]*|E[1-9][0-9]*|NONE|[:,;]"
    )
    tokens: list[str] = []
    position = 0
    # Anchored scanning rejects every unknown character, including suffixes.
    while position < len(text):
        match = token_pattern.match(text, position)
        if match is None:
            raise ValueError("invalid resolver selection syntax")
        token = match[0]
        if token[0] not in " \t":
            tokens.append("\n" if token[0] in "\r\n" else token)
        position = match.end()

    cursor = 0

    def skip_newlines(index: int) -> int:
        while index < len(tokens) and tokens[index] == "\n":
            index += 1
        return index

    cursor = skip_newlines(cursor)
    if cursor == len(tokens):
        raise ValueError("invalid resolver selection syntax")
    output: list[tuple[int, int]] = []
    seen: set[int] = set()
    while cursor < len(tokens):
        if not tokens[cursor].startswith("f"):
            raise ValueError("invalid resolver selection syntax")
        field = int(tokens[cursor][1:])
        if field > fields or field in seen:
            raise ValueError("unknown or repeated field")
        seen.add(field)
        cursor += 1
        if cursor == len(tokens) or tokens[cursor] != ":":
            raise ValueError("invalid resolver selection syntax")
        cursor += 1
        if cursor == len(tokens):
            raise ValueError("invalid resolver selection syntax")
        if tokens[cursor] == "NONE":
            cursor += 1
        else:
            while True:
                if not tokens[cursor].startswith("E"):
                    raise ValueError("invalid resolver selection syntax")
                unit = int(tokens[cursor][1:])
                if unit > units:
                    raise ValueError("unknown evidence unit")
                if (field, unit) not in output:
                    output.append((field, unit))
                cursor += 1
                if cursor == len(tokens) or tokens[cursor] != ",":
                    break
                following = skip_newlines(cursor + 1)
                if following == len(tokens) or not tokens[following].startswith("E"):
                    break
                cursor = following

        if cursor == len(tokens):
            break
        if tokens[cursor] == "\n":
            cursor = skip_newlines(cursor)
        elif tokens[cursor] in {",", ";"}:
            cursor = skip_newlines(cursor + 1)
            if cursor == len(tokens):
                raise ValueError("invalid resolver selection syntax")
        else:
            raise ValueError("invalid resolver selection syntax")
    if seen != set(range(1, fields + 1)):
        raise ValueError("resolver omitted a field")
    return output
