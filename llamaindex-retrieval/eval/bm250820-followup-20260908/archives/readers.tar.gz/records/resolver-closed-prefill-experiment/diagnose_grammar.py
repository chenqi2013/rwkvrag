from pathlib import Path
import json,re,importlib.util,collections,hashlib
R=Path(__file__).resolve().parent;D=R/'diagnostic-grammar-v2';B=R.parent
def module(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
runner=module(R/'run_replay.py','diagnostic_replay');plan,requests,native,oldparse,checks=runner.preflight(R);newparse=module(D/'parse_selections.py','next_grammar').parse_selections
refs=[json.loads(x) for x in (B/'wiki-smoke-v2/frozen/fixtures.jsonl').read_text().splitlines()]
counts=collections.defaultdict(collections.Counter);rows=[];selected=collections.defaultdict(lambda:collections.defaultdict(list));positive=[]
def parse(t,fn,nf,nu):
 if t['status']!='completed':return None,'not_completed',None
 bounds=native.inspect_envelope(t['raw_text'],t['prefill'])
 if not bounds:return None,'invalid_envelope',None
 body=t['raw_text'][bounds[0]:bounds[1]].strip()
 try:return fn(body,nf,nu),None,body
 except (ValueError,TypeError) as e:return None,str(e),body

def segments(item,unit):
 source=item['source'];meta=source['metadata'];span=meta['source_span'];text=source['snippet'][unit['start']:unit['end']]
 assert hashlib.sha256(text.encode()).hexdigest()==unit['sha256']
 out=[{'start':span['start']+unit['start'],'end':span['start']+unit['end'],'text':text,'meta':meta}]
 out +=[{**x,'meta':meta} for x in meta.get('context_spans',[])]
 return out

def cover(ref,segs):
 quote=ref['quote'];lo,hi=ref['start'],ref['end'];assert len(quote)==hi-lo;covered=[]
 for s in segs:
  m=s['meta']
  if m.get('external_id')!=ref['document_id'] or m.get('version')!=ref['revision_id'] or m.get('source_text_sha256')!=ref['body_sha256']:continue
  a,b=max(lo,s['start']),min(hi,s['end'])
  if a>=b:continue
  assert quote[a-lo:b-lo]==s['text'][a-s['start']:b-s['start']],'exact frozen gold/source intersection'
  covered.append((a,b))
 end=lo
 for a,b in sorted(covered):
  if a>end:return False
  end=max(end,b)
 return end>=hi

for item,check in zip(requests,checks):
 traces={'baseline':json.loads((R/item['baseline_completed']).read_text())['trace'],'closed':json.loads((R/'run/completed'/f"{item['id']}.json").read_text())['trace']};row={'id':item['id'],'case_id':item['case_id'],'source_title':item['source']['title'],'rank':item['baseline_rank'],'variants':{}}
 for arm,t in traces.items():
  for label,parser in [('strict',oldparse),('grammar-v2',newparse)]:
   mode=arm+'-'+label;chosen,error,body=parse(t,parser,check['fields'],check['units']);counts[mode]['total']+=1;counts[mode]['valid']+=chosen is not None;counts[mode]['selected_unit_instances']+=len({u for f,u in chosen or []});counts[mode]['field_unit_pairs']+=len(chosen or [])
   if chosen==[]:counts[mode]['valid_NONE']+=1
   if body:
    if any(len(re.findall(r'\bf[1-9][0-9]*\s*:',line))>1 for line in body.splitlines()):counts[mode]['multiple_fields_same_line']+=1
    rhs=re.findall(r'\bf[1-9][0-9]*\s*:\s*(.*?)(?=\bf[1-9][0-9]*\s*:|$)',body,re.S)
    invalid_rhs=[x.strip(' ,;\r\n\t') for x in rhs if not re.fullmatch(r'(?:NONE|E[1-9][0-9]*(?:\s*,\s*E[1-9][0-9]*)*)',x.strip(' ,;\r\n\t'))]
    counts[mode]['contains_non_id_rhs']+=bool(invalid_rhs)
   else:invalid_rhs=[]
   row['variants'][mode]={'status':t['status'],'parsed':chosen,'error':error,'body':body,'non_id_rhs_examples':invalid_rhs}
   for u in {u for f,u in chosen or []}:selected[mode][item['case_id']].extend(segments(item,item['units'][u-1]))
 for unit in item['units']:
  segs=segments(item,unit);selected['available-resolver-units'][item['case_id']].extend(segs)
  matched=[]
  oracle=next(x['oracle'] for x in refs if x['id']==item['case_id'])
  for fact in oracle['required_facts']:
   if any(all(cover(ref,segs) for ref in refs0) for refs0 in fact['evidence_sets']):matched.append(fact['id'])
  if matched:
   positive.append({'request_id':item['id'],'case_id':item['case_id'],'source_title':item['source']['title'],'rank':item['baseline_rank'],'unit_id':unit['id'],'gold_full_quote_fact_ids':matched,'variants':{mode:{'selected':any(u==int(unit['id'][1:]) for f,u in v['parsed'] or []),'error':v['error'],'body':v['body']} for mode,v in row['variants'].items()}})
 rows.append(row)
coverage={}
for mode,bycase in selected.items():
 coverage[mode]=[]
 for fixture in refs:
  facts=fixture['oracle']['required_facts'];segs=bycase[fixture['id']];found=[f['id'] for f in facts if any(all(cover(ref,segs) for ref in refs0) for refs0 in f['evidence_sets'])]
  coverage[mode].append({'id':fixture['id'],'full_quote_covered':found,'required_count':len(facts)})
for name,values in [('rows.jsonl',rows),('positive-source-units.jsonl',positive)]:
 with (D/name).open('x') as f:
  for row in values:f.write(json.dumps(row,ensure_ascii=False,sort_keys=True)+'\n')
summary={'status':'PASS_OFFLINE_DIAGNOSTIC_ONLY','primary_old_strict_result_unchanged':True,'parser_sha256':hashlib.sha256((D/'parse_selections.py').read_bytes()).hexdigest(),'metrics':{m:dict(v) for m,v in counts.items()},'full_gold_AND_OR_quote_coverage':coverage,'total_fact_groups':29,'coverage_is_not_answer_quality_or_field_support':True,'inference_requests':0}
with (D/'SUMMARY.json').open('x') as f:json.dump(summary,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'metrics':summary['metrics'],'coverage':{k:sum(len(x['full_quote_covered']) for x in v) for k,v in coverage.items()},'positive_source_units':len(positive)},ensure_ascii=False,indent=2))
