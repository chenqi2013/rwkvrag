from pathlib import Path
import json,hashlib,collections
R=Path(__file__).resolve().parent;B=R.parent
requests=json.loads((R/'requests.json').read_text());fixtures=[json.loads(x) for x in (B/'wiki-smoke-v2/frozen/fixtures.jsonl').read_text().splitlines()]
def segments(item,unit):
 source=item['source'];meta=source['metadata'];span=meta['source_span'];text=source['snippet'][unit['start']:unit['end']]
 assert hashlib.sha256(text.encode()).hexdigest()==unit['sha256']
 out=[{'start':span['start']+unit['start'],'end':span['start']+unit['end'],'text':text,'meta':meta}]
 out +=[{**x,'meta':meta} for x in meta.get('context_spans',[])]
 return out

def cover(ref,segs):
 quote=ref['quote'];lo,hi=ref['start'],ref['end'];assert len(quote)==hi-lo;covered=[]
 for s in segs:
  m=s['meta']
  if m.get('external_id')!=ref['document_id'] or m.get('version')!=ref['revision_id'] or m.get('source_text_sha256')!=ref['body_sha256']:continue
  a,b=max(lo,s['start']),min(hi,s['end'])
  if a>=b:continue
  assert quote[a-lo:b-lo]==s['text'][a-s['start']:b-s['start']],'exact frozen gold/source intersection'
  covered.append((a,b))
 end=lo
 for a,b in sorted(covered):
  if a>end:return False
  end=max(end,b)
 return end>=hi
selected=collections.defaultdict(lambda:collections.defaultdict(list));positive=[]
for item in requests:
 baseline=json.loads((R/item['baseline_completed']).read_text());current=json.loads((R/'run/completed'/f"{item['id']}.json").read_text())
 oldunits={u for f,u in baseline.get('selections',[])} if baseline.get('protocol_valid') else set()
 newunits=set(current.get('selected_units',[])) if current.get('protocol_valid') else set()
 for unit in item['units']:
  segs=segments(item,unit);selected['available-resolver'][item['case_id']].extend(segs)
  for mode,ids in [('closed-fields',oldunits),('task-units',newunits)]:
   if unit['id'] in ids:selected[mode][item['case_id']].extend(segs)
  facts=next(x['oracle']['required_facts'] for x in fixtures if x['id']==item['case_id']);matched=[f['id'] for f in facts if any(all(cover(ref,segs) for ref in refs) for refs in f['evidence_sets'])]
  if matched:positive.append({'request_id':item['id'],'case_id':item['case_id'],'rank':item['baseline_rank'],'title':item['source']['title'],'unit':unit['id'],'gold_full_quote_fact_ids':matched,'baseline_selected':unit['id'] in oldunits,'task_selected':unit['id'] in newunits,'task_status':current['status'],'task_protocol_valid':current['protocol_valid'],'task_raw_text':current['raw_text']})
for p in (R/'baseline/cases').glob('*.json'):
 row=json.loads(p.read_text())
 for source in row['response']['retrieval']['candidates']:
  fake={'source':source};u={'start':0,'end':len(source['snippet']),'sha256':hashlib.sha256(source['snippet'].encode()).hexdigest()};selected['raw-retrieved'][row['id']].extend(segments(fake,u))
coverage={}
for mode,bycase in selected.items():
 coverage[mode]=[]
 for fixture in fixtures:
  facts=fixture['oracle']['required_facts'];found=[f['id'] for f in facts if any(all(cover(ref,bycase[fixture['id']]) for ref in refs) for refs in f['evidence_sets'])]
  coverage[mode].append({'id':fixture['id'],'covered_fact_ids':found,'required_fact_count':len(facts),'missing_fact_ids':[f['id'] for f in facts if f['id'] not in found]})
report={'kind':'Complete original gold AND/OR quote exact identity+span coverage; not semantic field support or answer score','coverage':coverage,'totals':{k:sum(len(x['covered_fact_ids']) for x in v) for k,v in coverage.items()},'original_fact_denominator':29,'all_8_case_denominators_preserved':True,'reference_fixture_sha256':hashlib.sha256((B/'wiki-smoke-v2/frozen/fixtures.jsonl').read_bytes()).hexdigest()}
with (R/'EXACT-EVIDENCE-COVERAGE.json').open('x') as f:json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n')
with (R/'positive-source-unit-diagnostic.jsonl').open('x') as f:
 for row in positive:f.write(json.dumps(row,ensure_ascii=False,sort_keys=True)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
