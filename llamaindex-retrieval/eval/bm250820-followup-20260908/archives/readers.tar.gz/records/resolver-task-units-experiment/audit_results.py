from pathlib import Path
import json,hashlib,base64,importlib.util,sys,collections
from datetime import datetime
R=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def h(data):return hashlib.sha256(data).hexdigest()
spec=importlib.util.spec_from_file_location('frozen_replay_runner',R/'run_replay.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
plan,requests,native,parse,checks=runner.preflight(R)
files=read(R/'run/FILES.json')
for rel,v in files.items():
 p=R/'run'/rel;assert p.stat().st_size==v['bytes'] and sha(p)==v['sha256'],rel
assert {str(p.relative_to(R/'run')) for p in (R/'run').rglob('*') if p.is_file()}==set(files)|{'FILES.json'}
ids={r['id'] for r in requests};assert {p.stem for p in (R/'run/started').glob('*.json')}==ids=={p.stem for p in (R/'run/completed').glob('*.json')}
counts={mode:collections.Counter() for mode in ['baseline','task_units']};statuses={mode:collections.Counter() for mode in counts};httpcounts=collections.Counter();worksheets=[];intervals=[];seen_callids=set()
def selections(status,raw,prefill,fields,units):
 if status!='completed':return None
 bounds=native.inspect_envelope(raw,prefill)
 if bounds is None:return None
 try:return [f'E{u}' for u in parse(raw[bounds[0]:bounds[1]].strip(),units)]
 except (ValueError,TypeError):return None
for item,check in zip(requests,checks):
 before=read(R/item['baseline_completed']);old=before['trace'];row=read(R/'run/completed'/f"{item['id']}.json");start=read(R/'run/started'/f"{item['id']}.json");t=row['trace']
 assert row['id']==start['id']==item['id'] and start['messages']==item['messages'] and start['kwargs']==item['kwargs']
 assert row['plan_sha256']==runner.PLAN_SHA and row['runner_sha256']==sha(R/'run_replay.py')
 assert t['call_id'] not in seen_callids;seen_callids.add(t['call_id'])
 assert t['messages']==item['messages'] and t['parameters']==old['parameters'] and t['prompt_sha256']==check['candidate_prompt_sha256']
 assert t['prefill']==old['prefill']=='<think></think'
 assert t.get('raw_text')==row.get('raw_text') and t.get('finish_reason')==row.get('finish_reason')
 assert sum(e['stage']=='completion' for e in t['http'])<=1
 for e in t['http']:
  a=read(R/'run/http'/f"{item['id']}.{e['stage']}.started.json");z=read(R/'run/http'/f"{item['id']}.{e['stage']}.completed.json");assert z['trace']==e and a['payload']==e['payload']
  raw=base64.b64decode(e['request_body_base64'],validate=True);assert h(raw)==e['request_body_sha256'] and json.loads(raw)==e['payload']
  if 'response_body_base64' in e:
   raw=base64.b64decode(e['response_body_base64'],validate=True);assert h(raw)==e['response_body_sha256']
   if e.get('http_status')==200 and e.get('response_body_complete'):
    payload=json.loads(raw)
    if e['stage']=='completion':assert payload['choices'][0]['text']==row['raw_text'] and payload['choices'][0]['finish_reason']==row['finish_reason']
  httpcounts[(e['stage'],e.get('http_status'))]+=1
 oldchosen=before.get('selections',[]) if before.get('protocol_valid') else []
 oldunits={pair[1] for pair in oldchosen}
 counts['baseline']['original_denominator']+=1
 counts['baseline']['protocol_valid']+=before.get('protocol_valid') is True
 counts['baseline']['selected_unit_instances']+=len(oldunits)
 statuses['baseline'][old['status']]+=1
 chosen=selections(t['status'],t['raw_text'],t['prefill'],check['fields'],check['units'])
 counts['task_units']['original_denominator']+=1
 counts['task_units']['protocol_valid']+=chosen is not None
 counts['task_units']['selected_unit_instances']+=len(chosen or [])
 statuses['task_units'][t['status']]+=1
 assert row['protocol_valid']==(chosen is not None) and row.get('selected_units',[])==(chosen or [])
 if chosen is not None:assert row['field_coverage_assessed'] is False
 for unit in chosen or []:
  u=next(x for x in item['units'] if x['id']==unit);text=item['source']['snippet'][u['start']:u['end']]
  assert h(text.encode())==u['sha256']
  worksheets.append({'request_id':item['id'],'case_id':item['case_id'],'source_id':item['source_id'],'source_title':item['source']['title'],'source_uri':item['source']['uri'],'task':item['task'],'subquestions':list(item['fields'].values()),'unit_id':unit,'unit':u,'selected_text':text,'full_source':item['source'],'new_selected_unit':unit not in oldunits,'baseline_selected_pairs':oldchosen,'task_selected_units':chosen,'field_coverage_assessed':False,'semantic_review':'PENDING_NOT_AUTOMATICALLY_VERIFIED','completion_receipt_sha256':sha(R/'run/completed'/f"{item['id']}.json")})
 end=datetime.fromisoformat(t['ended_at']).timestamp();intervals.extend([(end-t['active_ms']/1000,1),(end,-1)])
active=peak=0
for _,delta in sorted(intervals,key=lambda x:(x[0],x[1])):active+=delta;peak=max(active,peak)
with (R/'selected-unit-review.jsonl').open('x') as f:
 for x in worksheets:f.write(json.dumps(x,ensure_ascii=False,sort_keys=True)+'\n')
report={'status':'PASS_MECHANICAL_REPLAY','original_denominator':192,'baseline':{'statuses':dict(statuses['baseline']),**counts['baseline']},'task_units':{'statuses':dict(statuses['task_units']),**counts['task_units']},'http':{str(k):v for k,v in httpcounts.items()},'model_generations':sum(bool(read(R/'run/completed'/f"{r['id']}.json")['trace']['completion_attempted']) for r in requests),'observed_peak_native_operations':peak,'only_output_contract_changed':True,'original_closed_prefill_and_model_parameters_preserved':True,'frozen_task_parser_used':True,'baseline_original_strict_selections_read_from_bound_receipts':True,'raw_output_unchanged':True,'all_192_complete_receipts':True,'new_selected_units_requiring_review':sum(x['new_selected_unit'] for x in worksheets),'selected_unit_instances_for_review':len({(x['request_id'],x['unit_id']) for x in worksheets}),'selected_distinct_source_spans_for_review':len({(x['case_id'],x['source_id'],x['unit']['start'],x['unit']['end']) for x in worksheets}),'semantic_quality_verified':False,'writer_invoked':False,'retrieval_invoked':False,'plan_sha256':runner.PLAN_SHA,'runner_sha256':sha(R/'run_replay.py'),'run_files_sha256':sha(R/'run/FILES.json'),'worksheet_sha256':sha(R/'selected-unit-review.jsonl')}
with (R/'INDEPENDENT-AUDIT.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps(report,indent=2))
