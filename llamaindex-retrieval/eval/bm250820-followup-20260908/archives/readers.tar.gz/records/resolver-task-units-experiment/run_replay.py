"""Single-variable resolver replay, using frozen client/parser and fsynced receipts."""
from __future__ import annotations

import argparse
import asyncio
import base64
import collections
import contextvars
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
from types import SimpleNamespace
from datetime import datetime, timezone

PLAN_SHA = "04b3c45598ac71c88e9b79bfdb2e1b7e0fc0136033ba496f1c126b2d4ebc8e4c"
SLOT = contextvars.ContextVar("resolver_replay_slot")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2).encode() + b"\n"


def now():
    return datetime.now(timezone.utc).isoformat()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(encoded(value))
        stream.flush()
        os.fsync(stream.fileno())
    descriptor = os.open(path.parent, os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def load_modules(root):
    path = root / "frozen/native_rwkv.py"
    spec = importlib.util.spec_from_file_location("frozen_replay_native", path)
    native = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = native
    spec.loader.exec_module(native)
    path = root / "frozen/task_contract.py"
    spec = importlib.util.spec_from_file_location("frozen_task_contract", path)
    contract = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(contract)
    return native, contract.parse_task_selections, contract.task_resolver_prompt


def preflight(root):
    assert sha((root / "PLAN.json").read_bytes()) == PLAN_SHA
    plan = json.loads((root / "PLAN.json").read_bytes())
    for name, record in plan["bindings"].items():
        raw = (root / name).read_bytes()
        assert len(raw) == record["bytes"] and sha(raw) == record["sha256"], name
    requests = json.loads((root / "requests.json").read_bytes())
    assert len(requests) == 192 and len({item["id"] for item in requests}) == 192
    native, parse, build = load_modules(root)
    checks = []
    for item in requests:
        old = json.loads((root / item["baseline_completed"]).read_bytes())
        trace = old["trace"]
        assert item["baseline_messages"] == trace["messages"]
        assert item["baseline_parameters"] == trace["parameters"]
        assert item["baseline_prompt"] == trace["prompt"]
        assert len(item["messages"]) == 1 and item["messages"][0]["role"] == "user"
        assert item["kwargs"]["evidence_ids"] == trace["evidence_ids"] == [item["source_id"]]
        assert item["kwargs"]["assistant_prefill"] == trace["prefill"] == "<think></think"
        assert item["kwargs"]["stage"] == trace["stage"] == "resolver"
        for key in ("max_tokens", "temperature", "top_p", "top_k", "presence_penalty", "frequency_penalty"):
            assert item["kwargs"][key] == trace["parameters"][key]
        assert ("seed" in item["kwargs"]) == ("seed" in trace["parameters"])
        if "seed" in item["kwargs"]:
            assert item["kwargs"]["seed"] == trace["parameters"]["seed"]
        rendered_old = native.render_native_prompt(trace["messages"], trace["prefill"])
        rendered_new = native.render_native_prompt(item["messages"], item["kwargs"]["assistant_prefill"])
        assert rendered_old.prompt == trace["prompt"]
        assert rendered_new.delimiter_escape == rendered_old.delimiter_escape
        prompt = trace["messages"][0]["content"]
        fields = json.loads(prompt.split("\n字段：", 1)[1].split("\n来源：", 1)[0])
        units = json.loads(prompt.rsplit("\n原文：", 1)[1])
        assert fields == item["fields"]
        assert list(fields) == [f"f{i}" for i in range(1, len(fields) + 1)]
        assert list(units) == [unit["id"] for unit in item["units"]]
        for unit in item["units"]:
            assert sha(units[unit["id"]].encode()) == unit["sha256"]
        task = prompt.split("\n任务：", 1)[1].split("\n字段：", 1)[0]
        contexts = json.loads(prompt.split("\n原文父级上下文：", 1)[1].split("\n原文：", 1)[0])
        assert contexts == item["source"]["metadata"].get("context_spans", [])
        source = SimpleNamespace(**{**item["source"], "metadata": {
            **item["source"]["metadata"], "context_spans": contexts}})
        expected = build(task, list(fields.values()), source,
                         [SimpleNamespace(text=units[u["id"]]) for u in item["units"]])
        assert item["task"] == task
        assert item["messages"] == [{"role": "user", "content": expected}]
        assert expected.split("\n来源：", 1)[1] == prompt.split("\n来源：", 1)[1]
        checks.append({"id": item["id"], "contract_only": True,
                       "unchanged_parameters": True, "fields": len(fields), "units": len(units),
                       "candidate_prompt_sha256": sha(rendered_new.prompt.encode())})
    assert parse("E1,E2", 2) == [1, 2]
    assert parse("NONE", 1) == []
    for invalid in ("E1,E2", "f1: E1", "E1;NONE", "E1 explanation", "", "E0"):
        try:
            parse(invalid, 1)
        except ValueError:
            pass
        else:
            raise AssertionError("task parser accepted invalid output")
    return plan, requests, native, parse, checks


async def execute(root, plan, requests, native, parse, checks):
    output = root / "run"
    output.mkdir(exist_ok=False)
    if not (root / "GPU-RELEASE.json").is_file():
        raise ValueError("explicit prior job completion/release receipt required")
    bindings = {"plan_sha256": PLAN_SHA, "runner_sha256": sha(Path(__file__).read_bytes()),
                "gpu_release_sha256": sha((root / "GPU-RELEASE.json").read_bytes())}
    save(output / "MANIFEST.json", {"started_at": now(), **bindings, "calls": 192,
         "run_parameters": {key: plan[key] for key in ("base_url", "model", "timeout_seconds",
             "context_window_tokens", "native_concurrency", "automatic_retries")},
         "preflight": checks, "inference_inputs": "Original frozen requests only; no question gold or semantic review is included or loaded."})

    class RecordedClient(native.NativeRWKVClient):
        async def _post(self, url, payload, stage, trace):
            slot = SLOT.get()
            save(output / "http" / f"{slot}.{stage}.started.json",
                 {**bindings, "id": slot, "stage": stage, "url": url,
                  "payload": payload, "started_at": now()})
            try:
                return await super()._post(url, payload, stage, trace)
            finally:
                save(output / "http" / f"{slot}.{stage}.completed.json",
                     {**bindings, "id": slot, "completed_at": now(),
                      "trace": copy.deepcopy(trace["http"][-1])})

    client = RecordedClient(base_url=plan["base_url"], model=plan["model"],
                            timeout_seconds=plan["timeout_seconds"],
                            context_window_tokens=plan["context_window_tokens"],
                            max_concurrency=plan["native_concurrency"])
    active = 0
    peak = 0
    started = time.perf_counter()

    async def one(item, check):
        nonlocal active, peak
        token = SLOT.set(item["id"])
        trace = {}
        begin = time.perf_counter()
        save(output / "started" / f"{item['id']}.json",
             {**bindings, "id": item["id"], "source_id": item["source_id"],
              "messages": item["messages"], "kwargs": item["kwargs"], "started_at": now()})
        active += 1
        peak = max(peak, active)
        receipt = {**bindings, "id": item["id"], "source_id": item["source_id"],
                   "baseline_rank": item["baseline_rank"], "case_id": item["case_id"]}
        try:
            result = await client.complete(item["messages"], trace=trace, **item["kwargs"])
            receipt.update(status=result.status, raw_text=result.raw_text, finish_reason=result.finish_reason)
            assert trace["messages"] == item["messages"]
            assert trace["parameters"] == item["baseline_parameters"]
            assert trace["prompt_sha256"] == check["candidate_prompt_sha256"]
            for http in trace["http"]:
                request = base64.b64decode(http["request_body_base64"])
                assert sha(request) == http["request_body_sha256"]
                assert json.loads(request) == http["payload"]
                if "response_body_base64" in http:
                    assert sha(base64.b64decode(http["response_body_base64"])) == http["response_body_sha256"]
            receipt["wire_input_audit"] = "PASS"
            try:
                if result.status != "completed":
                    raise ValueError(f"model stage did not complete: {result.status}")
                bounds = native.inspect_envelope(result.raw_text, item["kwargs"]["assistant_prefill"])
                if bounds is None:
                    raise ValueError("missing closed thinking envelope")
                body = result.raw_text[bounds[0]:bounds[1]].strip()
                receipt["selected_units"] = [f"E{unit}" for unit in parse(body, check["units"])]
                receipt["field_coverage_assessed"] = False
                receipt["protocol_valid"] = True
            except (ValueError, TypeError) as error:
                receipt.update(protocol_valid=False, parse_error=str(error))
        except BaseException as error:
            receipt.update(exception_type=type(error).__name__, exception=str(error))
            if isinstance(error, asyncio.CancelledError):
                raise
        finally:
            active -= 1
            receipt.update(trace=trace, elapsed_ms=(time.perf_counter() - begin) * 1000, completed_at=now())
            save(output / "completed" / f"{item['id']}.json", receipt)
            SLOT.reset(token)
        return receipt

    semaphore = asyncio.Semaphore(plan["native_concurrency"])

    async def limited(item, check):
        async with semaphore:
            return await one(item, check)

    try:
        receipts = await asyncio.gather(*(limited(item, check) for item, check in zip(requests, checks)))
    finally:
        await client.aclose()
    summary = {**bindings, "completed_at": now(), "original_denominator": 192,
               "receipts": len(receipts), "statuses": dict(collections.Counter(r.get("status", "exception") for r in receipts)),
               "protocol_valid": sum(r.get("protocol_valid") is True for r in receipts),
               "generation_attempts": sum(r["trace"].get("completion_attempted") is True for r in receipts),
               "http_requests": sum(len(r["trace"].get("http", [])) for r in receipts),
               "actual_peak_active_calls": peak, "elapsed_seconds": time.perf_counter() - started,
               "semantic_quality_reviewed": False, "end_to_end_quality_claim": False}
    save(output / "SUMMARY.json", summary)
    hashes = {str(path.relative_to(output)): {"bytes": path.stat().st_size, "sha256": sha(path.read_bytes())}
              for path in sorted(output.rglob("*")) if path.is_file()}
    save(output / "FILES.json", hashes)
    print(json.dumps(summary), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--run", action="store_true")
    args = parser.parse_args()
    plan, requests, native, strict_parser, checks = preflight(args.root)
    if args.run:
        asyncio.run(execute(args.root, plan, requests, native, strict_parser, checks))
    else:
        print(json.dumps({"status": "PASS", "plan_sha256": PLAN_SHA,
                          "calls": len(checks), "checks": checks}), flush=True)


if __name__ == "__main__":
    main()
