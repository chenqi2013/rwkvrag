from pathlib import Path
import os,json,hashlib,tarfile,datetime,subprocess,urllib.request,base64,re
B=Path('/home/chase/rwkvrag-bm-rebuild-20260908');R=B/'resolver-task-units-experiment'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
R.mkdir()
with tarfile.open(B/'resolver-task-units-inputs.tar.gz') as t:t.extractall(R,filter='data')
freeze=json.loads((R/'PRE-RUN-FREEZE.json').read_text())
assert hashlib.sha256((R/'PRE-RUN-FREEZE.json').read_bytes()).hexdigest()=='f75efe23cbf1ab1ff4179b24c55f51707ff209139e35fa45f10b15771aef5a63'
for rel,v in freeze['files'].items():
 d=(R/rel).read_bytes();assert len(d)==v['bytes'] and hashlib.sha256(d).hexdigest()==v['sha256'],rel
save(R/'TRANSFER-VERIFIED.json',{'at':now(),'files':len(freeze['files']),'all_local_remote_bytes_identical':True,'freeze_sha256':hashlib.sha256((R/'PRE-RUN-FREEZE.json').read_bytes()).hexdigest()})
py=B/'source-wiki-v3/.venv/bin/python';cmd=[str(py),str(R/'run_replay.py'),'--root',str(R)]
p=subprocess.run(cmd,cwd=R,capture_output=True,text=True)
save(R/'PREFLIGHT-SERVER.json',{'at':now(),'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'command':cmd})
if p.returncode:raise SystemExit(p.returncode)
with urllib.request.urlopen('http://127.0.0.1:18421/metrics',timeout=30) as h:raw=h.read();status=h.status
running=[];waiting=[]
for line in raw.decode().splitlines():
 if line.startswith('vllm:num_requests_running'):running.append(float(line.rsplit(' ',1)[1]))
 if line.startswith('vllm:num_requests_waiting'):waiting.append(float(line.rsplit(' ',1)[1]))
release={'at':now(),'http_status':status,'metrics_body_base64':base64.b64encode(raw).decode(),'metrics_body_sha256':hashlib.sha256(raw).hexdigest(),'running':running,'waiting':waiting,'root_authorization':'192 original Wiki-v2 resolver source data, only task-unit output contract versus closed-prefill baseline; zero retry; independent GPU batch','prior_task_completed':'shared-tasks planner 8 complete 2026-09-08T10:19:43Z, confirmed by owner'}
save(R/'GPU-RELEASE.json',release)
assert running and waiting and all(v==0 for v in running+waiting),'model engine not idle'
unit='rwkvrag-bm250820-resolver-task-units-20260908'
state=subprocess.run(['systemctl','--user','show',unit+'.service','-p','LoadState','--value'],capture_output=True,text=True)
assert state.stdout.strip() in {'','not-found'}
command=['systemd-run','--user','--unit',unit,'--property=Restart=no','--property=StandardOutput=append:'+str(R/'run.log'),'--property=StandardError=append:'+str(R/'run.log'),'--working-directory='+str(R)]+cmd+['--run']
save(R/'LAUNCH-INTENT.json',{'at':now(),'command':command,'runner_sha256':freeze['runner_sha256'],'plan_sha256':freeze['plan_sha256'],'retries':0})
p=subprocess.run(command,capture_output=True,text=True)
save(R/'LAUNCH-RESULT.json',{'at':now(),'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
print(json.dumps({'transfer':'PASS','preflight':'PASS','model_idle_before_launch':True,'returncode':p.returncode,'stderr':p.stderr}),flush=True)
raise SystemExit(p.returncode)
