from pathlib import Path
import json,ast,hashlib,itertools
B=Path(__file__).resolve().parent.parent
original=B/'resolver-task-units-experiment/audit_coverage.py'
tree=ast.parse(original.read_text());scope={'hashlib':hashlib}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'segments','cover'}],type_ignores=[]),'frozen-gold-coverage-functions','exec'),scope)
fixtures=[json.loads(l) for l in (B/'wiki-smoke-v3/frozen/fixtures.jsonl').read_text().splitlines()]
rows=[]
for fixture in fixtures:
 p=B/'wiki-smoke-v3/completed'/f"{fixture['id']}.json";row=json.loads(p.read_text());retrieval=row['response']['retrieval'];candidates=retrieval['candidates'];byid={s['id']:s for s in candidates};fair=[];seen=set()
 for positions in itertools.zip_longest(*retrieval['query_results']):
  for identity in positions:
   if identity is not None and identity not in seen:seen.add(identity);fair.append(byid[identity])
 assert set(byid)=={s['id'] for s in fair}
 modes={}
 for name,sources in [('rrf',candidates),('query_round_robin',fair)]:
  modes[name]={}
  for budget in [12,24,48,80,160,len(sources)]:
   segs=[]
   for source in sources[:budget]:
    unit={'start':0,'end':len(source['snippet']),'sha256':hashlib.sha256(source['snippet'].encode()).hexdigest()};segs.extend(scope['segments']({'source':source},unit))
   facts=fixture['oracle']['required_facts'];found=[f['id'] for f in facts if any(all(scope['cover'](ref,segs) for ref in refs) for refs in f['evidence_sets'])]
   modes[name][str(budget)]={'covered':found,'missing':[f['id'] for f in facts if f['id'] not in found]}
 rows.append({'id':fixture['id'],'original_run_receipt_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'candidate_count':len(candidates),'query_count':len(retrieval['query_results']),'queries':retrieval['plan']['queries'],'coverage':modes,'round_robin_order':[s['id'] for s in fair]})
totals={mode:{str(n):sum(len(row['coverage'][mode][str(n)]['covered']) for row in rows) for n in [12,24,48,80,160]} for mode in ['rrf','query_round_robin']}
out={'kind':'offline scheduling diagnostic on exposed development suite, no model calls or old score changes','original_fact_count':29,'no_per_document_limit':True,'all_candidate_identities_preserved':True,'coverage_kind':'complete frozen gold AND/OR quote identity+span coverage, not semantic QA','totals':totals,'rows':rows}
p=B/'candidate-scheduling-diagnostic/RESULTS.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(totals,ensure_ascii=False))
